#!/usr/bin/env python3
"""Launch MITMPro (the unified AI-assisted security assessment platform).

Usage:
    python3 run.py
    python3 -m mitmpro.main        # equivalent

All AI runs locally via Ollama (http://127.0.0.1:11434). Start Ollama first:
    ollama serve
    ollama pull llama3.2:1b
"""
import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from mitmpro.main import main

if __name__ == "__main__":
    main()
