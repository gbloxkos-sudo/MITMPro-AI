# MITMPro — Pro User Guide (v2.0)

**Unified AI-Assisted Security Assessment Platform**
Local-first · Ollama-powered · 21 modules

> **Scope note:** This guide covers the full application, every module, the natural‑language automation engine, and a complete **App Commands** reference (the underlying CLI binaries and exact command templates MITMPro drives). For authorized security testing only.

---

## 1. What MITMPro is

MITMPro is a single desktop application (Python + Tkinter) that bundles AI‑assisted
recon, scanning, traffic interception, WAF bypass, phishing/campaign tooling, and
orchestration behind one GUI. All AI inference runs **locally** through
[Ollama](https://ollama.com); nothing about your prompts or targets leaves the
machine unless you explicitly toggle **Internet: ON** in the toolbar.

### 1.1 Modules at a glance (sidebar)

| Key | Label | Category |
|-----|-------|----------|
| dashboard | Dashboard | Home |
| ai | AI Assistant (Ollama) | AI |
| traffic | AI Traffic Analyst | AI |
| helper | AI Helper | AI |
| burp | Burp Tools | Scanner |
| websploit | WebSploit | Scanner |
| proxy | Proxy Tools | Intercept |
| waf | WAF/Bypass | Evasion |
| phish | Website Masquerading | Phishing |
| dlp | Inline DLP Proxy | Intercept |
| network | Network Attacks | MITM/L2 |
| sslstrip | SSL Strip / MITM | MITM/L2 |
| campaigns | Campaign Manager | Phishing |
| email | Email Engineer | Phishing |
| history | HTTP History | Traffic |
| oast | OAST / DNS | Out-of-band |
| macro | Macro / Flow | Workflow |
| scope | Scope | Config |
| analysis | Analysis | Diagnostics |
| nsniffer | Nsniffer Toolkit | Recon |
| autorun | AI Auto-Run | Orchestration |

The sidebar is **scrollable** and has a **live search box** at the top — type any
substring (e.g. `ssl`, `phish`, `arp`) to filter the module list. Scroll with the
mouse wheel while the pointer is over the sidebar.

---

## 2. Requirements

| Component | Minimum |
|-----------|----------|
| OS | Linux (primary), macOS, Windows 10+ |
| Python | 3.10+ (developed on 3.11/3.13) |
| RAM | 4 GB (8 GB+ recommended for local models) |
| Disk | ~2 GB for app + models |
| Ollama | Required for **all** AI features (local) |
| Root/sudo | Only for Network Attacks (ARP/DNS spoof, raw sniff) and optional transparent proxy modes |
| Display | Required (the app is a GUI) |

### 2.1 Python dependencies
`requests`, `urllib3`, `beautifulsoup4`, `lxml`, `psutil`, `flask`, `cryptography`,
`PyYAML` (plus `scapy`/`netifaces` for the network modules). Install from the
project root (`MITM_PRO_AI/`):

```bash
pip install -r requirements.txt
```

### 2.2 AI engine
```bash
# Linux/macOS — start the local model server (one terminal, leave running)
ollama serve

# Pull at least one model (small/fast first, then a security-tuned one)
ollama pull llama3.2:1b
ollama pull huihui_ai/qwen3-abliterated:4b      # optional, stronger
# community pentest models if available:
ollama pull xploiter/pentester
ollama pull xploiter/bugbounty-ai
```

### 2.3 Optional external tools (used by specific modules)
These are launched by MITMPro automatically when present on `PATH`:

| Tool | Used by | Purpose |
|------|---------|---------|
| `bettercap` | Network Attacks | ARP/DNS spoof, live caplets |
| `nmap` | Network Attacks, Nsniffer | Host/port discovery |
| `mitmdump` / `mitmproxy` | SSL Strip / MITM | HTTPS downgrade, traffic modification |
| `dig`, `whois` | Nsniffer / Passive recon | DNS & ownership enumeration |
| `sysctl` | Network Attacks | IP forwarding toggle |
| `manage-proxy.sh` | Inline DLP | External DLP proxy lifecycle |
| `nsniffer` | Nsniffer Toolkit | External recon toolkit |
| `xdg-open` / `open` | DLP, editors | Open rules/logs in default app |

---

## 3. Installation & Launch

From the project root `MITM_PRO_AI/`:

```bash
# 1) (Optional) create & activate a virtualenv
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2) install deps
pip install -r requirements.txt

# 3) make sure Ollama is up (see §2.2)
ollama serve &

# 4) launch MITMPro (either command works)
python3 run.py
# or:
python3 -m mitmpro.main
```

The window opens with a branded header, the global **Ollama Model** selector +
**Refresh Models** + **Ollama health** indicator in the toolbar, a left **module
sidebar** (with search), the active module in the centre, a persistent **AI Help**
dock on the right, and a live status bar at the bottom.

> If you already have a `venv`, activate it first. If a dependency is missing you
> will see `ImportError: No module named X` — run `pip install X`.

---

## 4. Choosing the AI Model (whole-system)

The toolbar **Ollama Model** dropdown is the single source of truth for the entire
app. Selecting a model there updates in real time:

- the embedded **AI Assistant** chat,
- the **AI Helper** tab,
- the **AI Traffic Analyst**,
- **WAF/Bypass → Explain with AI**,
- the **Email Engineer → AI Generate**,
- the **Campaign Manager → Generate AI Report**,
- the **AI Auto-Run** planner, and
- the persistent **AI Help** dock (visible on every module).

Click **Refresh Models** to re-read the list from the running Ollama service. The
status bar always shows the active model and Ollama health (green dot = running,
red = offline). You may also pick a model directly inside any AI panel; all stay in
sync via a shared model listener.

### 4.1 The MITMPro-AI engine (`mitmpro/ai_core.py`)
- **One selector drives everything** (see above).
- **Self-healing:** if the chosen model is unavailable or Ollama hiccups, it retries
  and falls back to any other local model; if Ollama is fully offline it returns a
  clear, grounded message instead of crashing.
- **Anti-hallucination:** answers are grounded in real MITMPro tool documentation;
  the model is told only to describe tools that actually exist and to state
  confidence (High/Medium/Low). A verification pass flags any claim referencing a
  non-existent tool.
- **Self-learning:** verified Q&A pairs persist locally
  (`~/.mitmpro/memory.jsonl`) and are reused for consistency.
- **Self-aware system context:** the engine is injected with live system context —
  OS, hardware, interfaces, installed tools (nmap, curl, mitmproxy, frida,
  sqlmap…), running Ollama models, current Scope, captured HTTP history, and the
  active module — so advice matches what the host can actually do.
- **RAG:** before answering it retrieves the most relevant passages from the
  MITMPro docs, source code, and bundled READMEs (offline BM25 index cached at
  `~/.mitmpro/rag_index.json`).
- **Internet research (opt-in):** the toolbar **Internet: OFF/ON** button enables
  live verification. When ON, the assistant may emit `<<WEB: <query>>` or
  `<<FETCH: <url>>`; the engine fetches the live result and continues the answer.
  This is the **only** traffic that leaves the machine, and only on demand; AI
  inference always stays local.

---

## 5. Layout

```
+----------------------------------------------------------------------+
| Header: MITMPro · v2.0 · Unified AI-Assisted Security Platform        |
+----------------------------------------------------------------------+
| Toolbar: Ollama Model [v] Refresh  Ollama:RUNNING  Internet:OFF  ... |
+--------------+-------------------------------------------+--------------+
| MODULES      |  Active module (centre, scrollable)    | AI Help dock |
| [Search box] |                                           | (always on)  |
|  Dashboard   |                                           |              |
|  AI Assistant|                                           |              |
|  ... (scroll)|                                           |              |
+--------------+-------------------------------------------+--------------+
| Status bar: ● Ollama status | module | model: <name>                   |
+----------------------------------------------------------------------+
```

### 5.1 Universal copy/paste & right-click menu
Every text surface (chat, request/response boxes, logs, console, entries,
comboboxes, listboxes, result tables) supports a right-click menu: **Cut**,
**Copy**, **Paste**, **Select All**. Read-only widgets show Copy / Select All.
Treeviews copy selected row(s) as tab-separated values. Shortcuts:
`Ctrl+C` / `Ctrl+Insert` (copy), `Ctrl+X` (cut), `Ctrl+V` (paste).

---

## 6. Module Reference

### 6.1 Dashboard
Landing tab. Shows AI‑engine health, live stats (HTTP requests, vulns found, AI
queries, active modules), module‑health indicators (Ollama/Flask/BeautifulSoup/
requests), recent captured activity, a **Quick start** grid (one click jumps to any
module), a 3‑step "new here?" walkthrough, a rotating security tip, and a colour‑
coded **Threat radar** tally of patterns seen in captured traffic. A first‑run
onboarding tour pops up automatically (dismiss with *Skip*; delete
`~/.mitmpro_tour_done` to replay).

### 6.2 AI Assistant (Ollama)
Fully embedded Ollama chat client. Auto-detects local models; multi-turn streaming
chat with a **Stop** button; right-click a message to copy, double-click to edit.
A **Model Management** window (gear icon) downloads/deletes models from the running
Ollama host. **Open Standalone Ollama GUI** launches the bundled `ollama-gui-1.2.2`.
All responses are local — no cloud, no telemetry.

### 6.3 AI Traffic Analyst
Paste a raw HTTP request (and optional response), pick an action
(*Explain request/response*, *Find vulnerabilities*, *Suggest exploit / bypass
payload*); the local AI analyses it for OWASP Top 10 issues (SQLi, XSS, SSRF,
IDOR, access control, deserialization, XXE, SSTI, request smuggling) using the
exact lines/parameters, and proposes copy-paste-ready payloads. **Load a captured
request from HTTP History → Send to AI Analyst.**

### 6.4 Burp Tools
- **Repeater:** build/send raw HTTP requests (method, URL, headers, body); inspect
  the full response (status, headers, byte count, body).
- **Intruder:** fuzzing/brute force. Mark injection points with `§name§`. *Sniper*
  (one payload across all markers) or *Cluster bomb* (cartesian product). Load
  wordlists; results show `payload -> HTTP status (size)`.
- **Decoder:** Base64 / URL / HTML / Hex / ASCII-HEX encode & decode.
- **Comparer:** unified diff between two text blobs.
- **Sequencer:** per-position + overall entropy analysis of session tokens.
- **Scanner:** light passive/active checks for **Reflected XSS** and **SQL
  Injection** across discovered form/URL params (live requests to the target).

### 6.5 WebSploit
Live console into the WebSploit 4.0.4 toolkit. Pick a **Module**
(`arp_spoof`, `http_sniffer`, `scan_network`, `scan_wifi`, `wifi_deauth`,
`wifi_fap`, `wifi_fap_spam`). **Use & Launch** starts it in an interactive console
(`help`, `options`, `set`, `run`); **Stop** terminates it. Network modules require
root and a real interface.

### 6.6 Proxy Tools
Launches bundled MITM interception scripts in an interactive console:
- **mitm_intercept.py** — SSL interception relay (TCP/UDP, mixed TLS). Example
  args: `-l 0.0.0.0:8080 -t 127.0.0.1:80 -lc cert.pem -lk key.pem`
- **DatajackProxy.py** — Frida-based MITM of a running process
  (Linux/Windows); requires `frida`/`frida-tools`.
The **extra args** box is pre-filled with a template; click it to edit.

### 6.7 WAF/Bypass (Advanced WAF & Security Bypass Engine)
Generates a large set of **real** evasion variants for a payload:
- **Category:** SQLi, XSS, Path Traversal, Command Injection, SSRF.
- **Base Payload** + **Generate** → encoding/obfuscation variants: URL
  (single/double/nested), HTML entity, Unicode, UTF‑8 overlong, Base64, Hex,
  MySQL `CHAR()`, PostgreSQL `CHR()`, MSSQL `NCHAR()`, case randomization, inline
  comments (`/**/`, `/*!*/`, `--`, `#`, `;`), null-byte, plus category tricks
  (`0x7f000001` for `127.0.0.1`, `....//` for `../`).
- **Test Bypass** sends each variant to the **Test URL** and flags responses whose
  status/size/block-signature differ from the baseline; also sends spoofed headers
  (`X-Forwarded-For`, `X-Original-URL`, …).
- **Explain with AI** uses the active model to pick the best variant(s).
- **Save** writes the variant list for use in Intruder.

### 6.8 Website Masquerading (Phishing)
Adversary-in-the-Middle phishing engine. Runs a Flask reverse-proxy **Mirror** of a
target (rewrites all links/forms so victims' credentials + cookies are captured to
`output/`), or serves static cloned **Templates**.
- **Target Site** + **Deploy Mirror** (MODE=MIRROR).
- **Local Port** (default `8080`) + **Start Engine** launches the Flask server on
  `0.0.0.0:<port>`.
- **Validate Creds** replays captured creds via POST to `<target>/login` to mark them
  VERIFIED. **Clear Captures** wipes the table (auto-refreshes every 3 s).
- **Template Gallery** tab lists local templates under `mitm_tools/templates/*`;
  **Deploy Selected Template** serves them in TEMPLATE mode.
A `before_request` filter blocks bots (`nmap`, `sqlmap`, `masscan`, `zgrab`,
`googlebot`, …) returning 404.

### 6.9 Inline DLP Proxy
Front-end for the external **inline-dlp-proxy** tool. Buttons:
**Start / Stop / Restart / Status** (drive `manage-proxy.sh`),
**Edit Rules** (opens `rules/dlp_patterns.json`), **View Alerts** (reads
`logs/dlp_alerts.log`). Info bar shows Admin `http://localhost:9901` and Dashboard
`http://localhost:3000`.

### 6.10 Network Attacks (L2/L3 MITM) — **requires Linux + root**
Four tabs:
- **ARP Spoof:** Target IP, Gateway IP, Interface; **Start ARP Spoof** / **Stop** /
  **Restore Targets**; checkboxes *Full duplex* and *Enable IP forwarding*.
- **DNS Spoof:** Spoof IP (attacker), Domain (blank = all), Interface; **Start DNS
  Spoof** / **Stop**.
- **Discovery:** Target (e.g. `192.168.1.0/24`), Method (`arp`/`icmp`/`tcp`/`nmap`);
  **Scan** / **Clear**.
- **Sniffer:** Interface, BPF Filter, Count; **Start Capture** / **Stop** / **Clear**.
Uses `bettercap` (primary) or `scapy` (fallback). The app refuses to run ARP/DNS
spoof, arp/icmp scans, or raw sniff unless `os.geteuid() == 0`.

### 6.11 SSL Strip / MITM
HTTPS downgrade + credential/cookie capture + live traffic modification via
`mitmdump`/`mitmproxy` addons.
- **SSL Strip:** Listen Port (`8080`), Upstream Proxy, Mode (`sslstrip`/`reverse`/
  `transparent`); checkboxes *Strip HSTS / Inject cookies / Follow redirects*;
  **Start SSL Strip** / **Stop** / **Open mitmproxy UI**.
- **Modify Traffic:** URL Pattern (regex), Action (`add_header`/`remove_header`/
  `replace_body`/`redirect`/`drop_request`), Value; **Add Rule** / **Clear Rules** /
  **Start Modifier** / **Stop**.
- **Cookies:** Name/Value; **Add Cookie** / **Load from JSON** / **Clear All** /
  **Export**.
Generated addon scripts are written to `output/` (`_sslstrip_addon.py`,
`_cookie_inject_addon.py`, `_traffic_modifier_addon.py`) and capture creds/cookies
to `output/credentials.json` / `output/all_captures.txt`.

### 6.12 Campaign Manager (GoPhish-style)
- **Create Campaign:** name, description, Landing Page (`mirror`/`template`), Target
  URL, Email Template (built-ins), SMTP Server/Port (default `587`)/User/Pass/From,
  TLS; **Create Campaign**, **Import Targets (CSV)**, **Add Target Manually**.
- **Active Campaigns:** tree; **Launch Selected** / **Stop Selected** / **View
  Report** / **Export Report** / **Refresh**.
- **Reports:** **Generate AI Report** (via `ai_core.stream_chat`) / **Export JSON**.
Sends via Python `smtplib` (`SMTP_SSL` on 465, otherwise `SMTP`+`starttls`).

### 6.13 Email Engineer (SET-style)
- **Template Editor:** built-in + custom templates (`credential_harvest`,
  `sharepoint_invite`, `password_reset`, `invoice_attach`, `wifi_portal`); Subject,
  From Name; **Load / Save Custom / Delete Custom / Preview / AI Generate** (expects
  JSON `{"subject","from_name","body","html_body"}`).
- **Preview & Send:** SMTP server/port/user/pass/from, TLS; variable fields
  (`{target_name}`,`{target_email}`,`{company_name}`,`{phish_link}`,`{sender_name}`,
  `{doc_name}`,`{invoice_num}`,`{due_date}`); **Send Test Email** / **Preview Rendered**.
- **Template Library:** **Refresh** / **Export Selected**.

### 6.14 AI Helper
Context-aware assistant with full product knowledge. **Context** selects the module
(auto-filled by **Use Current Tab**). Ask how to use a tool, request payloads, or
explain findings. **Assessment Checklist** generates a phased methodology
(recon → enumeration → exploitation → validation → reporting) for the selected
module. Uses the same global model.

### 6.15 HTTP History
Live log of every real HTTP request the suite sends (Repeater, Intruder, Scanner,
Macro, Auto-Run). Columns: #, Method, Status, Host, Path, Size. Double-click to
view full request/response. **Filter** by URL substring. **Send to Repeater** /
**Send to AI Analyst** / **Clear**.

### 6.16 OAST / DNS (Out-of-Band)
Local HTTP listener (default port `8888`) capturing out-of-band callbacks — proves
blind SSRF, Blind XSS, XXE exfiltration, etc.
- **Generate Payload** creates a callback URL using the machine's reachable LAN IP.
- **Copy Headers** copies collaborator-style headers (`X-Forwarded-For`,
  `True-Client-IP`, `X-Original-URL`, `Referer`) pre-filled with the callback URL.
Use bind `0.0.0.0` (instead of `127.0.0.1`) if the target is on another host.

### 6.17 Macro / Flow
Builds multi-step request chains (e.g. login → fetch CSRF token → authenticated
action). Each step: Method, URL, optional **Extract regex** capturing a value from
the response into `{{extract}}` for later steps, and a Body. Save/Load sequences as
JSON. Runs requests in order, substituting `{{var}}` placeholders. Sends via
`requests.request(method, url, data=body, timeout=20, verify=False)`.

### 6.18 Scope
Add hostnames you are authorized to test. When Scope is non-empty, tools should stay
inside it (empty scope = all targets allowed). Add/Remove from the list.

### 6.19 Analysis
On open, scans every project folder and reports presence, file/Python counts, and
size per folder; dependency availability (`requests`, `scapy`, `netifaces`,
`psutil`, `beautifulsoup4`, `lxml`, `tkinter`); and Ollama status + running models.
Use as a pre-engagement health check.

### 6.20 Nsniffer Toolkit
UI wrapper launching the external `Nsniffer-1.1.0` toolkit. **Command** combobox
(`scan`/`capture`/`analyze`/`mitm`/`arp`/`list`/`extract`/`log`/`setup`),
**Args** (default `-i eth0`), **Run** / **Clear**. Resolves the tool via
`common._find_tool_dir("Nsniffer-1.1.0")`; if not executable it prints a `chmod +x`
hint. Also imports `PassiveScanner` from `pnis_scanner` (DNS/SSL/WHOIS/subdomain/
tech/port recon via `dig`, `whois`, and sockets).

### 6.21 AI Auto-Run (Orchestration)
Natural-language goal → AI plan → live execution. Four tabs:
- **AI Auto-Run:** pick a model, use example-goal chips, type a goal in plain
  English (e.g. *"Scan example.com for XSS"*), **Execute AI Plan**. Controls:
  **Stop / Pause / Resume / Skip**; progress bar; colour-coded step tree; error
  details; execution log. **Load/Save Template/Plan** (JSON).
- **Manual Plan:** Tool combobox (17 registered tools), Action (dependent on tool),
  Params JSON, On Error (`skip`/`retry`/`abort`); **Add Step** / **Clear All** /
  **Execute Plan**.
- **History:** past plans + detail viewer.

See §7 for the planning engine and mini-language.

---

## 7. AI Auto-Run — how the orchestration works

`autorun_engine.py` turns a goal into an executable **plan** and runs it by driving
the real panels (pre-populating their widgets, then calling the underlying methods).

- **Tool registry:** 17 tools ( `burp`, `waf`, `masquerading`, `nsniffer`, `dlp`,
  `proxy`, `scope`, `ai_traffic`, `network`, `sslstrip`, `campaigns`, `email`,
  `websploit`, `oast`, `macro`, `history` ) each with concrete actions mapped to
  real panel methods.
- **Resolution:** names are normalized and matched by exact → alias → substring →
  fuzzy (`difflib`, cutoff 0.6). Aliases: `phishing→masquerading`,
  `arpspoof→start_arp_spoof`, etc. `masquerading→phish` and `ai_traffic→traffic`
  map to the actual `app.panels` keys.
- **Widget mapping:** step params are written into the matching panel widgets
  (e.g. `masquerading.url → url_entry`, `network.target_ip → arp_target`) before
  the method is invoked, so the GUI reflects exactly what ran.
- **Planning:** system prompt — *"You are the MITMPro Orchestrator. Create a
  technical execution plan as a JSON list of actions … Respond ONLY with the JSON
  list."* Up to 3 AI attempts, then a **heuristic fallback** (keyword → template:
  `full web assess`, `xss`, `waf bypass`, `mitm/arp/strip`, `recon`, `phish/
  campaign/email`, `mirror/clone`, `network`). Plan JSON is repaired
  (`_loose_json_fix`: trailing commas, `//` comments, single-quoted keys/values,
  unquoted keys) and validated (drops unknown tools, defaults unknown actions,
  normalizes `on_error`).
- **Placeholders:** `TARGET_HOST`, `TARGET_SITE`, `TARGET_URL`, `TARGET_IP`,
  `GATEWAY_IP`, `LOCAL_IP`, `TARGET_CAMPAIGN`, `CAMPAIGN_ID` are filled from the
  goal text or templates.
- **Execution:** runs on the main Tk thread with a 30 s per-step timeout; supports
  conditional branching, `retry`/`skip`/`abort`, progress & step callbacks, and plan
  history (`~/.mitmpro/plan_history.json`).

### 7.1 Other mini-languages in MITMPro
- **Macro DSL:** step list of `method / URL / extract-regex / body`; `{{var}}`
  substitution pulls values captured from earlier responses via regex.
- **AI tool-instruction language** (`web.py`): when Internet is ON the model may
  emit `<<FETCH: https://…>>` → `fetch_url`, or `<<WEB: <query>>> → web search.
  This is the only egress path and is opt-in.
- **SSL-strip / traffic-modifier addon DSL:** rules of
  `add_header`/`remove_header`/`replace_body`/`redirect`/`drop_request` keyed by a
  URL regex, compiled into `mitmproxy` Python addons.

---

## 8. Full App Commands Reference

This is the consolidated list of **every external command MITMPro launches** (via
`subprocess`/`pty`) and the **exact templates** used. These are what power the
modules above; you can reproduce any action from a terminal.

### 8.1 Ollama (AI core)
```bash
ollama serve                                  # start local model server (http://127.0.0.1:11434)
ollama pull llama3.2:1b                      # small/fast model
ollama pull <model>                           # any local model
ollama list                                   # list installed models
```
MITMPro queries `http://127.0.0.1:11434/api/tags` to detect models and health.

### 8.2 Network Attacks (bettercap)
Bettercap binary: `bettercap` (or `/usr/bin/bettercap`). Caplets are written
temporarily and launched as:
```bash
bettercap -iface <iface> -caplet <caplet.cap>
```
ARP spoof caplet:
```
set arp.spoof.targets <target>
set arp.spoof.interface <iface>
arp.spoof on
active
```
ARP restore caplet: `set arp.spoof.targets <target>` / `arp.spoof off` / `quit`.
DNS spoof caplet:
```
set dns.spoof.address <spoof_ip>
set dns.spoof.interface <iface>
dns.spoof on [<domain>]
active
```
IP forwarding:
```bash
sysctl -w net.ipv4.ip_forward=1      # enable  (disable: =0)
```
Host/route discovery (used to auto-detect gateway/interface):
```bash
ip route show default                # Linux
route print 0.0.0.0                  # Windows
route -n get default                 # macOS
```

### 8.3 Network Attacks — discovery scans
```bash
nmap -sn <target>                    # ARP/ICMP host discovery
nmap -sT -p 80,443,22,21,25,53,8080 <target>   # TCP port scan
```
Fallback scans use `scapy` in-process (`srp(Ether/ARP(pdst=target))` for ARP,
`sr(IP(dst)/ICMP())` for ICMP).

### 8.4 SSL Strip / MITM (mitmproxy)
```bash
mitmdump -p <port> -s <addon>.py --set ssl_insecure=true
# + -s <inject_addon>.py                 (if inject cookies)
# + --mode upstream:<upstream>           (if upstream proxy set)
# + --set connection_strategy=lazy        (if follow redirects)
mitmproxy -p <port>                  # open interactive UI
```
`mitmdump`/`mitmproxy` resolve via `shutil.which` (fallback `~/.local/bin/...`).

### 8.5 Inline DLP Proxy
```bash
bash <mitm_tools>/inline-dlp-proxy-main/scripts/manage-proxy.sh start|stop|restart|status
xdg-open <rules_file>                # Linux  (open rules)
open <rules_file>                    # macOS
```
Alerts are read from `<tool>/logs/dlp_alerts.log`. Admin `http://localhost:9901`,
Dashboard `http://localhost:3000`.

### 8.6 Nsniffer Toolkit
```bash
<nsniffer> <cmd> <args>             # cmd ∈ scan|capture|analyze|mitm|arp|list|extract|log|setup
                                    # default args: -i eth0
```
Tool path resolved via `common._find_tool_dir("Nsniffer-1.1.0")`; must be
executable (`chmod +x` if not).

### 8.7 Passive recon (pnis_scanner / nsniffer)
```bash
dig +short <target> <rtype>         # rtype ∈ A AAAA MX NS TXT CNAME SOA
whois <target>                      # ownership (truncated to 5000 chars)
```
SSL analysis uses an in-process `ssl` socket on 443; subdomain discovery probes a
common-subdomain list via `socket.gethostbyname`; tech fingerprinting does a
`urllib.request` GET on `https://<target>`; port scan is a TCP `socket.connect_ex`
against `21,22,23,25,53,80,110,143,443,465,587,993,995,3306,3389,5432,8080,8443`.

### 8.8 WebSploit (console)
```bash
# launched inside an interactive PTY console; module + commands issued there:
use <module>        # e.g. use arp_spoof
options             # list settings
set <key> <val>
run                 # start
help / stop         # control
```
Modules: `arp_spoof`, `http_sniffer`, `scan_network`, `scan_wifi`, `wifi_deauth`,
`wifi_fap`, `wifi_fap_spam`.

### 8.9 Proxy Tools (console)
```bash
python3 mitm_intercept.py -l 0.0.0.0:8080 -t 127.0.0.1:80 -lc cert.pem -lk key.pem
python3 DatajackProxy.py <args>      # Frida-based process MITM (needs frida)
```

### 8.10 Email / Campaign delivery (smtplib, no CLI)
MITMPro sends via Python `smtplib` — `SMTP_SSL(host, 465)` when port is 465,
otherwise `SMTP(host, port)` + `starttls()` (port 587 common). No external binary.

### 8.11 Integrated console (console.py)
The **ConsoleWidget** runs any command in a real PTY (`pty.fork` + `os.execvpe` on
Linux/macOS; `os.kill(pid, 9)` to stop). Used by SSL Strip, Proxy Tools, and
WebSploit. You type directly into it as you would a terminal.

---

## 9. Troubleshooting

| Symptom | Fix |
|---------|-----|
| AI says "Ollama: OFFLINE" | Start `ollama serve`; click **Refresh Models** |
| No models in dropdown | `ollama pull llama3.2:1b` then **Refresh Models** |
| AI tab shows red error | Ensure `ollama-gui-1.2.2/ollama_gui.py` exists |
| Network Attacks won't start | Run the app as **root** (`sudo`); needs a real interface |
| ARP/DNS spoof blocked | App refuses unless `os.geteuid()==0` on Linux |
| Proxy arg errors | Click the args box and enter real arguments |
| `ImportError: No module named X` | `pip install X` (see §2.1) |
| SSL Strip won't start | Install `mitmproxy` (`pip install mitmproxy`) |
| DLP buttons do nothing | Ensure `inline-dlp-proxy` tool dir exists & `manage-proxy.sh` is executable |
| Nsniffer "not executable" | `chmod +x` the resolved `nsniffer` binary |
| Can't reach lower sidebar items | Scroll the sidebar with the mouse wheel, or type in the **Search** box to filter |
| Dashboard looks cramped | It is a 2-column responsive grid; scroll the centre panel if needed |

---

## 10. Legal & Responsible Use

MITMPro is built for **authorized security testing** — penetration tests, bug-bounty
programs, and red-team engagements on systems you own or have written permission to
test. ARP/DNS spoofing, SSL stripping, and phishing simulation must only be run on
networks and targets you are explicitly authorized to assess. Always obey applicable
law and scope agreements; document consent and stay within agreed scope.
