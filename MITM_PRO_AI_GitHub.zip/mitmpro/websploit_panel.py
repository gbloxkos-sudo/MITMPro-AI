import sys
import os
import re
import threading
from tkinter import ttk, messagebox
import tkinter as tk

from mitmpro import common
from mitmpro.common import WEBSPLOIT_DIR, PYTHON
from mitmpro.console import ConsoleWidget

from mitmpro.ai_components import AIHelperTab

# WEBSPLOIT_DIR is computed by common.py and may point at either the package's
# parent dir or the package dir itself (whichever exists on disk). Resolve the
# actual importable 'websploit' package and the directory it must be run from
# defensively so the tool can launch regardless of the on-disk layout.
def _resolve_websploit():
    here = WEBSPLOIT_DIR
    if os.path.isdir(os.path.join(here, "modules")) and os.path.isfile(os.path.join(here, "websploit.py")):
        return here, os.path.dirname(here)
    nested = os.path.join(here, "websploit")
    if os.path.isdir(os.path.join(nested, "modules")) and os.path.isfile(os.path.join(nested, "websploit.py")):
        return nested, here
    return here, os.path.dirname(here)

WEBSPLOIT_PKG, WEBSPLOIT_PARENT = _resolve_websploit()
WEBSPLOIT_ENTRY = os.path.join(WEBSPLOIT_PKG, "websploit.py")

class WebSploitPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="WebSploit Toolkit")
        self.add(AIHelperTab(self, "WebSploit"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        bar = ttk.Frame(self.main_frame)
        bar.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        ttk.Label(bar, text="Module:").grid(row=0, column=0)
        self.module = ttk.Combobox(bar, values=self.list_modules(), width=30)
        self.module.grid(row=0, column=1)
        ttk.Button(bar, text="Use & Launch", command=lambda: threading.Thread(target=self.launch, daemon=True).start()).grid(row=0, column=2)
        ttk.Button(bar, text="Stop", command=self.stop).grid(row=0, column=3)
        ttk.Label(bar, text="(some modules require root & a network interface)").grid(row=0, column=4)

        # cwd must be the package's parent dir so `websploit` is importable.
        self.console = ConsoleWidget(self.main_frame, cwd=WEBSPLOIT_PARENT)
        self.console.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)


    def list_modules(self):
        mods = []
        d = os.path.join(WEBSPLOIT_PKG, "modules")
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.endswith(".py") and not f.startswith("__"):
                    mods.append(f[:-3])
        return mods

    def launch(self):
        if not os.path.isfile(WEBSPLOIT_ENTRY):
            msg = ("[!] WebSploit entry not found at:\n{}\n\n"
                   "Ensure websploit-4.0.4 is installed under the project root.").format(WEBSPLOIT_ENTRY)
            self.after(0, lambda: (
                self.console.console.insert("end", msg + "\n"),
                self.console.console.see("end"),
                messagebox.showerror("WebSploit missing", msg),
            ))
            return
        # Must run as a module (-m) so the package-relative imports resolve.
        # cwd is the package parent dir, so `websploit` is importable.
        mod = self.module.get().strip()
        if mod and not re.match(r"^[a-zA-Z0-9_\-]+$", mod):
            self.after(0, lambda: messagebox.showerror(
                "Invalid module", "Module name contains disallowed characters."))
            return
        cmd = [PYTHON, "-m", "websploit.websploit"]
        if mod:
            cmd += ["-m", mod]
        self.console.start(cmd)

    def stop(self):
        self.console.stop()
