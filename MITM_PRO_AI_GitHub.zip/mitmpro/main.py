import sys
import os
import threading

# Make the app launchable both as `python3 -m mitmpro.main` and as a plain script
# (`python3 mitmpro/main.py`). Without this, `from mitmpro import common` fails
# when the file is executed directly because the project root isn't on sys.path.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

import tkinter as tk
from tkinter import ttk, messagebox

from mitmpro import common
from mitmpro.theme import (
    apply_enterprise_theme, make_header, make_statusbar, SidebarNav,
    ScrollableFrame, install_global_context_menu,
)

common.add_path(common.OLLAMA_GUI_DIR)

from mitmpro.ai_panel import AIPanel
from mitmpro.ai_helper_panel import AIHelperPanel
from mitmpro.ai_traffic_panel import AITrafficAnalyst
from mitmpro.burp_panel import BurpPanel
from mitmpro.websploit_panel import WebSploitPanel
from mitmpro.proxy_panel import ProxyPanel
from mitmpro.waf_panel import WAFPanel
from mitmpro.logger_panel import LoggerPanel
from mitmpro.oast_panel import OASTPanel
from mitmpro.macro_panel import MacroPanel
from mitmpro.scope_panel import ScopePanel
from mitmpro.analysis_panel import AnalysisPanel
from mitmpro.welcome_panel import WelcomePanel
from mitmpro.masquerading_panel import MasqueradingPanel
from mitmpro.nsniffer_panel import NsnifferPanel
from mitmpro.dlp_panel import DLPPanel
from mitmpro.autorun_panel import AutoRunPanel
from mitmpro.autorun_engine import AutoRunEngine
from mitmpro.ai_widget import AIHelpWidget
from mitmpro.network_attack_panel import NetworkAttackPanel
from mitmpro.sslstrip_panel import SSLStripPanel
from mitmpro.campaign_panel import CampaignManager
from mitmpro.email_engineer_panel import EmailEngineer





from mitmpro.traffic import install_hook


# (key, sidebar label, icon)  -- labels are also used by the Welcome quick-start
NAV_ITEMS = [
    ("dashboard", "Dashboard", "🏠"),
    ("ai", "AI Assistant (Ollama)", "💬"),
    ("traffic", "AI Traffic Analyst", "🔍"),
    ("burp", "Burp Tools", "🛡️"),
    ("websploit", "WebSploit", "🌐"),
    ("proxy", "Proxy Tools", "🔀"),
    ("waf", "WAF/Bypass", "🚧"),
    ("phish", "Website Masquerading", "🎭"),
    ("dlp", "Inline DLP Proxy", "🛡️"),
    ("network", "Network Attacks", "⚡"),
    ("sslstrip", "SSL Strip / MITM", "🔒"),
    ("campaigns", "Campaign Manager", "📊"),
    ("email", "Email Engineer", "✉️"),
    ("helper", "AI Helper", "🧠"),
    ("history", "HTTP History", "📜"),
    ("oast", "OAST / DNS", "📡"),
    ("macro", "Macro / Flow", "🔁"),
    ("scope", "Scope", "🎯"),
    ("analysis", "Analysis", "📊"),
    ("nsniffer", "Nsniffer Toolkit", "📡"),
    ("autorun", "AI Auto-Run", "🚀"),
]


LABEL_TO_KEY = {label: key for key, label, _ in NAV_ITEMS}
KEY_TO_LABEL = {key: label for key, label, _ in NAV_ITEMS}


class MITMProApp(tk.Tk):
    def __init__(self):
        super().__init__()
        apply_enterprise_theme(self)
        install_hook()  # capture every real HTTP request into HTTP History
        self.title("MITMPro — Unified Security Suite")
        self.geometry("1280x800")
        self.minsize(1100, 720)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        make_header(self, "MITMPro", "Unified AI-Assisted Security Assessment Platform", "v1.0")

        self._build_toolbar()

        body = tk.Frame(self, bg="#0d1117")
        self.body = body
        body.grid(row=2, column=0, sticky="nsew")
        body.columnconfigure(1, weight=1)
        body.columnconfigure(2, weight=0, minsize=370)
        body.rowconfigure(0, weight=1)

        self.sidebar = SidebarNav(body, NAV_ITEMS, self._navigate)
        self.sidebar.grid(row=0, column=0, sticky="ns")
        
        self.autorun_engine = AutoRunEngine(self)


        self.content = ScrollableFrame(body, bg="#0d1117")
        self.content.grid(row=0, column=1, sticky="nsew", padx=4, pady=4)
        self.content.inner.columnconfigure(0, weight=1)
        self.content.inner.rowconfigure(0, weight=1)

        self._build_panels()

        # Persistent, context-aware AI helper docked next to every module.
        self.ai_dock = AIHelpWidget(
            body, get_context=self._active_feature, get_health=self._health_text)
        self.ai_dock.grid(row=0, column=2, sticky="ns", padx=4)

        self.status = make_statusbar(self)

        self._build_menu()

        install_global_context_menu(self)

        common.register_model_listener(self._on_global_model)
        self._refresh_models()
        self._refresh_status()
        self._navigate("dashboard")
        threading.Thread(target=self._watch_models, daemon=True).start()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------------------------------------------------------- toolbar
    def _build_toolbar(self):
        bar = ttk.Frame(self)
        bar.grid(row=1, column=0, sticky="ew", padx=8, pady=4)
        bar.columnconfigure(4, weight=1)

        ttk.Label(bar, text="Ollama Model:").grid(row=0, column=0)
        self.global_model = ttk.Combobox(bar, width=34, state="readonly")
        self.global_model.grid(row=0, column=1)
        self.global_model.bind("<<ComboboxSelected>>",
                               lambda e: common.set_model(self.global_model.get()))

        ttk.Button(bar, text="Refresh Models", command=self._refresh_models).grid(
            row=0, column=2, padx=6)

        self.ollama_health = ttk.Label(bar, text="Ollama: …")
        self.ollama_health.grid(row=0, column=3, padx=10)

        ttk.Label(bar, text="Global model drives every AI feature in the suite").grid(
            row=0, column=4, sticky="w", padx=10)

        self.internet_btn = ttk.Button(bar, text="Internet: OFF",
                                        command=self._toggle_internet)
        self.internet_btn.grid(row=0, column=5, padx=10)
        common.register_internet_listener(self._on_internet)

        self.start_ollama_btn = ttk.Button(bar, text="Start Ollama",
                                           command=self._start_ollama)
        self.start_ollama_btn.grid(row=0, column=6, padx=10)

        self.dock_btn = ttk.Button(bar, text="◧ Hide AI Dock",
                                         command=self._toggle_dock)
        self.dock_btn.grid(row=0, column=7, padx=10)

    # ---------------------------------------------------------------- panels
    def _build_panels(self):
        self.panels = {}

        self.panels["dashboard"] = WelcomePanel(
            self.content.inner, notebook=None, go=self._go_label)
        self.panels["ai"] = AIPanel(self.content.inner)
        self.panels["traffic"] = AITrafficAnalyst(self.content.inner)
        self.panels["burp"] = BurpPanel(self.content.inner)
        self.panels["websploit"] = WebSploitPanel(self.content.inner)
        self.panels["proxy"] = ProxyPanel(self.content.inner)
        self.panels["waf"] = WAFPanel(self.content.inner)
        self.panels["phish"] = MasqueradingPanel(self.content.inner)
        self.panels["dlp"] = DLPPanel(self.content.inner)
        self.panels["network"] = NetworkAttackPanel(self.content.inner)
        self.panels["sslstrip"] = SSLStripPanel(self.content.inner)
        self.panels["campaigns"] = CampaignManager(self.content.inner)
        self.panels["email"] = EmailEngineer(self.content.inner)


        self.panels["helper"] = AIHelperPanel(
            self.content.inner, get_active_feature=self._active_feature)
        self.panels["history"] = LoggerPanel(
            self.content.inner,
            on_send_to_repeater=self._to_repeater,
            on_send_to_ai=self._to_traffic)
        self.panels["oast"] = OASTPanel(self.content.inner)
        self.panels["macro"] = MacroPanel(self.content.inner)
        self.panels["scope"] = ScopePanel(self.content.inner)
        self.panels["analysis"] = AnalysisPanel(self.content.inner)
        self.panels["nsniffer"] = NsnifferPanel(self.content.inner)
        self.panels["autorun"] = AutoRunPanel(self.content.inner, self)



        for p in self.panels.values():
            p.grid(row=0, column=0, sticky="nsew")
            p.grid_remove()

    # ------------------------------------------------------------- navigation
    def _navigate(self, key):
        for k, p in self.panels.items():
            if k == key:
                p.grid()
            else:
                p.grid_remove()
        self.current = key
        self._set_status(f"Module: {KEY_TO_LABEL.get(key, key)}")

    def _go_label(self, label):
        key = LABEL_TO_KEY.get(label)
        if key:
            self.sidebar.select(key)

    def _active_feature(self):
        return KEY_TO_LABEL.get(self.current, self.current)

    def _health_text(self):
        net = "Internet ON" if common.INTERNET_ENABLED else "Internet OFF"
        if common.ollama_running():
            return f"Ollama RUNNING | model {common.SELECTED_MODEL or 'none'} | {net}"
        return f"Ollama OFFLINE | {net}"

    # --------------------------------------------------------- external wiring
    def _to_repeater(self, entry):
        self.panels["burp"].load_into_repeater(entry)
        self.sidebar.select("burp")

    def _to_traffic(self, entry):
        self.panels["traffic"].load_from_entry(entry)
        self.sidebar.select("traffic")

    # -------------------------------------------------------------- model sys
    def _refresh_models(self):
        models = common.ollama_models()
        self.global_model["values"] = models
        if models:
            if common.SELECTED_MODEL not in models:
                common.set_model(models[0])
            self.global_model.set(common.SELECTED_MODEL)
        else:
            self.global_model.set("")
        self._update_status_model()

    def _on_global_model(self, model):
        if model:
            try:
                vals = list(self.global_model["values"] or ())
                if model not in vals:
                    self.global_model["values"] = vals + [model]
                self.global_model.set(model)
            except Exception as e:
                print(f"Error setting global model: {e}")
        self._update_status_model()

    def _update_status_model(self):
        self.status["model"].config(
            text=f"model: {common.SELECTED_MODEL or '—'}")

    def _toggle_internet(self):
        common.set_internet(not common.INTERNET_ENABLED)

    def _toggle_dock(self):
        """Collapse/expand the AI helper dock to reclaim horizontal space."""
        if self.ai_dock.winfo_viewable():
            self.ai_dock.grid_remove()
            self.body.columnconfigure(2, minsize=0)
            self.dock_btn.config(text="◨ Show AI Dock")
        else:
            self.ai_dock.grid()
            self.body.columnconfigure(2, minsize=370)
            self.dock_btn.config(text="◧ Hide AI Dock")

    def _on_internet(self, on):
        try:
            self.internet_btn.config(text="Internet: ON" if on else "Internet: OFF")
        except Exception as e:
            print(f"Error updating internet button: {e}")
        self._set_status("Internet access " + ("ENABLED — AI may fetch live data"
                                                  if on else "OFF (private mode)"))

    # ---------------------------------------------------------------- status
    def _set_status(self, text):
        self.status["status"].config(text=text)

    def _refresh_status(self):
        try:
            if not self.winfo_exists():
                return
            threading.Thread(target=self._poll_ollama, daemon=True).start()
            self.after(5000, self._refresh_status)
        except Exception as e:
            print(f"Error refreshing status: {e}")

    def _poll_ollama(self):
        try:
            models = common.ollama_models()
            running = bool(models)
        except Exception as e:
            print(f"Error polling ollama: {e}")
            running = False
            models = []
        try:
            if self.winfo_exists():
                self.after(0, self._apply_status, running, models)
        except Exception as e:
            print(f"Error applying status: {e}")

    def _apply_status(self, running, models):
        if not self.winfo_exists():
            return
        if running:
            self.ollama_health.config(text="Ollama: RUNNING", foreground="#2ea043")
            self.status["dot"].config(fg="#2ea043")
            self._set_status(
                f"Ollama: RUNNING | active: {common.SELECTED_MODEL or 'none'} | "
                f"models: {', '.join(models) if models else 'none'}")
        else:
            self.ollama_health.config(text="Ollama: OFFLINE", foreground="#f85149")
            self.status["dot"].config(fg="#f85149")
            self._set_status("Ollama: OFFLINE — click 'Start Ollama' or run 'ollama serve'")

    # ----------------------------------------------------- ollama lifecycle
    def _start_ollama(self):
        if common.ollama_running():
            self._set_status("Ollama already running")
            self._refresh_models()
            return
        import shutil
        import subprocess
        if not shutil.which("ollama"):
            messagebox.showerror(
                "Ollama not found",
                "Ollama is not installed on this machine.\n\n"
                "Install it from https://ollama.com , then run:\n"
                "  ollama serve\n  ollama pull llama3.2:1b")
            return
        try:
            subprocess.Popen(["ollama", "serve"],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._set_status("Starting Ollama service, please wait…")
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return
        threading.Thread(target=self._wait_ollama, daemon=True).start()

    def _wait_ollama(self):
        import time
        for _ in range(20):
            time.sleep(1)
            if common.ollama_running():
                if self.winfo_exists():
                    self.after(0, self._refresh_models)
                    self.after(0, self._refresh_status)
                return

    def _watch_models(self):
        # If Ollama isn't up yet, try to auto-start it once and then keep polling
        # (off the GUI thread) so a model is selected automatically as soon as it
        # becomes available — no manual 'Refresh Models' needed.
        import time
        import shutil
        import subprocess
        for _ in range(40):  # ~2 minutes
            if not self.winfo_exists():
                return
            if common.ollama_running():
                if self.winfo_exists():
                    self.after(0, self._refresh_models)
                return
            if _ == 0 and shutil.which("ollama"):
                try:
                    subprocess.Popen(["ollama", "serve"],
                                     stdout=subprocess.DEVNULL,
                                     stderr=subprocess.DEVNULL)
                except Exception as e:
                    print(f"Error starting ollama: {e}")
            time.sleep(3)

    # ---------------------------------------------------------------- menus
    def _build_menu(self):
        menubar = tk.Menu(self, bg="#161b22", fg="#e6edf3")
        file_menu = tk.Menu(menubar, tearoff=0, bg="#161b22", fg="#e6edf3")
        file_menu.add_command(label="Refresh Ollama Models", command=self._refresh_models)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        tools_menu = tk.Menu(menubar, tearoff=0, bg="#161b22", fg="#e6edf3")
        tools_menu.add_command(label="Open Standalone Ollama GUI",
                               command=self.panels["ai"].open_standalone)
        tools_menu.add_command(label="Run Full Diagnostics",
                               command=lambda: self._go_label("Analysis"))
        menubar.add_cascade(label="Tools", menu=tools_menu)

        help_menu = tk.Menu(menubar, tearoff=0, bg="#161b22", fg="#e6edf3")
        help_menu.add_command(label="About MITMPro", command=self._about)
        menubar.add_cascade(label="Help", menu=help_menu)
        self.config(menu=menubar)

    def _about(self):
        messagebox.showinfo("About MITMPro",
            "MITMPro — Unified Security Suite  v1.0\n\n"
            "Integrates: AI Assistant (Ollama), AI Traffic Analyst, Burp-style "
            "Tools, WebSploit, Proxy Interception, an advanced WAF/Bypass engine, "
            "AI Helper, HTTP History, OAST, Macro flows, Scope and Analysis.\n\n"
            "Developed by GBLOXKOS LLC.\n"
            "For authorized security testing only.")

    def _on_close(self):
        # Stop AutoRun engine
        try:
            if hasattr(self, 'autorun_engine') and self.autorun_engine.is_running:
                self.autorun_engine.stop()
        except Exception as e:
            print(f"Error stopping autorun engine: {e}")
        
        # Stop all panels with destroy method
        for key in list(self.panels.keys()):
            try:
                p = self.panels.get(key)
                if p and hasattr(p, 'destroy'):
                    p.destroy()
            except Exception as e:
                print(f"Error destroying panel {key}: {e}")
        
        # Cancel any pending after callbacks
        # (no-op needed, just keeping structure)
        
        try:
            self.destroy()
        except Exception as e:
            print(f"Error destroying app: {e}")


def main():
    app = MITMProApp()
    app.mainloop()


if __name__ == "__main__":
    main()
