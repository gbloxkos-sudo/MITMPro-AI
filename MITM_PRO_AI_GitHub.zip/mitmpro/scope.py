from urllib.parse import urlparse


SCOPE = []


def add(host):
    h = host.strip()
    if h and h not in SCOPE:
        SCOPE.append(h)


def remove(host):
    h = host.strip()
    if h in SCOPE:
        SCOPE.remove(h)


def in_scope(url):
    if not SCOPE:
        return True
    host = urlparse(url).netloc.split(":")[0].lower()
    for s in SCOPE:
        s = s.strip().lower()
        if host == s or host.endswith("." + s):
            return True
    return False
