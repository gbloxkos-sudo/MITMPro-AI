import tkinter as tk
from tkinter import ttk, messagebox
import os, time, re
from datetime import datetime
from mitmpro.common import ollama_models
from mitmpro.ai_components import AIHelperTab

try:
    import psutil
except ImportError:
    psutil = None


_TOUR = [("Welcome!", "This is your security testing hub. Pick any module below to get started."), ("AI Engine", "Ollama powers the AI locally. Start it with 'ollama serve'."), ("Quick Start", "Jump to any module with one click from the action grid."), ("Threat Radar", "Findings are categorized here at a glance."), ("Activity", "Recent HTTP requests captured by the proxy appear here.")]
_TIPS = ["Always set scope before scanning to avoid testing unauthorized targets.", "Use SQLMap with --random-agent to avoid WAF fingerprinting.", "Check for CORS misconfigurations — they leak data across origins.", "Monitor DNS lookups for hidden subdomains during recon.", "Review HTTP headers — missing CSP/HSTS can be critical findings.", "Test for SSRF by supplying internal IPs in URL parameters.", "Chain vulns: an open redirect can enable cookie theft.", "Test auth bypass by modifying session tokens directly.", "Always save your traffic logs for post-engagement analysis.", "Rate-limit your scanners to avoid crashing target services.", "Use nikto for a quick baseline before deep-dive testing.", "Test IDOR by incrementing resource IDs in API calls."]
_VP = {"XSS": ["<script", "alert(", "onerror="], "SQLi": ["union select", "or 1=1", "drop table"], "SSRF": ["127.0.0.1", "169.254", "localhost"], "IDOR": ["/admin", "/user/"], "CSRF": ["csrf", "_token"], "Leak": ["password", "secret", "api_key"]}


class WelcomePanel(ttk.Notebook):
    def __init__(self, master, notebook, go):
        super().__init__(master)
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Welcome")
        self.add(AIHelperTab(self, "Getting Started"), text="AI Helper")
        self.notebook, self.go = notebook, go
        self._start = time.time()
        self._tip_idx = 0
        self._timer_id = None
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.columnconfigure(1, weight=1)
        self.main_frame.rowconfigure(5, weight=1)
        c = ttk.Frame(self.main_frame)
        c.grid(row=0, column=0, columnspan=2, sticky="ew", padx=16, pady=10); c.columnconfigure(0, weight=1)
        ttk.Label(c, text="Welcome to MITMPro", font=("Segoe UI", 20, "bold"), style="Bold.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(c, text="All-in-one local security testing suite. AI, scanners, traffic interception, bypass — all private.", 
                  wraplength=900, style="TLabel").grid(row=1, column=0, sticky="w", pady=(6, 12))
        h = ttk.Frame(c); h.grid(row=2, column=0, sticky="ew", pady=4); h.columnconfigure(1, weight=1)
        ttk.Label(h, text="AI engine:", style="Muted.TLabel").grid(row=0, column=0)
        self.health = ttk.Label(h, text="checking...", style="TLabel"); self.health.grid(row=0, column=1, sticky="w", padx=8)
        ttk.Button(h, text="How to start Ollama", command=self.how_ollama).grid(row=0, column=2, padx=12)
        pf = ttk.Frame(c); pf.grid(row=3, column=0, sticky="ew", pady=6)
        self._ul = ttk.Label(pf, text="Uptime: --", style="Muted.TLabel"); self._ul.grid(row=0, column=0, padx=(0, 16))
        self._ml = ttk.Label(pf, text="Memory: --", style="Muted.TLabel"); self._ml.grid(row=0, column=1, padx=(0, 16))
        self._cl = ttk.Label(pf, text="AI convos: 0", style="Muted.TLabel"); self._cl.grid(row=0, column=2)
        sf = ttk.LabelFrame(self.main_frame, text="Live stats"); sf.grid(row=1, column=0, columnspan=2, sticky="ew", padx=16, pady=8); sf.columnconfigure((0, 1, 2, 3), weight=1)
        self._sv = {}
        for i, (k, lb) in enumerate([("r", "HTTP Requests"), ("v", "Vulns Found"), ("a", "AI Queries"), ("m", "Active Modules")]):
            ttk.Label(sf, text=lb, style="Muted.TLabel").grid(row=0, column=i, padx=10, pady=(8, 2))
            self._sv[k] = ttk.Label(sf, text="0", font=("Segoe UI", 14, "bold"), style="TLabel"); self._sv[k].grid(row=1, column=i, padx=10, pady=(0, 8))
        mf = ttk.LabelFrame(self.main_frame, text="Module health"); mf.grid(row=2, column=0, columnspan=2, sticky="ew", padx=16, pady=8); mf.columnconfigure((0, 1, 2, 3), weight=1)
        self._dots = {}
        for i, n in enumerate(["Ollama", "Flask", "BeautifulSoup", "requests"]):
            ttk.Label(mf, text=n, style="Muted.TLabel").grid(row=0, column=i, sticky="w", padx=10, pady=(8, 2))
            d = tk.Canvas(mf, width=14, height=14, bg="#161b22", highlightthickness=0); d.grid(row=1, column=i, padx=6)
            self._dots[n] = d
        af = ttk.LabelFrame(self.main_frame, text="Recent activity"); af.grid(row=3, column=0, columnspan=2, sticky="ew", padx=12, pady=3); af.columnconfigure((0, 1, 2), weight=1)
        self._al = []
        for r in range(5):
            row = []
            for c2 in range(3):
                lbl = ttk.Label(af, text="--", foreground="#c9d1d9", font=("Consolas", 8)); lbl.grid(row=r, column=c2, sticky="w", padx=4)
                row.append(lbl)
            self._al.append(row)
        ac = ttk.LabelFrame(self.main_frame, text="Quick start"); ac.grid(row=4, column=0, columnspan=2, sticky="ew", padx=12, pady=3); ac.columnconfigure((0, 1, 2), weight=1)
        for i, (txt, tgt) in enumerate([("Chat with AI", "AI Assistant (Ollama)"), ("Scan a website", "Burp Tools"), ("Analyze traffic", "AI Traffic Analyst"), ("Bypass a WAF", "WAF/Bypass"), ("Network MITM", "Network Attacks"), ("SSL Strip", "SSL Strip / MITM"), ("Phishing Campaign", "Campaign Manager"), ("Email Engineer", "Email Engineer"), ("AI Auto-Run", "AI Auto-Run")]):
            r2, c2 = divmod(i, 3)
            ttk.Button(ac, text=txt, command=lambda t=tgt: self.go(t) if t else messagebox.showinfo("Info", "Coming soon.")).grid(row=r2, column=c2, padx=4, pady=3, sticky="ew")
        # -- Beginner first-steps guide --
        bg = ttk.LabelFrame(self.main_frame, text="\U0001f9e0 New here? Run your first test in 3 steps")
        bg.grid(row=5, column=0, sticky="nsew", padx=12, pady=3)
        steps = [
            "1. Start the AI engine — click 'How to start Ollama' above and run:  ollama serve   then   ollama pull llama3.2:1b",
            "2. Open the 'AI Auto-Run' tab and click an example goal (e.g. 'Scan example.com for XSS'), or type your own goal in plain English.",
            "3. Watch the AI build the plan and run the tools for you. Open any module's 'AI Helper' tab for a plain-English explanation of that tool.",
        ]
        for i, s in enumerate(steps):
            ttk.Label(bg, text=s, wraplength=430, justify="left",
                      foreground="#c9d1d9").grid(row=i, column=0, sticky="w", padx=8, pady=3)
        tf = ttk.LabelFrame(self.main_frame, text="Security tip of the day"); tf.grid(row=5, column=1, sticky="nsew", padx=12, pady=3); tf.columnconfigure(0, weight=1)
        self._tl = ttk.Label(tf, text="", wraplength=430, justify="left", foreground="#c9d1d9"); self._tl.grid(row=0, column=0, sticky="w", padx=8, pady=2)
        self._tt = ttk.Label(tf, text="", foreground="#8b949e"); self._tt.grid(row=1, column=0, sticky="w", padx=8)
        thr = ttk.LabelFrame(self.main_frame, text="Threat radar"); thr.grid(row=6, column=0, columnspan=2, sticky="ew", padx=12, pady=3); thr.columnconfigure((0, 1, 2, 3, 4, 5), weight=1)
        cols = {"XSS": "#f97583", "SQLi": "#d2a8ff", "SSRF": "#79c0ff", "IDOR": "#56d364", "CSRF": "#e3b341", "Leak": "#ffa657"}
        self._thr = {}
        for i, (cat, col) in enumerate(cols.items()):
            f = ttk.Frame(thr); f.grid(row=0, column=i, padx=3)
            tk.Canvas(f, width=10, height=10, bg=col, highlightthickness=0).grid(row=0, column=0)
            ttk.Label(f, text=cat, foreground="#8b949e", font=("Segoe UI", 8)).grid(row=0, column=1, padx=2)
            l = ttk.Label(f, text="0", foreground="#e6edf3", font=("Segoe UI", 9, "bold")); l.grid(row=0, column=2, padx=2)
            self._thr[cat] = l
        self._tour_active = not os.path.exists(os.path.expanduser("~/.mitmpro_tour_done"))
        self._tour_idx = 0; self._tour_win = None
        if self._tour_active:
            self._tour_win = tk.Toplevel(self.main_frame)
            self._tour_win.title("Onboarding Tour"); self._tour_win.configure(bg="#1c2333"); self._tour_win.resizable(False, False); self._tour_win.geometry("440x150")
            self._tour_win.protocol("WM_DELETE_WINDOW", self._end_tour)
            self._t_lbl = tk.Label(self._tour_win, text="", bg="#1c2333", fg="#e6edf3", wraplength=400, justify="left", font=("Segoe UI", 11)); self._t_lbl.pack(padx=16, pady=(16, 8))
            bf = tk.Frame(self._tour_win, bg="#1c2333"); bf.pack(pady=8)
            self._t_prev = tk.Button(bf, text="Previous", command=lambda: self._tour_step(-1), bg="#21262d", fg="#c9d1d9", bd=0); self._t_prev.pack(side="left", padx=4)
            self._t_next = tk.Button(bf, text="Next",
                command=lambda: self._end_tour() if self._tour_idx == len(_TOUR) - 1 else self._tour_step(1),
                bg="#238636", fg="#fff", bd=0); self._t_next.pack(side="left", padx=4)
            tk.Button(bf, text="Skip", command=self._end_tour, bg="#21262d", fg="#8b949e", bd=0).pack(side="left", padx=4)
            self._show_tour()
        self.after(300, self.check_health)

    def _show_tour(self):
        if self._tour_idx < len(_TOUR):
            t, b = _TOUR[self._tour_idx]; self._t_lbl.config(text=f"{t}\n\n{b}")
            self._t_prev.config(state="normal" if self._tour_idx > 0 else "disabled")
            self._t_next.config(text="Finish" if self._tour_idx == len(_TOUR) - 1 else "Next")

    def _tour_step(self, d):
        self._tour_idx = max(0, min(self._tour_idx + d, len(_TOUR) - 1))
        self._show_tour()

    def _end_tour(self):
        self._tour_active = False
        try:
            with open(os.path.expanduser("~/.mitmpro_tour_done"), "w") as f:
                pass
        except Exception:
            pass
        try:
            self._tour_win.destroy()
        except Exception:
            pass

    def _dot(self, canvas, col):
        canvas.delete("all"); canvas.create_oval(2, 2, 12, 12, fill=col, outline="")

    def _rlog(self):
        try:
            from mitmpro.traffic import log
            entries = log.snapshot()[-200:]
            lines = []
            for e in entries:
                method = e.get("method", "")
                url = e.get("url", "")
                status = e.get("status", "ERR")
                lines.append(f"{method} {url} {status}")
            return lines
        except Exception:
            return []

    def check_health(self):
        models = ollama_models()
        if models: self.health.config(text=f"ready — {len(models)} model(s)", foreground="#2ea043")
        else: self.health.config(text="not running — start Ollama to enable AI", foreground="#d29922")
        st = {"Ollama": bool(models)}
        for mod, key in [("flask", "Flask"), ("bs4", "BeautifulSoup"), ("requests", "requests")]:
            try: __import__(mod); st[key] = True
            except ImportError: st[key] = False
        for n, ok in st.items(): self._dot(self._dots[n], "#2ea043" if ok else "#e3b341" if n != "Ollama" else "#f85149")
        self._sv["m"].config(text=str(sum(st.values())))
        lines = self._rlog(); self._sv["r"].config(text=str(len(lines)))
        parsed = []
        for ln in reversed(lines):
            s = ln.strip(); ms = re.search(r"(\d{3})\s*$", s); st2 = ms.group(1) if ms else "--"
            parts = s.split(); mt = next((p.upper() for p in parts if p.upper() in ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS")), "")
            url = next((p[:38] for p in parts if p.startswith("http")), parts[1][:38] if len(parts) > 1 else "--")
            parsed.append((mt, url, st2))
            if len(parsed) >= 5: break
        for i in range(5):
            if i < len(parsed):
                for c2 in range(3): self._al[i][c2].config(text=parsed[i][c2])
            else:
                for c2 in range(3): self._al[i][c2].config(text="--")
        aiq = sum(1 for l in lines if "ollama" in l.lower() or "ai" in l.lower())
        self._sv["a"].config(text=str(aiq)); self._sv["v"].config(text="0")
        up = time.time() - self._start; h, m2 = int(up // 3600), int(up % 3600 // 60)
        self._ul.config(text=f"Uptime: {h}h {m2}m")
        try: mb = psutil.Process(os.getpid()).memory_info().rss / 1048576; self._ml.config(text=f"Memory: {mb:.1f} MB")
        except Exception: self._ml.config(text="Memory: --")
        self._cl.config(text=f"AI convos: {aiq}")
        try:
            from mitmpro.traffic import log
            entries = log.snapshot()
            data = " ".join(
                (e.get("url", "") + " " + (e.get("req_body", "") or "") + " " + (e.get("resp_body", "") or "")).lower()
                for e in entries
            )
            for cat, pats in _VP.items(): self._thr[cat].config(text=str(sum(data.count(p) for p in pats)))
        except Exception as e:
            print(f"Threat radar error: {e}")
        tip = _TIPS[self._tip_idx % len(_TIPS)]; self._tl.config(text=tip)
        self._tt.config(text=f"Rotated at {datetime.now():%Y-%m-%d %H:%M}"); self._tip_idx += 1
        try:
            if self.winfo_exists():
                self._timer_id = self.after(2000, self.check_health)
        except Exception as e:
            print(f"Timer error: {e}")

    def how_ollama(self):
        messagebox.showinfo("Start Ollama", "Open a terminal and run:\n\n    ollama serve\n\nThen:\n    ollama pull llama3.2:1b\n\nRestart MITMPro afterwards.")

    def destroy(self):
        if self._timer_id:
            try:
                self.after_cancel(self._timer_id)
            except Exception:
                pass
            self._timer_id = None
        super().destroy()
