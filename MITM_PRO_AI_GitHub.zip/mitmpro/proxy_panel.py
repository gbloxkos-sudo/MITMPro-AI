import os
import sys
import threading
from tkinter import ttk, messagebox

from mitmpro import common
from mitmpro.common import MITMNEW_DIR, PYTHON, MITM_UI_DIR, MITMPROXY_UI_DIR
from mitmpro.console import ConsoleWidget


def find_proxy_tools():
    tools = []
    base = MITMNEW_DIR
    candidates = [
        ("mitm_intercept.py", "SSL interception relay (TCP/UDP, mixed TLS)",
         os.path.join(base, "MITM_Intercept-main", "mitm_intercept.py")),
        ("DatajackProxy.py", "Frida-based process MITM (Linux/Windows)",
         os.path.join(base, "DatajackProxy-master", "DatajackProxy.py")),
    ]
    for name, desc, path in candidates:
        if os.path.isfile(path):
            tools.append((name, desc, path))
    if os.path.isfile(os.path.join(MITM_UI_DIR, "MitmUI.py")):
        tools.append(("MitmUI.py", "PyQt5 MITM proxy UI (Python 2 - legacy)",
                      os.path.join(MITM_UI_DIR, "MitmUI.py")))
    return tools


from mitmpro.ai_components import AIHelperTab

class ProxyPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Proxy Tools")
        self.add(AIHelperTab(self, "Proxy Tools"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(2, weight=1)

        self.tools = find_proxy_tools()
        self.args_placeholder = "extra args (e.g. -l 0.0.0.0:8080 -t 127.0.0.1:80 -lc cert.pem -lk key.pem)"

        bar = ttk.Frame(self.main_frame)
        bar.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        bar.columnconfigure(1, weight=1)
        ttk.Label(bar, text="Tool:").grid(row=0, column=0)
        self.tool = ttk.Combobox(bar, values=[f"{t[0]} — {t[1]}" for t in self.tools], width=60)
        self.tool.grid(row=0, column=1, sticky="ew")
        if self.tools:
            self.tool.set(self.tool["values"][0])
        self.launch_btn = ttk.Button(bar, text="Launch", command=self.launch)
        self.launch_btn.grid(row=0, column=2)
        self.stop_btn = ttk.Button(bar, text="Stop", command=self.stop)
        self.stop_btn.grid(row=0, column=3)

        self.args = ttk.Entry(bar)
        self.args.grid(row=1, column=0, columnspan=4, sticky="ew", padx=4, pady=2)
        self.args.insert(0, self.args_placeholder)
        self.args.bind("<FocusIn>", self._clear_placeholder)
        self.args.bind("<FocusOut>", self._restore_placeholder)

        self.console = ConsoleWidget(self.main_frame)
        self.console.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)


    def _clear_placeholder(self, event):
        if self.args.get() == self.args_placeholder:
            self.args.delete(0, "end")

    def _restore_placeholder(self, event):
        if not self.args.get().strip():
            self.args.insert(0, self.args_placeholder)

    def launch(self, tool=None, args=None, **kwargs):
        sel = tool or self.tool.get()
        path = None
        for t in self.tools:
            if sel.startswith(t[0]):
                path = t[2]
                break
        if not path:
            self.after(0, lambda: messagebox.showerror("No tool", "Select a proxy tool."))
            return
        if not os.path.isfile(path):
            msg = ("[!] Proxy tool not found at:\n{}\n\n"
                   "Ensure the bundled tool is present in {}.").format(path, MITMNEW_DIR)
            self.after(0, lambda m=msg: (
                self.console.console.insert("end", m + "\n"),
                self.console.console.see("end"),
                messagebox.showerror("Tool missing", m),
            ))
            return
        if args is None:
            args = self.args.get().split() if self.args.get() != self.args_placeholder else []
        elif isinstance(args, str):
            args = args.split()
        cmd = [PYTHON, path] + args
        self.console.start(cmd)

    def stop(self):
        self.console.stop()
