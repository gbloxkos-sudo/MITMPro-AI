"""
MITMPro - Burp Suite Advanced Integration Module
Integrates all Burp Suite extensions, Bambdas, and advanced techniques
"""

import os
import json
import subprocess
import threading
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class BurpExtensionType(Enum):
    """Types of Burp Suite extensions integrated"""
    BAMBDA = "bambda"
    BAPP = "bapp"
    PYTHON_EXTENSION = "python_extension"
    JAVA_EXTENSION = "java_extension"


@dataclass
class BurpBambda:
    """Represents a Burp Suite Bambda (custom extension)"""
    name: str
    category: str
    code: str
    description: str
    trigger: str
    target_tools: List[str] = field(default_factory=list)


@dataclass
class BurpExtension:
    """Represents a Burp Suite extension"""
    name: str
    type: BurpExtensionType
    description: str
    features: List[str]
    install_path: str
    config_schema: Dict = field(default_factory=dict)


class BurpSuiteIntegrator:
    """Main integrator for all Burp Suite tools and extensions"""
    
    def __init__(self, base_path: str = "/home/dfat/Downloads/MITM_PRO_AI"):
        self.base_path = base_path
        self.bambdas: List[BurpBambda] = []
        self.extensions: List[BurpExtension] = []
        self.turbo_intruder_scripts: Dict[str, str] = {}
        self.auth_matrix_configs: List[Dict] = []
        self.totp_configs: List[Dict] = []
        self._load_all()
    
    def _load_all(self):
        """Load all Burp Suite integrations"""
        self._load_bambdas()
        self._load_turbo_intruder_scripts()
        self._load_auth_matrix()
        self._load_totp_configs()
        self._register_extensions()
    
    def _load_bambdas(self):
        """Load all Bambdas from bambdas-main folder"""
        bambda_path = os.path.join(self.base_path, "bambdas-main")
        if not os.path.exists(bambda_path):
            return
        
        categories = {
            "CustomAction": "custom_actions",
            "CustomColumn": "custom_columns",
            "CustomScanChecks": "custom_scans",
            "Filter/Logger": "logger_filters",
            "Filter/Proxy": "proxy_filters",
            "Filter/SiteMap": "sitemap_filters",
            "MatchAndReplace/Request": "request_match_replace",
            "MatchAndReplace/Response": "response_match_replace"
        }
        
        for folder, category in categories.items():
            full_path = os.path.join(bambda_path, folder)
            if os.path.exists(full_path):
                for file in os.listdir(full_path):
                    if file.endswith(".bambda"):
                        file_path = os.path.join(full_path, file)
                        with open(file_path, 'r') as f:
                            code = f.read()
                        
                        name = file.replace(".bambda", "")
                        self.bambdas.append(BurpBambda(
                            name=name,
                            category=category,
                            code=code,
                            description=self._extract_bambda_description(code),
                            trigger="auto",
                            target_tools=["Proxy", "Repeater", "Intruder", "Scanner", "Logger"]
                        ))
    
    def _extract_bambda_description(self, code: str) -> str:
        """Extract description from bambda code comments"""
        lines = code.split('\n')
        for line in lines[:10]:
            if line.strip().startswith('#') or line.strip().startswith('//'):
                return line.strip().lstrip('#/').strip()
        return "Custom Burp Suite Bambda"
    
    def _load_turbo_intruder_scripts(self):
        """Load Turbo Intruder attack scripts"""
        # Built-in race condition scripts
        self.turbo_intruder_scripts = {
            "race_single_packet": '''
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=1,
                           engine=Engine.BURP2)
    
    for i in range(20):
        engine.queue(target.req, gate='race1')
    
    engine.openGate('race1')

def handleResponse(req, interesting):
    table.add(req)
''',
            "race_last_byte_sync": '''
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=10,
                           engine=Engine.THREADED)
    
    for i in range(50):
        engine.queue(target.req, gate='race1')
    
    engine.openGate('race1')

def handleResponse(req, interesting):
    if req.status != 404:
        table.add(req)
''',
            "otp_bruteforce": '''
import itertools

def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=50,
                           requestsPerConnection=100,
                           pipeline=False)
    
    # Common OTPs
    common_otps = ["000000", "111111", "123456", "654321", "123123", 
                   "0000", "1111", "1234", "4321", "admin", "welcome"]
    
    for otp in common_otps:
        engine.queue(target.req, otp)
    
    # Sequential range if OTP length known
    for i in range(1000000):
        engine.queue(target.req, str(i).zfill(6))

def handleResponse(req, interesting):
    if req.status in [200, 302] and "invalid" not in req.response.lower():
        table.add(req)
''',
            "multi_endpoint_race": '''
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=1,
                           engine=Engine.BURP2)
    
    # Phase 1: Trigger state change (e.g., change email)
    for i in range(10):
        engine.queue(target.req1, gate=f'phase1_{i}')
    
    # Phase 2: Race the verification
    for i in range(10):
        engine.queue(target.req2, gate=f'phase1_{i}')
    
    for i in range(10):
        engine.openGate(f'phase1_{i}')

def handleResponse(req, interesting):
    table.add(req)
''',
            "coupon_race": '''
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=1,
                           engine=Engine.BURP2)
    
    for i in range(50):
        engine.queue(target.req, gate='coupon')
    
    engine.openGate('coupon')

def handleResponse(req, interesting):
    if "success" in req.response.lower() or req.status == 200:
        table.add(req)
''',
            "rate_limit_bypass": '''
import time

def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=10,
                           requestsPerConnection=100,
                           engine=Engine.THREADED)
    
    # Send dummy requests to trigger rate limit
    for i in range(100):
        engine.queue(target.dummy_req)
    
    time.sleep(1)
    
    # Now send actual attack
    for otp in wordlists.otp_list:
        engine.queue(target.req, otp)

def handleResponse(req, interesting):
    if req.status != 429:
        table.add(req)
''',
            "totp_time_window": '''
def queueRequests(target, wordlists):
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=20,
                           engine=Engine.THREADED)
    
    # Test TOTP codes from adjacent time windows
    import time
    import base64
    import hmac
    import hashlib
    import struct
    
    secret = target.secret  # Base32 encoded secret
    current_counter = int(time.time()) // 30
    
    for offset in range(-5, 6):
        counter = current_counter + offset
        msg = struct.pack(">Q", counter)
        hmac_digest = hmac.new(base64.b32decode(secret), msg, hashlib.sha1).digest()
        offset = hmac_digest[-1] & 0x0F
        code = (struct.unpack(">I", hmac_digest[offset:offset+4])[0] & 0x7FFFFFFF) % 1000000
        totp = str(code).zfill(6)
        engine.queue(target.req, totp)

def handleResponse(req, interesting):
    if req.status == 200 and "success" in req.response.lower():
        table.add(req)
'''
        }
    
    def _load_auth_matrix(self):
        """Load AuthMatrix authorization testing configurations"""
        self.auth_matrix_configs = [
            {
                "name": "RBAC Testing",
                "description": "Role-Based Access Control matrix testing",
                "users": ["admin", "manager", "user", "guest", "anonymous"],
                "roles": ["ROLE_ADMIN", "ROLE_MANAGER", "ROLE_USER", "ROLE_GUEST"],
                "endpoints": [
                    "/api/admin/*",
                    "/api/manager/*", 
                    "/api/user/*",
                    "/api/public/*",
                    "/api/user/profile",
                    "/api/admin/users",
                    "/api/manager/reports"
                ],
                "test_matrix": "full_cross_product"
            },
            {
                "name": "ABAC Testing",
                "description": "Attribute-Based Access Control testing",
                "attributes": ["department", "clearance", "project_access", "time_of_day"],
                "policies": [
                    "department:finance AND clearance:high",
                    "project_access:project_alpha OR role:admin",
                    "time_of_day:business_hours AND role:user"
                ]
            },
            {
                "name": "IDOR Testing",
                "description": "Insecure Direct Object Reference testing",
                "object_types": ["user", "order", "document", "invoice", "report"],
                "id_formats": ["numeric", "uuid", "slug", "encoded"],
                "test_cases": [
                    "horizontal_privilege_escalation",
                    "vertical_privilege_escalation",
                    "object_enumeration"
                ]
            }
        ]
    
    def _load_totp_configs(self):
        """Load TOTP/2FA authenticator configurations"""
        self.totp_configs = [
            {
                "name": "Google Authenticator",
                "type": "totp",
                "algorithm": "SHA1",
                "digits": 6,
                "period": 30,
                "format": "base32",
                "use_cases": ["MFA login", "API authentication", "Session handling"],
                "burp_integration": "session_handling_rules"
            },
            {
                "name": "Microsoft Authenticator",
                "type": "totp",
                "algorithm": "SHA1",
                "digits": 6,
                "period": 30,
                "format": "base32",
                "push_notification": True,
                "use_cases": ["Azure AD", "Office 365", "Microsoft services"]
            },
            {
                "name": "Authy / Twilio",
                "type": "totp",
                "algorithm": "SHA1",
                "digits": 7,
                "period": 30,
                "format": "base32",
                "multi_device": True,
                "backup_codes": True,
                "use_cases": ["Twilio Verify", "Authy API"]
            },
            {
                "name": "Duo Security",
                "type": "push",
                "push_notification": True,
                "offline_codes": True,
                "use_cases": ["Cisco Duo", "Enterprise SSO"]
            },
            {
                "name": "YubiKey OATH",
                "type": "hardware",
                "algorithm": "SHA1",
                "digits": 6,
                "period": 30,
                "touch_required": True,
                "use_cases": ["Hardware MFA", "FIDO2/WebAuthn"]
            }
        ]
    
    def _register_extensions(self):
        """Register known Burp Suite extensions"""
        self.extensions = [
            BurpExtension(
                name="Turbo Intruder",
                type=BurpExtensionType.BAPP,
                description="High-performance HTTP fuzzing and race condition exploitation",
                features=[
                    "Single-packet attack (HTTP/2)",
                    "Last-byte synchronization (HTTP/1.1)",
                    "Python scripting engine",
                    "Custom HTTP stack",
                    "Result filtering and diffing",
                    "Headless CLI mode"
                ],
                install_path="https://portswigger.net/bappstore/9abaa233088242e8be252cd4ff534988",
                config_schema={
                    "engine": {"type": "select", "options": ["BURP2", "THREADED", "BURP"]},
                    "concurrentConnections": {"type": "int", "default": 10},
                    "requestsPerConnection": {"type": "int", "default": 100},
                    "pipeline": {"type": "bool", "default": False}
                }
            ),
            BurpExtension(
                name="AuthMatrix",
                type=BurpExtensionType.BAPP,
                description="Authorization testing matrix for web applications",
                features=[
                    "User/Role/Request matrix",
                    "Color-coded results",
                    "Session token management",
                    "CSRF token chaining",
                    "Regression testing",
                    "Cross-user resource testing"
                ],
                install_path="https://github.com/portswigger/auth-matrix",
                config_schema={
                    "users": {"type": "array", "items": {"type": "string"}},
                    "roles": {"type": "array", "items": {"type": "string"}},
                    "requests": {"type": "array", "items": {"type": "string"}},
                    "success_regex": {"type": "string"},
                    "failure_regex": {"type": "string"}
                }
            ),
            BurpExtension(
                name="Multi-TOTP Authenticator",
                type=BurpExtensionType.BAPP,
                description="Generate and inject TOTP codes into requests",
                features=[
                    "Auto-refresh TOTP codes",
                    "Regex-based injection",
                    "Scanner integration",
                    "Repeater integration",
                    "Multiple secrets management"
                ],
                install_path="https://github.com/portswigger/multi-totp-authenticator",
                config_schema={
                    "secrets": {"type": "array", "items": {"type": "object"}},
                    "match_string": {"type": "string"},
                    "use_regex": {"type": "bool", "default": False}
                }
            ),
            BurpExtension(
                name="Google Authenticator 2FA",
                type=BurpExtensionType.BAPP,
                description="Auto-apply Google 2FA codes to requests",
                features=[
                    "Real-time code generation",
                    "Session handling rules",
                    "Parameter/Header/Cookie injection",
                    "Scope configuration"
                ],
                install_path="https://github.com/portswigger/google-authenticator",
                config_schema={
                    "shared_secret": {"type": "string"},
                    "regex": {"type": "string"},
                    "rule_type": {"type": "select", "options": ["HEADER", "PARAMETER", "COOKIE"]}
                }
            ),
            BurpExtension(
                name="Twilio OTP Authenticator",
                type=BurpExtensionType.BAPP,
                description="Inject Twilio-generated OTPs into requests",
                features=[
                    "Dynamic OTP generation",
                    "Session handling integration",
                    "Configurable phone numbers",
                    "Scanner support"
                ],
                install_path="https://portswigger.net/bappstore/164f1ad7f29b47748feeb2f8c0d23b14",
                config_schema={
                    "account_sid": {"type": "string"},
                    "auth_token": {"type": "string"},
                    "from_number": {"type": "string"},
                    "to_number": {"type": "string"}
                }
            ),
            BurpExtension(
                name="Active Scan++",
                type=BurpExtensionType.BAPP,
                description="Enhanced active scanning capabilities",
                features=[
                    "Additional vulnerability checks",
                    "Custom scan checks",
                    "Improved detection logic",
                    "Reduced false positives"
                ],
                install_path="https://portswigger.net/bappstore/18",
                config_schema={}
            ),
            BurpExtension(
                name="Software Vulnerability Scanner",
                type=BurpExtensionType.BAPP,
                description="Automated scanning for known software vulnerabilities",
                features=[
                    "CVE detection",
                    "Version fingerprinting",
                    "Component analysis",
                    "Report generation"
                ],
                install_path="https://portswigger.net/bappstore/18",
                config_schema={}
            ),
            BurpExtension(
                name="HackBar",
                type=BurpExtensionType.BAPP,
                description="Quick payload crafting and testing toolbar",
                features=[
                    "Common payloads",
                    "Encoding/decoding",
                    "Hash generation",
                    "SQLi/XSS payloads"
                ],
                install_path="https://portswigger.net/bappstore",
                config_schema={}
            ),
            BurpExtension(
                name="Burp Sequencer",
                type=BurpExtensionType.BAPP,
                description="Analyze randomness of session tokens and cookies",
                features=[
                    "Entropy analysis",
                    "Character-level analysis",
                    "Bit-level analysis",
                    "FIPS 140-2 compliance"
                ],
                install_path="builtin",
                config_schema={
                    "sample_size": {"type": "int", "default": 10000},
                    "significance_level": {"type": "float", "default": 0.05}
                }
            )
        ]
    
    def get_bambdas_by_category(self, category: str) -> List[BurpBambda]:
        """Get all bambdas for a specific category"""
        return [b for b in self.bambdas if b.category == category]
    
    def get_bambda(self, name: str) -> Optional[BurpBambda]:
        """Get a specific bambda by name"""
        for b in self.bambdas:
            if b.name == name:
                return b
        return None
    
    def get_turbo_script(self, name: str) -> Optional[str]:
        """Get a Turbo Intruder script by name"""
        return self.turbo_intruder_scripts.get(name)
    
    def get_all_turbo_scripts(self) -> Dict[str, str]:
        """Get all Turbo Intruder scripts"""
        return self.turbo_intruder_scripts.copy()
    
    def get_extension(self, name: str) -> Optional[BurpExtension]:
        """Get extension by name"""
        for ext in self.extensions:
            if ext.name == name:
                return ext
        return None
    
    def get_all_extensions(self) -> List[BurpExtension]:
        """Get all registered extensions"""
        return self.extensions.copy()
    
    def generate_burp_config(self) -> Dict:
        """Generate a complete Burp Suite configuration"""
        return {
            "bambdas": {
                "custom_actions": [b.name for b in self.get_bambdas_by_category("custom_actions")],
                "custom_columns": [b.name for b in self.get_bambdas_by_category("custom_columns")],
                "custom_scans": [b.name for b in self.get_bambdas_by_category("custom_scans")],
                "logger_filters": [b.name for b in self.get_bambdas_by_category("logger_filters")],
                "proxy_filters": [b.name for b in self.get_bambdas_by_category("proxy_filters")],
                "sitemap_filters": [b.name for b in self.get_bambdas_by_category("sitemap_filters")],
                "request_match_replace": [b.name for b in self.get_bambdas_by_category("request_match_replace")],
                "response_match_replace": [b.name for b in self.get_bambdas_by_category("response_match_replace")]
            },
            "turbo_intruder_scripts": list(self.turbo_intruder_scripts.keys()),
            "auth_matrix_configs": self.auth_matrix_configs,
            "totp_configs": self.totp_configs,
            "extensions": [
                {
                    "name": ext.name,
                    "type": ext.type.value,
                    "description": ext.description,
                    "features": ext.features,
                    "install_path": ext.install_path
                }
                for ext in self.extensions
            ]
        }
    
    def export_bambda(self, name: str, output_path: str) -> bool:
        """Export a bambda to a file"""
        bambda = self.get_bambda(name)
        if bambda:
            with open(output_path, 'w') as f:
                f.write(bambda.code)
            return True
        return False
    
    def export_all_bambdas(self, output_dir: str) -> int:
        """Export all bambdas to a directory"""
        os.makedirs(output_dir, exist_ok=True)
        count = 0
        for bambda in self.bambdas:
            category_dir = os.path.join(output_dir, bambda.category)
            os.makedirs(category_dir, exist_ok=True)
            filepath = os.path.join(category_dir, f"{bambda.name}.bambda")
            with open(filepath, 'w') as f:
                f.write(bambda.code)
            count += 1
        return count
    
    def run_turbo_intruder(self, script_name: str, target_url: str, 
                           request_template: str, wordlist: List[str] = None) -> Dict:
        """Execute a Turbo Intruder attack (requires Burp Suite)"""
        script = self.get_turbo_script(script_name)
        if not script:
            return {"error": f"Script {script_name} not found"}
        
        # This would integrate with Burp Suite's Turbo Intruder
        # For now, return the script for manual execution
        return {
            "script": script,
            "target": target_url,
            "template": request_template,
            "wordlist": wordlist or [],
            "instructions": "Copy this script to Turbo Intruder in Burp Suite and execute"
        }


# Global integrator instance
_burp_integrator = None

def get_burp_integrator(base_path: str = None) -> BurpSuiteIntegrator:
    """Get or create the global Burp Suite integrator"""
    global _burp_integrator
    if _burp_integrator is None:
        _burp_integrator = BurpSuiteIntegrator(base_path or "/home/dfat/Downloads/MITM_PRO_AI")
    return _burp_integrator


if __name__ == "__main__":
    integrator = get_burp_integrator()
    config = integrator.generate_burp_config()
    print(json.dumps(config, indent=2))