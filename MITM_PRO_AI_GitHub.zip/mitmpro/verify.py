"""Advanced anti-hallucination and logic-consistency verification for MITMPro-AI.

Two independent layers run on every assistant answer:

  1. DETERMINISTIC GROUNDING CHECK
     Extracts every MITMPro module / tool / command the model *named* and
     verifies it literally exists in ``APP_KNOWLEDGE`` (the ground-truth
     documentation string). Anything referenced but absent is flagged so the
     assistant can never invent modules, buttons, flags, tabs or endpoints.

  2. LLM LOGIC-CONSISTENCY PASS
     A strict second model call asks the model to detect self-contradictions,
     invalid commands, and unverifiable claims. This catches logically broken
     or internally inconsistent guidance that a single grounding scan misses.

Both layers are deterministic-or-model-backed, never crash the caller, and
degrade gracefully (returning no flags) if something goes wrong.
"""
import re
from mitmpro.knowledge import APP_KNOWLEDGE


# --------------------------------------------------------------------------- #
# 1. Deterministic grounding
# --------------------------------------------------------------------------- #
_KNOWN = APP_KNOWLEDGE.lower()

# Canonical module titles parsed from the "=== MODULE N: TITLE ===" headers.
_MODULE_TITLES = set()
for _m in re.finditer(r"=== MODULE \s*\d+\s*:\s*([A-Za-z0-9 /()\-]+?) ===", APP_KNOWLEDGE):
    _t = _m.group(1).strip().lower()
    _MODULE_TITLES.add(_t)
    _MODULE_TITLES.add(_t.split("(")[0].strip())

# Single-token tool / product names that MUST be grounded.
_TOOL_TOKENS = {
    "websploit", "mitmproxy", "burp", "burpsuite", "ollama", "nmap", "sqlmap",
    "masscan", "zap", "owasp", "scapy", "bettercap", "ettercap", "sslstrip",
    "evilginx", "phishtool", "gophish", "blackphish", "cyberphish", "phishbait",
    "mitmui", "mitm-ui", "yoshirio", "yorishiro", "datajackproxy", "datajack",
    "mitm_intercept", "nsniffer", "pt-mitm", "dlp", "oast", "collaborator",
    "wireshark", "tcpdump", "arpspoof", "dsniff", "responder", "impacket",
}

# Phrases that, when followed by "MITMPro", denote an invented feature if the
# remainder is not in the docs.
_INVENTED_HINTS = ("mitmpro-", "mitmpro pro", "mitmpro-pro", "mitmpro scanner",
                   "mitmpro exploit", "mitmpro toolkit", "mitmpro engine")


def _referenced_candidates(text):
    """Yield candidate module/tool/command strings named in the answer."""
    cands = set()
    # MODULE N references (must be within the real range).
    for m in re.finditer(r"MODULE\s+(\d+)", text, re.IGNORECASE):
        cands.add(("module_ref", int(m.group(1))))
    # Quoted identifiers ('...', "..." , `...`) that look like names.
    for m in re.finditer(r"['\"`]([A-Za-z][A-Za-z0-9 /_\-]{2,40})['\"`]", text):
        cands.add(("quoted", m.group(1).strip()))
    # "MITMPro <Word>" feature claims.
    for m in re.finditer(r"MITMPro[- ]+([A-Za-z][A-Za-z0-9 ]{2,30})", text):
        cands.add(("mitmpro_feat", m.group(1).strip()))
    # Capitalized multi-word phrases resembling a module/tool name.
    for m in re.finditer(r"\b([A-Z][A-Za-z0-9]+(?:\s+[A-Z][A-Za-z0-9]+){1,3})\b", text):
        cands.add(("cap_phrase", m.group(1).strip()))
    return cands


def grounding_flags(text):
    """Return a list of human-readable grounding violations (empty if clean)."""
    flags = []
    try:
        seen = set()
        for kind, val in _referenced_candidates(text):
            if kind == "module_ref":
                if val < 1 or val > 21:
                    msg = f"references non-existent MODULE {val} (valid range 1-21)"
                    if msg not in seen:
                        seen.add(msg); flags.append(msg)
                continue
            low = val.lower()
            if any(h in low for h in _INVENTED_HINTS):
                msg = f"references invented MITMPro feature '{val}'"
                if msg not in seen:
                    seen.add(msg); flags.append(msg)
                continue
            # Tool-token grounding: a known tool token must not be claimed as a
            # brand-new MITMPro module unless it actually appears in the docs.
            if kind == "quoted" and low in _TOOL_TOKENS and low not in _KNOWN:
                msg = f"references tool '{val}' not present in MITMPro docs"
                if msg not in seen:
                    seen.add(msg); flags.append(msg)
                continue
# Module title grounding: a capitalized phrase that matches a known
            # module title fragment is fine; otherwise only flag if it is a
            # clear module-style claim (contains 'Panel'/'Engine'/'Module'/'Tab'/'Toolkit'/'Assistant').
            if kind in ("cap_phrase", "mitmpro_feat", "quoted"):
                looks_like_module = any(
                    k in low for k in ("panel", "engine", "module", "tab", "toolkit", "assistant"))
                if looks_like_module and low not in _KNOWN and low not in _MODULE_TITLES:
                    msg = f"references unverified module/tool '{val}'"
                    if msg not in seen:
                        seen.add(msg); flags.append(msg)
    except Exception:
        # Never let verification break the assistant.
        pass
    return flags


# --------------------------------------------------------------------------- #
# 2. LLM logic-consistency pass
# --------------------------------------------------------------------------- #
def logic_flags(model, answer, host=None, timeout=20):
    """Strict second-pass check for contradictions, invalid commands and
    unverifiable claims. Returns a list of violation strings (empty if clean)."""
    flags = []
    try:
        import json
        import urllib.request
        import urllib.parse
        from mitmpro.ai_core import _ollama_chat_url
        probe = (
            "You are a senior technical reviewer for the MITMPro security "
            "assistant. Critically audit the ANSWER below against the MITMPro "
            "tool documentation already in your context. Reply with at most 5 "
            "bullet lines. For each problem output 'ISSUE: <short reason>'. "
            "Only report REAL problems: (a) self-contradictions, (b) commands "
            "that would fail or are syntactically wrong, (c) claims that cannot "
            "be verified from the documentation, (d) steps in the wrong order. "
            "If the answer is sound, reply exactly 'CONSISTENT'.\n\nANSWER:\n"
            + answer[:4000])
        payload = json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": probe}],
            "stream": False,
            "options": {"temperature": 0.0},
        }).encode()
        req = urllib.request.Request(
            _ollama_chat_url(host), data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        verdict = data.get("message", {}).get("content", "").strip()
        if verdict and "CONSISTENT" not in verdict.upper():
            for line in verdict.splitlines():
                line = line.strip(" -•*\t").strip()
                if line:
                    flags.append(line[:160])
    except Exception:
        # Graceful: if the model is unreachable, skip the logic pass.
        pass
    return flags
