"""Advanced AI Auto-Run Panel for MITMPro.

Provides a full UI for the AutoRun engine with:
  - Goal input and AI plan generation
  - Pre-built plan templates for common assessments
  - Real-time step-by-step execution display with status indicators
  - Progress bar showing overall completion
  - Error details and retry status
  - Stop/Pause/Resume/Skip controls
  - Plan history browser with save/load
  - Custom plan editor (manual step addition)
"""
import threading
import json
import time
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog
import copy

from mitmpro import common
from mitmpro.ai_components import AIHelperTab
from mitmpro.autorun_engine import (
    STATUS_PENDING, STATUS_RUNNING, STATUS_COMPLETED,
    STATUS_FAILED, STATUS_SKIPPED, STATUS_RETRYING,
    ON_ERROR_SKIP, ON_ERROR_RETRY, ON_ERROR_ABORT,
    TOOL_REGISTRY, PLAN_TEMPLATES,
)


class AutoRunPanel(ttk.Notebook):
    def __init__(self, master, app_instance):
        super().__init__(master)
        self.app = app_instance

        # --- Main Tab ---
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="AI Auto-Run")

        # --- Manual Plan Tab ---
        self.manual_frame = ttk.Frame(self)
        self.add(self.manual_frame, text="Manual Plan")

        # --- History Tab ---
        self.history_frame = ttk.Frame(self)
        self.add(self.history_frame, text="History")

        # --- AI Helper Tab ---
        self.add(AIHelperTab(self, "AI Auto-Run"), text="AI Helper")

        self._build_main_tab()
        self._build_manual_tab()
        self._build_history_tab()

        # Wire up engine callbacks
        engine = self.app.autorun_engine
        engine.set_progress_callback(self._on_progress)
        engine.set_step_callback(self._on_step_update)
        engine.set_plan_callback(self._on_plan_built)

    # ============================================================= MAIN TAB
    def _build_main_tab(self):
        f = self.main_frame
        f.columnconfigure(0, weight=1)
        f.rowconfigure(3, weight=1)

        # -- Ollama model header (consistent with other AI panels) --
        hdr = ttk.Frame(f)
        hdr.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 0))
        ttk.Label(hdr, text="Ollama Model:").pack(side="left")
        self.model_combo = ttk.Combobox(hdr, width=26, state="readonly")
        self.model_combo.pack(side="left", padx=4)
        self.model_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: common.set_model(self.model_combo.get()))
        ttk.Button(hdr, text="Refresh Models",
                   command=self._load_models).pack(side="left", padx=4)
        common.register_model_listener(self._on_global_model)
        self._load_models()

        # -- Beginner help banner --
        help_frame = ttk.LabelFrame(f, text="\U0001f9e0 What is this?")
        help_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        ttk.Label(
            help_frame,
            text=("Describe what you want to achieve in plain English and the AI "
                  "will build a step-by-step plan, then run the tools for you. "
                  "You don't need to know which tool to use — just state your goal."),
            wraplength=760, justify="left").grid(row=0, column=0, sticky="w", padx=6, pady=4)

        # -- Example goal chips --
        ex_frame = ttk.Frame(help_frame)
        ex_frame.grid(row=1, column=0, sticky="ew", padx=6, pady=(0, 6))
        ttk.Label(ex_frame, text="Examples:").grid(row=0, column=0, sticky="w")
        examples = [
            "Scan example.com for XSS and try a WAF bypass",
            "ARP spoof the network and capture credentials",
            "Clone login.microsoft.com and send a phishing email",
            "Test how well our WAF blocks SQL injection",
        ]
        for i, ex in enumerate(examples):
            b = ttk.Button(
                ex_frame, text=ex, width=48,
                command=lambda g=ex: self._use_example(g))
            b.grid(row=(i // 2) + 1, column=(i % 2), padx=4, pady=2, sticky="w")

        # -- Goal input row --
        goal_row = ttk.Frame(f)
        goal_row.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        goal_row.columnconfigure(1, weight=1)
        ttk.Label(goal_row, text="Goal:").grid(row=0, column=0)
        self.goal_entry = ttk.Entry(goal_row)
        self.goal_entry.grid(row=0, column=1, sticky="ew")
        self.goal_entry.insert(0, "Scan target for XSS and then try to bypass the WAF")
        self.run_btn = ttk.Button(
            goal_row, text="\U0001f680 Execute AI Plan",
            command=lambda: threading.Thread(
                target=self._run_ai_plan, daemon=True).start())
        self.run_btn.grid(row=0, column=2, padx=5)

        # -- Template row --
        tpl_row = ttk.Frame(f)
        tpl_row.grid(row=3, column=0, sticky="ew", padx=4, pady=2)
        ttk.Label(tpl_row, text="Template:").grid(row=0, column=0)
        self.tpl_var = tk.StringVar()
        self.tpl_combo = ttk.Combobox(
            tpl_row, textvariable=self.tpl_var,
            values=list(PLAN_TEMPLATES.keys()), width=30)
        self.tpl_combo.grid(row=0, column=1, padx=4)
        ttk.Button(tpl_row, text="Load Template",
                   command=self._load_template).grid(row=0, column=2, padx=4)
        ttk.Button(tpl_row, text="Save Plan",
                   command=self._save_plan).grid(row=0, column=3, padx=4)
        ttk.Button(tpl_row, text="Load Plan",
                   command=self._load_plan).grid(row=0, column=4, padx=4)

        # -- Controls row --
        ctrl_row = ttk.Frame(f)
        ctrl_row.grid(row=4, column=0, sticky="ew", padx=4, pady=2)
        self.stop_btn = ttk.Button(ctrl_row, text="Stop",
                                   command=self._stop, state="disabled")
        self.stop_btn.grid(row=0, column=0, padx=4)
        self.pause_btn = ttk.Button(ctrl_row, text="Pause",
                                    command=self._pause, state="disabled")
        self.pause_btn.grid(row=0, column=1, padx=4)
        self.resume_btn = ttk.Button(ctrl_row, text="Resume",
                                     command=self._resume, state="disabled")
        self.resume_btn.grid(row=0, column=2, padx=4)
        self.skip_btn = ttk.Button(ctrl_row, text="Skip Step",
                                   command=self._skip, state="disabled")
        self.skip_btn.grid(row=0, column=3, padx=4)

        # -- Progress bar --
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(
            f, variable=self.progress_var, maximum=100)
        self.progress_bar.grid(row=5, column=0, sticky="ew", padx=4, pady=1)

        self.progress_lbl = ttk.Label(f, text="0 / 0 steps (0%)")
        self.progress_lbl.grid(row=6, column=0, sticky="w", padx=4)

        # -- Step list (Treeview) --
        step_frame = ttk.LabelFrame(f, text="Execution Steps")
        step_frame.grid(row=7, column=0, sticky="nsew", padx=4, pady=4)
        step_frame.columnconfigure(0, weight=1)
        step_frame.rowconfigure(0, weight=1)
        f.rowconfigure(7, weight=1)

        cols = ("Step", "Status", "Tool", "Action", "Description", "Duration")
        self.step_tree = ttk.Treeview(
            step_frame, columns=cols, show="headings", height=10)
        for c in cols:
            self.step_tree.heading(c, text=c)
        self.step_tree.column("Step", width=50)
        self.step_tree.column("Status", width=90)
        self.step_tree.column("Tool", width=100)
        self.step_tree.column("Action", width=120)
        self.step_tree.column("Description", width=250)
        self.step_tree.column("Duration", width=80)
        self.step_tree.grid(row=0, column=0, sticky="nsew")
        self.step_tree.bind("<<TreeviewSelect>>", self._on_step_select)

        scroll = ttk.Scrollbar(step_frame, orient="vertical",
                               command=self.step_tree.yview)
        self.step_tree.configure(yscrollcommand=scroll.set)
        scroll.grid(row=0, column=1, sticky="ns")

        # -- Error details --
        self.error_text = scrolledtext.ScrolledText(
            f, height=5, bg="#1c1c1c", fg="#f85149",
            font=("Courier", 10), state="disabled")
        self.error_text.grid(row=8, column=0, sticky="ew", padx=4, pady=4)

        # -- Log output --
        log_frame = ttk.LabelFrame(f, text="Execution Log")
        log_frame.grid(row=9, column=0, sticky="nsew", padx=4, pady=4)
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        f.rowconfigure(9, weight=1)

        self.log_text = scrolledtext.ScrolledText(
            log_frame, height=12, bg="black", fg="lightgreen",
            font=("Courier", 10), state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew")

        # Status colors for treeview
        self.step_tree.tag_configure(STATUS_PENDING, foreground="#8b949e")
        self.step_tree.tag_configure(STATUS_RUNNING, foreground="#58a6ff")
        self.step_tree.tag_configure(STATUS_COMPLETED, foreground="#3fb950")
        self.step_tree.tag_configure(STATUS_FAILED, foreground="#f85149")
        self.step_tree.tag_configure(STATUS_SKIPPED, foreground="#d29922")
        self.step_tree.tag_configure(STATUS_RETRYING, foreground="#d2a8ff")

    # ========================================================== MODEL HEADER
    def _load_models(self):
        try:
            models = common.ollama_models()
        except Exception:
            models = []
        self.model_combo["values"] = models
        if models:
            sel = common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0]
            self.model_combo.set(sel)

    def _on_global_model(self, model):
        try:
            if model and model in (self.model_combo["values"] or ()):
                self.model_combo.set(model)
        except Exception:
            pass

    # ========================================================== EXAMPLE CHIPS
    def _use_example(self, goal):
        self.goal_entry.delete(0, "end")
        self.goal_entry.insert(0, goal)
        threading.Thread(target=self._run_ai_plan, daemon=True).start()

    # ========================================================== MANUAL TAB
    def _build_manual_tab(self):
        f = self.manual_frame
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        ttk.Label(f, text="Manual Step Builder",
                  font=("Segoe UI", 12, "bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=8)

        # Step builder form
        form = ttk.Frame(f)
        form.grid(row=1, column=0, sticky="ew", padx=8, pady=4)
        form.columnconfigure(1, weight=1)
        form.columnconfigure(3, weight=1)

        ttk.Label(form, text="Tool:").grid(row=0, column=0, sticky="w")
        self.m_tool = ttk.Combobox(
            form, values=list(TOOL_REGISTRY.keys()), width=20)
        self.m_tool.grid(row=0, column=1, sticky="w", padx=4)
        self.m_tool.bind("<<ComboboxSelected>>", self._on_tool_select)

        ttk.Label(form, text="Action:").grid(row=0, column=2, sticky="w")
        self.m_action = ttk.Combobox(form, width=20)
        self.m_action.grid(row=0, column=3, sticky="w", padx=4)

        ttk.Label(form, text="Params (JSON):").grid(
            row=1, column=0, sticky="w")
        self.m_params = ttk.Entry(form)
        self.m_params.grid(row=1, column=1, columnspan=3, sticky="ew", padx=4)
        self.m_params.insert(0, '{"url": "https://example.com"}')

        ttk.Label(form, text="On Error:").grid(row=2, column=0, sticky="w")
        self.m_on_error = ttk.Combobox(
            form, values=[ON_ERROR_SKIP, ON_ERROR_RETRY, ON_ERROR_ABORT],
            width=15)
        self.m_on_error.set(ON_ERROR_SKIP)
        self.m_on_error.grid(row=2, column=1, sticky="w", padx=4)

        ttk.Label(form, text="Description:").grid(
            row=2, column=2, sticky="w")
        self.m_desc = ttk.Entry(form)
        self.m_desc.grid(row=2, column=3, sticky="w", padx=4)
        self.m_desc.insert(0, "Manual step")

        btn_row = ttk.Frame(f)
        btn_row.grid(row=2, column=0, sticky="ew", padx=8, pady=4)
        ttk.Button(btn_row, text="Add Step",
                   command=self._add_manual_step).pack(side="left", padx=4)
        ttk.Button(btn_row, text="Clear All",
                   command=self._clear_manual_steps).pack(side="left", padx=4)
        ttk.Button(btn_row, text="Execute Plan",
                   command=self._execute_manual_plan).pack(side="left", padx=4)

        # Manual step list
        self.manual_tree = ttk.Treeview(
            f, columns=("Step", "Tool", "Action", "Params", "On Error"),
            show="headings", height=10)
        for c in ("Step", "Tool", "Action", "Params", "On Error"):
            self.manual_tree.heading(c, text=c)
        self.manual_tree.column("Step", width=50)
        self.manual_tree.column("Tool", width=100)
        self.manual_tree.column("Action", width=120)
        self.manual_tree.column("Params", width=250)
        self.manual_tree.column("On Error", width=90)
        self.manual_tree.grid(row=3, column=0, sticky="nsew", padx=8, pady=4)
        f.rowconfigure(3, weight=1)

        self._manual_steps = []

    # ========================================================= HISTORY TAB
    def _build_history_tab(self):
        f = self.history_frame
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)

        ttk.Label(f, text="Plan Execution History",
                  font=("Segoe UI", 12, "bold")).grid(
            row=0, column=0, sticky="w", padx=8, pady=8)

        ttk.Button(f, text="Refresh", command=self._refresh_history).grid(
            row=0, column=1, padx=8)

        self.hist_tree = ttk.Treeview(
            f, columns=("Time", "Steps", "Completed", "Failed"),
            show="headings", height=12)
        for c in ("Time", "Steps", "Completed", "Failed"):
            self.hist_tree.heading(c, text=c)
        self.hist_tree.column("Time", width=180)
        self.hist_tree.column("Steps", width=80)
        self.hist_tree.column("Completed", width=100)
        self.hist_tree.column("Failed", width=80)
        self.hist_tree.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        self.hist_tree.bind("<<TreeviewSelect>>", self._on_history_select)

        self.hist_detail = scrolledtext.ScrolledText(
            f, height=10, state="disabled", font=("Courier", 10))
        self.hist_detail.grid(row=2, column=0, sticky="nsew", padx=8, pady=4)
        f.rowconfigure(2, weight=1)

    # ======================================================== CALLBACKS
    def _on_progress(self, completed, total, percent):
        def update():
            self.progress_var.set(percent)
            self.progress_lbl.config(
                text=f"{completed} / {total} steps ({percent:.0f}%)")
        self.after(0, update)

    def _on_step_update(self, step):
        def update():
            iid = str(step.index)
            if not self.step_tree.exists(iid):
                self.step_tree.insert("", "end", iid=iid, values=(
                    step.index, STATUS_PENDING, step.tool, step.action,
                    step.desc, ""), tags=(STATUS_PENDING,))
            dur = f"{step.duration:.1f}s" if step.duration else ""
            self.step_tree.item(iid, values=(
                step.index, step.status, step.tool,
                step.action, step.desc, dur),
                tags=(step.status,))
            engine = self.app.autorun_engine
            running = engine.is_running
            paused = engine.is_paused
            self._update_buttons(running, paused)
        self.after(0, update)

    def _on_plan_built(self, steps):
        def update():
            self._clear_step_tree()
            for ss in steps:
                iid = str(ss.index)
                dur = f"{ss.duration:.1f}s" if ss.duration else ""
                self.step_tree.insert("", "end", iid=iid, values=(
                    ss.index, ss.status, ss.tool, ss.action, ss.desc, dur),
                    tags=(ss.status,))
        self.after(0, update)

    def _update_buttons(self, running, paused):
        state_normal = "normal" if running else "disabled"
        state_pause = "normal" if running and not paused else "disabled"
        state_resume = "normal" if running else "disabled"
        self.stop_btn.config(state=state_normal)
        self.pause_btn.config(state=state_pause)
        self.resume_btn.config(state=state_resume)
        self.skip_btn.config(state=state_resume if paused else state_normal)
        self.run_btn.config(
            state="disabled" if running else "normal")

    def _on_step_select(self, event):
        sel = self.step_tree.selection()
        if not sel:
            return
        iid = sel[0]
        try:
            idx = int(iid)
            ss = self.app.autorun_engine.get_step_state(idx)
            if ss:
                self.error_text.config(state="normal")
                self.error_text.delete("1.0", "end")
                info = f"Step {ss.index}: {ss.tool}.{ss.action}\n"
                info += f"Status: {ss.status}\n"
                info += f"Description: {ss.desc}\n"
                info += f"Params: {json.dumps(ss.params, indent=2)}\n"
                info += f"On Error: {ss.on_error}\n"
                info += f"Retries: {ss.retries}/{ss.max_retries}\n"
                if ss.error:
                    info += f"Error: {ss.error}\n"
                if ss.result:
                    info += f"Result: {ss.result}\n"
                self.error_text.insert("1.0", info)
                self.error_text.config(state="disabled")
        except (ValueError, IndexError):
            pass

    # ======================================================== AI PLAN
    def _run_ai_plan(self):
        goal = self.goal_entry.get().strip()
        if not goal:
            return

        self.after(0, lambda: self._clear_step_tree())
        self.after(0, lambda: self._set_buttons_running())
        result = self.app.autorun_engine.execute_goal(
            goal, context="AutoRun")
        self.after(0, lambda: self.log(result))

    def _set_buttons_running(self):
        self.stop_btn.config(state="normal")
        self.pause_btn.config(state="normal")
        self.resume_btn.config(state="disabled")
        self.skip_btn.config(state="disabled")
        self.run_btn.config(state="disabled")

    # ======================================================== TEMPLATE
    def _load_template(self, name=None, target=None, campaign=None):
        """Load and execute a built-in template plan.

        Interactive (button) use prompts for a target via a dialog. Programmatic
        callers (tests / AutoRun) can pass ``name``, ``target`` and ``campaign``
        directly to skip all dialogs."""
        programmatic = target is not None
        name = name or self.tpl_var.get()
        if not name:
            messagebox.showinfo("Info", "Select a template first.")
            return
        tpl = self.app.autorun_engine.get_template(name)
        if not tpl:
            return

        # Prompt for the target used to substitute TARGET_* placeholders
        if target is None:
            target = simpledialog.askstring(
                "Target Required",
                f"Template '{name}' needs a target.\n"
                "Enter the target host or URL\n"
                "(e.g. example.com or https://example.com):",
                initialvalue="https://example.com")
            if target is None:
                return
        target = target.strip()
        if not target:
            messagebox.showerror("Error", "A target is required.")
            return
        if campaign is None and not programmatic:
            campaign = simpledialog.askstring(
                "Campaign Name (optional)",
                "Enter a campaign name (replaces TARGET_CAMPAIGN):",
                initialvalue="AutoRun_Campaign")
        if campaign is None:
            campaign = "AutoRun_Campaign"

        # Apply the SAME substitution the heuristic path uses, then fill in
        # any remaining placeholders (campaign name, TARGET_URL, etc.)
        steps = self.app.autorun_engine._substitute_target(
            copy.deepcopy(tpl["steps"]), target)
        steps = self._substitute_placeholders(steps, target, campaign)

        self._clear_step_tree()
        for i, step in enumerate(steps):
            iid = str(i)
            self.step_tree.insert("", "end", iid=iid, values=(
                i, STATUS_PENDING, step.get("tool", ""),
                step.get("action", ""), step.get("desc", ""), ""),
                tags=(STATUS_PENDING,))
        self.goal_entry.delete(0, "end")
        self.goal_entry.insert(0, tpl["description"])
        # Execute the (substituted) template plan
        self.after(100, lambda: self._execute_template_plan(steps))

    def _substitute_placeholders(self, steps, target, campaign=None):
        """Substitute TARGET_HOST/TARGET_SITE/TARGET_URL/TARGET_CAMPAIGN and
        GATEWAY_IP/LOCAL_IP in string params."""
        import re as _re
        try:
            from mitmpro.autorun_engine import AutoRunEngine
            local_ip, gateway = AutoRunEngine._local_network()
        except Exception:
            local_ip, gateway = "", ""
        url = target
        if not _re.match(r"https?://", url):
            url = "https://" + url
        host = url.split("//", 1)[-1].split("/", 1)[0]
        for s in steps:
            p = s.get("params", {})
            for k, v in list(p.items()):
                if not isinstance(v, str):
                    continue
                if "TARGET_HOST" in v:
                    p[k] = v.replace("TARGET_HOST", host)
                if "TARGET_SITE" in v:
                    p[k] = v.replace("TARGET_SITE", url)
                if "TARGET_URL" in v:
                    p[k] = v.replace("TARGET_URL", url)
                if "TARGET_CAMPAIGN" in v and campaign:
                    p[k] = v.replace("TARGET_CAMPAIGN", campaign)
                if "GATEWAY_IP" in v and gateway:
                    p[k] = v.replace("GATEWAY_IP", gateway)
                if "LOCAL_IP" in v and local_ip:
                    p[k] = v.replace("LOCAL_IP", local_ip)
        return steps

    def _execute_template_plan(self, steps):
        self._set_buttons_running()
        result = self.app.autorun_engine.execute_plan(steps)
        self.after(0, lambda: self.log(result))

    # ======================================================== SAVE/LOAD
    def _save_plan(self):
        engine = self.app.autorun_engine
        if not engine.step_states:
            messagebox.showinfo("Info", "No active plan to save.")
            return
        from tkinter import filedialog
        p = filedialog.asksaveasfilename(
            defaultextension=".json",
            title="Save Plan",
            filetypes=[("JSON", "*.json")])
        if p:
            data = [ss.to_dict() for ss in engine.step_states]
            with open(p, "w") as f:
                json.dump(data, f, indent=2, default=str)
            messagebox.showinfo("Saved", f"Plan saved to {p}")

    def _load_plan(self):
        from tkinter import filedialog
        p = filedialog.askopenfilename(
            filetypes=[("JSON", "*.json")],
            title="Load Plan")
        if not p:
            return
        try:
            with open(p) as f:
                data = json.load(f)
            if not isinstance(data, list):
                messagebox.showerror("Error", "Invalid plan format.")
                return
            self._clear_step_tree()
            for i, step in enumerate(data):
                iid = str(i)
                self.step_tree.insert("", "end", iid=iid, values=(
                    i, STATUS_PENDING, step.get("tool", ""),
                    step.get("action", ""), step.get("desc", ""), ""),
                    tags=(STATUS_PENDING,))
            self._set_buttons_running()
            result = self.app.autorun_engine.execute_plan(data)
            self.after(0, lambda: self.log(result))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load plan: {e}")

    # ======================================================== CONTROLS
    def _stop(self):
        self.app.autorun_engine.stop()

    def _pause(self):
        self.app.autorun_engine.pause()
        self.after(0, lambda: self._update_buttons(True, True))

    def _resume(self):
        self.app.autorun_engine.resume()
        self.after(0, lambda: self._update_buttons(True, False))

    def _skip(self):
        self.app.autorun_engine.skip_step()

    # ======================================================== MANUAL PLAN
    def _on_tool_select(self, event):
        tool = self.m_tool.get()
        if tool in TOOL_REGISTRY:
            actions = list(TOOL_REGISTRY[tool].keys())
            self.m_action["values"] = actions
            if actions:
                self.m_action.set(actions[0])

    def _add_manual_step(self):
        tool = self.m_tool.get().strip()
        action = self.m_action.get().strip()
        params_str = self.m_params.get().strip()
        on_error = self.m_on_error.get()
        desc = self.m_desc.get().strip()

        if not tool or not action:
            messagebox.showerror("Error", "Tool and Action are required.")
            return

        try:
            params = json.loads(params_str) if params_str else {}
        except json.JSONDecodeError as e:
            messagebox.showerror("Error", f"Invalid JSON params: {e}")
            return

        idx = len(self._manual_steps)
        step = {
            "tool": tool,
            "action": action,
            "params": params,
            "desc": desc,
            "on_error": on_error,
        }
        self._manual_steps.append(step)
        self.manual_tree.insert("", "end", iid=str(idx), values=(
            idx, tool, action, params_str, on_error))

    def _clear_manual_steps(self):
        self._manual_steps.clear()
        self.manual_tree.delete(*self.manual_tree.get_children())

    def _execute_manual_plan(self):
        if not self._manual_steps:
            messagebox.showinfo("Info", "Add some steps first.")
            return
        self._clear_step_tree()
        self._set_buttons_running()
        result = self.app.autorun_engine.execute_plan(
            list(self._manual_steps))
        self.after(0, lambda: self.log(result))

    # ======================================================== HISTORY
    def _refresh_history(self):
        self.hist_tree.delete(*self.hist_tree.get_children())
        engine = self.app.autorun_engine
        for entry in engine.get_plan_history():
            self.hist_tree.insert("", "end", iid=str(entry["index"]),
                                  values=(
                                      entry["timestamp"],
                                      entry["total"],
                                      entry["completed"],
                                      entry["failed"]))

    def _on_history_select(self, event):
        sel = self.hist_tree.selection()
        if not sel:
            return
        try:
            idx = int(sel[0])
        except ValueError:
            return
        engine = self.app.autorun_engine
        steps = engine.get_plan_history_steps(idx)
        self.hist_detail.config(state="normal")
        self.hist_detail.delete("1.0", "end")
        for s in steps:
            status = s.get("status", "?")
            tool = s.get("tool", "?")
            action = s.get("action", "?")
            desc = s.get("desc", "")
            error = s.get("error", "")
            line = f"[{status}] {tool}.{action} - {desc}"
            if error:
                line += f"  ERROR: {error}"
            self.hist_detail.insert("end", line + "\n")
        self.hist_detail.config(state="disabled")

    # ======================================================== HELPERS
    def _clear_step_tree(self):
        self.step_tree.delete(*self.step_tree.get_children())
        self.progress_var.set(0)
        self.progress_lbl.config(text="0 / 0 steps (0%)")
        self.error_text.config(state="normal")
        self.error_text.delete("1.0", "end")
        self.error_text.config(state="disabled")

    def log(self, text):
        self.log_text.config(state="normal")
        self.log_text.insert("end", text + "\n")
        line_count = int(self.log_text.index("end-1c").split(".")[0])
        if line_count > 500:
            self.log_text.delete("1.0", f"{line_count - 400}.0")
        self.log_text.see("end")
        self.log_text.config(state="disabled")
