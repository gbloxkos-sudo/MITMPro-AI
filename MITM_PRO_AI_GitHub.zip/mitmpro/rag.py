"""Local RAG (Retrieval-Augmented Generation) for MITMPro.

Builds a searchable index from:
  * the MITMPro tool documentation (knowledge.APP_KNOWLEDGE),
  * every Python source file in the application package,
  * the user / sale guides,
  * the bundled tool READMEs (WebSploit, Ollama GUI, mitmnew, mitmproxy-ui).

Retrieval is a pure-Python BM25 ranker — it works fully offline, needs no model
downloads, and is fast for a corpus this size. This is what augments every AI
answer so the assistant cites real, retrieved MITMPro knowledge instead of
guessing.

A persistent index cache is stored under ~/.mitmpro/rag_index.json.
"""
import os
import re
import math
import json
import threading

from mitmpro import common
from mitmpro import logger
from mitmpro.knowledge import APP_KNOWLEDGE

INDEX_CACHE = os.path.join(os.path.expanduser("~/.mitmpro"), "rag_index.json")

_CHUNK = 700
_OVERLAP = 120
_K1 = 1.5
_B = 0.75

_TOKEN = re.compile(r"[a-z0-9_]{2,}")

# Text file extensions we crawl from bundled tool directories. Everything else
# (binaries, images, archives, lock files, etc.) is skipped to keep the index
# clean and fast.
_TEXT_EXT = {".py", ".md", ".txt", ".rst", ".ini", ".json", ".yml", ".yaml",
             ".cfg", ".conf", ".toml", ".lua", ".sh", ".go"}
_README_PREFIXES = ("readme",)

# Directory names to skip while crawling (heavy / generated / binary junk).
_SKIP_DIRS = {".git", "__pycache__", "node_modules", "dist", "build", ".venv",
              "venv", "env", ".idea", ".vscode", "vendor", "site-packages",
              ".pytest_cache", ".mypy_cache", "__pycache__", "assets",
              "certs", "images", "img"}

# Per-file byte ceiling — skip anything larger to avoid indexing huge junk
# (minified bundles, lock files, generated data blobs).
_MAX_FILE_BYTES = 300 * 1024

# Skip specific noisy generated files by (lowercase) name.
_SKIP_NAMES = {"package-lock.json", "yarn.lock", "poetry.lock", "go.sum",
               "pnpm-lock.yaml"}

# Real bundled tool directories (relative to the project root) that the AI must
# be able to answer about. These are crawled for text files so the assistant can
# cite the actual code, READMEs and module docs of every shipped tool.
_TOOL_DIRS = [
    ("websploit-4.0.4", "websploit"),
    ("mitm_tools/inline-dlp-proxy-main", "inline-dlp-proxy"),
    ("mitm_tools/Nsniffer-1.1.0", "nsniffer"),
    ("mitm_tools/PoC-Website-Masquerading-main", "masquerading"),
    ("mitm_tools/yorishiro-proxy-0.18.2", "yorishiro-proxy"),
    ("mitmnew/MITM_Intercept-main", "mitm-intercept"),
    ("mitmnew/MITM-master", "mitm"),
    ("mitmnew/DatajackProxy-master", "datajackproxy"),
    ("mitm-ui-0.1", "mitm-ui"),
    ("mitmproxy-ui-master", "mitmproxy-ui"),
    ("ollama-gui-1.2.2", "ollama-gui"),
    ("KPHISH_AI/BlackPhish-master", "blackphish"),
    ("KPHISH_AI/CyberPhish-master", "cyberphish"),
    ("KPHISH_AI/Phishbait-main", "phishbait"),
    ("pt-MitM-master", "pt-mitm"),
]

# Standalone bundled files worth indexing individually.
_TOOL_FILES = [
    ("intergration", "integration-notes"),
]


def _tok(text):
    return _TOKEN.findall(text.lower())


def _is_text_file(fn):
    low = fn.lower()
    if low in _SKIP_NAMES:
        return False
    _, ext = os.path.splitext(low)
    if ext in _TEXT_EXT:
        return True
    if low.startswith(_README_PREFIXES):
        return True
    if low in ("license", "license.txt", "notice", "changelog", "disclaimer"):
        return True
    return False


def _read_text(path):
    try:
        if os.path.getsize(path) > _MAX_FILE_BYTES:
            return None
        with open(path, encoding="utf-8", errors="ignore") as f:
            return f.read()
    except Exception as e:
        logger.log_exception(e, f"reading text file {path}")
        return None


def _doc_priority(fn):
    """Lower sorts first: docs before source so they win the per-tool budget."""
    low = fn.lower()
    _, ext = os.path.splitext(low)
    if low.startswith(_README_PREFIXES):
        return 0
    if ext in (".md", ".rst", ".txt"):
        return 1
    if ext in (".ini", ".cfg", ".conf", ".toml", ".yml", ".yaml", ".json"):
        return 2
    return 3


# Max chunks indexed per bundled tool directory. Keeps very large codebases
# (e.g. the Go yorishiro-proxy) from swamping the index while still capturing
# their docs and representative source.
_MAX_CHUNKS_PER_TOOL = 400


def _crawl_dir(root, label, docs, seen):
    """Walk a bundled tool directory and index its text files (docs first)."""
    if not os.path.isdir(root):
        return
    collected = []  # (priority, rel, path)
    try:
        for dirpath, dirnames, files in os.walk(root):
            dirnames[:] = [d for d in dirnames if d.lower() not in _SKIP_DIRS]
            for fn in sorted(files):
                if not _is_text_file(fn):
                    continue
                fp = os.path.join(dirpath, fn)
                collected.append((_doc_priority(fn), os.path.relpath(fp, root), fp))
    except Exception as e:
        logger.log_exception(e, f"crawling directory {root}")
    # docs first, then source, alphabetical within each priority
    collected.sort(key=lambda x: (x[0], x[1]))
    budget = _MAX_CHUNKS_PER_TOOL
    for _, rel, fp in collected:
        if budget <= 0:
            break
        try:
            real = os.path.abspath(fp)
            if real in seen:
                continue
            seen.add(real)
            text = _read_text(fp)
            if not text:
                continue
            chunks = _chunk_text(text, f"tool:{label}/{rel}")
            if len(chunks) > budget:
                chunks = chunks[:budget]
            docs += chunks
            budget -= len(chunks)
        except Exception as e:
            logger.log_exception(e, f"indexing file {fp}")

def _chunk_text(text, source):

    text = text.strip()
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(len(text), start + _CHUNK)
        piece = text[start:end].strip()
        if piece:
            chunks.append((piece, source))
        if end == len(text):
            break
        # try to break on a sentence/line boundary inside the window
        nxt = text.rfind("\n", start, end)
        if nxt <= start:
            nxt = text.rfind(". ", start, end)
        start = (nxt + 1) if nxt > start else end
    return chunks


def _collect_documents():
    docs = []  # (text, source_label)

    docs += _chunk_text(APP_KNOWLEDGE, "MITMPro Tool Docs")

    # application source
    pkg = os.path.dirname(os.path.abspath(__file__))
    for fn in sorted(os.listdir(pkg)):
        if fn.endswith(".py") and not fn.startswith("__"):
            try:
                with open(os.path.join(pkg, fn), encoding="utf-8", errors="ignore") as f:
                    docs += _chunk_text(f.read(), f"source:{fn}")
            except Exception:
                pass

    # guides (parent project dir)
    for g in ("USER_GUIDE.md", "SALE_GUIDE.md"):
        p = os.path.join(common.PROJECT_ROOT, g)
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8", errors="ignore") as f:
                    docs += _chunk_text(f.read(), f"guide:{g}")
            except Exception:
                pass

    # bundled tool READMEs
    candidates = [
        ("websploit-4.0.4/README.md", "websploit"),
        ("websploit-4.0.4/websploit/README.md", "websploit"),
        ("ollama-gui-1.2.2/README.md", "ollama-gui"),
        ("mitmproxy-ui-master/README.md", "mitmproxy-ui"),
    ]
    for rel, label in candidates:
        p = os.path.join(common.PROJECT_ROOT, rel)
        if os.path.isfile(p):
            try:
                with open(p, encoding="utf-8", errors="ignore") as f:
                    docs += _chunk_text(f.read(), f"readme:{label}")
            except Exception:
                pass
    # Full crawl of every bundled tool directory so the AI can answer about the
    # real code, READMEs and modules of all shipped tools (not just top-level
    # READMEs). Text files only, with junk/binary/lock files filtered out.
    seen = set()
    for rel, label in _TOOL_DIRS:
        _crawl_dir(os.path.join(common.PROJECT_ROOT, rel), label, docs, seen)

    # Standalone bundled files.
    for rel, label in _TOOL_FILES:
        p = os.path.join(common.PROJECT_ROOT, rel)
        if os.path.isfile(p):
            text = _read_text(p)
            if text:
                docs += _chunk_text(text, f"tool:{label}")

    return docs


class RAG:
    def __init__(self):
        self.lock = threading.Lock()
        self.docs = []
        self.df = {}
        self.idf = {}
        self.tfidf = []
        self.built = False
        self.avgdl = 0.0

    # ----------------------------------------------------------- indexing
    def build(self, force=False):
        if self.built and not force:
            return len(self.docs)
        with self.lock:
            cached = self._load_cache()
            if cached and not force:
                self.docs, self.df, self.idf, self.tfidf, self.avgdl = cached
                self.built = True
                return len(self.docs)
            docs = _collect_documents()
            df = {}
            tfidf = []
            total_len = 0
            for text, src in docs:
                toks = _tok(text)
                if not toks:
                    tfidf.append({})
                    continue
                tf = {}
                for t in toks:
                    tf[t] = tf.get(t, 0) + 1
                for t in tf:
                    df[t] = df.get(t, 0) + 1
                tfidf.append(tf)
                total_len += len(text.split())
            n = len(docs)
            idf = {t: math.log(1 + n / (c + 0.5)) for t, c in df.items()}
            self.docs = docs
            self.df = df
            self.idf = idf
            self.tfidf = tfidf
            self.avgdl = total_len / max(1, n)
            self.built = True
            self._save_cache()
            return len(self.docs)

    def _save_cache(self):
        try:
            os.makedirs(os.path.dirname(INDEX_CACHE), exist_ok=True)
            with open(INDEX_CACHE, "w", encoding="utf-8") as f:
                json.dump([self.docs, self.df, self.idf, self.tfidf, self.avgdl], f)
        except Exception as e:
            logger.log_exception(e, "saving RAG cache")

    def _load_cache(self):
        try:
            if os.path.isfile(INDEX_CACHE):
                with open(INDEX_CACHE, encoding="utf-8") as f:
                    data = json.load(f)
                # Handle both old (4 elements) and new (5 elements) cache formats
                if isinstance(data, list) and len(data) == 5:
                    return data
                elif isinstance(data, list) and len(data) == 4:
                    # Old format without avgdl - compute it
                    docs, df, idf, tfidf = data
                    total_len = sum(len(d[0].split()) for d in docs if d and isinstance(d, tuple) and d[0])
                    n = max(1, len(docs))
                    avgdl = total_len / n if n > 0 else 700.0
                    return [docs, df, idf, tfidf, avgdl]
        except Exception as e:
            logger.log_exception(e, "loading RAG cache")
        return None

    # ------------------------------------------------------------ search
    def search(self, query, k=5):
        # If not built yet, try to wait for background build (with timeout)
        if not self.built:
            global _rag_build_thread
            if _rag_build_thread and _rag_build_thread.is_alive():
                _rag_build_thread.join(timeout=2.0)  # wait up to 2s for build
        self.build()  # will use cache if built, otherwise build now
        with self.lock:
            q = _tok(query)
            if not q:
                return []
            scores = []
            avgdl = self.avgdl or 1.0
            for i, tf in enumerate(self.tfidf):
                if not tf:
                    continue
                score = 0.0
                dl = len(self.docs[i][0].split())
                for t in set(q):
                    if t in tf:
                        f = tf[t]
                        idf = self.idf.get(t, 0.0)
                        score += idf * (f * (1 + _K1)) / (f + _K1 * (1 - _B + _B * dl / avgdl))
                if score > 0:
                    scores.append((score, i))
            scores.sort(reverse=True)
            out = []
            for s, i in scores[:k]:
                out.append({"score": round(s, 3), "source": self.docs[i][1],
                            "text": self.docs[i][0]})
            return out


_rag = RAG()
_rag_build_started = False
_rag_build_thread = None


def _start_background_build():
    """Start building the RAG index in a background thread."""
    global _rag_build_started, _rag_build_thread
    if _rag_build_started:
        return
    _rag_build_started = True
    
    def _build():
        try:
            _rag.build()
        except Exception as e:
            logger.log_exception(e, "background RAG index build")
    
    _rag_build_thread = threading.Thread(target=_build, daemon=True)
    _rag_build_thread.start()


# Start building the index in background when module loads
_start_background_build()


def retrieve(query, k=5):
    """Return top-k retrieved chunks as a formatted context string."""
    try:
        hits = _rag.search(query, k=k)
    except Exception as e:
        logger.log_exception(e, "RAG retrieval search")
        return ""
    if not hits:
        return ""
    parts = []
    for h in hits:
        parts.append(f"[source: {h['source']} | score {h['score']}]\n{h['text']}")
    return "\n\n".join(parts)



def retrieve_for_prompt(query, k=5):
    ctx = retrieve(query, k=k)
    if not ctx:
        return ""
    return ("=== RETRIEVED MITMPro KNOWLEDGE (RAG) ===\n" + ctx +
            "\n=== END RETRIEVED KNOWLEDGE ===")


def search(query, k=5):
    """Module-level convenience: search using the shared index."""
    _rag.build()
    return _rag.search(query, k=k)
