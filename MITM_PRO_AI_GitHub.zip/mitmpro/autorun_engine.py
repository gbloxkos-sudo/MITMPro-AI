"""Advanced AutoRun Engine for MITMPro.

Orchestrates multi-step security assessments across different modules.
Translates high-level goals into execution plans via the local AI model,
then runs each step with progress tracking, error recovery, conditional
branching, and plan history.

Features:
  - AI-generated execution plans from natural language goals
  - Step-by-step execution with real-time status tracking
  - Error recovery: configurable per-step (retry / skip / abort)
  - Conditional branching: if step N fails, branch to alternative steps
  - Plan templates for common assessment scenarios
  - Plan history with save/load (JSON)
  - Thread-safe step state management
  - Progress callbacks to UI
"""
import threading
import json
import time
import os
import copy
from mitmpro import common

# Self-learning store (pure-Python, headless-safe). Optional: if it fails to
# import we simply skip learning persistence rather than break assessments.
try:
    from mitmpro import ai_learn
except Exception:  # pragma: no cover
    ai_learn = None

# ------------------------------------------------------------------ constants
MEMORY_DIR = os.path.expanduser("~/.mitmpro")
PLAN_HISTORY_FILE = os.path.join(MEMORY_DIR, "plan_history.json")

# Step statuses
STATUS_PENDING = "pending"
STATUS_RUNNING = "running"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
STATUS_SKIPPED = "skipped"
STATUS_RETRYING = "retrying"

# On-error policies
ON_ERROR_SKIP = "skip"
ON_ERROR_RETRY = "retry"
ON_ERROR_ABORT = "abort"

# Available tools and their methods
TOOL_REGISTRY = {
    "burp": {
        "scan": {
            "desc": "Run web vulnerability scanner on a target URL",
            "params": ["url"],
        },
        "load_into_repeater": {
            "desc": "Load an HTTP entry into the Repeater tab",
            "params": ["entry"],
        },
    },
    "waf": {
        "generate": {
            "desc": "Generate WAF bypass variants for a payload",
            "params": ["payload", "category"],
        },
        "test": {
            "desc": "Live-test WAF bypass variants against a URL",
            "params": ["payload", "cat"],
        },
        "test_batch": {
            "desc": "Batch test pre-generated payloads against a URL",
            "params": [],
        },
    },
    "masquerading": {
        "deploy": {
            "desc": "Deploy a reverse-proxy mirror of a target site",
            "params": ["url"],
        },
        "start_server": {
            "desc": "Start the phishing Flask server",
            "params": [],
        },
    },
    "nsniffer": {
        "run_command": {
            "desc": "Run an Nsniffer subcommand",
            "params": ["cmd", "args"],
        },
    },
    "dlp": {
        "run_manage": {
            "desc": "Manage the DLP proxy (start/stop/restart/status)",
            "params": ["cmd"],
        },
    },
    "proxy": {
        "launch": {
            "desc": "Launch a proxy tool with arguments",
            "params": ["tool", "args"],
        },
    },
    "scope": {
        "add_to_scope": {
            "desc": "Add a hostname to the authorized scope",
            "params": ["hostname"],
        },
    },
    "ai_traffic": {
        "analyze": {
            "desc": "Analyze HTTP traffic with AI",
            "params": ["req", "resp"],
        },
    },
    "network": {
        "start_arp_spoof": {
            "desc": "Start ARP spoofing between target and gateway",
            "params": ["target_ip", "gateway_ip"],
        },
        "stop_arp_spoof": {
            "desc": "Stop ARP spoofing and restore ARP tables",
            "params": [],
        },
        "start_dns_spoof": {
            "desc": "Start DNS spoofing to redirect domains to attacker IP",
            "params": ["spoof_ip", "domain"],
        },
        "stop_dns_spoof": {
            "desc": "Stop DNS spoofing",
            "params": [],
        },
        "run_scan": {
            "desc": "Scan network for live hosts (arp/icmp/tcp/nmap)",
            "params": ["target", "method"],
        },
        "start_sniff": {
            "desc": "Start packet capture on a network interface",
            "params": ["iface", "bpf_filter", "count"],
        },
        "stop_sniff": {
            "desc": "Stop packet capture",
            "params": [],
        },
    },
    "sslstrip": {
        "start_strip": {
            "desc": "Start SSL strip proxy to downgrade HTTPS to HTTP",
            "params": ["port"],
        },
        "stop_strip": {
            "desc": "Stop SSL strip proxy",
            "params": [],
        },
        "start_modifier": {
            "desc": "Start traffic modifier with custom rules",
            "params": ["port"],
        },
        "stop_modifier": {
            "desc": "Stop traffic modifier",
            "params": [],
        },
    },
    "campaigns": {
        "create_campaign": {
            "desc": "Create a new phishing campaign with targets",
            "params": ["name", "target_url"],
        },
        "launch_campaign": {
            "desc": "Launch a phishing campaign",
            "params": ["camp_id"],
        },
        "stop_campaign": {
            "desc": "Stop a running phishing campaign",
            "params": ["camp_id"],
        },
        "view_report": {
            "desc": "View campaign report with statistics",
            "params": ["camp_name"],
        },
    },
    "email": {
        "send_test_email": {
            "desc": "Send a test phishing email via SMTP",
            "params": ["to_addr"],
        },
        "preview_email": {
            "desc": "Preview rendered email with variable substitution",
            "params": [],
        },
        "ai_generate": {
            "desc": "Generate a phishing email template with AI",
            "params": ["description", "category"],
        },
    },
    "websploit": {
        "launch": {"desc": "Launch the selected WebSploit module", "params": []},
        "stop": {"desc": "Stop the running WebSploit module", "params": []},
        "list_modules": {"desc": "List available WebSploit modules", "params": []},
    },
    "oast": {
        "start": {"desc": "Start the OAST/DNS out-of-band listener", "params": []},
        "stop": {"desc": "Stop the OAST listener", "params": []},
        "gen_payload": {"desc": "Generate an OAST callback payload URL", "params": []},
    },
    "macro": {
        "run": {"desc": "Run the current multi-step request macro", "params": []},
        "save": {"desc": "Save the macro sequence to JSON", "params": []},
        "load": {"desc": "Load a macro sequence from JSON", "params": []},
    },
    "history": {
        "refresh": {"desc": "Refresh the HTTP history log", "params": []},
    },
}

# Common names the AI (or a user) might use for each tool. Maps any alias to the
# canonical panel key in TOOL_REGISTRY / app.panels. This makes the orchestrator
# resilient to model hallucination of tool names.
TOOL_ALIASES = {
    "burpsuite": "burp", "burp_suite": "burp", "scanner": "burp",
    "webscanner": "burp", "web_scanner": "burp", "vulnscanner": "burp",
    "repeater": "burp", "intruder": "burp",
    "wafbypass": "waf", "waf_bypass": "waf", "bypass": "waf", "firewall": "waf",
    "phishing": "masquerading", "phish": "masquerading", "mirror": "masquerading",
    "clone": "masquerading", "impersonation": "masquerading",
    "reverse_proxy": "masquerading", "masq": "masquerading",
    "sniffer": "nsniffer", "tshark": "nsniffer", "packet_sniffer": "nsniffer",
    "dataloss": "dlp", "data_loss": "dlp", "inline_dlp": "dlp",
    "proxytools": "proxy", "proxy_tools": "proxy", "mitm_proxy": "proxy",
    "scoping": "scope", "targets": "scope",
    "traffic": "ai_traffic", "traffic_analyst": "ai_traffic",
    "analyst": "ai_traffic", "http_analysis": "ai_traffic",
    "arp": "network", "arp_spoof": "network", "dns_spoof": "network",
    "netattack": "network", "network_attack": "network", "mitm": "network",
    "discovery": "network", "netscan": "network",
    "ssl": "sslstrip", "ssl_strip": "sslstrip", "sslstriping": "sslstrip",
    "https_downgrade": "sslstrip", "strip": "sslstrip",
    "campaign": "campaigns", "gophish": "campaigns",
    "mail": "email", "emails": "email", "email_engineer": "email",
    "smtp": "email", "phishing_email": "email",
    "websploit_toolkit": "websploit", "wifi": "websploit", "deauth": "websploit",
    "oast_dns": "oast", "collaborator": "oast", "callback": "oast",
    "out_of_band": "oast", "interactsh": "oast",
    "flow": "macro", "macros": "macro", "chain": "macro", "sequence": "macro",
    "logger": "history", "http_history": "history", "log": "history",
}

# Map common action synonyms to the real method name (checked per-tool).
ACTION_ALIASES = {
    "run": "scan", "start": "scan", "execute": "scan",
    "generate_payload": "generate", "make": "generate", "create": "generate",
    "run_test": "test", "attack": "test", "check": "test",
    "start_proxy": "start_server", "serve": "start_server",
    "clone": "deploy", "mirror": "deploy", "setup": "deploy",
    "spoof": "start_arp_spoof", "arpspoof": "start_arp_spoof",
    "dnsspoof": "start_dns_spoof",
    "sniff": "start_sniff", "capture": "start_sniff",
    "scan_network": "run_scan", "discover": "run_scan", "netscan": "run_scan",
    "strip_ssl": "start_strip", "start_sslstrip": "start_strip",
    "add": "add_to_scope", "add_scope": "add_to_scope",
    "manage": "run_manage", "control": "run_manage",
    "generate_email": "ai_generate", "gen_email": "ai_generate",
    "send": "send_test_email", "send_email": "send_test_email",
    "create_camp": "create_campaign", "new_campaign": "create_campaign",
    "launch": "launch_campaign", "start_campaign": "launch_campaign",
}

# Canonical registry tool key -> actual key in app.panels (main.py). Most match
# 1:1; these two differ and were silently failing before.
PANEL_KEY_MAP = {
    "masquerading": "phish",
    "ai_traffic": "traffic",
}

# Precise per-tool mapping of a step's param name -> the panel's widget attr, so
# planner params actually drive the GUI controls each panel reads from. This is
# what makes Auto-Run truly "run the command", not just click a default button.
WIDGET_MAP = {
    "burp": {"url": "url"},
    "waf": {"payload": "payload", "category": "cat", "cat": "cat"},
    "masquerading": {"url": "url_entry", "port": "port_entry"},
    "nsniffer": {"cmd": "cmd_combo", "args": "args_entry"},
    "scope": {"hostname": "entry"},
    "network": {
        "target_ip": "arp_target", "gateway_ip": "arp_gw",
        "spoof_ip": "dns_spoof_ip", "domain": "dns_domain",
        "target": "scan_target", "method": "scan_method",
        "iface": "sniff_iface", "bpf_filter": "sniff_filter", "count": "sniff_count",
    },
    "sslstrip": {"port": "strip_port", "upstream": "strip_upstream"},
    "campaigns": {"name": "camp_name", "target_url": "camp_target_url"},
    "email": {"to_addr": "send_to"},
}


def _difflib_close(word, options):
    """Return the closest match to *word* from *options* (or None)."""
    try:
        import difflib
        m = difflib.get_close_matches(word, list(options), n=1, cutoff=0.6)
        return m[0] if m else None
    except Exception:
        return None


def resolve_tool(tool_key):
    """Map any tool name/alias to a canonical registry key, or None."""
    if not tool_key:
        return None
    t = str(tool_key).strip().lower().replace("-", "_").replace(" ", "_")
    if t in TOOL_REGISTRY:
        return t
    if t in TOOL_ALIASES:
        return TOOL_ALIASES[t]
    # substring / fuzzy match against known keys
    for key in TOOL_REGISTRY:
        if key in t or t in key:
            return key
    return _difflib_close(t, TOOL_REGISTRY.keys())


def resolve_action(tool_key, action):
    """Map any action name to a real method on the given tool, or None."""
    if not tool_key or tool_key not in TOOL_REGISTRY or not action:
        return None
    methods = TOOL_REGISTRY[tool_key]
    a = str(action).strip().lower().replace("-", "_").replace(" ", "_")
    if a in methods:
        return a
    if a in ACTION_ALIASES and ACTION_ALIASES[a] in methods:
        return ACTION_ALIASES[a]
    for m in methods:
        if m in a or a in m:
            return m
    return _difflib_close(a, methods.keys())

# ------------------------------------------------------------------ templates
PLAN_TEMPLATES = {
    "Full Web Assessment": {
        "description": "Complete web application security assessment",
        "steps": [
            {"tool": "scope", "action": "add_to_scope",
             "params": {"hostname": "TARGET_HOST"},
             "desc": "Add target to scope"},
            {"tool": "burp", "action": "scan",
             "params": {"url": "https://TARGET_HOST"},
             "desc": "Run web vulnerability scanner"},
            {"tool": "waf", "action": "generate",
             "params": {"payload": "' OR 1=1--", "category": "SQLi"},
             "desc": "Generate SQLi WAF bypass variants"},
            {"tool": "waf", "action": "test",
             "params": {"payload": "' OR 1=1--", "cat": "SQLi"},
             "desc": "Test SQLi WAF bypasses live"},
            {"tool": "nsniffer", "action": "run_command",
             "params": {"cmd": "scan", "args": "-i eth0"},
             "desc": "Network scan for additional attack surface"},
        ],
    },
    "XSS Assessment": {
        "description": "Cross-site scripting focused assessment",
        "steps": [
            {"tool": "burp", "action": "scan",
             "params": {"url": "https://TARGET_HOST"},
             "desc": "Scan for XSS vulnerabilities"},
            {"tool": "waf", "action": "generate",
             "params": {"payload": "<script>alert(1)</script>", "category": "XSS"},
             "desc": "Generate XSS WAF bypass variants"},
            {"tool": "waf", "action": "test",
             "params": {"payload": "<script>alert(1)</script>", "cat": "XSS"},
             "desc": "Test XSS bypasses against target"},
        ],
    },
    "WAF Bypass Testing": {
        "description": "Focused WAF bypass assessment",
        "steps": [
            {"tool": "waf", "action": "generate",
             "params": {"payload": "' OR '1'='1", "category": "SQLi"},
             "desc": "Generate SQLi variants"},
            {"tool": "waf", "action": "test",
             "params": {"payload": "' OR '1'='1", "cat": "SQLi"},
             "desc": "Live test SQLi bypasses"},
            {"tool": "waf", "action": "generate",
             "params": {"payload": "<script>alert(1)</script>", "category": "XSS"},
             "desc": "Generate XSS variants"},
            {"tool": "waf", "action": "test",
             "params": {"payload": "<script>alert(1)</script>", "cat": "XSS"},
             "desc": "Live test XSS bypasses"},
        ],
    },
    "Network Recon": {
        "description": "Network-level reconnaissance",
        "steps": [
            {"tool": "nsniffer", "action": "run_command",
             "params": {"cmd": "scan", "args": "-i eth0"},
             "desc": "ARP scan the local network"},
            {"tool": "nsniffer", "action": "run_command",
             "params": {"cmd": "capture", "args": "-i eth0 -c 100"},
             "desc": "Capture 100 packets for analysis"},
            {"tool": "nsniffer", "action": "run_command",
             "params": {"cmd": "analyze", "args": ""},
             "desc": "Analyze captured traffic"},
        ],
    },
    "Phishing Campaign": {
        "description": "Set up a website impersonation campaign",
        "steps": [
            {"tool": "masquerading", "action": "deploy",
             "params": {"url": "https://TARGET_SITE"},
             "desc": "Deploy reverse proxy mirror"},
            {"tool": "masquerading", "action": "start_server",
             "params": {},
             "desc": "Start the phishing server"},
        ],
    },
    "Network MITM Attack": {
        "description": "Full L2/L3 man-in-the-middle attack chain",
        "steps": [
            {"tool": "network", "action": "run_scan",
             "params": {"target": "192.168.1.0/24", "method": "arp"},
             "desc": "Discover live hosts on the network"},
            {"tool": "network", "action": "start_arp_spoof",
             "params": {"target_ip": "TARGET_IP", "gateway_ip": "GATEWAY_IP"},
             "desc": "Start ARP spoofing to intercept traffic"},
            {"tool": "sslstrip", "action": "start_strip",
             "params": {"port": "8080"},
             "desc": "Start SSL strip to downgrade HTTPS"},
            {"tool": "network", "action": "start_sniff",
             "params": {"iface": "eth0", "bpf_filter": "tcp port 80", "count": "500"},
             "desc": "Capture stripped HTTP traffic"},
        ],
    },
    "Full Phishing Engagement": {
        "description": "End-to-end phishing campaign with email + landing page",
        "steps": [
            {"tool": "campaigns", "action": "create_campaign",
             "params": {"name": "TARGET_CAMPAIGN", "target_url": "https://TARGET_SITE"},
             "desc": "Create phishing campaign"},
            {"tool": "email", "action": "ai_generate",
             "params": {"description": "Password reset from IT department", "category": "credential"},
             "desc": "Generate phishing email template"},
            {"tool": "masquerading", "action": "deploy",
             "params": {"url": "https://TARGET_SITE"},
             "desc": "Deploy credential harvesting landing page"},
            {"tool": "masquerading", "action": "start_server",
             "params": {},
             "desc": "Start the phishing server"},
            {"tool": "campaigns", "action": "launch_campaign",
             "params": {"camp_id": "CAMPAIGN_ID"},
             "desc": "Launch the campaign"},
        ],
    },
    "Network Recon + MITM": {
        "description": "Network discovery followed by targeted MITM",
        "steps": [
            {"tool": "network", "action": "run_scan",
             "params": {"target": "192.168.1.0/24", "method": "arp"},
             "desc": "ARP scan for live hosts"},
            {"tool": "network", "action": "run_scan",
             "params": {"target": "192.168.1.0/24", "method": "nmap"},
             "desc": "Nmap service discovery"},
            {"tool": "network", "action": "start_arp_spoof",
             "params": {"target_ip": "TARGET_IP", "gateway_ip": "GATEWAY_IP"},
             "desc": "ARP spoof the target"},
            {"tool": "network", "action": "start_dns_spoof",
             "params": {"spoof_ip": "LOCAL_IP", "domain": ""},
             "desc": "DNS spoof all domains"},
            {"tool": "network", "action": "start_sniff",
             "params": {"iface": "eth0", "bpf_filter": "", "count": "1000"},
             "desc": "Capture all traffic"},
        ],
    },
}


class StepState:
    """Tracks the state of a single execution step."""

    def __init__(self, index, tool, action, params, desc="",
                 on_error=ON_ERROR_SKIP, max_retries=2,
                 condition=None):
        self.index = index
        self.tool = tool
        self.action = action
        self.params = params
        self.desc = desc or f"{tool}.{action}"
        self.on_error = on_error
        self.max_retries = max_retries
        self.condition = condition  # optional: {"step": N, "status": "completed"}

        self.status = STATUS_PENDING
        self.result = None
        self.error = None
        self.retries = 0
        self.started_at = None
        self.finished_at = None
        self.duration = 0.0

    def to_dict(self):
        return {
            "index": self.index,
            "tool": self.tool,
            "action": self.action,
            "params": self.params,
            "desc": self.desc,
            "on_error": self.on_error,
            "max_retries": self.max_retries,
            "condition": self.condition,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "retries": self.retries,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration": self.duration,
        }

    def mark_running(self):
        self.status = STATUS_RUNNING
        self.started_at = time.time()

    def mark_completed(self, result=None):
        self.status = STATUS_COMPLETED
        self.result = result
        self.finished_at = time.time()
        if self.started_at:
            self.duration = self.finished_at - self.started_at

    def mark_failed(self, error):
        self.status = STATUS_FAILED
        self.error = str(error)
        self.finished_at = time.time()
        if self.started_at:
            self.duration = self.finished_at - self.started_at

    def mark_skipped(self, reason=""):
        self.status = STATUS_SKIPPED
        self.error = reason
        self.finished_at = time.time()

    def mark_retrying(self):
        self.status = STATUS_RETRYING
        self.retries += 1


class AutoRunEngine:
    """The central orchestrator for MITMPro.

    Translates AI-generated plans into actual method calls on the app's panels
    with full progress tracking, error recovery, and plan history.
    """

    def __init__(self, app_instance):
        self.app = app_instance
        self.is_running = False
        self.is_paused = False
        self.current_plan = []
        self.step_states = []
        self._states_lock = threading.Lock()
        self.logs = []
        self._log_lock = threading.Lock()
        self._progress_callback = None
        self._step_callback = None
        self._plan_callback = None
        self._abort_event = threading.Event()
        self._pause_event = threading.Event()
        self._pause_event.set()  # not paused initially
        self.plan_history = []
        self._created_campaigns = []
        self._load_history()

    # --------------------------------------------------------------- logging
    def log(self, text, level="info"):
        entry = f"[{time.strftime('%H:%M:%S')}] [{level.upper()}] {text}"
        with self._log_lock:
            self.logs.append(entry)
        if (self.app is not None and hasattr(self.app, "panels")
                and "autorun" in self.app.panels):
            try:
                self.app.panels["autorun"].after(
                    0, lambda: self.app.panels["autorun"].log(text))
            except Exception:
                pass

    # ----------------------------------------------------------- callbacks
    def set_progress_callback(self, fn):
        """fn(completed, total, percent) called on each step completion."""
        self._progress_callback = fn

    def set_step_callback(self, fn):
        """fn(step_state) called when a step's status changes."""
        self._step_callback = fn

    def set_plan_callback(self, fn):
        """fn(step_states) called once after a plan's steps are built, so the
        UI can pre-populate its step list before execution begins."""
        self._plan_callback = fn

    def _notify_plan(self):
        if self._plan_callback:
            try:
                with self._states_lock:
                    states = list(self.step_states)
                self._plan_callback(states)
            except Exception as e:
                self.log(f"UI Plan Callback Error: {e}", "error")

    def _notify_progress(self):
        with self._states_lock:
            completed = sum(1 for s in self.step_states
                            if s.status in (STATUS_COMPLETED, STATUS_SKIPPED,
                                             STATUS_FAILED))
            total = len(self.step_states)
        pct = (completed / total * 100) if total else 0
        if self._progress_callback:
            try:
                self._progress_callback(completed, total, pct)
            except Exception as e:
                self.log(f"UI Progress Callback Error: {e}", "error")

    def _notify_step(self, step):
        if self._step_callback:
            try:
                self._step_callback(step)
            except Exception as e:
                self.log(f"UI Step Callback Error: {e}", "error")

    # --------------------------------------------------------- execution
    def execute_goal(self, goal, context="General"):
        """Start an automated assessment for the given goal.

        Returns immediately; execution happens on a background thread.
        """
        if self.is_running:
            return "Already running an automated task."
        threading.Thread(
            target=self._orchestrate,
            args=(goal, context),
            daemon=True,
        ).start()
        return f"Started automated assessment for: {goal}"

    def execute_plan(self, plan_steps):
        """Execute a pre-built plan (list of step dicts).

        Returns immediately; execution happens on a background thread.
        """
        if self.is_running:
            return "Already running an automated task."
        threading.Thread(
            target=self._run_plan,
            args=(plan_steps,),
            daemon=True,
        ).start()
        return f"Plan submitted with {len(plan_steps)} steps."

    def stop(self):
        """Signal the engine to abort after the current step."""
        self._abort_event.set()
        self._pause_event.set()  # unpause so it can exit
        self.log("Abort signal sent.", "warn")

    def get_step_state(self, index):
        """Thread-safe access to a specific step's current state."""
        with self._states_lock:
            if 0 <= index < len(self.step_states):
                return self.step_states[index]
            return None

    def pause(self):
        """Pause execution after the current step."""
        self.is_paused = True
        self._pause_event.clear()
        self.log("Paused.", "info")

    def resume(self):
        """Resume paused execution."""
        self.is_paused = False
        self._pause_event.set()
        self.log("Resumed.", "info")

    def skip_step(self):
        """Skip the current running step (unpause with skip signal)."""
        self._pause_event.set()

    # -------------------------------------------------------- orchestrate
    def _orchestrate(self, goal, context):
        from mitmpro import ai_core
        self.is_running = True
        self._abort_event.clear()
        self._pause_event.set()
        with self._states_lock:
            self.step_states = []
        self.log(f"Starting Auto-Run for goal: {goal} (Context: {context})")

        # Ask the AI to generate a plan
        prompt = self._build_plan_prompt(goal, context)
        messages = [
            {"role": "system",
             "content": (
                 "You are the MITMPro Orchestrator. Create a technical "
                 "execution plan as a JSON list of actions. Each action must "
                 "be: {'tool': 'tool_key', 'action': 'method_name', 'params': "
                 "{...}, 'desc': 'short description', 'on_error': 'skip|retry|"
                 "abort'}. Respond ONLY with the JSON list. Do not include "
                 "markdown formatting.")},
            {"role": "user", "content": prompt},
        ]

        plan = []
        try:
            model = common.SELECTED_MODEL
            if not model:
                models = common.ollama_models()
                if models:
                    model = models[0]
                    common.set_model(model)

            if model:
                # Try the AI planner up to 3 times, accepting the first plan
                # that yields runnable steps after validation/repair.
                for attempt in range(1, 4):
                    full_result = {"v": ""}

                    def on_token(t):
                        full_result["v"] += t

                    try:
                        ai_core.stream_chat(model, messages, on_token=on_token,
                                            context="AutoRun", verify=False)
                    except Exception as e:
                        self.log(f"[~] AI plan attempt {attempt} errored: {e}", "warn")
                    plan = self._parse_plan(full_result["v"].strip())
                    if plan:
                        self.log(f"[+] AI plan accepted on attempt {attempt}: "
                                 f"{len(plan)} valid steps.")
                        break
                    self.log(f"[~] AI plan attempt {attempt} produced no valid "
                             f"steps; retrying...", "warn")
            else:
                self.log("[~] No AI model available — using heuristic planner.", "warn")

            # Guarantee a runnable plan: fall back to the keyword/template planner.
            if not plan:
                self.log("[+] Falling back to heuristic planner so the job still runs.")
                plan = self._heuristic_plan(goal, context)

            if not plan:
                self.log("[!] Unable to build any runnable plan.", "error")
                return

            self.log(f"[+] Final plan: {len(plan)} steps. Executing...")
            self._run_plan(plan)

        except Exception as e:
            self.log(f"[!] Orchestration failed: {e}", "error")
            # Even on unexpected failure, attempt the heuristic plan once.
            try:
                if not self.step_states:
                    fallback = self._heuristic_plan(goal, context)
                    if fallback:
                        self.log("[+] Executing heuristic fallback after error.")
                        self._run_plan(fallback)
            except Exception as e2:
                self.log(f"[!] Fallback also failed: {e2}", "error")
        finally:
            self.is_running = False
            self._save_history()

    def _run_plan(self, plan_steps):
        """Execute a plan (list of step dicts) with full tracking."""
        self.is_running = True
        with self._states_lock:
            self.step_states = []
        self._abort_event.clear()
        self._pause_event.set()
        self._created_campaigns = []

        # Build StepState objects
        for i, step in enumerate(plan_steps):
            ss = StepState(
                index=i,
                tool=step.get("tool", ""),
                action=step.get("action", ""),
                params=step.get("params", {}),
                desc=step.get("desc", ""),
                on_error=step.get("on_error", ON_ERROR_SKIP),
                max_retries=step.get("max_retries", 2),
                condition=step.get("condition"),
            )
            with self._states_lock:
                self.step_states.append(ss)

        self._notify_plan()

        total = len(self.step_states)
        self.log(f"[+] Executing plan: {total} steps.")

        for i, ss in enumerate(self.step_states):
            # Check abort
            if self._abort_event.is_set():
                self.log("[!] Plan aborted by user.", "warn")
                for remaining in self.step_states[i:]:
                    remaining.mark_skipped("Aborted")
                    self._notify_step(remaining)
                break

            # Check pause
            self._pause_event.wait()
            if self._abort_event.is_set():
                continue

            # Check conditional
            if ss.condition:
                cond_step_idx = ss.condition.get("step", -1)
                cond_status = ss.condition.get("status", STATUS_COMPLETED)
                if 0 <= cond_step_idx < len(self.step_states):
                    ref = self.step_states[cond_step_idx]
                    if ref.status != cond_status:
                        ss.mark_skipped(
                            f"Condition not met: step {cond_step_idx} "
                            f"is '{ref.status}', needed '{cond_status}'")
                        self.log(f"Step {i}: Skipped - {ss.error}", "warn")
                        self._notify_step(ss)
                        self._notify_progress()
                        continue

            # Execute with retry logic
            success = self._execute_step(ss)
            self._notify_progress()

            # Delay between steps (except after last)
            if i < total - 1 and success:
                time.sleep(3)

        # Save to history
        self._save_history()
        completed = sum(1 for s in self.step_states
                        if s.status == STATUS_COMPLETED)
        failed = sum(1 for s in self.step_states
                     if s.status == STATUS_FAILED)
        skipped = sum(1 for s in self.step_states
                      if s.status == STATUS_SKIPPED)
        self.log(
            f"[+] Plan complete. {completed} completed, {failed} failed, "
            f"{skipped} skipped out of {total}.")
        self.is_running = False

    def _execute_step(self, ss):
        """Execute a single step with retry logic. Returns True on success."""
        max_attempts = ss.max_retries + 1 if ss.on_error == ON_ERROR_RETRY else 1

        for attempt in range(max_attempts):
            if self._abort_event.is_set():
                ss.mark_skipped("Aborted")
                self._notify_step(ss)
                return False

            if attempt > 0:
                ss.mark_retrying()
                self.log(
                    f"Step {ss.index}: Retrying ({attempt}/{ss.max_retries}) "
                    f"- {ss.desc}", "warn")
                self._notify_step(ss)
                time.sleep(2)

            ss.mark_running()
            self.log(f"Step {ss.index}: Running - {ss.desc}")
            self._notify_step(ss)

            try:
                result = self._call_tool_method(
                    ss.tool, ss.action, ss.params)
                ss.mark_completed(result)
                # Track campaigns created during the plan so a later
                # launch_campaign step can resolve the CAMPAIGN_ID placeholder.
                if (ss.action == "create_campaign" and result
                        and str(result).lower() not in ("none", "")):
                    self._created_campaigns.append(str(result))
                self.log(f"Step {ss.index}: Completed - {ss.desc}")
                self._notify_step(ss)
                if ai_learn is not None:
                    try:
                        ai_learn.record_from_autorun(
                            ss.tool, ss.action, ss.params, result, True)
                    except Exception:
                        pass
                return True

            except Exception as e:
                ss.error = str(e)
                self.log(
                    f"Step {ss.index}: Error - {e}", "error")

                if attempt < max_attempts - 1:
                    continue  # will retry

                # Final attempt failed
                if ss.on_error == ON_ERROR_ABORT:
                    ss.mark_failed(e)
                    self._notify_step(ss)
                    self.log(
                        f"[!] Step {ss.index}: Abort policy - "
                        f"stopping plan.", "error")
                    self._record_learning(ss, False)
                    self._abort_event.set()
                    return False
                elif ss.on_error == ON_ERROR_RETRY:
                    ss.mark_failed(e)
                    self._notify_step(ss)
                    self._record_learning(ss, False)
                    return False
                else:  # skip
                    ss.mark_failed(e)
                    self._notify_step(ss)
                    self._record_learning(ss, False)
                    return False

        return False

    def _record_learning(self, ss, success):
        """Persist a completed/failed AutoRun step to the learning store."""
        if ai_learn is None:
            return
        try:
            ai_learn.record_from_autorun(
                ss.tool, ss.action, ss.params, ss.error or ss.result, success)
        except Exception:
            pass

    # -------------------------------------------------------- tool calls
    def _call_tool_method(self, tool_key, action, params):
        """Call a panel method. Raises on failure.

        Panel methods typically read their values from GUI widgets (Entries,
        Comboboxes etc.) and do not accept keyword arguments from the engine.
        We therefore attempt the call *with* params first; if that raises a
        TypeError (unexpected keyword argument) we fall back to a no-arg call.
        This lets the AutoRun engine integrate with every panel without
        requiring every method to accept **kwargs.
        """
        # Translate a canonical registry key to the real app.panels key.
        panel_key = PANEL_KEY_MAP.get(tool_key, tool_key)
        if panel_key not in self.app.panels:
            # last-chance fuzzy resolve against actual panel keys
            alt = resolve_tool(tool_key)
            panel_key = PANEL_KEY_MAP.get(alt, alt) if alt else panel_key
        if panel_key not in self.app.panels:
            raise RuntimeError(f"Tool '{tool_key}' not found in panels")

        panel = self.app.panels[panel_key]
        # Many panels are ttk.Notebook containers whose real work lives on a
        # sub-tab widget (e.g. BurpPanel.scan actually lives on its ScannerPanel
        # child). Resolve the object that truly owns the method by searching the
        # panel and its descendant widgets.
        owner = self._find_action_target(panel, action)
        if owner is None:
            raise RuntimeError(
                f"Method '{action}' not found in panel '{panel_key}'")

        method = getattr(owner, action)

        # Some methods need to be called on the main thread for GUI safety
        result_holder = {"result": None, "error": None}
        event = threading.Event()

        def _call():
            try:
                # Drive the panel's own widgets from the step params so the action
                # runs with the intended target/command, then invoke the method.
                self._apply_params_to_widgets(tool_key, owner, params)

                # Resolve the CAMPAIGN_ID / last placeholder for launch_campaign so a
                # plan that creates a campaign can launch the one it just created.
                if action == "launch_campaign":
                    cid = params.get("camp_id") if isinstance(params, dict) else None
                    if cid in ("CAMPAIGN_ID", "last", "LAST"):
                        if self._created_campaigns:
                            params = dict(params)
                            params["camp_id"] = self._created_campaigns[-1]

                try:
                    result_holder["result"] = method(**params)
                except TypeError:
                    # Panel method doesn't accept these kwargs — call without args
                    # (it will read the widget values we just populated).
                    try:
                        result_holder["result"] = method()
                    except Exception as e2:
                        result_holder["error"] = e2
                except Exception as e:
                    result_holder["error"] = e
            finally:
                event.set()

        # Run on the GUI/main thread when a Tk event loop is available; fall back
        # to a direct call otherwise (e.g. headless tests pumping update()).
        scheduled = False
        try:
            if threading.current_thread() is threading.main_thread():
                _call()
                scheduled = True
            else:
                self.app.after(0, _call)
                scheduled = True
                if not event.wait(timeout=300):
                    raise RuntimeError(
                        f"Tool call timed out after 300s: {tool_key}.{action}")
        except RuntimeError as e:
            # app.after can raise "main thread is not in main loop" when no
            # mainloop is running. Fall back to a direct call so the plan runs.
            if not scheduled or "main loop" in str(e).lower():
                try:
                    _call()
                    event.wait(timeout=1)
                except Exception as e2:
                    if not result_holder["error"]:
                        result_holder["error"] = e2
            elif not result_holder["error"]:
                result_holder["error"] = e
        except Exception as e:
            if not result_holder["error"]:
                result_holder["error"] = e

        if result_holder["error"] is not None:
            err = result_holder["error"]
            if isinstance(err, BaseException):
                raise err.with_traceback(err.__traceback__)
            raise RuntimeError(str(err))
        return result_holder["result"]

    @staticmethod
    def _find_action_target(panel, action, max_depth=4):
        """Return the panel (or a descendant widget) that owns *action*.

        Panels are frequently ttk.Notebook containers whose functional methods
        live on child tab widgets. We search breadth-first so the top-level
        panel wins ties, then descend into child widgets."""
        if hasattr(panel, action) and callable(getattr(panel, action, None)):
            return panel
        try:
            frontier = [(panel, 0)]
            seen = set()
            while frontier:
                widget, depth = frontier.pop(0)
                if depth >= max_depth:
                    continue
                try:
                    children = widget.winfo_children()
                except Exception:
                    children = []
                for child in children:
                    if id(child) in seen:
                        continue
                    seen.add(id(child))
                    if hasattr(child, action) and callable(
                            getattr(child, action, None)):
                        return child
                    frontier.append((child, depth + 1))
        except Exception:
            pass
        return None

    def _apply_params_to_widgets(self, tool_key, panel, params):
        """Best-effort: set the panel's Entry/Combobox widgets from step params
        so the action executes against the intended target/command. Silent on
        any mismatch — the method still falls back to widget defaults."""
        if not isinstance(params, dict) or not params:
            return
        mapping = WIDGET_MAP.get(tool_key, {})
        for pname, value in params.items():
            if value is None:
                continue
            attr = mapping.get(pname)
            candidates = [attr] if attr else []
            # generic fallbacks in case the map misses a param
            candidates += [pname, pname + "_entry", pname + "_combo"]
            for cand in candidates:
                if not cand:
                    continue
                widget = getattr(panel, cand, None)
                if widget is None:
                    continue
                try:
                    if hasattr(widget, "set") and hasattr(widget, "current"):
                        widget.set(str(value))          # Combobox
                    elif hasattr(widget, "delete") and hasattr(widget, "insert"):
                        widget.delete(0, "end")          # Entry
                        widget.insert(0, str(value))
                    else:
                        continue
                    break
                except Exception:
                    continue

    # -------------------------------------------------------- plan parsing
    def _parse_plan(self, text):
        """Parse a plan from AI output, tolerating markdown, prose, dict/list
        wrappers, and minor JSON errors, then validate + repair every step so
        only runnable steps survive."""
        raw = self._extract_json_steps(text)
        repaired = self._validate_and_repair_plan(raw)
        if not repaired:
            self.log("[!] AI plan had no runnable steps.", "warn")
        return repaired

    def _extract_json_steps(self, text):
        """Best-effort extraction of a list of step dicts from arbitrary text."""
        if not text:
            return []
        text = text.strip()
        # Strip markdown code fences
        if "```json" in text:
            text = text.split("```json", 1)[1].split("```", 1)[0].strip()
        elif "```" in text:
            text = text.split("```", 1)[1].split("```", 1)[0].strip()

        candidates = []
        # Prefer an explicit JSON array
        start = text.find("[")
        end = text.rfind("]")
        if start != -1 and end > start:
            candidates.append(text[start:end + 1])
        # Or a single/steps object
        ostart = text.find("{")
        oend = text.rfind("}")
        if ostart != -1 and oend > ostart:
            candidates.append(text[ostart:oend + 1])
        candidates.append(text)

        for cand in candidates:
            for attempt in (cand, self._loose_json_fix(cand)):
                try:
                    data = json.loads(attempt)
                except (json.JSONDecodeError, ValueError, TypeError):
                    continue
                if isinstance(data, list):
                    return [s for s in data if isinstance(s, dict)]
                if isinstance(data, dict):
                    if isinstance(data.get("steps"), list):
                        return [s for s in data["steps"] if isinstance(s, dict)]
                    if isinstance(data.get("plan"), list):
                        return [s for s in data["plan"] if isinstance(s, dict)]
                    if "tool" in data or "action" in data:
                        return [data]
        return []

    @staticmethod
    def _loose_json_fix(text):
        """Repair the most common LLM JSON mistakes."""
        if not text:
            return text
        import re as _re
        fixed = text
        # Remove trailing commas before ] or }
        fixed = _re.sub(r",\s*([}\]])", r"\1", fixed)
        # Remove // comments (but NOT the // inside http://, https://, etc.)
        fixed = _re.sub(r"(?<![:/])//[^\n]*", "", fixed)
        fixed = _re.sub(r"/\*.*?\*/", "", fixed, flags=_re.DOTALL)
        # Fix single-quoted keys/values ONLY when they look like JSON structure
        # This regex targets: {'key': 'value'} -> {"key": "value"}
        # but avoids replacing apostrophes inside words like "it's"
        fixed = _re.sub(r"(['\"])([a-zA-Z0-9_]+)\1\s*:\s*(['\"])([^'\"]*)\3", r'"\2": "\4"', fixed)
        # Also handle unquoted keys: {key: "value"} -> {"key": "value"}
        fixed = _re.sub(r"([{,]\s*)([a-zA-Z0-9_]+)\s*:", r'\1"\2":', fixed)
        return fixed

    def _validate_and_repair_plan(self, raw_steps):
        """Turn arbitrary step dicts into a list of valid, runnable steps.
        Unknown tools/actions are remapped via aliases/fuzzy matching; params
        are coerced to a dict; irreparable steps are dropped."""
        normalized = []
        for step in raw_steps:
            if not isinstance(step, dict):
                continue
            tool = resolve_tool(step.get("tool") or step.get("module") or step.get("panel"))
            if not tool:
                self.log(f"[~] Dropped step with unknown tool: {step.get('tool')}", "warn")
                continue
            action = resolve_action(tool, step.get("action") or step.get("method") or step.get("command"))
            if not action:
                # default to the tool's first method rather than dropping
                action = next(iter(TOOL_REGISTRY[tool]))
                self.log(f"[~] Unknown action for '{tool}', defaulting to '{action}'.", "warn")
            params = step.get("params") or step.get("parameters") or step.get("args") or {}
            if not isinstance(params, dict):
                params = {}
            on_error = str(step.get("on_error", ON_ERROR_RETRY)).lower()
            if on_error not in (ON_ERROR_SKIP, ON_ERROR_RETRY, ON_ERROR_ABORT):
                on_error = ON_ERROR_RETRY
            normalized.append({
                "tool": tool,
                "action": action,
                "params": params,
                "desc": step.get("desc") or f"{tool}.{action}",
                "on_error": on_error,
                "max_retries": int(step.get("max_retries", 2) or 2),
                "condition": step.get("condition"),
            })
        return normalized

    # ------------------------------------------------ heuristic fallback plan
    def _heuristic_plan(self, goal, context):
        """Build a runnable plan from goal keywords when the AI can't. This
        guarantees Auto-Run always has something valid to execute."""
        g = (goal or "").lower()
        c = (context or "").lower()

        # 1) Exact/loose template match by keywords
        keyword_templates = [
            (("full", "web", "assess"), "Full Web Assessment"),
            (("xss",), "XSS Assessment"),
            (("waf", "bypass"), "WAF Bypass Testing"),
            (("mitm", "arp", "strip"), "Network MITM Attack"),
            (("recon", "discover", "scan network"), "Network Recon"),
            (("phish", "campaign", "email"), "Full Phishing Engagement"),
            (("mirror", "clone", "impersonat"), "Phishing Campaign"),
            (("network",), "Network Recon + MITM"),
        ]
        for keys, tname in keyword_templates:
            if any(k in g for k in keys):
                tpl = self.get_template(tname)
                if tpl:
                    self.log(f"[+] Heuristic fallback -> template '{tname}'.")
                    return self._substitute_target(tpl["steps"], goal)

        # 2) Context-based single-tool plan
        ctx_tool = resolve_tool(context)
        if ctx_tool:
            action = next(iter(TOOL_REGISTRY[ctx_tool]))
            self.log(f"[+] Heuristic fallback -> current module '{ctx_tool}.{action}'.")
            return self._substitute_target(
                [{"tool": ctx_tool, "action": action, "params": {},
                  "desc": f"Run {ctx_tool}.{action}"}], goal)

        # 3) Last resort: safe web scan
        self.log("[+] Heuristic fallback -> default web scan.")
        return self._substitute_target(self.get_template("Full Web Assessment")["steps"], goal)

    @staticmethod
    def _local_network():
        """Best-effort discovery of the local IP and default gateway.

        Used to resolve GATEWAY_IP / LOCAL_IP placeholders in network-MITM
        plan steps. Returns (local_ip, gateway_ip); either may be "" if it
        cannot be determined.
        """
        import socket
        local_ip = ""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except Exception:
            try:
                local_ip = socket.gethostbyname(socket.gethostname())
            except Exception:
                local_ip = ""
        gateway_ip = ""
        # Linux: default route lives in /proc/net/route
        try:
            with open("/proc/net/route") as f:
                for line in f.readlines()[1:]:
                    parts = line.split()
                    if len(parts) >= 4 and parts[1] == "00000000":
                        gw_hex = parts[2]
                        gateway_ip = ".".join(
                            str(int(gw_hex[i:i + 2], 16))
                            for i in (6, 4, 2, 0))
                        break
        except Exception:
            gateway_ip = ""
        if not gateway_ip and local_ip:
            # Worst-case fallback: assume .1 inside the local subnet.
            try:
                base = ".".join(local_ip.split(".")[:3])
                gateway_ip = base + ".1"
            except Exception:
                gateway_ip = ""
        return local_ip, gateway_ip

    @staticmethod
    def _substitute_target(steps, goal):
        """Replace TEMPLATE placeholders using anything URL/host/IP-like in goal,
        plus GATEWAY_IP / LOCAL_IP derived from the host's network."""
        import re as _re
        steps = copy.deepcopy(steps)
        url = None
        m = _re.search(r"https?://[^\s'\"]+", goal or "")
        if m:
            url = m.group(0)
        host = None
        mh = _re.search(r"\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b", goal or "", _re.I)
        if mh:
            host = mh.group(0)
        ip = None
        mi = _re.search(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", goal or "")
        if mi:
            ip = mi.group(0)
        if url and not host:
            host = url.split("//", 1)[-1].split("/", 1)[0]
        local_ip, gateway_ip = AutoRunEngine._local_network()
        for s in steps:
            p = s.get("params", {})
            for k, v in list(p.items()):
                if not isinstance(v, str):
                    continue
                if "TARGET_HOST" in v and host:
                    p[k] = v.replace("TARGET_HOST", host)
                elif "TARGET_SITE" in v and (url or host):
                    p[k] = v.replace("TARGET_SITE", url or ("https://" + host))
                elif "TARGET_IP" in v and ip:
                    p[k] = v.replace("TARGET_IP", ip)
                if "GATEWAY_IP" in v and gateway_ip:
                    p[k] = v.replace("GATEWAY_IP", gateway_ip)
                if "LOCAL_IP" in v and local_ip:
                    p[k] = v.replace("LOCAL_IP", local_ip)
        return steps

    # --------------------------------------------------- plan prompt
    def _build_plan_prompt(self, goal, context):
        tools_desc = "\n".join(
            f"- '{tool}': " + ", ".join(
                f"{action}({', '.join(info['params'])})"
                for action, info in methods.items()
            )
            for tool, methods in TOOL_REGISTRY.items()
        )
        return (
            f"User Goal: {goal}\n"
            f"Current Context: {context}\n\n"
            f"Available Tools & Methods:\n{tools_desc}\n\n"
            "Respond ONLY with a JSON list. Each element: "
            "{'tool': 'key', 'action': 'method', 'params': {...}, "
            "'desc': 'short description', 'on_error': 'skip|retry|abort'}"
        )

    # --------------------------------------------------- history
    def _load_history(self):
        try:
            if os.path.isfile(PLAN_HISTORY_FILE):
                with open(PLAN_HISTORY_FILE, encoding="utf-8") as f:
                    self.plan_history = json.load(f)
        except (OSError, json.JSONDecodeError):
            self.plan_history = []

    def _save_history(self):
        try:
            os.makedirs(MEMORY_DIR, exist_ok=True)
            entry = {
                "timestamp": time.time(),
                "steps": [ss.to_dict() for ss in self.step_states],
                "total_steps": len(self.step_states),
                "completed": sum(1 for s in self.step_states
                                 if s.status == STATUS_COMPLETED),
                "failed": sum(1 for s in self.step_states
                              if s.status == STATUS_FAILED),
            }
            self.plan_history.append(entry)
            # Keep last 20 plans
            if len(self.plan_history) > 20:
                self.plan_history = self.plan_history[-20:]
            with open(PLAN_HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump(self.plan_history, f, indent=2, default=str)
        except (OSError, IOError):
            pass

    def get_plan_history(self):
        """Return a summary list of past plans."""
        out = []
        for i, p in enumerate(self.plan_history):
            ts = time.strftime(
                "%Y-%m-%d %H:%M",
                time.localtime(p.get("timestamp", 0)))
            out.append({
                "index": i,
                "timestamp": ts,
                "total": p.get("total_steps", 0),
                "completed": p.get("completed", 0),
                "failed": p.get("failed", 0),
            })
        return out

    def get_plan_history_steps(self, index):
        """Return the step details for a historical plan."""
        if 0 <= index < len(self.plan_history):
            return self.plan_history[index].get("steps", [])
        return []

    # --------------------------------------------------- templates
    @staticmethod
    def get_templates():
        """Return available plan templates."""
        return {
            name: {
                "description": t["description"],
                "steps": copy.deepcopy(t["steps"]),
            }
            for name, t in PLAN_TEMPLATES.items()
        }

    @staticmethod
    def get_template(name):
        """Return a deep copy of a named template."""
        if name in PLAN_TEMPLATES:
            return copy.deepcopy(PLAN_TEMPLATES[name])
        return None

    @staticmethod
    def get_tool_registry():
        """Return the tool registry for UI display."""
        return TOOL_REGISTRY
