import threading
import subprocess
import os
import re
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from mitmpro import common
from mitmpro.ai_components import AIHelperTab

class NsnifferPanel(ttk.Notebook):
    @staticmethod
    def _resolve_nsniffer_path():
        tool_dir = common._find_tool_dir("Nsniffer-1.1.0")
        candidates = [
            os.path.join(tool_dir, "nsniffer"),
            os.path.join(tool_dir, "nsniffer.py"),
            os.path.join(tool_dir, "bin", "nsniffer"),
            os.path.join(common.PROJECT_ROOT, "mitm_tools", "Nsniffer-1.1.0", "nsniffer"),
            tool_dir,
        ]
        # Prefer an actual executable file; never return a directory as if it
        # were runnable (that would later raise PermissionError).
        for c in candidates:
            if c and os.path.isfile(c):
                if os.access(c, os.X_OK) or c.endswith(".py"):
                    return c
        # Fall back to the directory only so the user gets a clear "not found"
        # message instead of a crash.
        if os.path.isdir(tool_dir):
            return tool_dir
        return None

    def __init__(self, master):
        super().__init__(master)
        self.nsniffer_path = self._resolve_nsniffer_path()

        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Nsniffer Toolkit")
        self.add(AIHelperTab(self, "Nsniffer"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(2, weight=1)

        # Subcommand selection
        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Command:").grid(row=0, column=0)
        self.cmd_var = tk.StringVar(value="scan")
        self.cmd_combo = ttk.Combobox(top, textvariable=self.cmd_var, values=[
            "scan", "capture", "analyze", "mitm", "arp", "list", "extract", "log", "setup"
        ], width=15)
        self.cmd_combo.grid(row=0, column=1, padx=5)
        ttk.Button(top, text="Run", command=self.run_command).grid(row=0, column=2, padx=5)
        ttk.Button(top, text="Clear", command=self.clear_output).grid(row=0, column=3, padx=5)

        # Arguments
        args_frame = ttk.LabelFrame(self.main_frame, text="Arguments / Options")
        args_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        args_frame.columnconfigure(1, weight=1)
        
        ttk.Label(args_frame, text="Args:").grid(row=0, column=0, sticky="w", padx=4)
        self.args_entry = ttk.Entry(args_frame)
        self.args_entry.grid(row=0, column=1, sticky="ew", padx=4, pady=4)
        self.args_entry.insert(0, "-i eth0")

        # Output
        self.out = scrolledtext.ScrolledText(self.main_frame, height=15, bg="black", fg="lightgreen", font=("Courier", 10))
        self.out.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        self.out.config(state="disabled")
        self.main_frame.rowconfigure(2, weight=1)

        self.process = None

    def run_command(self, cmd=None, args=None, **kwargs):
        if self.process and self.process.poll() is None:
            messagebox.showinfo("Info", "A command is already running.")
            return

        if not self.nsniffer_path or not os.path.isfile(self.nsniffer_path):
            self._append_output(
                f"\n[!] Nsniffer tool not found at: {self.nsniffer_path}\n")
            self._append_output(
                "[*] Ensure the Nsniffer toolkit is installed in mitm_tools/.\n")
            return

        if not os.access(self.nsniffer_path, os.X_OK) and \
                not self.nsniffer_path.endswith(".py"):
            self._append_output(
                f"\n[!] Nsniffer at {self.nsniffer_path} is not executable.\n")
            self._append_output(
                "[*] Run: chmod +x {}\n".format(self.nsniffer_path))
            return

        if cmd is None:
            cmd = self.cmd_var.get()
        if args is None:
            args = self.args_entry.get()

        allowed_cmds = {"scan", "capture", "analyze", "mitm", "arp", "list", "extract", "log", "setup"}
        if cmd not in allowed_cmds:
            messagebox.showerror("Error", "Invalid command selected.")
            return

        if args:
            if not re.match(r"^[a-zA-Z0-9\s\.\-_/:=,]*$", args):
                messagebox.showerror("Error", "Arguments contain disallowed characters.")
                return
            tokens = args.split()
            for token in tokens:
                if ".." in token:
                    messagebox.showerror("Error", "Path traversal detected in arguments.")
                    return

        cmd_list = [self.nsniffer_path, cmd]
        if args:
            cmd_list.extend(args.split())
        
        self.out.config(state="normal")
        self.out.delete("1.0", "end")
        self.out.insert("end", f"Executing: {' '.join(cmd_list)}\n" + "-"*40 + "\n")
        self.out.config(state="disabled")
        
        threading.Thread(target=self._execute, args=(cmd_list,), daemon=True).start()

    def _execute(self, cmd):
        try:
            self.process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1
            )
            for line in self.process.stdout:
                try:
                    self.after(0, self._append_output, line)
                except RuntimeError:
                    break
            self.process.wait()
            try:
                self.after(0, self._append_output, f"\n[Process exited with code {self.process.returncode}]\n")
            except RuntimeError:
                pass
        except Exception as e:
            try:
                self.after(0, self._append_output, f"\n[Error: {e}]\n")
            except RuntimeError:
                pass

    def destroy(self):
        if self.process and self.process.poll() is None:
            try:
                self.process.kill()
            except Exception:
                pass
        super().destroy()

    def _append_output(self, text):
        self.out.config(state="normal")
        self.out.insert("end", text)
        self.out.see("end")
        self.out.config(state="disabled")

    def clear_output(self):
        self.out.config(state="normal")
        self.out.delete("1.0", "end")
        self.out.config(state="disabled")
