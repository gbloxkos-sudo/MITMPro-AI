class MITMProApp {
  constructor() {
    this.state = {
      modules: [], currentModule: 'dashboard', ollamaRunning: false,
      availableModels: [], selectedModel: null, scopeCount: 0,
      showAiDrawer: false, aiContext: 'MITMPro', aiMessages: [],
      sseUrl: null, reconnectAttempts: 0,
    };
    this.init();
  }

  async loadModules() {
    try {
      const resp = await fetch('/api/modules');
      const data = await resp.json();
      this.state.modules = data.modules || [];
      this.renderSidebar();
      this.renderModelSelector();
    } catch (e) { console.error('Failed to load modules:', e); }
  }

  renderSidebar() {
    const nav = document.getElementById('navMenu');
    if (!nav) return;
    nav.innerHTML = '';
    this.state.modules.forEach(m => {
      const item = document.createElement('div');
      item.className = 'nav-item';
      item.id = `nav-${m.key}`;
      item.innerHTML = `<span class="nav-icon">${m.icon}</span><span>${m.label}</span>`;
      item.addEventListener('click', () => this.switchModule(m.key));
      if (m.key === this.state.currentModule) item.classList.add('active');
      nav.appendChild(item);
    });
  }

  switchModule(key) {
    this.state.currentModule = key;
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    const active = document.getElementById(`nav-${key}`);
    if (active) active.classList.add('active');
    const ui = this.renderModuleUI();
    document.getElementById('content').innerHTML = ui.html || '';
    document.getElementById('crumb').textContent = ui.title || key.replace('-', ' ');
    if (this['init' + key.charAt(0).toUpperCase() + key.slice(1)]) {
      this['init' + key.charAt(0).toUpperCase() + key.slice(1)]();
    }
    if (key === 'ai') this.toggleAiDrawer(true);
  }

  renderModuleUI() {
    const modules = {
      dashboard: { title: 'Dashboard', html: this.renderDashboard() },
      ai: { title: 'AI Assistant', html: '' },
      traffic: { title: 'AI Traffic Analyst', html: this.renderTrafficAnalyst() },
      burp: { title: 'Burp Tools', html: this.renderBurpTools() },
      websploit: { title: 'WebSploit', html: this.renderWebSploit() },
      proxy: { title: 'Proxy Tools', html: this.renderProxyTools() },
      waf: { title: 'WAF/Bypass', html: this.renderWaf() },
      phish: { title: 'Website Masquerading', html: this.renderMasquerading() },
      dlp: { title: 'Inline DLP Proxy', html: this.renderDlp() },
      network: { title: 'Network Attacks', html: this.renderNetworkAttacks() },
      sslstrip: { title: 'SSL Strip / MITM', html: this.renderSslstrip() },
      campaigns: { title: 'Campaign Manager', html: this.renderCampaigns() },
      email: { title: 'Email Engineer', html: this.renderEmail() },
      helper: { title: 'AI Helper', html: '' },
      history: { title: 'HTTP History', html: this.renderHistory() },
      oast: { title: 'OAST / DNS', html: this.renderOast() },
      macro: { title: 'Macro / Flow', html: this.renderMacro() },
      scope: { title: 'Scope', html: this.renderScope() },
      analysis: { title: 'Analysis', html: this.renderAnalysis() },
      nsniffer: { title: 'Nsniffer Toolkit', html: this.renderNsniffer() },
      autorun: { title: 'AI Auto-Run', html: this.renderAutoRun() },
    };
    return modules[this.state.currentModule] || { title: 'Module Not Found', html: '<div class="alert error">Module not found</div>' };
  }

  setupEventListeners() {
    const toggleBtn = document.getElementById('menuToggle');
    if (toggleBtn) toggleBtn.addEventListener('click', () => this.toggleMobileMenu());
    const modelSelect = document.getElementById('modelSelect');
    if (modelSelect) {
      modelSelect.addEventListener('change', () => {
        const val = modelSelect.value;
        if (val) { common.setModel(val); this.state.selectedModel = val; }
      });
    }
    document.querySelectorAll('.tab').forEach(tab => {
      tab.addEventListener('click', (e) => {
        const target = e.currentTarget.getAttribute('data-tab');
        this.switchTab(target);
      });
    });
  }

  setupAiDrawerEvents() {
    const closeAi = document.getElementById('closeAi');
    if (closeAi) closeAi.addEventListener('click', () => this.toggleAiDrawer(false));
    const toggleAiBtn = document.getElementById('toggleAi');
    if (toggleAiBtn) toggleAiBtn.addEventListener('click', () => this.toggleAiDrawer(!this.state.showAiDrawer));
    const aiForm = document.getElementById('aiForm');
    if (aiForm) {
      aiForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.sendAiMessage();
      });
    }
  }

  async initModelsSelect() {
    try {
      const resp = await fetch('/api/models');
      const data = await resp.json();
      this.state.availableModels = data.models || [];
      this.state.selectedModel = data.selected || this.state.availableModels[0] || 'llama3.2';
      this.renderModelSelector();
    } catch (e) { console.error('Failed to load models:', e); }
  }

  renderModelSelector() {
    const select = document.getElementById('modelSelect');
    if (!select) return;
    select.innerHTML = '';
    if (this.state.availableModels.length) {
      this.state.availableModels.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m;
        opt.text = m;
        if (m === this.state.selectedModel) opt.selected = true;
        select.appendChild(opt);
      });
    } else {
      const opt = document.createElement('option');
      opt.value = '';
      opt.text = 'No models available';
      opt.disabled = true;
      select.appendChild(opt);
    }
  }

  renderDashboard() {
    return `
      <div class="grid">
        <div class="card"><div class="card-header"><span>⚡ Quick Stats</span></div><div class="card-body">
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;">
            <div style="padding:1.5rem;background:var(--panel-header);border-radius:8px;text-align:center;">
              <div style="font-size:2rem;font-weight:700;color:var(--accent);">${this.state.scopeCount}</div>
              <div style="font-size:0.9rem;color:var(--text-muted);margin-top:0.5rem;">Scope Targets</div>
            </div>
            <div style="padding:1.5rem;background:var(--panel-header);border-radius:8px;text-align:center;">
              <div style="font-size:2rem;font-weight:700;color:var(--warning);">${this.state.availableModels.length}</div>
              <div style="font-size:0.9rem;color:var(--text-muted);margin-top:0.5rem;">Ollama Models</div>
            </div>
            <div style="padding:1.5rem;background:var(--panel-header);border-radius:8px;text-align:center;">
              <div style="font-size:2rem;font-weight:700;color:var(--success);">${this.state.modules.length}</div>
              <div style="font-size:0.9rem;color:var(--text-muted);margin-top:0.5rem;">Available Tools</div>
            </div>
          </div>
        </div></div>
      </div>
      <div class="grid">
        <div class="card"><div class="card-header"><span>🛡️ Recent Activity</span></div><div class="card-body">
          <div style="font-size:0.95rem;color:var(--text-muted);text-align:center;padding:2rem;">
            Activity feed will be populated as tools are used.
          </div></div></div>
        <div class="card"><div class="card-header"><span>🧠 AI Learning Status</span></div><div class="card-body">
          <div style="font-size:0.95rem;">
            <div style="margin-bottom:1rem;">
              <div style="display:flex;justify-content:space-between;margin-bottom:0.5rem;"><span>Payload Effectiveness</span><span style="color:var(--success);">OK</span></div>
              <div style="height:8px;background:var(--border);border-radius:4px;"><div style="height:100%;width:85%;background:var(--success);border-radius:4px;"></div></div>
            </div>
            <div style="margin-bottom:1rem;">
              <div style="display:flex;justify-content:space-between;margin-bottom:0.5rem;"><span>Technique Success Rate</span><span style="color:var(--accent);">Excellent</span></div>
              <div style="height:8px;background:var(--border);border-radius:4px;"><div style="height:100%;width:92%;background:var(--accent);border-radius:4px;"></div></div>
            </div>
          </div>
        </div></div>
      </div>
    `;
  }

  renderTrafficAnalyst() {
    return `
      <div class="tabs">
        <button class="tab active" data-tab="history">Request/Response History</button>
        <button class="tab" data-tab="decode">Hex/Decode</button>
      </div>
      <div class="tab-content active" id="history">
        <div class="card"><div class="card-header"><span>🔍 Analyze HTTP Request/Response</span><button class="btn secondary" id="clearTraffic">Clear</button></div><div class="card-body">
          <div class="form-group"><label class="form-label">Request (Raw):</label><textarea id="reqText" class="form-control" rows="8" placeholder="e.g., GET /api/users HTTP/1.1..."></textarea></div>
          <div class="form-group"><label class="form-label">Response (Raw):</label><textarea id="respText" class="form-control" rows="8" placeholder="e.g., HTTP/1.1 200 OK..."></textarea></div>
          <div class="input-group"><input id="actionInput" type="text" class="form-control" placeholder="Action: 'Find vulnerabilities', 'Explain', 'Hash', etc." value="Find vulnerabilities" /><button class="btn primary" id="analyzeBtn">Analyze</button></div>
        </div></div>
        <div class="card" style="margin-top:2rem;"><div class="card-header"><span>📝 Analysis Result</span></div><div class="card-body">
          <div id="analysisResult" style="min-height:200px;font-family:monospace;white-space:pre-wrap;background:var(--bg);padding:1.5rem;border-radius:6px;border:1px solid var(--border);">
            Paste a request/response to analyze...
          </div>
        </div></div>
      </div>
      <div class="tab-content" id="decode">
        <div class="card"><div class="card-header"><span>🔎 Hex/Decode Utilities</span></div><div class="card-body">
          <div class="tabs"><button class="tab active" data-tab="base64">Base64</button><button class="tab" data-tab="url">URL Encode</button><button class="tab" data-tab="html">HTML Escape</button><button class="tab" data-tab="hex">Hex</button></div>
          <div class="tab-content active" id="base64">
            <div class="form-group"><label class="form-label">Text to Encode:</label><textarea id="b64In" class="form-control" rows="4" placeholder="Text..."></textarea><button class="btn primary" style="margin-top:1rem;" id="b64Encode">Encode</button><pre id="b64Out" class="code-block" style="margin-top:1rem;display:none;"></pre></div>
          </div>
          <div class="tab-content" id="url">
            <div class="form-group"><label class="form-label">Text to Encode:</label><textarea id="urlIn" class="form-control" rows="4" placeholder="Text..."></textarea><button class="btn primary" style="margin-top:1rem;" id="urlEncode">Encode</button><pre id="urlOut" class="code-block" style="margin-top:1rem;display:none;"></pre></div>
          </div>
          <div class="tab-content" id="html">
            <div class="form-group"><label class="form-label">Text to Escape:</label><textarea id="htmlIn" class="form-control" rows="4" placeholder="Text..."></textarea><button class="btn primary" style="margin-top:1rem;" id="htmlEscape">Escape</button><pre id="htmlOut" class="code-block" style="margin-top:1rem;display:none;"></pre></div>
          </div>
          <div class="tab-content" id="hex">
            <div class="form-group"><label class="form-label">Text to Convert:</label><textarea id="hexIn" class="form-control" rows="4" placeholder="Text..."></textarea><button class="btn primary" style="margin-top:1rem;" id="hexConvert">Convert</button><pre id="hexOut" class="code-block" style="margin-top:1rem;display:none;"></pre></div>
          </div>
        </div></div>
      </div>
    `;
  }

  renderBurpTools() {
    return `
      <div class="tabs"><button class="tab active" data-tab="repeater">Repeater</button><button class="tab" data-tab="intruder">Intruder</button><button class="tab" data-tab="decoder">Decoder</button><button class="tab" data-tab="scanner">Scanner</button><button class="tab" data-tab="otp">OTP Bypass</button></div>
      <div class="tab-content active" id="repeater">
        <div class="card"><div class="card-header"><span>🔁 Burp Repeater</span></div><div class="card-body">
          <div class="form-group"><label class="form-label">URL:</label><div class="input-group"><input type="text" id="repUrl" class="form-control" placeholder="https://example.com/api" /><button class="btn primary" id="repSend">Send</button></div></div>
          <div class="form-group"><label class="form-label">Method:</label><select id="repMethod" class="form-control"><option>GET</option><option>POST</option><option>PUT</option><option>PATCH</option><option>DELETE</option></select></div>
          <div class="form-group" style="display:none;" id="repBodyGroup"><label class="form-label">Body (JSON/Plain):</label><textarea id="repBody" class="form-control" rows="4"></textarea></div>
          <div class="form-group"><label class="form-label">Headers (JSON):</label><textarea id="repHeaders" class="form-control" rows="4" placeholder='{"X-API-Key": "value"}'></textarea></div>
          <div id="repResult" class="code-block" style="display:none;"></div>
        </div></div>
      </div>
      <div class="tab-content" id="intruder">
        <div class="card"><div class="card-header"><span>🔥 Burp Intruder</span></div><div class="card-body">
          <div class="form-group"><label class="form-label">Template (with § markers):</label><textarea id="intruderTemplate" class="form-control" rows="6" placeholder="POST /api/login HTTP/1.1&#10;Content-Type: application/json&#10;&#10;{\n  &#34;user&#34;: &#34;§user§&#34;,\n  &#34;pass&#34;: &#34;§pass§\n}\"></textarea></div>
          <div class="form-group"><label class="form-label">Payloads (comma-separated):</label><textarea id="intruderPayloads" class="form-control" rows="4" placeholder="admin,admin123,user,user1"></textarea></div>
          <div class="form-group"><label class="form-label">Mode:</label><select id="intruderMode" class="form-control"><option>Sniper</option><option>Battering Ram</option></select></div>
          <button class="btn primary" id="intruderRun">Run Attack</button><div id="intruderResult" class="code-block" style="display:none;"></div>
        </div></div>
      </div>
      <div class="tab-content" id="decoder">
        <div class="card"><div class="card-header"><span>🔓 Burp Decoder/Encoder</span></div><div class="card-body">
          <div class="form-group"><label class="form-label">Input:</label><textarea id="decodeInput" class="form-control" rows="4" placeholder="Base64, URL, HTML, Hex, etc..."></textarea></div>
          <div class="form-group"><label class="form-label">Format:</label><select id="decodeFormat" class="form-control"><option>Base64</option><option>URL</option><option>HTML</option><option>Hex</option></select></div>
          <div class="form-group"><label class="form-label">Mode:</label><select id="decodeMode" class="form-control"><option>Encode</option><option>Decode</option></select></div>
          <button class="btn primary" id="decodeRun">Convert</button><div id="decodeOutput" class="code-block" style="display:none;"></div>
        </div></div>
      </div>
      <div class="tab-content" id="scanner">
        <div class="card"><div class="card-header"><span>📊 Burp Scanner</span></div><div class="card-body">
          <div class="form-group"><label class="form-label">Target URL:</label><input type="text" id="scannerUrl" class="form-control" placeholder="https://example.com" /></div>
          <div class="form-group"><label class="form-label">Checks:</label><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;">
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Reflected XSS" checked /> Reflected XSS</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="SQL Injection" checked /> SQL Injection</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Open Redirect" checked /> Open Redirect</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="LFI/RFI" checked /> LFI/RFI</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="SSRF" checked /> SSRF</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Command Injection" checked /> Command Injection</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Sensitive Files" checked /> Sensitive Files</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Header Security" checked /> Header Security</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Directory Busting" checked /> Directory Busting</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="CORS Misconfig" checked /> CORS Misconfig</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="Cookie Security" checked /> Cookie Security</label>
            <label style="display:flex;align-items:center;gap:0.5rem;"><input type="checkbox" value="SSL/TLS Info" checked /> SSL/TLS Info</label>
          </div></div>
          <button class="btn primary" id="scannerRun">Run Scan</button><div id="scannerOutput" style="margin-top:1.5rem;max-height:400px;overflow-y:auto;"></div>
        </div></div>
      </div>
      <div class="tab-content" id="otp">
        <div class="card"><div class="card-header"><span>🔐 OTP Bypass Toolbox</span></div><div class="card-body">
          <div class="alert info"><strong>🔥 TIP:</strong> Click 'Load Techniques' to see all available methods, then configure and run each one.</div>
          <div class="form-group"><label class="form-label">Available Techniques:</label><div id="otpTechniques" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;"></div></div>
          <hr style="border-color:var(--border);margin:2rem 0;"><div id="otpRunner" style="display:none;">
            <div class="form-group"><label class="form-label">Select Technique:</label><select id="otpTechSelect" class="form-control"></select></div>
            <div class="form-group"><label class="form-label">Target URL:</label><input type="text" id="otpTargetUrl" class="form-control" placeholder="https://api.example.com/auth" /></div>
            <div class="form-group"><label class="form-label">Username (optional):</label><input type="text" id="otpUsername" class="form-control" placeholder="admin" /></div>
            <div class="form-group"><label class="form-label">Password (optional):</label><input type="password" id="otpPassword" class="form-control" placeholder="password" /></div>
            <button class="btn danger" id="otpRun">🔓 Run Bypass Technique</button><div id="otpOutput" class="code-block" style="margin-top:1.5rem;display:none;"></div>
          </div></div></div>
      </div>
    `;
  }

  renderWebSploit() { return `<div class="card"><div class="card-header"><span>🌐 WebSploit Framework</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🌐</div><h3>WebSploit is loading...</h3><p>The WebSploit automation framework will appear here once initialized.</p></div></div></div>`; }
  renderProxyTools() { return `<div class="card"><div class="card-header"><span>🔀 MITM Proxy Tools</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🔀</div><h3>Proxy tools will be loaded here.</h3><p>Intercept and modify HTTP traffic for testing.</p></div></div></div>`; }
  renderWaf() { return `<div class="card"><div class="card-header"><span>🚧 WAF/Bypass Generator</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🚧</div><h3>WAF bypass tools loading...</h3><p>Generate payload variants and bypass detection logic.</p></div></div></div>`; }
  renderMasquerading() { return `<div class="card"><div class="card-header"><span>🎭 Website Masquerading</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🎭</div><h3>Masquerading tools loading...</h3><p>Clone sites, generate fake SSL certs, perform domain spoofing.</p></div></div></div>`; }
  renderDlp() { return `<div class="card"><div class="card-header"><span>🛡️ Inline DLP Proxy</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🛡️</div><h3>DLP proxy loading...</h3><p>Detect and block sensitive data leakage.</p></div></div></div>`; }
  renderNetworkAttacks() { return `<div class="card"><div class="card-header"><span>⚡ Network Attacks</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">⚡</div><h3>Network attacks loading...</h3><p>ARP poisoning, DNS spoofing, ICMP flood, and more.</p></div></div></div>`; }
  renderSslstrip() { return `<div class="card"><div class="card-header"><span>🔒 SSL Strip / MITM</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🔒</div><h3>SSL/MITM tools loading...</h3><p>Strip HTTPS, intercept TLS handshakes, perform CA injection.</p></div></div></div>`; }
  renderCampaigns() { return `<div class="card"><div class="card-header"><span>📊 Campaign Manager</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">📊</div><h3>Campaign manager loading...</h3><p>Plan, schedule, and track multiple security assessments.</p></div></div></div>`; }
  renderEmail() { return `<div class="card"><div class="card-header"><span>✉️ Email Engineer</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">✉️</div><h3>Email engineering loading...</h3><p>Create phishing templates, analyze headers, perform BEC simulations.</p></div></div></div>`; }
  renderHistory() { return `<div class="card"><div class="card-header"><span>📜 HTTP History</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">📜</div><h3>HTTP traffic history loading...</h3><p>View captured requests/responses with filtering and search.</p></div></div></div>`; }
  renderOast() { return `<div class="card"><div class="card-header"><span>📡 OAST / DNS</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">📡</div><h3>OAST/DNS tools loading...</h3><p>Deploy HTTP/DNS callbacks, monitor interactions, analyze payloads.</p></div></div></div>`; }
  renderMacro() { return `<div class="card"><div class="card-header"><span>🔁 Macro / Flow</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🔁</div><h3>Macro/flow recorder loading...</h3><p>Record and replay complex attack sequences.</p></div></div></div>`; }
  renderScope() { return `<div class="card"><div class="card-header"><span>🎯 Scope Management</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🎯</div><h3>Scope manager loading...</h3><p>Add/remove target hosts, manage exclusions, export configurations.</p></div></div></div>`; }
  renderAnalysis() { return `<div class="card"><div class="card-header"><span>📊 Analysis</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">📊</div><h3>Analysis dashboard loading...</h3><p>Generate reports, visualize findings, export to multiple formats.</p></div></div></div>`; }
  renderNsniffer() { return `<div class="card"><div class="card-header"><span>📡 Nsniffer Toolkit</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">📡</div><h3>Nsniffer toolkit loading...</h3><p>Packet sniffing, network reconnaissance, traffic analysis.</p></div></div></div>`; }
  renderAutoRun() { return `<div class="card"><div class="card-header"><span>🚀 AI Auto-Run</span></div><div class="card-body"><div style="text-align:center;padding:3rem;color:var(--text-muted);"><div style="font-size:3rem;margin-bottom:1rem;">🚀</div><h3>AI auto-run engine loading...</h3><p>Automated security assessments with AI-powered planning and execution.</p></div></div></div>`; }

  async initBurpTools() {
    const sendBtn = document.getElementById('repSend');
    if (sendBtn) {
      sendBtn.addEventListener('click', async () => {
        const url = document.getElementById('repUrl').value;
        const method = document.getElementById('repMethod').value;
        const headers = document.getElementById('repHeaders').value ? JSON.parse(document.getElementById('repHeaders').value) : {};
        const body = document.getElementById('repBody').value;
        try {
          const resp = await fetch('/api/burp/repeater/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url, method, headers, body }),
          });
          const data = await resp.json();
          const out = document.getElementById('repResult');
          out.style.display = 'block';
          if (data.error) out.textContent = `Error: ${data.error}`;
          else out.textContent = data.response;
        } catch (e) { console.error('Repeater error:', e); }
      });
    }
    const modeSelect = document.getElementById('repMethod');
    if (modeSelect) {
      modeSelect.addEventListener('change', () => {
        const bodyGroup = document.getElementById('repBodyGroup');
        if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(modeSelect.value)) {
          bodyGroup.style.display = 'block';
        } else {
          bodyGroup.style.display = 'none';
        }
      });
    }
  }

  async initScannerTab() {
    const btn = document.getElementById('scannerRun');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      const url = document.getElementById('scannerUrl').value;
      const checks = Array.from(document.querySelectorAll('input[type="checkbox"]:checked')).map(i => i.value);
      try {
        const resp = await fetch('/api/burp/scanner/scan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url, checks }),
        });
        const data = await resp.json();
        const out = document.getElementById('scannerOutput');
        out.innerHTML = '';
        data.findings.forEach(f => {
          const span = document.createElement('span');
          span.className = 'badge ' + (f.startsWith('CRITICAL') ? 'danger' : f.startsWith('HIGH') ? 'warning' : f.startsWith('MEDIUM') ? 'warning' : 'success');
          span.textContent = f;
          out.appendChild(span);
        });
      } catch (e) { console.error('Scanner error:', e); }
    });
  }

  async initIntruderTab() {
    const btn = document.getElementById('intruderRun');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      const template = document.getElementById('intruderTemplate').value;
      const payloads = document.getElementById('intruderPayloads').value.split(',').map(p => p.trim()).filter(p => p);
      const mode = document.getElementById('intruderMode').value;
      try {
        const resp = await fetch('/api/burp/intruder/attack', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ template, payloads, mode }),
        });
        const data = await resp.json();
        const out = document.getElementById('intruderResult');
        out.style.display = 'block';
        if (data.error) out.textContent = `Error: ${data.error}`;
        else out.textContent = JSON.stringify(data.results, null, 2);
      } catch (e) { console.error('Intruder error:', e); }
    });
  }

  async initDecoderTab() {
    const btn = document.getElementById('decodeRun');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      const input = document.getElementById('decodeInput').value;
      const format = document.getElementById('decodeFormat').value;
      const mode = document.getElementById('decodeMode').value;
      try {
        const resp = await fetch('/api/burp/decoder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: input, format, mode }),
        });
        const data = await resp.json();
        const out = document.getElementById('decodeOutput');
        out.style.display = 'block';
        if (data.error) out.textContent = `Error: ${data.error}`;
        else out.textContent = data.result;
      } catch (e) { console.error('Decoder error:', e); }
    });
  }

  async initOtpTechniques() {
    await fetch('/api/otp/techniques')
      .then(r => r.json())
      .then(data => {
        const container = document.getElementById('otpTechniques');
        if (!container) return;
        container.innerHTML = '';
        if (!data.techniques || !data.techniques.length) {
          container.innerHTML = '<div class="alert error">No techniques available</div>';
          return;
        }
        data.techniques.forEach(t => {
          const btn = document.createElement('button');
          btn.className = 'btn secondary';
          btn.textContent = t;
          btn.style.width = '100%';
          btn.style.marginBottom = '0.5rem';
          btn.onclick = () => this.loadOtpTechnique(t);
          container.appendChild(btn);
        });
      })
      .catch(e => console.error('Failed to load OTP techniques:', e));
  }

  async loadOtpTechnique(name) {
    document.getElementById('otpRunner').style.display = 'block';
    document.getElementById('otpTechSelect').innerHTML = '';
    const select = document.getElementById('otpTechSelect');
    const opt = document.createElement('option');
    opt.value = name;
    opt.text = name;
    select.appendChild(opt);
    select.value = name;
  }

  async initOtpTab() {
    const btn = document.getElementById('otpRun');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      const technique = document.getElementById('otpTechSelect').value;
      const targetUrl = document.getElementById('otpTargetUrl').value;
      const username = document.getElementById('otpUsername').value;
      const password = document.getElementById('otpPassword').value;
      try {
        const resp = await fetch('/api/otp/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ technique, target_url: targetUrl, username, password }),
        });
        const data = await resp.json();
        const out = document.getElementById('otpOutput');
        out.style.display = 'block';
        if (data.error) out.textContent = `Error: ${data.error}`;
        else out.textContent = data.result;
      } catch (e) { console.error('OTP run error:', e); }
    });
    await this.initOtpTechniques();
  }

  async initTrafficAnalystTab() {
    const analyzeBtn = document.getElementById('analyzeBtn');
    if (!analyzeBtn) return;
    analyzeBtn.addEventListener('click', async () => {
      const reqText = document.getElementById('reqText').value;
      const respText = document.getElementById('respText').value;
      const action = document.getElementById('actionInput').value;
      try {
        const resp = await fetch('/api/traffic/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ request: reqText, response: respText, action }),
        });
        const data = await resp.json();
        const out = document.getElementById('analysisResult');
        out.textContent = data.analysis || 'No analysis returned';
      } catch (e) { console.error('Traffic analysis error:', e); }
    });
  }

  async initDecodeTabs() {
    const utils = {
      b64Encode: () => {
        const inEl = document.getElementById('b64In');
        const outEl = document.getElementById('b64Out');
        try {
          const result = btoa(inEl.value);
          outEl.textContent = result;
          outEl.style.display = 'block';
        } catch (e) {
          outEl.textContent = `Error: ${e.message}`;
          outEl.style.display = 'block';
        }
      },
      urlEncode: () => {
        const inEl = document.getElementById('urlIn');
        const outEl = document.getElementById('urlOut');
        const result = encodeURIComponent(inEl.value);
        outEl.textContent = result;
        outEl.style.display = 'block';
      },
      htmlEscape: () => {
        const inEl = document.getElementById('htmlIn');
        const outEl = document.getElementById('htmlOut');
        const result = inEl.value
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#039;');
        outEl.textContent = result;
        outEl.style.display = 'block';
      },
      hexConvert: () => {
        const inEl = document.getElementById('hexIn');
        const outEl = document.getElementById('hexOut');
        const hex = Array.from(inEl.value)
          .map(c => c.charCodeAt(0).toString(16).padStart(2, '0'))
          .join(' ');
        outEl.textContent = hex;
        outEl.style.display = 'block';
      },
    };

    document.querySelectorAll('.tab[data-tab]').forEach(tab => {
      const target = tab.getAttribute('data-tab');
      if (utils[target]) {
        tab.addEventListener('click', () => {
          document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
          document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
          tab.classList.add('active');
          document.getElementById(target).classList.add('active');
        });
      }
    });

    Object.entries(utils).forEach(([id, fn]) => {
      const btn = document.getElementById(id);
      if (btn) btn.addEventListener('click', fn);
    });
  }

  async checkOllamaStatus() {
    try {
      const resp = await fetch('/api/ollama/health');
      const data = await resp.json();
      this.state.ollamaRunning = data.running;
      const badge = document.getElementById('ollamaBadge');
      const dot = document.getElementById('ollamaDot');
      const text = document.getElementById('ollamaText');
      if (badge && dot && text) {
        if (data.running) {
          dot.classList.add('running');
          text.textContent = 'AI Running';
        } else {
          dot.classList.remove('running');
          text.textContent = 'AI Offline';
        }
      }
      this.state.availableModels = data.models || [];
      this.renderModelSelector();
    } catch (e) { console.error('Ollama status check failed:', e); }
  }

  async loadScopeCount() {
    try {
      const resp = await fetch('/api/scope/full');
      const data = await resp.json();
      this.state.scopeCount = data.count;
      const pill = document.getElementById('scopePill');
      if (pill) pill.textContent = `Scope: ${data.count}`;
    } catch (e) { console.error('Failed to load scope count:', e); }
  }

  switchTab(target) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    const activeTab = document.querySelector(`.tab[data-tab="${target}"]`);
    if (activeTab) activeTab.classList.add('active');
    const activeContent = document.getElementById(target);
    if (activeContent) activeContent.classList.add('active');
    if (this['init' + target.charAt(0).toUpperCase() + target.slice(1)]) {
      this['init' + target.charAt(0).toUpperCase() + target.slice(1)]();
    }
  }

  toggleMobileMenu() {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth <= 768) {
      sidebar.classList.toggle('mobile-open');
    }
  }

  showToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    setTimeout(() => toast.classList.remove('show'), 3000);
  }

  init() {
    this.cache = {};
    this.loadModules();
    this.setupEventListeners();
    this.setupAiDrawerEvents();
    this.initModelsSelect();
    setTimeout(() => this.checkOllamaStatus(), 500);
    setTimeout(() => this.loadScopeCount(), 1000);
    setTimeout(() => this.initBurpTools(), 0);
    setInterval(() => this.checkOllamaStatus(), 15000);
    if (window.innerWidth <= 768) {
      document.getElementById('sidebar').classList.add('mobile-open');
    }
  }
}

window.addEventListener('DOMContentLoaded', () => {
  new MITMProApp();
});
