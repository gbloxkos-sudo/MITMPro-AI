import threading
import tkinter as tk
from tkinter import ttk, scrolledtext

from mitmpro.common import ollama_models, register_model_listener
from mitmpro import common
from mitmpro.knowledge import APP_KNOWLEDGE
from mitmpro import ai_core

FEATURES = [
    "AI Assistant (Ollama)",
    "AI Traffic Analyst",
    "Burp Tools",
    "WebSploit",
    "Proxy Tools",
    "WAF/Bypass",
    "AI Helper",
    "HTTP History",
    "OAST / DNS",
    "Macro / Flow",
    "Scope",
    "Analysis",
    "Network Attacks",
    "SSL Strip",
    "Campaign Manager",
    "Email Engineer",
    "Website Masquerading",
    "Inline DLP Proxy",
    "Nsniffer Toolkit",
    "AI Auto-Run",
    "Dashboard",
]


from mitmpro.ai_components import AIHelperTab

class AIHelperPanel(ttk.Notebook):
    def __init__(self, master, get_active_feature=None):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Helper Assistant")
        self.add(AIHelperTab(self, "General Guidance"), text="Quick Help")
        
        self.get_active_feature = get_active_feature
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(2, weight=1)
        self.history = []
        self._busy = False

        bar = ttk.Frame(self.main_frame)
        bar.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        bar.columnconfigure(2, weight=1)
        ttk.Label(bar, text="Context:").grid(row=0, column=0)
        self.feature = ttk.Combobox(bar, values=FEATURES, width=20)
        self.feature.set("Burp Tools")
        self.feature.grid(row=0, column=1)
        ttk.Button(bar, text="Use Current Tab", command=self.use_current).grid(row=0, column=2, sticky="w")
        self.model = ttk.Combobox(bar, width=22, state="readonly")
        self.model.grid(row=0, column=3)
        self.model.bind("<<ComboboxSelected>>",
                        lambda e: common.set_model(self.model.get()))
        ttk.Button(bar, text="Refresh Models", command=lambda: threading.Thread(target=self.load_models, daemon=True).start()).grid(row=0, column=4)
        ttk.Button(bar, text="Assessment Checklist", command=lambda: threading.Thread(target=self.auto_assessment, daemon=True).start()).grid(row=0, column=5)
        self.stop_btn = ttk.Button(bar, text="Stop", command=self.stop_stream, state="disabled")
        self.stop_btn.grid(row=0, column=6, padx=4)

        self.chat = scrolledtext.ScrolledText(self.main_frame, state="disabled", font=("TkDefaultFont", 11))
        self.chat.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

        bottom = ttk.Frame(self.main_frame)
        bottom.grid(row=3, column=0, sticky="ew", padx=4, pady=4)
        bottom.columnconfigure(0, weight=1)
        self.entry = scrolledtext.ScrolledText(bottom, height=3)
        self.entry.grid(row=0, column=0, sticky="ew")
        self.entry.bind("<Control-Return>", self.on_send)
        ttk.Button(bottom, text="Send (Ctrl+Enter)", command=lambda: threading.Thread(target=self.send, daemon=True).start()).grid(row=0, column=1)
        ttk.Button(bottom, text="Clear", command=self.clear).grid(row=0, column=2)

        self.load_models()
        register_model_listener(self._on_global_model)


    def load_models(self):
        import threading
        def _fetch():
            try:
                models = ollama_models()
            except Exception:
                models = []
            def apply():
                self.model["values"] = models
                if models:
                    self.model.set(common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0])
            try:
                self.after(0, apply)
            except Exception:
                apply()
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            if model and model not in (self.model["values"] or ()):
                self.model["values"] = list(self.model["values"] or ()) + [model]
            if model:
                self.model.set(model)
        try:
            self.after(0, apply)
        except Exception:
            pass

    def use_current(self):
        if self.get_active_feature:
            f = self.get_active_feature()
            if f in FEATURES:
                self.feature.set(f)

    def append(self, who, text):
        self.chat.config(state="normal")
        self.chat.insert("end", f"\n=== {who} ===\n{text}\n")
        self.chat.see("end")
        self.chat.config(state="disabled")

    def clear(self):
        self.history = []
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")

    def on_send(self, event):
        threading.Thread(target=self.send, daemon=True).start()
        return "break"

    def _system_prompt(self):
        ctx = self.feature.get()
        health = ""
        try:
            app = self.winfo_toplevel()
            if hasattr(app, "_health_text"):
                health = app._health_text()
        except Exception:
            pass
        return ai_core.build_system_prompt(ctx, health)

    def send(self):
        if self._busy:
            return
        self._busy = True
        def _do():
            msg = self.entry.get("1.0", "end").strip()
            if not msg:
                self._busy = False
                return
            self.entry.delete("1.0", "end")
            self.append("You", msg)
            self.history.append({"role": "user", "content": msg})
            self._stream(msg)
        self.after(0, _do)

    def auto_assessment(self):
        if self._busy:
            return
        self._busy = True
        def _do():
            ctx = self.feature.get()
            prompt = (f"Produce a complete, phased security assessment methodology / checklist for the "
                      f"'{ctx}' module in MITMPro. Cover recon, enumeration, exploitation, validation, and "
                      f"reporting. Include concrete commands, tool usage, and example payloads where relevant.")
            self.entry.delete("1.0", "end")
            self.append("You", "[Assessment Checklist] " + prompt)
            self.history.append({"role": "user", "content": prompt})
            self._stream(prompt)
        self.after(0, _do)

    def _stream(self, msg):
        model = self.model.get()
        if not model:
            models = ollama_models()
            if models:
                model = models[0]
                self.model.set(model)
            else:
                self.append("AI", "No Ollama model available. Start 'ollama serve' and "
                           "pull a model (e.g. `ollama pull llama3.2:1b`), "
                           "then click 'Refresh Models'.")
                self._busy = False
                return
        messages = [{"role": "system", "content": self._system_prompt()}] + self.history
        self.append("AI", "")
        
        self._cancel_event = threading.Event()
        self.stop_btn.config(state="normal")

        def on_token(t):
            def update():
                self.chat.config(state="normal")
                self.chat.insert("end", t)
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        def on_done(full):
            def update():
                self._busy = False
                self.stop_btn.config(state="disabled")
                self.history.append({"role": "assistant", "content": full})
                ai_core.remember(msg, full, self.feature.get())
            self.after(0, update)
        
        def on_error(e):
            def update():
                self._busy = False
                self.stop_btn.config(state="disabled")
                self.chat.config(state="normal")
                self.chat.insert("end", f"\n[error: {e}]")
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        threading.Thread(
            target=ai_core.stream_chat,
            args=(model, messages),
            kwargs={"on_token": on_token, "on_done": on_done, "on_error": on_error,
                    "context": self.feature.get(), "rag_query": msg,
                    "cancel_event": self._cancel_event},
            daemon=True,
        ).start()

    def stop_stream(self):
        """Stop the currently streaming AI response."""
        if hasattr(self, '_cancel_event') and self._cancel_event:
            self._cancel_event.set()
            self.stop_btn.config(state="disabled")
            self.append("System", "[Stopped by user]")