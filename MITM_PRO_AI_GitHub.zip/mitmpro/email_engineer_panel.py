"""Email Engineer — SET-style phishing email template engine.

Provides professional phishing email crafting:
  - Pre-built templates (credential harvest, malware delivery, callback)
  - AI-generated custom templates
  - Variable substitution (target name, company, link, etc.)
  - Preview and test send via SMTP
  - Template library with categories
"""
import os
import sys
import time
import json
import smtplib
import threading
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

from mitmpro import common
from mitmpro.ai_components import AIHelperTab
from mitmpro import logger

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

TEMPLATES_DIR = os.path.join(OUTPUT_DIR, "email_templates")
os.makedirs(TEMPLATES_DIR, exist_ok=True)

# Built-in templates
BUILTIN_TEMPLATES = {
    "credential_harvest": {
        "name": "Credential Harvest",
        "category": "credential",
        "subject": "Urgent: Your account requires verification",
        "from_name": "IT Security Team",
        "body": (
            "Dear {target_name},\n\n"
            "We have detected unusual activity on your account. "
            "To protect your account, please verify your credentials "
            "immediately by clicking the link below:\n\n"
            "{phish_link}\n\n"
            "If you do not verify within 24 hours, your account "
            "will be temporarily suspended.\n\n"
            "Best regards,\n{company_name} IT Security Team"
        ),
        "html_body": (
            "<html><body style='font-family:Arial; padding:20px;'>"
            "<div style='max-width:600px; margin:0 auto; border:1px solid #ddd; "
            "padding:20px; border-radius:8px;'>"
            "<h2 style='color:#d32f2f;'>Security Alert</h2>"
            "<p>Dear {target_name},</p>"
            "<p>We have detected unusual activity on your account. "
            "To protect your account, please verify your credentials "
            "immediately:</p>"
            "<p style='text-align:center; margin:30px 0;'>"
            "<a href='{phish_link}' style='background:#1976d2; color:white; "
            "padding:12px 30px; text-decoration:none; border-radius:5px; "
            "font-weight:bold;'>Verify Account</a></p>"
            "<p style='color:#666; font-size:12px;'>If you do not verify "
            "within 24 hours, your account will be temporarily suspended.</p>"
            "<hr style='border:none; border-top:1px solid #eee;'>"
            "<p style='color:#999; font-size:11px;'>{company_name} "
            "IT Security Team</p>"
            "</div></body></html>"
        ),
    },
    "sharepoint_invite": {
        "name": "SharePoint Document Share",
        "category": "sharing",
        "subject": "{sender_name} shared a document with you",
        "from_name": "Microsoft SharePoint",
        "body": (
            "Hi {target_name},\n\n"
            "{sender_name} has shared a document with you:\n\n"
            "\"{doc_name}\"\n\n"
            "Click the link below to access the document:\n\n"
            "{phish_link}\n\n"
            "Best regards,\n{company_name}"
        ),
        "html_body": (
            "<html><body style='font-family:Segoe UI; padding:20px;'>"
            "<div style='max-width:600px; margin:0 auto; padding:20px;'>"
            "<div style='background:#0078d4; color:white; padding:15px; "
            "border-radius:8px 8px 0 0;'>"
            "<h2 style='margin:0;'>SharePoint Online</h2></div>"
            "<div style='border:1px solid #ddd; padding:20px; "
            "border-radius:0 0 8px 8px;'>"
            "<p>Hi {target_name},</p>"
            "<p><strong>{sender_name}</strong> has shared a document:</p>"
            "<div style='background:#f5f5f5; padding:15px; border-left:4px "
            "solid #0078d4; margin:15px 0;'>"
            "<p style='margin:0;'>{doc_name}</p></div>"
            "<p style='text-align:center;'>"
            "<a href='{phish_link}' style='background:#0078d4; color:white; "
            "padding:10px 25px; text-decoration:none; border-radius:4px;'>"
            "Open Document</a></p>"
            "</div></div></body></html>"
        ),
    },
    "password_reset": {
        "name": "Password Reset",
        "category": "credential",
        "subject": "Password Reset Request",
        "from_name": "Account Services",
        "body": (
            "Dear {target_name},\n\n"
            "A password reset was requested for your account. "
            "If this was you, click the link below to set a new password:\n\n"
            "{phish_link}\n\n"
            "If you did not request this, please ignore this email.\n\n"
            "Regards,\n{company_name} Account Services"
        ),
        "html_body": (
            "<html><body style='font-family:Arial; padding:20px;'>"
            "<div style='max-width:500px; margin:0 auto; border:1px solid #ccc; "
            "padding:20px; border-radius:8px;'>"
            "<h2 style='color:#333;'>Password Reset</h2>"
            "<p>Dear {target_name},</p>"
            "<p>A password reset was requested for your account.</p>"
            "<p style='text-align:center; margin:25px 0;'>"
            "<a href='{phish_link}' style='background:#28a745; color:white; "
            "padding:12px 30px; text-decoration:none; border-radius:5px;'>"
            "Reset Password</a></p>"
            "<p style='color:#999; font-size:12px;'>If you did not request "
            "this, please ignore this email.</p>"
            "<hr style='border:none; border-top:1px solid #eee;'>"
            "<p style='color:#999; font-size:11px;'>{company_name}</p>"
            "</div></body></html>"
        ),
    },
    "invoice_attach": {
        "name": "Invoice / Payment",
        "category": "malware",
        "subject": "Invoice #{invoice_num} - Payment Required",
        "from_name": "Accounts Payable",
        "body": (
            "Dear {target_name},\n\n"
            "Please find attached the invoice #{invoice_num} for your review. "
            "Payment is due by {due_date}.\n\n"
            "You can also view the invoice online:\n{phish_link}\n\n"
            "Please process this at your earliest convenience.\n\n"
            "Best regards,\n{company_name} Accounts Department"
        ),
        "html_body": (
            "<html><body style='font-family:Arial; padding:20px;'>"
            "<div style='max-width:600px; margin:0 auto; border:1px solid #ddd; "
            "padding:20px; border-radius:8px;'>"
            "<h2 style='color:#333;'>Invoice #{invoice_num}</h2>"
            "<p>Dear {target_name},</p>"
            "<p>Please find attached the invoice for your review.</p>"
            "<div style='background:#fff3cd; border:1px solid #ffc107; "
            "padding:15px; border-radius:5px; margin:15px 0;'>"
            "<strong>Payment Due:</strong> {due_date}</div>"
            "<p style='text-align:center;'>"
            "<a href='{phish_link}' style='background:#dc3545; color:white; "
            "padding:12px 30px; text-decoration:none; border-radius:5px;'>"
            "View Invoice Online</a></p>"
            "<hr style='border:none; border-top:1px solid #eee;'>"
            "<p style='color:#999; font-size:11px;'>{company_name}</p>"
            "</div></body></html>"
        ),
    },
    "wifi_portal": {
        "name": "WiFi Portal Login",
        "category": "credential",
        "subject": "WiFi Access - Login Required",
        "from_name": "Network Admin",
        "body": (
            "Dear {target_name},\n\n"
            "To access the {company_name} WiFi network, please "
            "authenticate using your corporate credentials:\n\n"
            "{phish_link}\n\n"
            "This is required for network access compliance.\n\n"
            "IT Department"
        ),
        "html_body": (
            "<html><body style='font-family:Arial; background:#f0f2f5; "
            "padding:40px;'>"
            "<div style='max-width:400px; margin:0 auto; background:white; "
            "padding:30px; border-radius:10px; box-shadow:0 2px 10px "
            "rgba(0,0,0,0.1);'>"
            "<h2 style='text-align:center; color:#333;'>WiFi Login</h2>"
            "<p style='text-align:center; color:#666;'>{company_name} "
            "Corporate Network</p>"
            "<p style='text-align:center;'>"
            "<a href='{phish_link}' style='display:block; background:#4285f4; "
            "color:white; padding:12px; text-decoration:none; border-radius:5px; "
            "text-align:center; font-weight:bold;'>Sign In with Corporate "
            "Credentials</a></p>"
            "<p style='color:#999; font-size:11px; text-align:center;'>"
            "Required for network access compliance.</p>"
            "</div></body></html>"
        ),
    },
}

VARIABLES = [
    "{target_name}", "{target_email}", "{company_name}",
    "{phish_link}", "{sender_name}", "{doc_name}",
    "{invoice_num}", "{due_date}",
]


class EmailEngineer(ttk.Notebook):
    """Professional phishing email template engine with AI generation,
    SMTP preview, and template management."""

    def __init__(self, master):
        super().__init__(master)

        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Email Engineer")
        self.add(AIHelperTab(self, "Email Engineer"), text="AI Helper")

        self._custom_templates = {}
        self._load_custom_templates()

        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        self._build_ui()

    def _build_ui(self):
        # -- Ollama model header (consistent with other AI panels) --
        hdr = ttk.Frame(self.main_frame)
        hdr.grid(row=0, column=0, sticky="ew", padx=4, pady=(4, 0))
        ttk.Label(hdr, text="Ollama Model:").pack(side="left")
        self.model_combo = ttk.Combobox(hdr, width=26, state="readonly")
        self.model_combo.pack(side="left", padx=4)
        self.model_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: common.set_model(self.model_combo.get()))
        ttk.Button(hdr, text="Refresh Models",
                   command=self._load_models).pack(side="left", padx=4)
        common.register_model_listener(self._on_global_model)
        self._load_models()

        nb = ttk.Notebook(self.main_frame)
        nb.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.main_frame.rowconfigure(1, weight=1)

        # ---- Tab 1: Template Editor ----
        edit_frame = ttk.Frame(nb)
        nb.add(edit_frame, text="  Template Editor  ")
        edit_frame.columnconfigure(1, weight=1)
        edit_frame.rowconfigure(4, weight=1)

        edit_top = ttk.LabelFrame(edit_frame, text="Template Configuration")
        edit_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        edit_top.columnconfigure(1, weight=1)

        ttk.Label(edit_top, text="Template:").grid(
            row=0, column=0, sticky="w", padx=4)
        all_templates = list(BUILTIN_TEMPLATES.keys()) + \
            list(self._custom_templates.keys())
        self.tpl_combo = ttk.Combobox(edit_top, values=all_templates, width=30)
        self.tpl_combo.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.tpl_combo.bind("<<ComboboxSelected>>", self._on_template_select)
        if all_templates:
            self.tpl_combo.set(all_templates[0])

        ttk.Label(edit_top, text="Subject:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.tpl_subject = ttk.Entry(edit_top)
        self.tpl_subject.grid(row=1, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(edit_top, text="From Name:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.tpl_from = ttk.Entry(edit_top)
        self.tpl_from.grid(row=2, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(edit_top, text="Variables:").grid(
            row=3, column=0, sticky="nw", padx=4)
        var_frame = ttk.Frame(edit_top)
        var_frame.grid(row=3, column=1, sticky="ew", padx=4, pady=2)
        ttk.Label(var_frame, text="  ".join(VARIABLES),
                  foreground="#8b949e", font=("Courier", 8)).pack(
                      side="left", anchor="w")

        edit_btns = ttk.Frame(edit_frame)
        edit_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(edit_btns, text="Load Template",
                   command=self.load_template).pack(side="left", padx=4)
        ttk.Button(edit_btns, text="Save Custom",
                   command=self.save_custom_template).pack(side="left", padx=4)
        ttk.Button(edit_btns, text="Delete Custom",
                   command=self.delete_custom_template).pack(side="left", padx=4)
        ttk.Button(edit_btns, text="Preview",
                   command=self.preview_email).pack(side="left", padx=4)
        ttk.Button(edit_btns, text="AI Generate",
                   command=self.ai_generate).pack(side="left", padx=4)

        ttk.Label(edit_frame, text="HTML Body:").grid(
            row=2, column=0, sticky="w", padx=4, pady=(4, 0))
        self.html_body = scrolledtext.ScrolledText(
            edit_frame, height=12, font=("Courier", 10))
        self.html_body.grid(row=3, column=0, columnspan=2,
                            sticky="nsew", padx=4, pady=4)

        ttk.Label(edit_frame, text="Plain Text Body:").grid(
            row=4, column=0, sticky="nw", padx=4, pady=(4, 0))
        self.text_body = scrolledtext.ScrolledText(
            edit_frame, height=8, font=("Courier", 10))
        self.text_body.grid(row=5, column=0, columnspan=2,
                            sticky="nsew", padx=4, pady=4)

        # ---- Tab 2: Preview & Send ----
        send_frame = ttk.Frame(nb)
        nb.add(send_frame, text="  Preview & Send  ")
        send_frame.columnconfigure(1, weight=1)
        send_frame.rowconfigure(2, weight=1)

        send_top = ttk.LabelFrame(send_frame, text="SMTP Configuration")
        send_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        send_top.columnconfigure(1, weight=1)

        ttk.Label(send_top, text="SMTP Server:").grid(
            row=0, column=0, sticky="w", padx=4)
        self.smtp_host = ttk.Entry(send_top)
        self.smtp_host.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.smtp_host.insert(0, "smtp.gmail.com")

        ttk.Label(send_top, text="Port:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.smtp_port = ttk.Entry(send_top, width=8)
        self.smtp_port.grid(row=1, column=1, sticky="w", padx=4, pady=2)
        self.smtp_port.insert(0, "587")

        ttk.Label(send_top, text="Username:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.smtp_user = ttk.Entry(send_top)
        self.smtp_user.grid(row=2, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(send_top, text="Password:").grid(
            row=3, column=0, sticky="w", padx=4)
        self.smtp_pass = ttk.Entry(send_top, show="*")
        self.smtp_pass.grid(row=3, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(send_top, text="From Email:").grid(
            row=4, column=0, sticky="w", padx=4)
        self.smtp_from = ttk.Entry(send_top)
        self.smtp_from.grid(row=4, column=1, sticky="ew", padx=4, pady=2)

        send_opts = ttk.Frame(send_top)
        send_opts.grid(row=5, column=0, columnspan=2, sticky="w", padx=4, pady=2)
        self.send_use_tls = tk.BooleanVar(value=True)
        ttk.Checkbutton(send_opts, text="Use TLS",
                        variable=self.send_use_tls).pack(side="left", padx=4)

        preview_frame = ttk.LabelFrame(send_frame, text="Variables")
        preview_frame.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        preview_frame.columnconfigure(1, weight=1)

        self.var_entries = {}
        for i, var in enumerate(VARIABLES):
            ttk.Label(preview_frame, text=var).grid(
                row=i, column=0, sticky="w", padx=4, pady=1)
            entry = ttk.Entry(preview_frame)
            entry.grid(row=i, column=1, sticky="ew", padx=4, pady=1)
            self.var_entries[var] = entry

        self.var_entries["{company_name}"].insert(0, "Acme Corp")
        self.var_entries["{sender_name}"].insert(0, "John Smith")
        self.var_entries["{doc_name}"].insert(0, "Q4_Report.xlsx")
        self.var_entries["{invoice_num}"].insert(0, "INV-2024-001")
        self.var_entries["{due_date}"].insert(0, "2024-12-31")
        self.var_entries["{phish_link}"].insert(0, "http://192.168.1.1:8080/")

        send_btns = ttk.Frame(send_frame)
        send_btns.grid(row=2, column=0, sticky="ew", padx=4, pady=2)

        send_left = ttk.Frame(send_btns)
        send_left.pack(side="left")
        ttk.Label(send_left, text="To:").pack(side="left", padx=4)
        self.send_to = ttk.Entry(send_left, width=35)
        self.send_to.pack(side="left", padx=4)

        ttk.Button(send_btns, text="Send Test Email",
                   command=self.send_test_email).pack(side="left", padx=4)
        ttk.Button(send_btns, text="Preview Rendered",
                   command=self.preview_rendered).pack(side="left", padx=4)

        self.preview_out = scrolledtext.ScrolledText(
            send_frame, height=14, font=("Courier", 10))
        self.preview_out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 3: Template Library ----
        lib_frame = ttk.Frame(nb)
        nb.add(lib_frame, text="  Template Library  ")
        lib_frame.columnconfigure(0, weight=1)
        lib_frame.rowconfigure(1, weight=1)

        lib_top = ttk.Frame(lib_frame)
        lib_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        ttk.Label(lib_top, text="Template Library").pack(side="left", padx=4)
        ttk.Button(lib_top, text="Refresh",
                   command=self.refresh_library).pack(side="left", padx=4)
        ttk.Button(lib_top, text="Export Selected",
                   command=self.export_template).pack(side="left", padx=4)

        self.lib_tree = ttk.Treeview(
            lib_frame,
            columns=("Name", "Category", "Source"), show="headings")
        self.lib_tree.heading("Name", text="Name")
        self.lib_tree.heading("Category", text="Category")
        self.lib_tree.heading("Source", text="Source")
        self.lib_tree.column("Name", width=250)
        self.lib_tree.column("Category", width=120)
        self.lib_tree.column("Source", width=100)
        self.lib_tree.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)

        self.refresh_library()

    # -------------------------------------------------------- Model header
    def _load_models(self):
        try:
            models = common.ollama_models()
        except Exception as e:
            logger.log_exception(e, "loading Ollama models in EmailEngineer")
            models = []
        self.model_combo["values"] = models
        if models:
            sel = common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0]
            self.model_combo.set(sel)

    def _on_global_model(self, model):
        try:
            if model and model in (self.model_combo["values"] or ()):
                self.model_combo.set(model)
        except Exception as e:
            logger.log_exception(e, "updating model in EmailEngineer")

    # -------------------------------------------------------- Template Ops
    def _on_template_select(self, event=None):
        name = self.tpl_combo.get().strip()
        tpl = BUILTIN_TEMPLATES.get(name) or self._custom_templates.get(name)
        if not tpl:
            return
        self.tpl_subject.delete(0, "end")
        self.tpl_subject.insert(0, tpl.get("subject", ""))
        self.tpl_from.delete(0, "end")
        self.tpl_from.insert(0, tpl.get("from_name", ""))
        self.html_body.delete("1.0", "end")
        self.html_body.insert("1.0", tpl.get("html_body", ""))
        self.text_body.delete("1.0", "end")
        self.text_body.insert("1.0", tpl.get("body", ""))

    def load_template(self, name=None, **kwargs):
        if name:
            self.tpl_combo.set(name)
        self._on_template_select()
        return self.tpl_subject.get().strip()

    def save_custom_template(self, **kwargs):
        name = self.tpl_combo.get().strip()
        if not name:
            messagebox.showerror("Error", "Enter a template name.")
            return

        tpl = {
            "name": name,
            "category": "custom",
            "subject": self.tpl_subject.get().strip(),
            "from_name": self.tpl_from.get().strip(),
            "html_body": self.html_body.get("1.0", "end").strip(),
            "body": self.text_body.get("1.0", "end").strip(),
        }
        self._custom_templates[name] = tpl
        self._save_custom_templates()
        all_names = list(BUILTIN_TEMPLATES.keys()) + \
            list(self._custom_templates.keys())
        self.tpl_combo["values"] = all_names
        messagebox.showinfo("Saved", f"Template '{name}' saved.")

    def delete_custom_template(self, **kwargs):
        name = self.tpl_combo.get().strip()
        if name in self._custom_templates:
            del self._custom_templates[name]
            self._save_custom_templates()
            all_names = list(BUILTIN_TEMPLATES.keys()) + \
                list(self._custom_templates.keys())
            self.tpl_combo["values"] = all_names
            messagebox.showinfo("Deleted", f"Template '{name}' deleted.")
        elif name in BUILTIN_TEMPLATES:
            messagebox.showinfo("Built-in", "Cannot delete built-in templates.")

    def preview_email(self, **kwargs):
        html = self.html_body.get("1.0", "end").strip()
        text = self.text_body.get("1.0", "end").strip()
        subject = self.tpl_subject.get().strip()

        for var, entry in self.var_entries.items():
            val = entry.get().strip()
            html = html.replace(var, val)
            text = text.replace(var, val)
            subject = subject.replace(var, val)

        preview_win = tk.Toplevel(self.winfo_toplevel())
        preview_win.title(f"Preview: {subject}")
        preview_win.geometry("700x600")
        preview_win.configure(bg="#0d1117")

        notebook = ttk.Notebook(preview_win)
        notebook.pack(fill="both", expand=True, padx=4, pady=4)

        html_tab = ttk.Frame(notebook)
        notebook.add(html_tab, text="HTML")
        html_view = scrolledtext.ScrolledText(
            html_tab, font=("Courier", 10))
        html_view.pack(fill="both", expand=True, padx=4, pady=4)
        html_view.insert("1.0", html)

        text_tab = ttk.Frame(notebook)
        notebook.add(text_tab, text="Plain Text")
        text_view = scrolledtext.ScrolledText(
            text_tab, font=("Courier", 10))
        text_view.pack(fill="both", expand=True, padx=4, pady=4)
        text_view.insert("1.0", text)

    def preview_rendered(self, **kwargs):
        html = self.html_body.get("1.0", "end").strip()
        subject = self.tpl_subject.get().strip()
        for var, entry in self.var_entries.items():
            val = entry.get().strip()
            html = html.replace(var, val)
            subject = subject.replace(var, val)

        self.preview_out.delete("1.0", "end")
        rendered = (f"Subject: {subject}\n"
                    f"From: {self.tpl_from.get().strip()}\n"
                    f"To: {self.send_to.get().strip()}\n"
                    f"{'=' * 60}\n\n"
                    f"{html[:3000]}")
        self.preview_out.insert("1.0", rendered)
        return rendered

    def send_test_email(self, **kwargs):
        to_addr = self.send_to.get().strip()
        if not to_addr:
            messagebox.showerror("Error", "Enter a recipient email.")
            return

        smtp_host = self.smtp_host.get().strip()
        smtp_port = self.smtp_port.get().strip()
        smtp_user = self.smtp_user.get().strip()
        smtp_pass = self.smtp_pass.get().strip()
        from_addr = self.smtp_from.get().strip() or smtp_user
        from_name = self.tpl_from.get().strip()

        if not smtp_host or not smtp_user or not smtp_pass:
            messagebox.showerror("Error", "Configure SMTP server, "
                                 "username, and password.")
            return

        subject = self.tpl_subject.get().strip()
        html = self.html_body.get("1.0", "end").strip()
        text = self.text_body.get("1.0", "end").strip()

        for var, entry in self.var_entries.items():
            val = entry.get().strip()
            html = html.replace(var, val)
            text = text.replace(var, val)
            subject = subject.replace(var, val)

        def _send():
            try:
                msg = MIMEMultipart("alternative")
                msg["Subject"] = subject
                msg["From"] = f"{from_name} <{from_addr}>"
                msg["To"] = to_addr

                if text:
                    msg.attach(MIMEText(text, "plain"))
                if html:
                    msg.attach(MIMEText(html, "html"))

                port = int(smtp_port or "587")
                if port == 465:
                    server = smtplib.SMTP_SSL(smtp_host, port, timeout=15)
                elif self.send_use_tls.get():
                    server = smtplib.SMTP(smtp_host, port, timeout=15)
                    server.starttls()
                else:
                    server = smtplib.SMTP(smtp_host, port, timeout=15)

                server.login(smtp_user, smtp_pass)
                server.sendmail(from_addr, [to_addr], msg.as_string())
                server.quit()

                self.after(0, lambda: messagebox.showinfo(
                    "Sent", f"Test email sent to {to_addr}"))
            except Exception as e:
                err = e
                self.after(0, lambda: messagebox.showerror(
                    "Send Error", str(err)))

        threading.Thread(target=_send, daemon=True).start()

    # -------------------------------------------------------- AI Generate
    def ai_generate(self, **kwargs):
        description = kwargs.get("description")
        category = kwargs.get("category")
        programmatic = bool(description or category)

        model = common.SELECTED_MODEL
        if not model:
            models = common.ollama_models()
            if models:
                model = models[0]
            else:
                msg = ("No Ollama model available. Start 'ollama serve' and pull "
                       "a model (e.g. `ollama pull llama3.2:1b`), then Refresh "
                       "Models. Templates still work without AI.")
                if not programmatic:
                    messagebox.showinfo("No AI", msg)
                return msg

        import mitmpro.ai_core as ai_core

        dialog = tk.Toplevel(self.winfo_toplevel())
        dialog.title("AI Email Generation")
        dialog.geometry("500x200")
        dialog.configure(bg="#0d1117")
        dialog.transient(self.winfo_toplevel())

        ttk.Label(dialog, text="Describe the phishing email:").grid(
            row=0, column=0, sticky="w", padx=10, pady=8)
        desc_entry = ttk.Entry(dialog, width=60)
        desc_entry.grid(row=1, column=0, padx=10, pady=4)
        desc_entry.insert(0, description or "Password reset from IT department")

        ttk.Label(dialog, text="Category:").grid(
            row=2, column=0, sticky="w", padx=10, pady=4)
        cat_combo = ttk.Combobox(
            dialog,
            values=["credential", "sharing", "malware", "callback", "custom"],
            width=20)
        cat_combo.grid(row=3, column=0, sticky="w", padx=10, pady=4)
        cat_combo.set(category if category in (
            "credential", "sharing", "malware", "callback", "custom") else "credential")

        result_box = scrolledtext.ScrolledText(dialog, height=6)
        result_box.grid(row=4, column=0, padx=10, pady=8, sticky="nsew")

        def _generate():
            desc = desc_entry.get().strip()
            cat = cat_combo.get().strip()
            prompt = (
                f"Create a phishing email template for: {desc}\n"
                f"Category: {cat}\n\n"
                "Respond with JSON:\n"
                '{"subject": "...", "from_name": "...", '
                '"body": "...", "html_body": "..."}\n\n'
                "Use these variables: {target_name}, {target_email}, "
                "{company_name}, {phish_link}, {sender_name}\n"
                "Make it convincing but include realistic details.")

            messages = [
                {"role": "system", "content": (
                    "You are a security awareness training assistant. "
                    "Generate phishing email templates for authorized "
                    "penetration testing. Return valid JSON only.")},
                {"role": "user", "content": prompt}
            ]

            collected = {"text": ""}

            def on_token(t):
                collected["text"] += t

            ai_core.stream_chat(model, messages, on_token=on_token,
                                context="Email Engineer")

            try:
                result = collected["text"].strip()
                if "```json" in result:
                    result = result.split("```json", 1)[1].split("```", 1)[0]
                elif "```" in result:
                    result = result.split("```", 1)[1].split("```", 1)[0]

                start = result.find("{")
                end = result.rfind("}") + 1
                if start != -1 and end > start:
                    result = result[start:end]

                data = json.loads(result)
                self.after(0, lambda: self._apply_ai_result(data, dialog))
            except Exception as e:
                err = e
                self.after(0, lambda: result_box.insert(
                    "1.0", f"\n[Error parsing AI response: {err}]\n"))

        def _run():
            # GUI updates must happen on the main thread.
            self.after(0, lambda: (result_box.delete("1.0", "end"),
                                   result_box.insert("1.0", "Generating...\n")))
            _generate()

        ttk.Button(dialog, text="Generate",
                   command=lambda: threading.Thread(
                       target=_run, daemon=True).start()).grid(
                           row=3, column=1, padx=10)
        ttk.Button(dialog, text="Close",
                   command=dialog.destroy).grid(row=3, column=2, padx=10)

        # Auto-run when driven programmatically (e.g. AutoRun) without a click
        if description or category:
            threading.Thread(target=_run, daemon=True).start()
        return "AI generation started."

    def _apply_ai_result(self, data, dialog):
        if data.get("subject"):
            self.tpl_subject.delete(0, "end")
            self.tpl_subject.insert(0, data["subject"])
        if data.get("from_name"):
            self.tpl_from.delete(0, "end")
            self.tpl_from.insert(0, data["from_name"])
        if data.get("html_body"):
            self.html_body.delete("1.0", "end")
            self.html_body.insert("1.0", data["html_body"])
        if data.get("body"):
            self.text_body.delete("1.0", "end")
            self.text_body.insert("1.0", data["body"])
        dialog.destroy()

    # -------------------------------------------------------- Library
    def refresh_library(self, **kwargs):
        self.lib_tree.delete(*self.lib_tree.get_children())
        for name, tpl in BUILTIN_TEMPLATES.items():
            self.lib_tree.insert(
                "", "end",
                values=(tpl.get("name", name), tpl.get("category", ""),
                        "built-in"))
        for name, tpl in self._custom_templates.items():
            self.lib_tree.insert(
                "", "end",
                values=(tpl.get("name", name), tpl.get("category", ""),
                        "custom"))

    def export_template(self, name=None, path=None, **kwargs):
        programmatic = name is not None or path is not None
        if not name:
            sel = self.lib_tree.selection()
            if not sel:
                return "No template selected."
            name = self.lib_tree.item(sel[0], "values")[0]
        # The library tree shows display names; resolve by display name or key.
        tpl = BUILTIN_TEMPLATES.get(name) or self._custom_templates.get(name)
        if not tpl:
            for coll in (BUILTIN_TEMPLATES, self._custom_templates):
                for k, v in coll.items():
                    if v.get("name") == name:
                        tpl = v
                        name = k
                        break
                if tpl:
                    break
        if not tpl:
            return "Template not found."

        if not path:
            path = filedialog.asksaveasfilename(
                defaultextension=".json",
                initialfile=f"{name}.json",
                filetypes=[("JSON files", "*.json")])
        if not path:
            return "No path selected."
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(tpl, f, indent=2)
            return path
        except Exception as e:
            if not programmatic:
                messagebox.showerror("Error", str(e))
            return f"Error: {e}"

    # -------------------------------------------------------- Persistence
    def _load_custom_templates(self):
        path = os.path.join(TEMPLATES_DIR, "custom_templates.json")
        try:
            if os.path.isfile(path):
                with open(path, "r", encoding="utf-8") as f:
                    self._custom_templates = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            logger.log_exception(e, "loading custom email templates")
            self._custom_templates = {}

    def _save_custom_templates(self):
        path = os.path.join(TEMPLATES_DIR, "custom_templates.json")
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self._custom_templates, f, indent=2)
        except Exception as e:
            logger.log_exception(e, "saving custom email templates")
