import os
import sys
import threading

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except ImportError:
    pass

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

OUTPUT_DIR = os.path.join(PROJECT_ROOT, "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# External tool directories - check if they exist, provide fallbacks
def _find_tool_dir(name, subdir=""):
    """Find a tool directory, checking common locations."""
    candidates = [
        os.path.join(PROJECT_ROOT, name),
        os.path.join(PROJECT_ROOT, name, subdir) if subdir else None,
        os.path.join("/opt", name),
        os.path.join("/usr/local", name),
        os.path.expanduser(f"~/{name}"),
    ]
    for c in candidates:
        if c and os.path.isdir(c):
            return c
    return os.path.join(PROJECT_ROOT, name)  # fallback

OLLAMA_GUI_DIR = _find_tool_dir("ollama-gui-1.2.2")
WEBSPLOIT_DIR = _find_tool_dir("websploit-4.0.4", "websploit")
MITMNEW_DIR = _find_tool_dir("mitmnew")
MITM_UI_DIR = _find_tool_dir("mitm-ui-0.1")
MITMPROXY_UI_DIR = _find_tool_dir("mitmproxy-ui-master")

PYTHON = sys.executable

_listener_lock = threading.Lock()


def add_path(p):
    if p not in sys.path and os.path.isdir(p):
        sys.path.insert(0, p)


def ensure_ollama_gui_importable():
    add_path(OLLAMA_GUI_DIR)


def ollama_models():
    import urllib.request
    import urllib.parse
    import json
    from mitmpro.ai_core import get_ollama_host
    host = get_ollama_host()
    url = urllib.parse.urljoin(host, "/api/tags")
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            data = json.load(r)
        return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []


def ollama_running():
    return _reachable()


def _reachable():
    import urllib.request
    from mitmpro.ai_core import get_ollama_host
    host = get_ollama_host()
    try:
        urllib.request.urlopen(urllib.parse.urljoin(host, "/api/tags"), timeout=3)
        return True
    except Exception:
        return False


SELECTED_MODEL = None
_MODEL_LISTENERS = []

INTERNET_ENABLED = False
_INTERNET_LISTENERS = []


def register_internet_listener(fn):
    with _listener_lock:
        if fn not in _INTERNET_LISTENERS:
            _INTERNET_LISTENERS.append(fn)


def set_internet(on):
    global INTERNET_ENABLED
    INTERNET_ENABLED = bool(on)
    with _listener_lock:
        listeners = list(_INTERNET_LISTENERS)
    for fn in listeners:
        try:
            fn(INTERNET_ENABLED)
        except Exception:
            pass


def register_model_listener(fn):
    with _listener_lock:
        if fn not in _MODEL_LISTENERS:
            _MODEL_LISTENERS.append(fn)


def set_model(model):
    global SELECTED_MODEL
    SELECTED_MODEL = model
    with _listener_lock:
        listeners = list(_MODEL_LISTENERS)
    for fn in listeners:
        try:
            fn(model)
        except Exception:
            pass


def notify_model_listeners():
    with _listener_lock:
        listeners = list(_MODEL_LISTENERS)
    for fn in listeners:
        try:
            fn(SELECTED_MODEL)
        except Exception:
            pass
