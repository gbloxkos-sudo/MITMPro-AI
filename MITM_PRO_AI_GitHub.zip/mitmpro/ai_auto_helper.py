"""AI Auto Helper — module-aware suggestion engine.

This module powers the proactive "AI Auto Helper" behaviour inside every
MITMPro tool tab. Instead of a passive chat box, the helper now offers:

  * Context-aware quick-action chips (e.g. "Show OTP race-condition attack")
  * A "Smart Suggest" button that inspects the live module state and
    recommends the next best step for an assessment.
  * Beginner-friendly canned prompts so a non-expert can drive the tool.

Everything here is grounded in the real MITMPro inventory (knowledge.py,
advanced_attacks.py, burp_integration.py, phishing_templates.py,
otp_bypass_tools.py) so the AI never invents modules.
"""

from typing import Dict, List

# ---------------------------------------------------------------------------
# Per-module quick actions. Each entry is a one-click prompt the user can
# send to the AI. Keys MUST match the tool_name passed to AIHelperTab.
# ---------------------------------------------------------------------------

QUICK_ACTIONS: Dict[str, List[dict]] = {
    "Dashboard": [
        {"label": "What can MITMPro do?", "prompt": "Give me a 60-second tour of everything MITMPro can test."},
        {"label": "Plan my first pentest", "prompt": "I'm new. Give me a safe beginner methodology for testing my own app."},
    ],
    "AI Assistant": [
        {"label": "How does the AI work?", "prompt": "Explain how MITMPro's local AI stays private and anti-hallucination."},
        {"label": "Best model for security?", "prompt": "Which local Ollama model should I use for exploit chains and why?"},
        {"label": "Local-only privacy", "prompt": "Confirm that my prompts never leave the machine and how the model is sandboxed."},
        {"label": "Fix a failed step", "prompt": "The AI returned an error reaching Ollama — walk me through recovery steps."},
    ],
    "AI Traffic Analyst": [
        {"label": "Find vulns in a request", "prompt": "Explain how to paste a raw HTTP request and find OWASP Top 10 issues."},
        {"label": "Decode a token", "prompt": "Show me how to decode a JWT or base64 blob step by step."},
        {"label": "Spot request smuggling", "prompt": "What CL/TE header patterns indicate HTTP request smuggling and how do I confirm it?"},
        {"label": "Analyze an API response", "prompt": "Given a JSON API response, how do I spot IDOR, mass assignment, and authz flaws?"},
        {"label": "Build a test checklist", "prompt": "From this request, build a 5-step validation checklist I can run by hand."},
    ],
    "Burp": [
        {"label": "Repeater walkthrough", "prompt": "Walk me through Burp Repeater: send a request and read the response."},
        {"label": "OTP race attack", "prompt": "Show the Turbo Intruder single-packet OTP race-condition attack with commands."},
        {"label": "Run a web scan", "prompt": "How do I run the Burp Scanner against my own site and read findings?"},
        {"label": "Use a Bambda", "prompt": "Which Burp Bambda helps detect race conditions and how do I apply it?"},
        {"label": "Encode/decode", "prompt": "Show the decoder pipeline for a double-URL/base64/HTML-encoded payload."},
        {"label": "Scope the scan", "prompt": "How do I limit the scanner to in-scope hosts only so I stay authorized?"},
    ],
    "WebSploit": [
        {"label": "ARP spoof demo", "prompt": "Explain WebSploit ARP spoofing safely on a lab network, step by step."},
        {"label": "Module list", "prompt": "What modules does WebSploit have and when do I use each?"},
    ],
    "Proxy Tools": [
        {"label": "Intercept TLS", "prompt": "How does MITM_Intercept decrypt TLS and what certs do I need?"},
        {"label": "Frida MITM", "prompt": "When would I use DatajackProxy vs a standard proxy?"},
    ],
    "WAF/Bypass": [
        {"label": "Bypass Cloudflare", "prompt": "Generate WAF-bypass variants for Cloudflare and explain the top 3."},
        {"label": "Test a bypass", "prompt": "How do I live-test a WAF bypass payload against my target?"},
        {"label": "Read a fingerprint", "prompt": "How do I read the WAF fingerprint (Server/headers) to pick the right variant?"},
        {"label": "XML/CDATA trick", "prompt": "When does an XML CDATA or charset trick defeat a WAF and how do I craft it?"},
        {"label": "Explain scoring", "prompt": "How does the variant scoring rank payloads and what does the top pick mean?"},
    ],
    "Website Masquerading": [
        {"label": "Deploy a clone", "prompt": "How do I safely deploy a masquerading proxy for an authorized test?"},
        {"label": "Pick a template", "prompt": "Which phishing template should I use for a credential-capture demo?"},
    ],
    "Inline DLP Proxy": [
        {"label": "Start DLP", "prompt": "How do I start the inline DLP proxy and watch for leaks?"},
        {"label": "Write a rule", "prompt": "Show me how to write a DLP pattern to catch API keys."},
    ],
    "Network Attacks": [
        {"label": "ARP + DNS spoof", "prompt": "Chain ARP spoofing and DNS spoofing in one lab assessment."},
        {"label": "Discover hosts", "prompt": "How do I discover live hosts on my test network?"},
    ],
    "SSL Strip / MITM": [
        {"label": "Downgrade HTTPS", "prompt": "Explain SSL Strip mode and how to capture creds over HTTP."},
        {"label": "Inject a cookie", "prompt": "How do I use the cookie manager to inject a session cookie?"},
    ],
    "Campaign Manager": [
        {"label": "Build a campaign", "prompt": "Walk me through creating a phishing campaign for an authorized engagement."},
        {"label": "Read a report", "prompt": "How do I generate a professional report from campaign stats?"},
    ],
    "Email Engineer": [
        {"label": "Craft a test email", "prompt": "How do I build a safe phishing email template with AI?"},
        {"label": "Preview & send", "prompt": "Explain the Preview & Send tab and SMTP config."},
    ],
    "HTTP History": [
        {"label": "Read history", "prompt": "How do I send a captured request to Repeater or AI Analyst?"},
        {"label": "Filter noise", "prompt": "Show me how to filter HTTP History by URL."},
    ],
    "OAST / DNS": [
        {"label": "Blind SSRF", "prompt": "How do I use OAST to prove a blind SSRF?"},
        {"label": "Generate payload", "prompt": "Generate a collaborator-style OOB payload for XXE."},
        {"label": "Read callbacks", "prompt": "How do I read incoming OAST callbacks and map them to a sent request?"},
        {"label": "DNS exfil", "prompt": "Show a safe DNS-exfiltration detection pattern for a lab."},
    ],
    "Macro / Flow": [
        {"label": "Login flow", "prompt": "Build a macro: login -> grab CSRF token -> authenticated request."},
        {"label": "Extract regex", "prompt": "How does the extract-regex feature feed later steps?"},
        {"label": "Chain two calls", "prompt": "Show a 2-step macro where step 2 uses step 1's extracted value."},
        {"label": "Debug a flow", "prompt": "My macro stops early — how do I debug variable extraction?"},
    ],
    "Scope": [
        {"label": "Set scope", "prompt": "Why must I set Scope before testing and how?"},
        {"label": "Stay in bounds", "prompt": "How does Scope keep my testing authorized and legal?"},
        {"label": "Import a list", "prompt": "How do I import a list of in-scope hosts from a file?"},
        {"label": "Scope vs target", "prompt": "What is the difference between Scope and the active target URL?"},
    ],
    "Analysis": [
        {"label": "Health check", "prompt": "How do I run a pre-engagement health check?"},
        {"label": "Read results", "prompt": "Explain what the Analysis panel reports about my setup."},
        {"label": "Tool inventory", "prompt": "List the bundled external tools MITMPro can drive and what each does."},
    ],
    "Nsniffer": [
        {"label": "Capture traffic", "prompt": "How do I capture packets with Nsniffer on my lab net?"},
        {"label": "MITM mode", "prompt": "Explain Nsniffer's mitm/arp subcommands."},
        {"label": "Filter noise", "prompt": "Show a BPF filter that keeps only HTTP/TLS handshakes."},
    ],
    "AI Auto-Run": [
        {"label": "Write a goal", "prompt": "Give 3 example goals I can paste into Auto-Run."},
        {"label": "How plans work", "prompt": "Explain how the AI turns my goal into a tool-execution plan."},
        {"label": "Recover a failed plan", "prompt": "A plan step failed — what are my retry/skip/abort options?"},
        {"label": "Save & reuse", "prompt": "How do I save a plan and reload it for the next engagement?"},
    ],
    "AI Helper": [
        {"label": "What is this?", "prompt": "Explain the AI Helper and how it stays grounded."},
        {"label": "Best questions", "prompt": "What kinds of questions get the best answers here?"},
    ],
    "Getting Started": [
        {"label": "First steps", "prompt": "I just opened MITMPro. What should I do first?"},
        {"label": "Stay legal", "prompt": "Explain authorized testing scope in plain English."},
    ],
    "General Guidance": [
        {"label": "What is this?", "prompt": "Explain the AI Helper and how it stays grounded."},
        {"label": "Best questions", "prompt": "What kinds of questions get the best answers here?"},
    ],
    "SSL Strip": [
        {"label": "Downgrade HTTPS", "prompt": "Explain SSL Strip mode and how to capture creds over HTTP."},
        {"label": "Inject a cookie", "prompt": "How do I use the cookie manager to inject a session cookie?"},
    ],
    "OTP/2FA": [
        {"label": "OTP test plan", "prompt": "Give me a full OTP/2FA bypass testing checklist."},
        {"label": "Race condition", "prompt": "Explain the Turbo Intruder race-condition OTP bypass with steps."},
        {"label": "Response tampering", "prompt": "How does 2FA response tampering work and how do I test it?"},
    ],
}


# ---------------------------------------------------------------------------
# Smart Suggest: inspect live state and recommend a next step.
# Returns a human-readable recommendation string.
# ---------------------------------------------------------------------------

def smart_suggest(tool_name: str, state: dict = None) -> str:
    """Produce a contextual recommendation based on module + live state.

    `state` is an optional dict the panel can populate, e.g.
    {"scope_count": 0, "last_scan": None, "otp_target": ""}.
    """
    state = state or {}
    t = tool_name

    if t == "Scope":
        if not state.get("scope_count"):
            return ("No scope set yet. Add your authorized target hostname first "
                    "(e.g. 'myapp.example.com') so every tool stays in-bounds.")
        return "Scope is set. Open Burp Tools and run a Scanner pass against a scoped host."

    if t == "Burp":
        if not state.get("last_scan"):
            return ("Run a Burp Scanner pass on a scoped host (Reflected XSS, SQLi, "
                    "SSRF, header checks). Then send interesting requests to AI Traffic Analyst.")
        return "Review scan findings, then try the OTP/2FA tab for 2FA bypass testing."

    if t in ("OTP/2FA", "Burp") and state.get("otp_target"):
        return ("OTP target detected. Try the Turbo Intruder 'single_packet' or "
                "'last_byte_sync' race against /verify-otp. Confirm OTP length + lockout first.")

    if t == "AI Traffic Analyst":
        return "Paste a raw request/response and pick 'Find vulnerabilities' to map OWASP issues."

    if t == "WAF/Bypass":
        return "Pick a category (SQLi/XSS/SSRF), generate variants, then 'Test Bypass' live."

    if t == "Website Masquerading":
        return "Choose a template, deploy the mirror proxy on an authorized domain, capture creds."

    if t == "Network Attacks":
        return "On a lab LAN: discover hosts, then ARP spoof + optional DNS spoof, then sniff."

    if t == "SSL Strip / MITM":
        return "Start SSL Strip on a lab net, browse through the proxy, capture downgraded creds."

    if t == "AI Auto-Run":
        return "Type a goal like 'Scan target X for XSS and attempt WAF bypass', then Auto-Run."

    return ("Explore this tool's buttons above, or ask the AI a plain-English "
            "question — e.g. 'How do I use this?' or 'Give me an assessment checklist'.")


def get_quick_actions(tool_name: str) -> List[dict]:
    """Return quick-action chips for a module (falls back to generics)."""
    if tool_name in QUICK_ACTIONS:
        return QUICK_ACTIONS[tool_name]
    return [
        {"label": "How do I use this?", "prompt": f"Explain the {tool_name} tool step by step for a beginner."},
        {"label": "Assessment checklist", "prompt": f"Give me a phased assessment checklist for {tool_name}."},
    ]
