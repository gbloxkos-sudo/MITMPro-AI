"""MITMPro - Unified AI-Assisted Security Assessment Platform"""
__version__ = "1.0.0"
__author__ = "MITMPro Team"

# Import core modules for easy access
from mitmpro import common
from mitmpro import ai_core
from mitmpro import knowledge
from mitmpro import rag
from mitmpro import scope
from mitmpro import system_context
from mitmpro import web
from mitmpro import traffic
# console (Tkinter GUI) is imported lazily so the package can be used headless
# (e.g. the Web GUI / FastAPI backend) on systems without a display or tkinter.
try:  # pragma: no cover - optional GUI dependency
    from mitmpro import console
except ImportError:
    console = None
# theme is a Tkinter-based desktop styling module, optional when headless.
try:  # pragma: no cover - optional GUI dependency
    from mitmpro import theme
except ImportError:
    theme = None

# Import panel classes for direct access. These are Tkinter-based desktop UI
# components and are optional when running headless (e.g. the Web GUI backend).
def _optional_import_panel(name, from_module, attr):
    try:
        module = __import__(f"mitmpro.{from_module}", fromlist=[attr])
        return getattr(module, attr)
    except (ImportError, AttributeError):
        return None

AIHelperTab = _optional_import_panel("AIHelperTab", "ai_components", "AIHelperTab")
AIHelpWidget = _optional_import_panel("AIHelpWidget", "ai_widget", "AIHelpWidget")
AIPanel = _optional_import_panel("AIPanel", "ai_panel", "AIPanel")
AITrafficAnalyst = _optional_import_panel("AITrafficAnalyst", "ai_traffic_panel", "AITrafficAnalyst")
AIHelperPanel = _optional_import_panel("AIHelperPanel", "ai_helper_panel", "AIHelperPanel")
WelcomePanel = _optional_import_panel("WelcomePanel", "welcome_panel", "WelcomePanel")
BurpPanel = _optional_import_panel("BurpPanel", "burp_panel", "BurpPanel")
WAFPanel = _optional_import_panel("WAFPanel", "waf_panel", "WAFPanel")
MasqueradingPanel = _optional_import_panel("MasqueradingPanel", "masquerading_panel", "MasqueradingPanel")
CampaignManager = _optional_import_panel("CampaignManager", "campaign_panel", "CampaignManager")
EmailEngineer = _optional_import_panel("EmailEngineer", "email_engineer_panel", "EmailEngineer")
DLPPanel = _optional_import_panel("DLPPanel", "dlp_panel", "DLPPanel")
NsnifferPanel = _optional_import_panel("NsnifferPanel", "nsniffer_panel", "NsnifferPanel")
NetworkAttackPanel = _optional_import_panel("NetworkAttackPanel", "network_attack_panel", "NetworkAttackPanel")
ProxyPanel = _optional_import_panel("ProxyPanel", "proxy_panel", "ProxyPanel")
WebSploitPanel = _optional_import_panel("WebSploitPanel", "websploit_panel", "WebSploitPanel")
SSLStripPanel = _optional_import_panel("SSLStripPanel", "sslstrip_panel", "SSLStripPanel")
OASTPanel = _optional_import_panel("OASTPanel", "oast_panel", "OASTPanel")
AnalysisPanel = _optional_import_panel("AnalysisPanel", "analysis_panel", "AnalysisPanel")
MacroPanel = _optional_import_panel("MacroPanel", "macro_panel", "MacroPanel")
ScopePanel = _optional_import_panel("ScopePanel", "scope_panel", "ScopePanel")
LoggerPanel = _optional_import_panel("LoggerPanel", "logger_panel", "LoggerPanel")
AutoRunPanel = _optional_import_panel("AutoRunPanel", "autorun_panel", "AutoRunPanel")
AutoRunEngine = _optional_import_panel("AutoRunEngine", "autorun_engine", "AutoRunEngine")

__all__ = [
    "common",
    "ai_core",
    "knowledge",
    "rag",
    "scope",
    "system_context",
    "web",
    "traffic",
    "console",
    "theme",
    "AIHelperTab",
    "AIHelpWidget",
    "AIPanel",
    "AITrafficAnalyst",
    "AIHelperPanel",
    "WelcomePanel",
    "BurpPanel",
    "WAFPanel",
    "MasqueradingPanel",
    "CampaignManager",
    "EmailEngineer",
    "DLPPanel",
    "NsnifferPanel",
    "NetworkAttackPanel",
    "ProxyPanel",
    "WebSploitPanel",
    "SSLStripPanel",
    "OASTPanel",
    "AnalysisPanel",
    "MacroPanel",
    "ScopePanel",
    "LoggerPanel",
    "AutoRunPanel",
    "AutoRunEngine",
    "__version__",
    "__author__",
]