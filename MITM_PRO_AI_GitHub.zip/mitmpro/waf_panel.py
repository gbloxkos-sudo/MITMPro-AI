import json
import threading
import urllib.parse
import urllib.request
import base64
import html
import random
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import requests
from mitmpro.common import ollama_models, register_model_listener
from mitmpro import common
from mitmpro import ai_core
from mitmpro.waf_engine import *  # pure WAF variant logic (headless-safe)

from mitmpro.ai_components import AIHelperTab

class WAFPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Bypass Engine")
        self.add(AIHelperTab(self, "WAF/Bypass"), text="AI Helper")
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(3, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(2, weight=1)
        ttk.Label(top, text="Category:").grid(row=0, column=0)
        self.cat = ttk.Combobox(top, values=["SQLi", "XSS", "Path Traversal", "Command Injection", "SSRF"], width=16)
        self.cat.set("SQLi"); self.cat.grid(row=0, column=1)
        ttk.Label(top, text="Payload:").grid(row=0, column=2, sticky="e")
        self.payload = ttk.Entry(top); self.payload.grid(row=0, column=3, sticky="ew")
        self.payload.insert(0, "' OR '1'='1")
        ttk.Button(top, text="Generate", command=lambda: threading.Thread(target=self.generate, daemon=True).start()).grid(row=0, column=4)
        ttk.Button(top, text="Explain with AI", command=lambda: threading.Thread(target=self.explain, daemon=True).start()).grid(row=0, column=5, padx=4)
        ttk.Button(top, text="Predict Top 3", command=lambda: threading.Thread(target=self.ai_predict_top3, daemon=True).start()).grid(row=0, column=8, padx=4)
        self.model = ttk.Combobox(top, width=18, state="readonly"); self.model.grid(row=0, column=6, padx=6)
        self.model.bind("<<ComboboxSelected>>", lambda e: common.set_model(self.model.get()))
        ttk.Button(top, text="↻", width=3, command=self.load_models).grid(row=0, column=7, padx=2)

        mid = ttk.Frame(self.main_frame)
        mid.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        mid.columnconfigure(1, weight=1)
        ttk.Label(mid, text="Test URL (optional):").grid(row=0, column=0)
        self.url = ttk.Entry(mid); self.url.grid(row=0, column=1, sticky="ew")
        self.url.insert(0, "https://target/login?q=")
        ttk.Button(mid, text="Test Bypass", command=lambda: threading.Thread(target=self.test, daemon=True).start()).grid(row=0, column=2)
        ttk.Button(mid, text="Batch Test", command=lambda: threading.Thread(target=self.test_batch, daemon=True).start()).grid(row=0, column=3)
        ttk.Button(mid, text="Save", command=self.save).grid(row=0, column=4)

        cf = ttk.LabelFrame(self.main_frame, text="Custom Encoding Chain")
        cf.grid(row=2, column=0, sticky="ew", padx=4, pady=2); cf.columnconfigure(1, weight=1)
        ttk.Label(cf, text="Ops:").grid(row=0, column=0)
        self.chain_entry = ttk.Entry(cf); self.chain_entry.grid(row=0, column=1, sticky="ew")
        self.chain_entry.insert(0, "url,base64,double_url")
        ttk.Label(cf, text="Opts: " + ",".join(CHAIN_OPS.keys())).grid(row=0, column=2, padx=4)
        ttk.Button(cf, text="Apply Chain", command=lambda: threading.Thread(target=self.apply_custom_chain, daemon=True).start()).grid(row=0, column=3)

        self.progress_var = tk.DoubleVar()
        ttk.Progressbar(self.main_frame, variable=self.progress_var, maximum=100).grid(row=4, column=0, sticky="ew", padx=4, pady=1)
        self.out = scrolledtext.ScrolledText(self.main_frame)
        self.out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)
        self.out.config(state="disabled")
        self.last_variants = []; self.waf_type = "Unknown"
        self.load_models(); register_model_listener(self._on_global_model)

    def load_models(self):
        import threading
        def _fetch():
            try:
                models = ollama_models()
            except Exception:
                models = []
            def apply():
                self.model["values"] = models
                if models: self.model.set(common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0])
            try:
                self.after(0, apply)
            except Exception:
                apply()
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            if model and model not in (self.model["values"] or ()):
                self.model["values"] = list(self.model["values"] or ()) + [model]
            if model: self.model.set(model)
        try:
            self.after(0, apply)
        except Exception:
            pass

    def generate(self, payload=None, category=None, **kwargs):
        if payload is None:
            payload = self.payload.get().strip()
        if not payload:
            return
        if category is None:
            category = self.cat.get() or "SQLi"
        variants = generate_variants(payload, category)
        self.last_variants = sorted(variants, key=lambda v: score_variant(v, self.waf_type), reverse=True)
        self._show(self.last_variants, category)

    def apply_custom_chain(self):
        payload, cat = self.payload.get().strip(), self.cat.get()
        ops = [o.strip() for o in self.chain_entry.get().strip().split(",") if o.strip()]
        result = apply_chain(payload, ops); self.last_variants = [result]
        self._show([f"[chain result] {result}", f"[applied chain: {' -> '.join(ops)}]"], cat + " (chain)")

    def explain(self):
        if not self.last_variants: self.generate()
        model = self.model.get()
        if not model:
            messagebox.showinfo("No model", "Pick an Ollama model (start 'ollama serve').")
            return
        cat, payload = self.cat.get(), self.payload.get().strip()
        waf_info = f"Detected WAF: {self.waf_type}" if self.waf_type != "Unknown" else "WAF: Unknown"
        prompt = (f"You are the MITMPro WAF/Bypass expert. Category: {cat}. Base payload: {payload!r}. {waf_info}\n"
            f"Generated evasion variants (first 40):\n" + "\n".join(self.last_variants[:40]) + "\n\n"
            "From these variants, identify the 3 MOST LIKELY to bypass a modern WAF/IDS for this "
            "category and explain WHY each works (encoding, parser confusion, signature evasion). "
            "Then give the single best copy-paste payload to try first. State confidence (High/Medium/Low). "
            "Only reference techniques that are in the variant list above.")
        self.after(0, self._append_ai, "\n[AI] Analyzing variants for best bypass...\n")
        self._stream_ai(prompt)

    def ai_predict_top3(self):
        if not self.last_variants: return
        model = self.model.get()
        if not model: return
        cat, waf = self.cat.get(), self.waf_type
        prompt = (f"Category: {cat}, Detected WAF: {waf}\nVariants:\n" + "\n".join(self.last_variants[:50]) + "\n\n"
            "Return EXACTLY 3 variant strings from the list above, one per line, MOST LIKELY to bypass the WAF. Output ONLY the 3 payloads.")
        self.after(0, self._append_ai, "\n[AI-PREDICT] Selecting top 3 bypass candidates...\n")
        self._stream_ai(prompt)

    def _stream_ai(self, prompt):
        model = self.model.get() or common.SELECTED_MODEL
        if not model:
            self.after(0, self._append_ai,
                       "\n[AI unavailable] No Ollama model selected. Start 'ollama serve', "
                       "pull a model (e.g. `ollama pull llama3.2:1b`), then click ↻.\n")
            return
        def on_token(t):
            self.after(0, self._append_ai, t)
        def on_error(e):
            self.after(0, self._append_ai, f"\n[error: {e}]")
        threading.Thread(target=ai_core.stream_chat,
            args=(model, [{"role": "user", "content": prompt}]),
            kwargs={"on_token": on_token, "on_error": on_error,
                "verify": True, "context": "WAF/Bypass", "rag_query": prompt}, daemon=True).start()

    def _append_ai(self, text):
        self.out.config(state="normal"); self.out.insert("end", text)
        self.out.see("end"); self.out.config(state="disabled")

    def _build_target(self, base, payload):
        """Append `payload` to `base` as a query parameter, correctly joining
        with '&' when the base URL already contains a query string."""
        q = urllib.parse.quote(payload)
        if "?" in base:
            return base + "&" + q
        return base + "?" + q

    def _run_test(self, variants, base_label):
        base = self.url.get().strip()
        if not base:
            self.after(0, messagebox.showinfo, "Info", "Enter a test URL or just Generate variants.")
            return
        self.after(0, self._log, f"[*] Fingerprinting WAF at {base}...")
        self.waf_type, _ = fingerprint_waf(base)
        self.after(0, self._log, f"[*] Detected WAF: {self.waf_type}")
        variants = sorted(variants, key=lambda v: score_variant(v, self.waf_type), reverse=True)
        self.last_variants = list(variants)
        try:
            baseline_payload = self.payload.get().strip()
            baseline_target = self._build_target(base, baseline_payload)
            baseline_resp = requests.get(baseline_target, timeout=15, verify=False)
            baseline_sig = self._blocked(baseline_resp); baseline_fp = fingerprint_response(baseline_resp)
        except Exception as e:
            self._show([f"[!] baseline error: {e}"], base_label); return
        results, bp, bl, err, total = [], 0, 0, 0, len(variants)
        self.progress_var.set(0)
        for i, var in enumerate(variants):
            self.after(0, lambda v=i: self.progress_var.set((v / total) * 100))
            try:
                target = self._build_target(base, var)
                r = requests.get(target, timeout=15, verify=False, headers=SPOOF_HEADERS)
                rfp = fingerprint_response(r)
                bypassed = (r.status_code != baseline_resp.status_code or self._blocked(r) != baseline_sig
                    or abs(len(r.text) - len(baseline_resp.text)) > 50 or abs(rfp["time"] - baseline_fp["time"]) > 2.0
                    or any(rfp["headers"].get(k, "") != baseline_fp["headers"].get(k, "") for k in ["server", "x-powered-by", "content-type"]))
                tag = "BYPASS?" if bypassed else "blocked"
                if bypassed: bp += 1
                else: bl += 1
                results.append(f"[{tag}] {var}")
            except Exception as e:
                results.append(f"[ERR] {var} -> {e}"); err += 1
        self.after(0, lambda: self.progress_var.set(100))
        results.append(f"\n\n=== STATS ===\nTotal: {total} | Potential bypasses: {bp} | Blocked: {bl} | Errors: {err} | WAF: {self.waf_type}")
        self._show(results, base_label)

    def test(self, payload=None, cat=None, **kwargs):
        if payload is None:
            payload = self.payload.get().strip()
        if cat is None:
            cat = self.cat.get()
        self._run_test(generate_variants(payload, cat), cat + " (live test)")

    def test_batch(self):
        base = self.url.get().strip()
        if not base:
            messagebox.showinfo("Info", "Enter a test URL first."); return
        # Prefer the raw variant list produced by the last Generate/Test run so
        # we never re-test the [BYPASS?]/[blocked]/[ERR] tagged output lines.
        variants = getattr(self, "last_variants", None)
        if not variants:
            messagebox.showinfo("Info", "Generate variants first, then Batch Test."); return
        self._run_test(variants, "Batch Test")

    def _log(self, msg):
        self.out.config(state="normal"); self.out.insert("end", msg + "\n")
        self.out.see("end"); self.out.config(state="disabled")

    def _blocked(self, resp):
        body = resp.text.lower()
        return any(s in body for s in ["blocked", "forbidden", "waf", "cloudflare", "akamai", "mod_security", "access denied", "403"])

    def _show(self, items, title):
        self.out.config(state="normal"); self.out.delete("1.0", "end")
        self.out.insert("1.0", f"=== {title} ({len(items)} items) ===\n\n")
        for it in items: self.out.insert("end", it + "\n")
        self.out.config(state="disabled")

    def save(self):
        p = filedialog.asksaveasfilename(defaultextension=".txt", title="Save bypass variants")
        if p:
            try:
                with open(p, "w") as f: f.write(self.out.get("1.0", "end"))
                messagebox.showinfo("Saved", p)
            except Exception as e: messagebox.showerror("Error", str(e))
