import sys
import tkinter as tk
from tkinter import ttk
from tkinter import scrolledtext
import tkinter.font as tkfont


# ─── Color Palette (higher contrast, WCAG AA compliant) ────────────────────
BG         = "#0d1117"     # near-black background
PANEL      = "#161b22"     # panel background
PANEL2     = "#21262d"     # elevated panel (inputs, cards) - BRIGHTER
SIDEBAR    = "#0b0f14"     # sidebar
ACCENT     = "#58a6ff"     # brighter blue for better contrast
ACCENT_HOVER = "#79c0ff"   # hover state
TEXT       = "#e6edf3"     # primary text
MUTED      = "#a1a8b0"     # LIGHTER muted text for readability
SUCCESS    = "#3fb950"
WARNING    = "#d29922"
DANGER     = "#f85149"
BORDER     = "#30363d"

FONT_FAMILY = "Segoe UI" if sys.platform == "win32" else ("Ubuntu" if sys.platform == "linux" else "Helvetica")
FONT       = (FONT_FAMILY, 10)
FONT_BOLD  = (FONT_FAMILY, 10, "bold")
FONT_TITLE = (FONT_FAMILY, 15, "bold")
FONT_MONO  = ("Consolas", 10)


def apply_enterprise_theme(root):
    try:
        style = ttk.Style()
        style.theme_use("clam")
    except Exception:
        style = ttk.Style()

    # Base frame
    style.configure("TFrame", background=BG, borderwidth=0)

    # Labels - use PANEL as bg for labels on panels
    style.configure("TLabel", background=BG, foreground=TEXT, font=FONT)
    style.configure("Muted.TLabel", background=BG, foreground=MUTED, font=FONT)

    # Buttons - larger padding, better contrast
    style.configure("TButton",
                    background=ACCENT, foreground="white",
                    borderwidth=0, padding=(14, 8), font=FONT_BOLD)
    style.map("TButton",
              background=[("active", ACCENT_HOVER), ("disabled", BORDER)],
              foreground=[("disabled", MUTED)])

    # Secondary button style
    style.configure("Secondary.TButton",
                    background=PANEL2, foreground=TEXT,
                    borderwidth=1, bordercolor=BORDER,
                    padding=(12, 6), font=FONT)
    style.map("Secondary.TButton",
              background=[("active", BORDER)],
              foreground=[("active", TEXT)])

    # Notebook (tabs) - better contrast
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure("TNotebook.Tab",
                    background=PANEL, foreground=MUTED,
                    padding=[20, 10], borderwidth=0, font=FONT_BOLD)
    style.map("TNotebook.Tab",
              background=[("selected", PANEL2), ("active", PANEL2)],
              foreground=[("selected", ACCENT), ("active", TEXT)],
              expand=[("selected", (2, 2, 2, 2))])

    # Combobox - better field background
    style.configure("TCombobox",
                    fieldbackground=PANEL2, background=PANEL2,
                    foreground=TEXT, bordercolor=BORDER, lightcolor=PANEL2, font=FONT,
                    padding=(8, 6))
    style.map("TCombobox",
              fieldbackground=[("readonly", PANEL2)],
              bordercolor=[("focus", ACCENT)],
              foreground=[("readonly", TEXT)])

    # Entry - higher contrast field
    style.configure("TEntry",
                    fieldbackground=PANEL2, foreground=TEXT,
                    insertcolor=TEXT, bordercolor=BORDER, font=FONT,
                    padding=(8, 6))
    style.map("TEntry",
              bordercolor=[("focus", ACCENT)])

    # Checkbutton / Radiobutton
    style.configure("TCheckbutton", background=BG, foreground=TEXT, font=FONT)
    style.configure("TRadiobutton", background=BG, foreground=TEXT, font=FONT)

    # Labelframe - use PANEL background for better visibility
    style.configure("TLabelframe", background=BG, foreground=TEXT, bordercolor=BORDER)
    style.configure("TLabelframe.Label", background=BG, foreground=ACCENT, font=FONT_BOLD)

    # Scrollbar
    style.configure("TScrollbar", background=PANEL2, troughcolor=BG, bordercolor=BG,
                    arrowcolor=MUTED, width=12)
    style.map("TScrollbar",
              background=[("active", BORDER), ("!active", PANEL2)])

    # Progressbar
    style.configure("TProgressbar", background=ACCENT, troughcolor=PANEL2,
                    borderwidth=0, thickness=8)

    # Scale
    style.configure("TScale", background=BG, troughcolor=PANEL2)

    # Menu
    style.configure("TMenu", background=PANEL, foreground=TEXT,
                    activebackground=ACCENT, activeforeground="white")

    # Treeview - better row height and contrast
    style.configure("Treeview",
                    background=PANEL, foreground=TEXT,
                    fieldbackground=PANEL, bordercolor=BORDER, font=FONT,
                    rowheight=28)
    style.configure("Treeview.Heading",
                    background=PANEL2, foreground=ACCENT,
                    bordercolor=BORDER, font=FONT_BOLD, padding=(10, 8))
    style.map("Treeview",
              background=[("selected", ACCENT)],
              foreground=[("selected", "white")])
    style.map("Treeview.Heading",
              background=[("active", BORDER)])

    root.configure(bg=BG)
    try:
        root.option_add("*Text.background", PANEL2)
        root.option_add("*Text.foreground", TEXT)
        root.option_add("*Text.insertBackground", TEXT)
        root.option_add("*Text.selectBackground", ACCENT)
        root.option_add("*Text.font", FONT)
        root.option_add("*Listbox.background", PANEL2)
        root.option_add("*Listbox.foreground", TEXT)
        root.option_add("*Listbox.selectBackground", ACCENT)
        root.option_add("*Listbox.selectForeground", "white")
        root.option_add("*Listbox.font", FONT)
        root.option_add("*Listbox.borderColor", BORDER)
        root.option_add("*Entry.background", PANEL2)
        root.option_add("*Entry.foreground", TEXT)
    except Exception:
        pass


def make_header(parent, title, subtitle, version="v1.0"):
    header = tk.Frame(parent, bg=PANEL, height=58)
    header.grid(row=0, column=0, sticky="ew")
    header.columnconfigure(1, weight=1)
    header.grid_propagate(False)

    bar = tk.Frame(header, bg=ACCENT, width=6)
    bar.grid(row=0, column=0, sticky="ns")

    logo = tk.Label(header, text="◆", bg=PANEL, fg=ACCENT, font=("Segoe UI", 22, "bold"))
    logo.grid(row=0, column=1, padx=12)

    txt = tk.Label(header, text=title, bg=PANEL, fg=TEXT, font=FONT_TITLE)
    txt.grid(row=0, column=2, sticky="w")

    pill = tk.Label(header, text=version, bg=PANEL2, fg=ACCENT,
                    font=("Segoe UI", 8, "bold"), bd=0, padx=6, pady=2)
    pill.grid(row=0, column=3, padx=8)

    sub = tk.Label(header, text=subtitle, bg=PANEL, fg=MUTED, font=("Segoe UI", 9))
    sub.grid(row=0, column=4, sticky="w", padx=10)

    return header


def make_pill(parent, text, color=ACCENT, bg=PANEL2):
    return tk.Label(parent, text=text, bg=bg, fg=color,
                    font=("Segoe UI", 9, "bold"), padx=8, pady=3)


class ScrollableFrame(tk.Frame):
    """A frame whose contents scroll vertically when taller than the view.

    Use the ``inner`` attribute as the master for the widgets you want to
    be scrollable. Mouse-wheel (and Linux Button-4/Button-5) scrolling
    only engages while the pointer is over this widget, so it never
    hijacks scrolling elsewhere in the app.
    """

    def __init__(self, master, **kw):
        kw.setdefault("bg", BG)
        super().__init__(master, **kw)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.vsb = ttk.Scrollbar(self, orient="vertical")
        self.vsb.grid(row=0, column=1, sticky="ns")

        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0,
                               borderwidth=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.configure(command=self.canvas.yview)

        self.inner = tk.Frame(self.canvas, bg=BG)
        self._win = self.canvas.create_window(
            (0, 0), window=self.inner, anchor="nw")
        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self._win, width=e.width))

        self.bind_all("<MouseWheel>", self._on_scroll, add="+")
        self.bind_all("<Button-4>", self._on_scroll, add="+")
        self.bind_all("<Button-5>", self._on_scroll, add="+")

    def _is_inside(self, widget):
        w = widget
        while w is not None:
            if w is self or w is self.canvas or w is self.inner:
                return True
            w = getattr(w, "master", None)
        return False

    def _on_scroll(self, event):
        if not self._is_inside(event.widget):
            return
        if getattr(event, "num", 0) == 4:
            self.canvas.yview_scroll(-1, "units")
        elif getattr(event, "num", 0) == 5:
            self.canvas.yview_scroll(1, "units")
        elif getattr(event, "delta", 0):
            self.canvas.yview_scroll(int(-1 * event.delta / 120), "units")


class SidebarNav(tk.Frame):
    """Enterprise-style vertical navigation rail.

    The button list is rendered inside a scrollable canvas so every module
    stays reachable even when the window is short enough that all 20+ items
    cannot fit on screen at once.
    """

    def __init__(self, master, items, command, **kw):
        super().__init__(master, bg=SIDEBAR, **kw)
        self.command = command
        self.buttons = {}
        self._items = items
        self._search_default = "Search modules…"
        self.selected = None

        tk.Label(self, text="MODULES", bg=SIDEBAR, fg=MUTED,
                 font=("Segoe UI", 8, "bold"), anchor="w", padx=14, pady=10).pack(
            fill="x")

        # Live search filter keeps a long module list usable
        self._search = ttk.Entry(self, width=22)
        self._search.pack(fill="x", padx=10, pady=(2, 8))
        self._search.insert(0, self._search_default)
        self._search.config(foreground=MUTED)
        self._search.bind("<FocusIn>", self._on_search_focus_in)
        self._search.bind("<FocusOut>", self._on_search_focus_out)
        self._search.bind("<KeyRelease>", lambda e: self._filter())
        self._search.bind("<Return>", lambda e: self._select_first_match())

        # Scrollable button area. NOTE: the scrollbar is packed *before* the
        # canvas so it always claims its width; packing it after a
        # fill/expand canvas previously gave it zero space, hiding it and
        # making the lower modules unreachable on short windows.
        self.canvas = tk.Canvas(self, bg=SIDEBAR, highlightthickness=0,
                                borderwidth=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical",
                                 command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.vsb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        self.inner = tk.Frame(self.canvas, bg=SIDEBAR)
        self._win = self.canvas.create_window(
            (0, 0), window=self.inner, anchor="nw")
        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")))
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfig(self._win, width=e.width))

        for key, label, icon in items:
            b = tk.Button(self.inner, text=f"  {icon}  {label}", bg=SIDEBAR,
                           fg=MUTED, activebackground=PANEL2,
                           activeforeground=TEXT, bd=0, anchor="w", font=FONT,
                           padx=14, pady=7, relief="flat", cursor="hand2",
                           command=lambda k=key: self.select(k))
            b.bind("<Enter>", lambda e, w=b: self._hover(w, True))
            b.bind("<Leave>", lambda e, w=b: self._hover(w, False))
            b._mitmpro_label = label.lower()
            b.pack(fill="x", padx=6)
            self.buttons[key] = b

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", pady=6)
        self._brand = tk.Label(self, text="MITMPro\nEnterprise Suite", bg=SIDEBAR,
                                fg="#3a4452", font=("Segoe UI", 8), anchor="w",
                                padx=14, pady=8)
        self._brand.pack(side="bottom", fill="x")

        # Mouse-wheel scrolling (works when the pointer is over the sidebar,
        # but never while typing in the search box)
        self.bind_all("<MouseWheel>", self._on_scroll, add="+")
        self.bind_all("<Button-4>", self._on_scroll, add="+")
        self.bind_all("<Button-5>", self._on_scroll, add="+")

    # ----------------------------------------------------------------- search
    def _on_search_focus_in(self, event):
        if self._search.get() == self._search_default:
            self._search.delete(0, "end")
            self._search.config(foreground=TEXT)

    def _on_search_focus_out(self, event):
        if not self._search.get():
            self._search.insert(0, self._search_default)
            self._search.config(foreground=MUTED)

    def _filter(self):
        q = self._search.get().strip().lower()
        if q == self._search_default.lower():
            q = ""
        # Repack matching buttons in their original order so layout stays stable
        for key, label, icon in self._items:
            b = self.buttons[key]
            if not q or q in b._mitmpro_label or q in label.lower():
                b.pack(fill="x", padx=6)
            else:
                b.pack_forget()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _select_first_match(self):
        q = self._search.get().strip().lower()
        if q == self._search_default.lower():
            return
        for key, label, icon in self._items:
            if q in label.lower():
                self.select(key)
                return

    def _is_in_sidebar(self, widget):
        w = widget
        while w is not None:
            if w is self or w is self.canvas or w is self.inner:
                return True
            w = getattr(w, "master", None)
        return False

    def _on_scroll(self, event):
        if not self._is_in_sidebar(event.widget):
            return
        if getattr(event, "num", 0) == 4:
            self.canvas.yview_scroll(-1, "units")
        elif getattr(event, "num", 0) == 5:
            self.canvas.yview_scroll(1, "units")
        elif getattr(event, "delta", 0):
            self.canvas.yview_scroll(int(-1 * event.delta / 120), "units")

    def _hover(self, w, on):
        if self.selected and self.buttons.get(self.selected) is w:
            return
        w.config(bg=PANEL2 if on else SIDEBAR)

    def select(self, key):
        self.selected = key
        for k, b in self.buttons.items():
            if k == key:
                b.config(bg=ACCENT, fg="white")
            else:
                b.config(bg=SIDEBAR, fg=MUTED)
        self.command(key)


def make_statusbar(parent):
    bar = tk.Frame(parent, bg=PANEL, height=26)
    bar.grid(row=999, column=0, columnspan=2, sticky="ew")
    bar.columnconfigure(0, weight=0)
    bar.columnconfigure(1, weight=1)
    bar.columnconfigure(2, weight=0)

    dot = tk.Label(bar, text="●", bg=PANEL, fg=DANGER, font=("Segoe UI", 10), padx=8)
    dot.grid(row=0, column=0, sticky="w")

    status = tk.Label(bar, text="starting...", bg=PANEL, fg=MUTED,
                      font=("Segoe UI", 9), anchor="w")
    status.grid(row=0, column=1, sticky="ew")

    model = tk.Label(bar, text="model: —", bg=PANEL, fg=TEXT,
                     font=("Segoe UI", 9, "bold"), padx=10)
    model.grid(row=0, column=2, sticky="e")

    return {"frame": bar, "dot": dot, "status": status, "model": model}


# ---------------------------------------------------------------------------
# Global right-click context menu (Copy / Cut / Paste / Select All) for every
# text-like widget across the whole application. Read-only widgets (e.g. log
# panes) still support selection + copy; editable widgets additionally support
# cut and paste. Treeviews copy the selected row(s) as TSV.
# ---------------------------------------------------------------------------
def install_global_context_menu(root):
    """Bind a right-click context menu on all Text/Entry/Combobox/Listbox/Treeview."""

    def _copy_text(widget):
        try:
            try:
                sel = widget.get("sel.first", "sel.last")
            except tk.TclError:
                sel = ""
            if not sel:
                sel = widget.get("1.0", "end-1c")
            if sel:
                widget.clipboard_clear()
                widget.clipboard_append(sel)
        except Exception:
            pass

    def _cut_text(widget):
        _copy_text(widget)
        try:
            widget.delete("sel.first", "sel.last")
        except tk.TclError:
            pass

    def _paste_text(widget):
        try:
            txt = widget.clipboard_get()
        except Exception:
            return
        if txt is None:
            return
        try:
            widget.delete("sel.first", "sel.last")
        except tk.TclError:
            pass
        widget.insert("insert", txt)

    def _copy_entry(widget):
        try:
            try:
                sel = widget.selection_get()
            except tk.TclError:
                sel = ""
            if not sel:
                sel = widget.get()
            if sel:
                widget.clipboard_clear()
                widget.clipboard_append(sel)
        except Exception:
            pass

    def _cut_entry(widget):
        _copy_entry(widget)
        try:
            widget.delete("sel.first", "sel.last")
        except tk.TclError:
            pass

    def _paste_entry(widget):
        try:
            txt = widget.clipboard_get()
        except Exception:
            return
        if txt is None:
            return
        try:
            widget.delete("sel.first", "sel.last")
        except tk.TclError:
            pass
        widget.insert("insert", txt)

    def _copy_listbox(widget):
        try:
            sel = widget.curselection()
            if not sel:
                return
            lines = [widget.get(i) for i in sel]
            widget.clipboard_clear()
            widget.clipboard_append("\n".join(lines))
        except Exception:
            pass

    def _copy_tree(widget):
        try:
            sel = widget.selection()
            if not sel:
                return
            rows = []
            for item in sel:
                vals = widget.item(item, "values")
                rows.append("\t".join(str(v) for v in vals))
            widget.clipboard_clear()
            widget.clipboard_append("\n".join(rows))
        except Exception:
            pass

    def _menu_for_text(widget, parent):
        menu = tk.Menu(parent, tearoff=0, bg=PANEL, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white")
        readonly = str(widget.cget("state")) == "disabled"
        if not readonly:
            menu.add_command(label="Cut", command=lambda: _cut_text(widget))
            menu.add_command(label="Copy", command=lambda: _copy_text(widget))
            menu.add_command(label="Paste", command=lambda: _paste_text(widget))
        else:
            menu.add_command(label="Copy", command=lambda: _copy_text(widget))
        menu.add_separator()
        menu.add_command(label="Select All",
                         command=lambda: widget.tag_add("sel", "1.0", "end"))
        return menu

    def _menu_for_entry(widget, parent):
        menu = tk.Menu(parent, tearoff=0, bg=PANEL, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white")
        state = str(widget.cget("state"))
        readonly = state in ("disabled", "readonly")
        if not readonly:
            menu.add_command(label="Cut", command=lambda: _cut_entry(widget))
            menu.add_command(label="Copy", command=lambda: _copy_entry(widget))
            menu.add_command(label="Paste", command=lambda: _paste_entry(widget))
        else:
            menu.add_command(label="Copy", command=lambda: _copy_entry(widget))
        menu.add_separator()
        menu.add_command(label="Select All",
                         command=lambda: widget.select_range(0, "end"))
        return menu

    def _menu_for_listbox(widget, parent):
        menu = tk.Menu(parent, tearoff=0, bg=PANEL, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white")
        menu.add_command(label="Copy", command=lambda: _copy_listbox(widget))
        menu.add_command(label="Select All",
                         command=lambda: widget.selection_set(0, "end"))
        return menu

    def _menu_for_tree(widget, parent):
        menu = tk.Menu(parent, tearoff=0, bg=PANEL, fg=TEXT,
                       activebackground=ACCENT, activeforeground="white")
        menu.add_command(label="Copy", command=lambda: _copy_tree(widget))
        return menu

    def _build(widget):
        if isinstance(widget, (tk.Text, scrolledtext.ScrolledText)):
            return _menu_for_text(widget, root)
        if isinstance(widget, ttk.Combobox):
            return _menu_for_entry(widget, root)
        if isinstance(widget, (tk.Entry, ttk.Entry)):
            return _menu_for_entry(widget, root)
        if isinstance(widget, tk.Listbox):
            return _menu_for_listbox(widget, root)
        if isinstance(widget, ttk.Treeview):
            return _menu_for_tree(widget, root)
        # some comboboxes expose an internal Entry as the event target
        cls = widget.__class__.__name__
        if cls in ("Combobox", "Entry"):
            return _menu_for_entry(widget, root)
        return None

    def _popup(event):
        widget = event.widget
        if widget is None:
            return
        menu = _build(widget)
        if menu is None:
            return
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    root.bind_all("<Button-3>", _popup)

    # Make Ctrl+C / Ctrl+Insert work for read-only text (disabled) widgets too.
    def _ctrl_c(event):
        w = event.widget
        if isinstance(w, (tk.Text, scrolledtext.ScrolledText)):
            if str(w.cget("state")) == "disabled":
                return
            _copy_text(w)
            return "break"
        if isinstance(w, (tk.Entry, ttk.Entry, ttk.Combobox)):
            _copy_entry(w)
            return "break"
        if isinstance(w, tk.Listbox):
            _copy_listbox(w)
            return "break"
        return None


    root.bind_all("<Control-c>", _ctrl_c)
    root.bind_all("<Control-Insert>", _ctrl_c)
