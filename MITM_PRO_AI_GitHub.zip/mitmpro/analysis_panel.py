import os
import sys
import threading
from tkinter import ttk, scrolledtext

from mitmpro import common
from mitmpro.common import PROJECT_ROOT, OLLAMA_GUI_DIR, WEBSPLOIT_DIR, MITMNEW_DIR, MITM_UI_DIR, MITMPROXY_UI_DIR

FOLDERS = [
    ("ollama-gui-1.2.2", OLLAMA_GUI_DIR, "Ollama GUI — Tkinter chat/manager for local Ollama models (AI)"),
    ("websploit-4.0.4", WEBSPLOIT_DIR, "WebSploit — network attack toolkit (ARP spoof, sniffer, WiFi, scan)"),
    ("mitmnew", MITMNEW_DIR, "MITM proxy scripts (mitm_intercept, DatajackProxy)"),
    ("mitm-ui-0.1", MITM_UI_DIR, "Legacy PyQt5 MITM proxy UI (Python 2)"),
    ("mitmproxy-ui-master", MITMPROXY_UI_DIR, "Web-based MITM proxy UI (Node/React)"),
    ("mitmpro", os.path.join(PROJECT_ROOT, "mitmpro"), "This unified app package (integration layer)"),
]


def scan_dir(path):
    py = 0
    total = 0
    size = 0
    try:
        for root, dirs, files in os.walk(path):
            for f in files:
                total += 1
                fp = os.path.join(root, f)
                try:
                    size += os.path.getsize(fp)
                except Exception:
                    pass
                if f.endswith(".py"):
                    py += 1
    except Exception:
        pass
    return py, total, size


from mitmpro.ai_components import AIHelperTab

class AnalysisPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Diagnostics")
        self.add(AIHelperTab(self, "Analysis"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(0, weight=1)
        self.text = scrolledtext.ScrolledText(self.main_frame, font=("Courier", 10))
        self.text.grid(row=0, column=0, sticky="nsew", padx=4, pady=4)
        self.text.config(state="disabled")
        threading.Thread(target=self.build, daemon=True).start()


    def build(self):
        lines = []
        lines.append("MITM_PRO_AI — Folder Analysis")
        lines.append("=" * 60)
        lines.append("")
        for name, path, desc in FOLDERS:
            py, total, size = scan_dir(path)
            exists = os.path.isdir(path)
            status = "PRESENT" if exists else "MISSING"
            lines.append(f"[{status}] {name}")
            lines.append(f"    {desc}")
            if exists:
                lines.append(f"    files={total}  python={py}  size={size/1024:.1f} KB")
            lines.append("")
        lines.append("Dependencies (installed system-wide):")
        for mod in ["requests", "scapy", "netifaces", "psutil", "bs4", "lxml", "tkinter"]:
            try:
                __import__(mod)
                lines.append(f"    [OK]   {mod}")
            except Exception as e:
                lines.append(f"    [MISS] {mod} ({e})")
        lines.append("")
        lines.append(f"Ollama service: running models -> {', '.join(common.ollama_models()) or 'none'}")
        out = "\n".join(lines)
        def _update():
            self.text.config(state="normal")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", out)
            self.text.config(state="disabled")
        self.after(0, _update)
