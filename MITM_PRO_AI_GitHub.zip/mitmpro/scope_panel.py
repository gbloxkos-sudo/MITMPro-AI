import tkinter as tk
from tkinter import ttk, messagebox

from mitmpro import scope


from mitmpro.ai_components import AIHelperTab

class ScopePanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Scope Management")
        self.add(AIHelperTab(self, "Scope"), text="AI Helper")


        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(0, weight=1)
        self.entry = ttk.Entry(top)
        self.entry.grid(row=0, column=0, sticky="ew")
        self.entry.insert(0, "example.com")
        self.entry.bind("<Return>", lambda e: self.add_to_scope())
        ttk.Button(top, text="Add", command=self.add_to_scope).grid(row=0, column=1, padx=4)

        ttk.Button(top, text="Remove", command=self.remove).grid(row=0, column=2)
        ttk.Label(top, text="(empty scope = all targets allowed)").grid(row=0, column=3, padx=8)

        self.status_lbl = ttk.Label(self.main_frame, text="Scope: empty (all targets allowed)", foreground="#8b949e")
        self.status_lbl.grid(row=2, column=0, sticky="w", padx=4, pady=2)

        self.listbox = tk.Listbox(self.main_frame)
        self.listbox.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self._refresh()


    def _refresh(self):
        self.listbox.delete(0, "end")
        for h in scope.SCOPE:
            self.listbox.insert("end", h)
        count = len(scope.SCOPE)
        if count == 0:
            self.status_lbl.config(text="Scope: empty (all targets allowed)", foreground="#8b949e")
        else:
            self.status_lbl.config(text=f"Scope: {count} authorized target(s)", foreground="#2ea043")

    def add_to_scope(self, hostname=None, **kwargs):
        host = hostname or self.entry.get().strip()
        if not host:
            return
        host = host.lower().strip()
        if " " in host or "/" in host:
            host = host.split("/")[0].split(" ")[0].strip()
        if not host:
            return
        if host in scope.SCOPE:
            self.status_lbl.config(text=f"'{host}' is already in scope", foreground="#d29922")
            return
        scope.add(host)
        self.entry.delete(0, "end")
        self.entry.insert(0, "example.com")
        self._refresh()
        self.status_lbl.config(text=f"Added '{host}' to scope", foreground="#2ea043")


    def remove(self):
        sel = self.listbox.curselection()
        if sel:
            host = self.listbox.get(sel[0])
            scope.remove(host)
            self._refresh()
            self.status_lbl.config(text=f"Removed '{host}' from scope", foreground="#d29922")
