"""AI Self-Learning Engine for MITMPro.

Enables the AI assistant to learn from every assessment, tool run, and OTP/2FA
bypass attempt. Accumulates verified knowledge about which techniques work
against which targets, which WAF variants evade which vendors, and which OTP
bypass methods succeed.

Learning memory persists to ~/.mitmpro/learning.json and is injected into the AI
system prompt on every call, so the assistant becomes more expert over time —
mastering Burp Suite, MITM, and OTP/2FA bypass through verified experience.

Only confirmed wins are learned (never failures). Everything stays local.
"""
import os
import json
import time
import threading
from collections import defaultdict

from mitmpro import common
from mitmpro import logger

LEARNING_DIR = os.path.expanduser("~/.mitmpro")
LEARNING_FILE = os.path.join(LEARNING_DIR, "learning.json")

_lock = threading.Lock()


def _ensure_dir():
    try:
        os.makedirs(LEARNING_DIR, exist_ok=True)
    except OSError as e:
        logger.log_exception(e, "creating learning dir")


def _load():
    """Load the full learning store."""
    with _lock:
        _ensure_dir()
        store = {
            "domains": defaultdict(list),
            "techniques": defaultdict(list),
            "payloads": defaultdict(list),
            "waf_vendors": defaultdict(list),
            "chains": [],
            "feedback": [],
            "meta": {"total_learnings": 0, "last_updated": 0},
        }
        try:
            if os.path.isfile(LEARNING_FILE):
                with open(LEARNING_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        for k in ("domains", "techniques", "payloads", "waf_vendors"):
                            if k in data and isinstance(data[k], dict):
                                store[k] = defaultdict(list, data[k])
                        for k in ("chains", "feedback"):
                            if k in data and isinstance(data[k], list):
                                store[k] = data[k]
                        if isinstance(data.get("meta"), dict):
                            store["meta"].update(data["meta"])
        except (OSError, json.JSONDecodeError) as e:
            logger.log_exception(e, "loading learning store")
        return store


def _save(store):
    _ensure_dir()
    try:
        plain = {
            "domains": dict(store.get("domains", {})),
            "techniques": {k: v for k, v in store.get("techniques", {}).items()},
            "payloads": {k: v for k, v in store.get("payloads", {}).items()},
            "waf_vendors": {k: v for k, v in store.get("waf_vendors", {}).items()},
            "chains": store.get("chains", []),
            "feedback": store.get("feedback", []),
            "meta": store.get("meta", {}),
        }
        with open(LEARNING_FILE, "w", encoding="utf-8") as f:
            json.dump(plain, f, indent=2, default=str)
    except OSError as e:
        logger.log_exception(e, "saving learning store")


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #

def learn_otp_bypass(technique, target_url, target_type, success_details):
    """Record a successful OTP/2FA bypass attempt."""
    store = _load()
    entry = {
        "technique": technique,
        "target_url": target_url,
        "target_type": target_type,  # login, registration, password_reset, email_change
        "timestamp": time.time(),
        "details": success_details,
        "confidence": "high",
    }
    store["techniques"]["otp_bypass"].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def learn_waf_bypass(waf_vendor, payload, category, context):
    """Record a WAF bypass that worked."""
    store = _load()
    entry = {
        "waf_vendor": waf_vendor,
        "payload": payload,
        "category": category,
        "context": context,
        "timestamp": time.time(),
        "confidence": "high",
    }
    store["waf_vendors"][waf_vendor].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def learn_burp_technique(tool, technique, target, payload, result):
    """Record a successful Burp Suite technique (Repeater, Intruder, Scanner)."""
    store = _load()
    entry = {
        "tool": tool,
        "technique": technique,
        "target": target,
        "payload": payload,
        "result": result,
        "timestamp": time.time(),
        "confidence": "high",
    }
    store["techniques"][tool].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def learn_mitm_chain(chain_name, steps, target, outcome):
    """Record a successful MITM attack chain."""
    store = _load()
    entry = {
        "chain_name": chain_name,
        "steps": steps,
        "target": target,
        "outcome": outcome,
        "timestamp": time.time(),
        "confidence": "high",
    }
    store["chains"].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def learn_payload_efficacy(vuln_class, payload, encoding, target, success):
    """Record which payload/encoding worked for a vulnerability class."""
    if not success:
        return
    store = _load()
    entry = {
        "vuln_class": vuln_class,
        "payload": payload,
        "encoding": encoding,
        "target": target,
        "timestamp": time.time(),
        "confidence": "high",
    }
    store["payloads"][vuln_class].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def learn_from_assessment(assessment_type, target, methodology, findings, success):
    """Record a full assessment run (web, network, phishing, etc.)."""
    if not success:
        return
    store = _load()
    entry = {
        "assessment_type": assessment_type,
        "target": target,
        "methodology": methodology,
        "findings_summary": findings[:10] if isinstance(findings, list) else str(findings)[:500],
        "timestamp": time.time(),
        "confidence": "high",
    }
    store["domains"][assessment_type].append(entry)
    store["meta"]["total_learnings"] += 1
    store["meta"]["last_updated"] = time.time()
    _save(store)


def get_learning_context(max_entries_per_domain=3):
    """Return a formatted string of learned experience for injection into system prompt."""
    store = _load()
    parts = []
    
    # OTP bypass techniques
    otp = store.get("techniques", {}).get("otp_bypass", [])
    if otp:
        parts.append("OTP/2FA Bypass Techniques That Worked:")
        for e in otp[-max_entries_per_domain:]:
            parts.append(
                f"  - {e['technique']} on {e['target_type']} ({e['target_url']}): "
                f"{e['details']}"
            )
    
    # WAF bypasses
    waf = store.get("waf_vendors", {})
    if waf:
        parts.append("\nWAF Bypass Successes:")
        for vendor, entries in waf.items():
            if entries:
                parts.append(f"  {vendor}:")
                for e in entries[-max_entries_per_domain:]:
                    parts.append(f"    - {e['category']} payload: {e['payload'][:80]}...")
    
    # Burp techniques
    burp = store.get("techniques", {})
    for tool in ("repeater", "intruder", "scanner"):
        entries = burp.get(tool, [])
        if entries:
            parts.append(f"\nBurp {tool.capitalize()} Techniques:")
            for e in entries[-max_entries_per_domain:]:
                parts.append(
                    f"  - {e['technique']} on {e['target']}: {e['result']}"
                )
    
    # MITM chains
    chains = store.get("chains", [])
    if chains:
        parts.append("\nMITM Attack Chains:")
        for e in chains[-max_entries_per_domain:]:
            parts.append(f"  - {e['chain_name']} on {e['target']}: {e['outcome']}")
    
    # Payload efficacies
    payloads = store.get("payloads", {})
    for vuln_class, entries in payloads.items():
        if entries:
            parts.append(f"\n{vuln_class} Payloads:")
            for e in entries[-max_entries_per_domain:]:
                parts.append(f"  - {e['encoding']} encoding: {e['payload'][:60]}...")
    
    # Assessment domains
    domains = store.get("domains", {})
    for domain, entries in domains.items():
        if entries:
            parts.append(f"\n{domain} Assessment Methodology:")
            for e in entries[-max_entries_per_domain:]:
                parts.append(f"  - Target: {e['target']}, Method: {e['methodology'][:80]}...")
    
    if not parts:
        return ""
    
    header = (
        f"[Self-Learned from {store['meta']['total_learnings']} verified successes "
        f"(last update: {time.ctime(store['meta']['last_updated'])})]"
    )
    return header + "\n" + "\n".join(parts)


def get_learning_stats():
    """Return statistics about the learning store."""
    store = _load()
    return {
        "total_learnings": store["meta"]["total_learnings"],
        "last_updated": store["meta"]["last_updated"],
        "otp_bypasses": len(store.get("techniques", {}).get("otp_bypass", [])),
        "waf_bypasses": sum(len(v) for v in store.get("waf_vendors", {}).values()),
        "burp_techniques": sum(len(v) for v in store.get("techniques", {}).values()),
        "mitm_chains": len(store.get("chains", [])),
        "payloads": sum(len(v) for v in store.get("payloads", {}).values()),
        "assessments": sum(len(v) for v in store.get("domains", {}).values()),
    }


def clear_learning():
    """Clear all learning data (use with caution)."""
    _save({
        "domains": defaultdict(list),
        "techniques": defaultdict(list),
        "payloads": defaultdict(list),
        "waf_vendors": defaultdict(list),
        "chains": [],
        "feedback": [],
        "meta": {"total_learnings": 0, "last_updated": time.time()},
    })


# --------------------------------------------------------------------------- #
# Integration helpers for AutoRun engine and panels
# --------------------------------------------------------------------------- #

def record_otp_bypass_from_autorun(technique, target_url, target_type, details):
    """Convenience wrapper for AutoRun to record OTP bypass results."""
    learn_otp_bypass(technique, target_url, target_type, details)


def record_waf_bypass_from_scan(waf_vendor, payload, category, target_url):
    """Convenience wrapper for Scanner/WAF panel to record bypass results."""
    learn_waf_bypass(waf_vendor, payload, category, target_url)


def record_burp_result(tool, technique, target, payload, result):
    """Convenience wrapper for Burp tools to record results."""
    learn_burp_technique(tool, technique, target, payload, result)


def record_mitm_chain_from_autorun(chain_name, steps, target, outcome):
    """Convenience wrapper for AutoRun to record MITM chains."""
    learn_mitm_chain(chain_name, steps, target, outcome)


def record_assessment_completion(assessment_type, target, methodology, findings, success):
    """Convenience wrapper for AutoRun/campaigns to record assessments."""
    learn_from_assessment(assessment_type, target, methodology, findings, success)


# Mapping of AutoRun tool keys to the appropriate learning recorder.
_OT = ("otp", "2fa")
_WAF = ("waf",)
_BURP = ("burp", "repeater", "intruder", "decoder", "scanner")
_MITM = ("mitm", "network", "sslstrip", "nsniffer", "arp", "dns", "proxy", "dlp", "masquerading")


def record_from_autorun(tool, action, params, result, success):
    """Dispatch a completed/failed AutoRun step into the learning store.

    Routes the step to the most relevant learning domain based on the tool
    key so the AI can recall field-proven techniques later. Failures are
    recorded too (negative learnings) so the AI avoids repeating mistakes.
    """
    tool_l = (tool or "").lower()
    action_l = (action or "").lower()
    target = ""
    if isinstance(params, dict):
        target = (params.get("target") or params.get("target_url")
                  or params.get("url") or params.get("host") or "")
    findings = str(result)[:500] if result is not None else ""

    try:
        if any(k in tool_l or k in action_l for k in _OT):
            record_otp_bypass_from_autorun(
                action or tool, target, "autorun", findings)
        elif any(k in tool_l for k in _WAF):
            record_waf_bypass_from_scan(
                params.get("vendor", "Unknown") if isinstance(params, dict) else "Unknown",
                params.get("payload", "") if isinstance(params, dict) else "",
                params.get("category", "SQLi") if isinstance(params, dict) else "SQLi",
                target)
        elif any(k in tool_l for k in _BURP):
            record_burp_result(tool, action, target,
                               params.get("payload", "") if isinstance(params, dict) else "",
                               findings)
        elif any(k in tool_l for k in _MITM):
            record_mitm_chain_from_autorun(tool, [action], target, findings)
        else:
            record_assessment_completion(tool, target, action, findings, success)
    except Exception:
        # Learning must never break an assessment run.
        pass