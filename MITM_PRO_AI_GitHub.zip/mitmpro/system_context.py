"""Live system-context collector for MITMPro.

Produces a concise, real snapshot of the operator's machine and the running
application (OS, hardware, network interfaces, installed security tooling, Ollama
models, current Scope, captured HTTP history, active module). The AI engine injects
this so every answer is tailored to what the system can *actually* do — i.e. full
use of the system, not generic advice.
"""
import os
import sys
import platform
import shutil
import socket

from mitmpro import common


def _username():
    # os.getlogin() raises OSError when there is no controlling terminal
    # (e.g. launched from a service/cron/headless context), so fall back safely.
    try:
        if hasattr(os, "getlogin"):
            return os.getlogin()
    except Exception:
        pass
    return os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"


TOOL_HINTS = [
    "nmap", "curl", "wget", "mitmproxy", "mitmdump", "frida", "frida-ps", "tcpdump",
    "arpspoof", "ettercap", "sqlmap", "nikto", "dirb", "gobuster", "ffuf",
    "aircrack-ng", "bettercap", "proxychains", "tshark", "wireshark",
    "arp-scan", "arping", "hydra", "john", "hashcat", "metasploit",
]

# The 21 MITMPro modules/features (short launch map so the AI always has the full
# feature inventory in context, even before RAG retrieval).
MITMPRO_MODULES = [
    "Dashboard (Welcome)", "AI Assistant (Ollama)", "AI Traffic Analyst",
    "Burp Tools (Repeater/Intruder/Decoder/Comparer/Sequencer/Scanner)",
    "WebSploit", "Proxy Tools", "WAF/Bypass", "Website Masquerading",
    "Inline DLP Proxy", "Nsniffer Toolkit", "AI Helper", "HTTP History",
    "OAST / DNS", "Macro / Flow", "Scope", "Analysis", "Network Attacks (L2/L3)",
    "SSL Strip / MITM", "Campaign Manager", "Email Engineer", "AI Auto-Run",
]

# Bundled external tool directories (relative to project root) + one-line role.
BUNDLED_TOOLS = [
    ("websploit-4.0.4", "WebSploit network-attack framework (arp_spoof, http_sniffer, wifi)"),
    ("mitm_tools/inline-dlp-proxy-main", "Envoy inline DLP proxy (manage-proxy.sh)"),
    ("mitm_tools/Nsniffer-1.1.0", "TShark sniffer/MITM toolkit"),
    ("mitm_tools/PoC-Website-Masquerading-main", "reverse-proxy site impersonation PoC"),
    ("mitm_tools/yorishiro-proxy-0.18.2", "AI-first Go MITM proxy (MCP server)"),
    ("mitmnew/MITM_Intercept-main", "SSL interception relay (mitm_intercept.py)"),
    ("mitmnew/MITM-master", "ARP/MITM reference scripts"),
    ("mitmnew/DatajackProxy-master", "Frida-based process MITM"),
    ("mitm-ui-0.1", "legacy PyQt5 MITM proxy UI (reference)"),
    ("mitmproxy-ui-master", "mitmproxy JSON log/UI tooling (reference)"),
    ("ollama-gui-1.2.2", "standalone Ollama Tkinter chat client (embedded)"),
    ("KPHISH_AI/BlackPhish-master", "phishing templates"),
    ("KPHISH_AI/CyberPhish-master", "phishing tool + email templates"),
    ("KPHISH_AI/Phishbait-main", "phishing landing-page templates"),
    ("pt-MitM-master", "Password-Reset MitM PoC (Flask)"),
]


def _bundled_tools_status():
    lines = []
    for rel, role in BUNDLED_TOOLS:
        present = os.path.isdir(os.path.join(common.PROJECT_ROOT, rel))
        lines.append(f"  [{'OK' if present else 'MISSING'}] {rel} — {role}")
    return "\n".join(lines)



def _interfaces():
    try:
        import netifaces
        out = []
        for iface in netifaces.interfaces():
            try:
                addrs = netifaces.ifaddresses(iface)
            except Exception:
                continue
            ips = []
            for kind in (netifaces.AF_INET, netifaces.AF_INET6):
                for a in addrs.get(kind, []):
                    ips.append(a.get("addr"))
            if ips:
                out.append(f"{iface}({','.join(ips)})")
        if out:
            return out
    except Exception:
        pass
    try:
        import psutil
        return [f"{n}({','.join(a.address for a in addrs if a.family == socket.AF_INET)})"
                for n, addrs in psutil.net_if_addrs().items()]
    except Exception:
        pass
    return ["(unavailable)"]


def _hardware():
    try:
        import psutil
        vm = psutil.virtual_memory()
        return (f"cpu_cores={psutil.cpu_count()} "
                f"mem={vm.total//(1024*1024)}MB used={vm.percent}%")
    except Exception:
        return "cpu_cores=? mem=?"


def _tools():
    found = [t for t in TOOL_HINTS if shutil.which(t)]
    missing = [t for t in TOOL_HINTS if not shutil.which(t)]
    return found, missing


def collect(active_module="MITMPro"):
    try:
        import mitmpro.scope as scope
        scopes = list(scope.SCOPE)
    except Exception:
        scopes = []
    try:
        from mitmpro.traffic import log
        history = len(log.snapshot())
    except Exception:
        history = 0

    found, missing = _tools()
    lines = [
        "=== LIVE SYSTEM CONTEXT (full-use) ===",
        f"os={platform.system()} {platform.release()} arch={platform.machine()}",
        f"host={socket.gethostname()} user={_username()}",
        f"python={sys.version.split()[0]} cwd={os.getcwd()}",
        f"hardware: {_hardware()}",
        f"interfaces: {', '.join(_interfaces())}",
        f"ollama_running={common.ollama_running()} models={common.ollama_models()}",
        f"active_module={active_module}",
        f"scope={scopes if scopes else 'ALL (empty scope)'}",
        f"http_history_captured={history}",
        f"tools_available={found}",
        f"tools_missing={missing}",
        "--- MITMPro modules (all 21 features) ---",
        "  " + "; ".join(MITMPRO_MODULES),
        "--- Bundled external tools (present on this machine) ---",
        _bundled_tools_status(),
        "=== END SYSTEM CONTEXT ===",
    ]
    return "\n".join(lines)
