"""Reusable, context-aware AI Help widget.

This is the "AI helper on every feature": a compact assistant that is always
visible and knows which MITMPro module is active. It is used as a docked pane
and also can be embedded into individual panels. All calls go through
mitmpro.ai_core (self-healing, anti-hallucination, local learning memory).
"""
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext

from mitmpro import common
from mitmpro import ai_core


class AIHelpWidget(ttk.Frame):
    def __init__(self, master, get_context=None, get_health=None):
        super().__init__(master)
        self.get_context = get_context or (lambda: "MITMPro")
        self.get_health = get_health or (lambda: "")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.history = []
        self._busy = False
        self._cancel_event = None

        head = ttk.Frame(self)
        head.grid(row=0, column=0, sticky="ew", padx=6, pady=6)
        head.columnconfigure(0, weight=1)
        ttk.Label(head, text="🧠  AI Help", font=("Segoe UI", 11, "bold"),
                  foreground="#2f81f6").grid(row=0, column=0, sticky="w")
        self.ctx_lbl = ttk.Label(head, text="", foreground="#8b949e")
        self.ctx_lbl.grid(row=1, column=0, sticky="w")

        bar = ttk.Frame(self)
        bar.grid(row=1, column=0, sticky="ew", padx=6, pady=2)
        bar.columnconfigure(1, weight=1)
        ttk.Label(bar, text="Model:").grid(row=0, column=0)
        self.model = ttk.Combobox(bar, width=18)
        self.model.grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(bar, text="↻", width=3,
                   command=lambda: threading.Thread(target=self.load_models, daemon=True).start()).grid(row=0, column=2, padx=4)

        self.chat = scrolledtext.ScrolledText(self, state="disabled",
                                              font=("TkDefaultFont", 10))
        self.chat.grid(row=2, column=0, sticky="nsew", padx=6, pady=4)

        bottom = ttk.Frame(self)
        bottom.grid(row=3, column=0, sticky="ew", padx=6, pady=4)
        bottom.columnconfigure(0, weight=1)
        self.entry = scrolledtext.ScrolledText(bottom, height=3)
        self.entry.grid(row=0, column=0, sticky="ew")
        self.entry.bind("<Control-Return>", lambda e: (self.send(), "break")[1])
        btns = ttk.Frame(bottom)
        btns.grid(row=0, column=1, padx=4)
        ttk.Button(btns, text="Send", command=self.send).grid(row=0, column=0, sticky="ew")
        self.stop_btn = ttk.Button(btns, text="Stop", command=self.stop_stream, state="disabled")
        self.stop_btn.grid(row=0, column=1, sticky="ew", padx=3)
        ttk.Button(btns, text="Assess", command=self.assess).grid(row=1, column=0, sticky="ew", pady=3)
        ttk.Button(btns, text="Clear", command=self.clear).grid(row=2, column=0, sticky="ew", pady=3)

        self.load_models()
        common.register_model_listener(self._on_global_model)
        self._update_ctx()

    # -------------------------------------------------------------- helpers
    def load_models(self):
        import threading
        def _fetch():
            try:
                models = common.ollama_models()
            except Exception:
                models = []
            def apply():
                self.model["values"] = models
                if models:
                    self.model.set(common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0])
            try:
                self.after(0, apply)
            except Exception:
                apply()
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            if model and model not in (self.model["values"] or ()):
                self.model["values"] = list(self.model["values"] or ()) + [model]
            if model:
                self.model.set(model)
        try:
            self.after(0, apply)
        except Exception:
            pass

    def _update_ctx(self):
        try:
            self.ctx_lbl.config(text=f"context: {self.get_context()}")
        except Exception:
            pass

    def _append(self, who, text):
        self.chat.config(state="normal")
        self.chat.insert("end", f"\n{who}: {text}\n")
        self.chat.see("end")
        self.chat.config(state="disabled")

    def clear(self):
        self.history = []
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")

    # -------------------------------------------------------------- sending
    def _build_messages(self, user_text):
        ctx = self.get_context()
        sys = ai_core.build_system_prompt(ctx, self.get_health())
        # self-learning: inject relevant verified past answers
        past = ai_core.recall(user_text, ctx, limit=2)
        if past:
            sys += "\n\n=== Prior verified answers (reuse when consistent) ===\n"
            for r in past:
                sys += f"Q: {r['q']}\nA: {r['a'][:1500]}\n"
            sys += "=== END PRIOR ANSWERS ===\n"
        msgs = [{"role": "system", "content": sys}]
        msgs += self.history
        # NOTE: the caller already appended the latest user turn to self.history
        # before calling this, so do NOT append user_text again (avoids duplicates).
        return msgs

    def send(self):
        if self._busy:
            return
        self._busy = True
        def _do():
            msg = self.entry.get("1.0", "end").strip()
            if not msg:
                self._busy = False
                return
            self.entry.delete("1.0", "end")
            self._update_ctx()
            self._append("You", msg)
            self.history.append({"role": "user", "content": msg})
            self._stream(self._build_messages(msg), rag_query=msg, learn=True)
        self.after(0, _do)

    def assess(self):
        if self._busy:
            return
        self._busy = True
        ctx = self.get_context()
        self._update_ctx()
        prompt = (f"Produce a complete, phased security assessment methodology / "
                  f"checklist for the '{ctx}' module in MITMPro. Cover recon, "
                  f"enumeration, exploitation, validation, and reporting. Include "
                  f"concrete commands, tool usage, and example payloads.")
        self._append("You", "[Assessment] " + prompt)
        self.history.append({"role": "user", "content": prompt})
        self._stream(self._build_messages(prompt), rag_query=prompt, learn=True)

    def _stream(self, messages, rag_query=None, learn=False):
        model = self.model.get()
        if not model:
            self._append("AI", "No Ollama model available. Start 'ollama serve' and "
                           "pull a model, then Refresh Models.")
            self._busy = False
            return
        self._busy = True
        self._cancel_event = threading.Event()
        self.stop_btn.config(state="normal")
        self.chat.config(state="normal")
        self.chat.insert("end", "\nAI: ")
        self.chat.see("end")
        self.chat.config(state="disabled")

        collected = {"text": ""}

        def on_token(t):
            def update():
                collected["text"] += t
                self.chat.config(state="normal")
                self.chat.insert("end", t)
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        def on_done(full):
            def update():
                self._busy = False
                self.stop_btn.config(state="disabled")
                self.history.append({"role": "assistant", "content": full})
                if learn and rag_query:
                    ai_core.remember(rag_query, full, self.get_context())
            self.after(0, update)
        
        def on_error(e):
            def update():
                self._busy = False
                self.stop_btn.config(state="disabled")
                self.chat.config(state="normal")
                self.chat.insert("end", f"\n[error: {e}]")
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        threading.Thread(
            target=ai_core.stream_chat,
            args=(model, messages),
            kwargs={"on_token": on_token, "on_done": on_done, "on_error": on_error,
                    "context": self.get_context(), "rag_query": rag_query,
                    "cancel_event": self._cancel_event},
            daemon=True,
        ).start()

    def stop_stream(self):
        """Stop the currently streaming AI response."""
        if self._busy and self._cancel_event is not None:
            self._cancel_event.set()
            self._busy = False
            self._append("System", "[Stopped by user]")
