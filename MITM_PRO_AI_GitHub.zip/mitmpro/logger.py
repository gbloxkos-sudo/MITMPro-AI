import logging
import os
import traceback

# Ensure log directory exists
log_dir = os.path.expanduser("~/.mitmpro/logs")
os.makedirs(log_dir, exist_ok=True)

# Configure logging
logging.basicConfig(
    level=logging.ERROR,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename=os.path.join(log_dir, 'app.log'),
    filemode='a'
)

logger = logging.getLogger("MITMPro")

def log_exception(e, context=""):
    """Logs an exception with traceback to the application log."""
    msg = f"Error in {context}: {str(e)}"
    logger.error(msg)
    logger.error(traceback.format_exc())
    # Optional: Print to console for development
    print(msg)
    print(traceback.format_exc())
