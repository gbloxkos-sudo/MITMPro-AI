import os
import sys
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext

class ProcessMock:
    def __init__(self, pid):
        self.pid = pid
    def poll(self):
        try:
            os.kill(self.pid, 0)
            return None
        except OSError:
            return self.pid

HAS_PTY = sys.platform != "win32"
if HAS_PTY:
    import pty
    import select


class ConsoleWidget(ttk.Frame):
    def __init__(self, master, cwd=None):
        super().__init__(master)
        self.cwd = cwd
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.console = scrolledtext.ScrolledText(self, bg="black", fg="lightgreen",
                                                 insertbackground="white", font=("Courier", 10))
        self.console.grid(row=0, column=0, sticky="nsew")
        self.console.bind("<Key>", self.on_key)
        self.console.bind("<Control-c>", self.on_ctrl_c)
        self.master_fd = None
        self.pid = None
        self.running = False

    def start(self, cmd, env=None):
        if self.running:
            return
        if not HAS_PTY:
            self.running = True
            self.after(0, lambda: self._append_to_console(f"$ {' '.join(cmd)}\n"))
            self.after(0, lambda: self._append_to_console(
                "\n[console not available on this platform]\n"))
            return
        env = env or os.environ.copy()
        env["TERM"] = "xterm"
        pid, fd = pty.fork()
        if pid == 0:
            try:
                os.chdir(self.cwd or os.getcwd())
            except Exception as e:
                print(f"Console chdir error: {e}")
                pass
            try:
                os.execvpe(cmd[0], cmd, env)
            except Exception as e:
                os.write(1, f"exec failed: {e}\n".encode())
            finally:
                os._exit(1)
        self.pid = pid
        self.master_fd = fd
        self.running = True
        self.after(0, lambda: self._append_to_console(f"$ {' '.join(cmd)}"))
        threading.Thread(target=self._pump, daemon=True).start()
        return ProcessMock(pid)

    def _pump(self):
        while self.running:
            try:
                r, _, _ = select.select([self.master_fd], [], [], 0.1)
            except Exception as e:
                print(f"Console _pump select error: {e}")
                break
            if r:
                try:
                    data = os.read(self.master_fd, 4096)
                except OSError:
                    break
                if not data:
                    break
                text = data.decode("utf-8", "replace")
                self.after(0, self._append_to_console, text)
        self.running = False
        self.after(0, lambda: self.console.insert("end", "\n[process exited]\n"))

    def _append_to_console(self, text):
        self.console.insert("end", text)
        self.console.see("end")


    def on_key(self, event):
        if not self.running or self.master_fd is None:
            return
        try:
            if event.keysym == "BackSpace":
                os.write(self.master_fd, b"\x7f")
                return "break"
            if event.char:
                os.write(self.master_fd, event.char.encode())
            elif event.keysym in ("Return", "KP_Enter"):
                os.write(self.master_fd, b"\n")
            elif event.keysym == "Tab":
                os.write(self.master_fd, b"\t")
        except OSError as e:
            print(f"Console on_key error: {e}")
            self.running = False
            return "break"
        return "break"

    def on_ctrl_c(self, event):
        if self.running and self.master_fd is not None:
            try:
                os.write(self.master_fd, b"\x03")
            except OSError as e:
                print(f"Console on_ctrl_c error: {e}")
                self.running = False
        return "break"

    def stop(self):
        self.running = False
        if self.pid:
            try:
                os.kill(self.pid, 9)
            except Exception as e:
                print(f"Console stop kill error: {e}")
                pass
            try:
                os.waitpid(self.pid, os.WNOHANG)
            except Exception as e:
                print(f"Console stop waitpid error: {e}")
                pass
            self.pid = None
        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except Exception as e:
                print(f"Console stop close error: {e}")
                pass
            self.master_fd = None
