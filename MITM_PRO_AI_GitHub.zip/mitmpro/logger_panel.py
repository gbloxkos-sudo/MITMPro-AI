import tkinter as tk
import threading
from tkinter import ttk, scrolledtext, messagebox
from urllib.parse import urlparse

from mitmpro.traffic import log


from mitmpro.ai_components import AIHelperTab

class LoggerPanel(ttk.Notebook):
    def __init__(self, master, on_send_to_repeater=None, on_send_to_ai=None):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="HTTP History")
        self.add(AIHelperTab(self, "HTTP History"), text="AI Helper")
        
        self.on_send_to_repeater = on_send_to_repeater
        self.on_send_to_ai = on_send_to_ai
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Filter:").grid(row=0, column=0)
        self.filter = ttk.Entry(top)
        self.filter.grid(row=0, column=1, sticky="ew")
        self.filter.bind("<KeyRelease>", lambda e: self.refresh())
        ttk.Button(top, text="Refresh", command=self.refresh).grid(row=0, column=2, padx=4)
        ttk.Button(top, text="Clear", command=log.clear).grid(row=0, column=3)
        ttk.Button(top, text="Send to Repeater", command=self.to_repeater).grid(row=0, column=4)
        ttk.Button(top, text="Send to AI Analyst", command=self.to_ai).grid(row=0, column=5)

        cols = ("#", "Method", "Status", "Host", "Path", "Size")
        self.tree = ttk.Treeview(self.main_frame, columns=cols, show="headings", height=12)
        for c in cols:
            self.tree.heading(c, text=c)
        self.tree.column("#", width=40)
        self.tree.column("Method", width=70)
        self.tree.column("Status", width=70)
        self.tree.column("Host", width=180)
        self.tree.column("Path", width=220)
        self.tree.column("Size", width=70)
        self.tree.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.tree.bind("<Double-1>", self.view)

        self.detail = scrolledtext.ScrolledText(self.main_frame, height=10)
        self.detail.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        self.detail.config(state="disabled")
        self.main_frame.rowconfigure(2, weight=1)

        log.register(self.refresh)
        self.refresh()

    def destroy(self):
        log.unregister(self.refresh)
        super().destroy()


    def _entries(self):
        f = self.filter.get().strip().lower()
        out = []
        for i, e in enumerate(log.snapshot()):
            if f and f not in str(e.get("url") or "").lower():
                continue
            out.append((i, e))
        return out

    def refresh(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
        if threading.current_thread() is not threading.main_thread():
            self.after(0, self.refresh)
            return
        self.tree.delete(*self.tree.get_children())
        for i, e in self._entries():
            p = urlparse(e.get("url", ""))
            size = len(e.get("resp_body", "") or "")
            self.tree.insert("", "end", iid=str(i), values=(
                i, e.get("method", ""), e.get("status", "ERR"),
                p.netloc, p.path or "/", size))

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        i = int(sel[0])
        try:
            return log.snapshot()[i]
        except Exception:
            return None

    def view(self, event=None):
        e = self._selected()
        if not e:
            return
        txt = f"{e.get('method')} {e.get('url')}\n"
        if e.get("error"):
            txt += f"[ERROR] {e['error']}\n"
        else:
            txt += f"HTTP/1.1 {e.get('status') or 'ERR'}\n"
            for k, v in (e.get("req_headers") or {}).items():
                txt += f"{k}: {v}\n"
            txt += f"\n{e.get('req_body') or ''}\n"
            txt += f"\n--- RESPONSE ({e.get('status') or 'ERR'}) ---\n"
            for k, v in (e.get("resp_headers") or {}).items():
                txt += f"{k}: {v}\n"
            txt += f"\n{e.get('resp_body') or ''}\n"
        self.detail.config(state="normal")
        self.detail.delete("1.0", "end")
        self.detail.insert("1.0", txt)
        self.detail.config(state="disabled")

    def to_repeater(self):
        e = self._selected()
        if not e:
            messagebox.showinfo("Info", "Select a request first.")
            return
        if self.on_send_to_repeater:
            self.on_send_to_repeater(e)
        else:
            messagebox.showinfo("Info", "Repeater not available.")

    def to_ai(self):
        e = self._selected()
        if not e:
            messagebox.showinfo("Info", "Select a request first.")
            return
        if self.on_send_to_ai:
            self.on_send_to_ai(e)
        else:
            messagebox.showinfo("Info", "AI Analyst not available.")
