"""Internet access for MITMPro's AI.

Provides real, verified information retrieval so the assistant can answer with
current facts instead of guessing:
  * search(query)      — best-effort web search (DuckDuckGo HTML, then Bing).
  * fetch_url(url)     — downloads a page and returns clean readable text.

Outbound requests respect HTTP(S)_PROXY environment variables. This module is
only used when the operator enables "Internet" in the toolbar (off by default,
to preserve the product's private-by-default posture). All AI *inference* stays
local; only research/verification traffic leaves the machine, and only on demand.
"""
import re
import html as html_mod
import requests
import socket
import ipaddress
import urllib.parse
import logging

logger = logging.getLogger(__name__)

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/124.0 Safari/537.36")


def _session():
    s = requests.Session()
    s.headers.update({"User-Agent": UA, "Accept-Language": "en-US,en;q=0.9"})
    return s


def is_safe_url(url):
    """Prevent SSRF by blocking internal/private IP addresses."""
    try:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        
        hostname = parsed.hostname
        if not hostname:
            return False
            
        # Check for localhost and common internal hostnames
        if hostname.lower() in ("localhost", "localhost.localdomain", "127.0.0.1", "::1"):
            return False
            
        # Resolve hostname to IP
        try:
            ip = socket.gethostbyname(hostname)
        except socket.gaierror:
            return False
            
        ip_obj = ipaddress.ip_address(ip)
        
        # Block private, loopback, link-local, multicast, and reserved addresses
        return not (ip_obj.is_private or ip_obj.is_loopback or 
                    ip_obj.is_link_local or ip_obj.is_multicast or 
                    ip_obj.is_reserved or ip_obj.is_unspecified)
    except Exception as e:
        logger.warning(f"SSRF check failed for {url}: {e}")
        return False


def _clean(html_text):
    html_text = re.sub(r"(?is)<script.*?</script>", " ", html_text)
    html_text = re.sub(r"(?is)<style.*?</style>", " ", html_text)
    html_text = re.sub(r"(?is)<head.*?</head>", " ", html_text)
    html_text = re.sub(r"(?s)<[^>]+>", " ", html_text)
    html_text = html_mod.unescape(html_text)
    html_text = re.sub(r"[ \t]+", " ", html_text)
    html_text = re.sub(r"\n\s*\n+", "\n", html_text)
    return html_text.strip()


def fetch_url(url, max_chars=9000):
    if not is_safe_url(url):
        return f"[FETCH ERROR {url}: Access to internal/private resources is blocked for security reasons.]"
    try:
        r = _session().get(url, timeout=25, verify=True, allow_redirects=True)
        text = _clean(r.text)
        return f"[FETCH {r.status_code} {url}]\n{text[:max_chars]}"
    except Exception as e:
        logger.error(f"Fetch error for {url}: {e}")
        return f"[FETCH ERROR {url}: {e}]"


def search(query, max_results=5):
    q = query.strip()
    if re.match(r"^https?://", q):
        return fetch_url(q)
    results = []
    # 1) DuckDuckGo HTML
    try:
        r = _session().post("https://html.duckduckgo.com/html/",
                            data={"q": q}, timeout=20)
        links = re.findall(r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                           r.text, re.S)
        snippets = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', r.text, re.S)
        for i, (href, title) in enumerate(links[:max_results]):
            href = re.sub(r"^/l/\?uddg=", "", href)
            try:
                href = urllib.parse.unquote(href.split("?")[0])
            except (ValueError, TypeError):
                pass
            snip = re.sub(r"<[^>]+>", "", snippets[i]) if i < len(snippets) else ""
            results.append((re.sub(r"<[^>]+>", "", title), href, snip))
    except requests.RequestException as e:
        logger.warning(f"DuckDuckGo search failed: {e}")
        # Silent fallback to Bing if DuckDuckGo fails
        pass
    # 2) Bing fallback
    if not results:
        try:
            r = _session().get("https://www.bing.com/search",
                               params={"q": q}, timeout=20)
            blocks = re.findall(r'<li class="b_algo".*?</li>', r.text, re.S)
            for b in blocks[:max_results]:
                t = re.search(r"<h2>(.*?)</h2>", b, re.S)
                u = re.search(r'<a href="([^"]+)"', b)
                s = re.search(r'<p[^>]*>(.*?)</p>', b, re.S)
                title = re.sub(r"<[^>]+>", "", t.group(1)) if t else ""
                url = u.group(1) if u else ""
                snip = re.sub(r"<[^>]+>", "", s.group(1)) if s else ""
                if url:
                    results.append((title, url, snip))
        except requests.RequestException as e:
            logger.warning(f"Bing search failed: {e}")
            # Silent fallback if Bing search fails
            pass
    if not results:
        return f"[SEARCH: no results for '{q}']"
    out = [f"[SEARCH RESULTS for '{q}']"]
    for i, (title, url, snip) in enumerate(results, 1):
        out.append(f"{i}. {title}\n   {url}\n   {snip}")
    return "\n".join(out)


def run_tool(text):
    """Fulfil a <<WEB:...>> or <<FETCH:url>> instruction from the model."""
    m = re.search(r"<<FETCH:\s*(https?://\S+)\s*>>", text)
    if m:
        return fetch_url(m.group(1))
    m = re.search(r"<<WEB:\s*(.*?)\s*>>", text, re.S)
    if m:
        return search(m.group(1))
    return None
