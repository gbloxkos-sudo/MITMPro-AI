"""Passive Network Information Scanner (PNIS) - Passive reconnaissance module.

Provides passive scanning capabilities for network reconnaissance:
  - DNS enumeration
  - SSL certificate analysis
  - WHOIS lookups
  - Subdomain discovery
  - Technology fingerprinting
  - Port scanning (SYN, Connect)
"""

import re
import json

def is_valid_hostname(hostname):
    """Validate a hostname or IP address."""
    if not hostname:
        return False
    # Simple regex for hostnames and IP addresses
    pattern = re.compile(r'^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])(\.([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]))*$|^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')
    return bool(pattern.match(hostname))

import time
import socket
import threading
import subprocess
import urllib.request
import urllib.parse
import ssl
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed


class PassiveScanner:
    """Passive network scanner for reconnaissance."""
    
    def __init__(self, target, threads=10, timeout=10):
        if not is_valid_hostname(target):
            raise ValueError(f"Invalid target: {target}")
        self.target = target

        self.threads = threads
        self.timeout = timeout
        self.results = {}
        self._lock = threading.Lock()
        
    def scan(self):
        """Run all passive scans."""
        print(f"[*] Starting passive scan on {self.target}")
        
        # DNS enumeration
        self.results['dns'] = self._dns_enumeration()
        
        # SSL certificate analysis
        self.results['ssl'] = self._ssl_analysis()
        
        # WHOIS lookup
        self.results['whois'] = self._whois_lookup()
        
        # Subdomain discovery
        self.results['subdomains'] = self._subdomain_discovery()
        
        # Technology fingerprinting
        self.results['tech'] = self._tech_fingerprint()
        
        # Port scan
        self.results['ports'] = self._port_scan()
        
        return self.results
    
    def _dns_enumeration(self):
        """Enumerate DNS records."""
        records = {}
        # Strict allowlist for rtypes to prevent injection
        allowed_record_types = {'A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA'}
        
        for rtype in allowed_record_types:
            try:
                result = subprocess.run(
                    ['dig', '+short', self.target, rtype],
                    capture_output=True, text=True, timeout=self.timeout
                )
                if result.stdout.strip():
                    records[rtype] = result.stdout.strip().split('\n')
            except Exception:
                pass
        return records
    
    def _ssl_analysis(self):
        """Analyze SSL certificate."""
        try:
            context = ssl.create_default_context()
            with socket.create_connection((self.target, 443), timeout=self.timeout) as sock:
                with context.wrap_socket(sock, server_hostname=self.target) as ssock:
                    cert = ssock.getpeercert()
                    return {
                        'subject': dict(x[0] for x in cert.get('subject', [])),
                        'issuer': dict(x[0] for x in cert.get('issuer', [])),
                        'version': cert.get('version'),
                        'serial_number': cert.get('serialNumber'),
                        'not_before': cert.get('notBefore'),
                        'not_after': cert.get('notAfter'),
                        'san': cert.get('subjectAltName', []),
                    }
        except Exception as e:
            return {'error': str(e)}
    
    def _whois_lookup(self):
        """Perform WHOIS lookup."""
        try:
            # Use -- to signal end of options for whois
            result = subprocess.run(
                ['whois', '--', self.target],
                capture_output=True, text=True, timeout=self.timeout
            )
            return result.stdout[:5000]  # Limit output
        except Exception as e:
            return {'error': str(e)}
    
    def _subdomain_discovery(self):
        """Discover subdomains using common sources."""
        subdomains = set()
        common_subs = [
            'www', 'mail', 'ftp', 'admin', 'test', 'dev', 'staging', 'api',
            'blog', 'shop', 'app', 'portal', 'vpn', 'remote', 'webmail',
            'owa', 'autodiscover', 'cpanel', 'whm', 'phpmyadmin', 'db',
            'mysql', 'postgres', 'redis', 'mongo', 'jenkins', 'gitlab',
            'github', 'git', 'svn', 'jira', 'confluence', 'wiki'
        ]
        
        def check_subdomain(sub):
            try:
                socket.gethostbyname(f"{sub}.{self.target}")
                return f"{sub}.{self.target}"
            except Exception:
                return None
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(check_subdomain, sub): sub for sub in common_subs}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    subdomains.add(result)
        
        return list(subdomains)
    
    def _tech_fingerprint(self):
        """Fingerprint web technologies."""
        tech = {}
        try:
            url = f"https://{self.target}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                headers = dict(response.headers)
                body = response.read().decode('utf-8', errors='ignore')
                
                # Server header
                if 'Server' in headers:
                    tech['server'] = headers['Server']
                
                # X-Powered-By
                if 'X-Powered-By' in headers:
                    tech['x-powered-by'] = headers['X-Powered-By']
                
                # Framework detection
                if 'wp-content' in body or 'wp-includes' in body:
                    tech['cms'] = 'WordPress'
                elif 'Drupal' in body or 'drupal' in body.lower():
                    tech['cms'] = 'Drupal'
                elif 'Joomla' in body:
                    tech['cms'] = 'Joomla'
                
                # JavaScript frameworks
                if 'react' in body.lower():
                    tech['js_framework'] = tech.get('js_framework', []) + ['React']
                if 'vue' in body.lower():
                    tech['js_framework'] = tech.get('js_framework', []) + ['Vue']
                if 'angular' in body.lower():
                    tech['js_framework'] = tech.get('js_framework', []) + ['Angular']
                
                # CDN detection
                if 'cloudflare' in headers.get('Server', '').lower():
                    tech['cdn'] = 'Cloudflare'
                elif 'akamai' in headers.get('Server', '').lower():
                    tech['cdn'] = 'Akamai'
                    
        except Exception as e:
            tech['error'] = str(e)
        return tech
    
    def _port_scan(self):
        """Scan common ports."""
        common_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 5432, 8080, 8443]
        open_ports = []
        
        def check_port(port):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                result = sock.connect_ex((self.target, port))
                sock.close()
                if result == 0:
                    return port
            except Exception:
                pass
            return None
        
        with ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(check_port, port): port for port in common_ports}
            for future in as_completed(futures):
                result = future.result()
                if result:
                    open_ports.append(result)
        
        return sorted(open_ports)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Passive Network Information Scanner')
    parser.add_argument('target', help='Target domain or IP')
    parser.add_argument('-t', '--threads', type=int, default=10, help='Number of threads')
    parser.add_argument('-o', '--output', help='Output file (JSON)')
    parser.add_argument('--timeout', type=int, default=10, help='Timeout in seconds')
    
    args = parser.parse_args()
    
    scanner = PassiveScanner(args.target, threads=args.threads, timeout=args.timeout)
    results = scanner.scan()
    
    print(json.dumps(results, indent=2, default=str))
    
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        print(f"\n[*] Results saved to {args.output}")


if __name__ == '__main__':
    main()