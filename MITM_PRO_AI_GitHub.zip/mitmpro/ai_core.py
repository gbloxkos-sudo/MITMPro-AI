"""Central AI engine for MITMPro.

Provides a single, robust path for every AI feature in the suite:
  * streaming chat to the local Ollama service,
  * self-healing (retry + automatic model fallback if a call fails),
  * anti-hallucination grounding (answers are bound to the real MITMPro
    tool documentation supplied as context),
  * a local learning memory (verified Q&A pairs are stored and reused so
    the assistant stays consistent and improves over time).

No data ever leaves the machine: this module only talks to
http://127.0.0.1:11434 (the local Ollama API).
"""
import os
import json
import time
import urllib.request
import urllib.parse
import urllib.error
import random
import threading
import socket

from mitmpro import common
from mitmpro.knowledge import APP_KNOWLEDGE
from mitmpro import rag
from mitmpro import system_context
from mitmpro import logger
from mitmpro import ai_learn


OLLAMA_URL = "http://127.0.0.1:11434/api/chat"

# The base URL can be overridden at runtime (e.g. via the Host field in the
# AI Assistant panel) so a remote Ollama instance is reachable. Defaults to
# the local service.
_OLLAMA_HOST = "http://127.0.0.1:11434"


def set_ollama_host(host):
    """Override the Ollama base host (e.g. 'http://192.168.1.10:11434')."""
    global _OLLAMA_HOST
    if host:
        _OLLAMA_HOST = str(host).strip().rstrip("/")


def get_ollama_host():
    return _OLLAMA_HOST


def _ollama_chat_url(host=None):
    base = (host or _OLLAMA_HOST).rstrip("/")
    return base + "/api/chat"

MEMORY_DIR = os.path.expanduser("~/.mitmpro")
MEMORY_FILE = os.path.join(MEMORY_DIR, "memory.jsonl")
ANALYTICS_FILE = os.path.join(MEMORY_DIR, "analytics.json")
TOOL_TRACK_FILE = os.path.join(MEMORY_DIR, "tool_usage.json")

_SUMMARY_THRESHOLD = 20
_SUMMARY_TRIGGERED = False
_summary_triggered_lock = threading.Lock()
_analytics_lock = threading.Lock()
_tool_lock = threading.Lock()
_cot_lock = threading.Lock()


def _ensure_memory():
    try:
        os.makedirs(MEMORY_DIR, exist_ok=True)
    except OSError as e:
        logger.log_exception(e, "creating memory directory")


def remember(question, answer, context):
    """Persist a verified Q&A pair for later self-learning / consistency."""
    try:
        _ensure_memory()
        with open(MEMORY_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "t": time.time(),
                "q": question,
                "a": answer,
                "ctx": context,
            }, ensure_ascii=False) + "\n")
    except (OSError, IOError) as e:
        logger.log_exception(e, "persisting memory (remember)")


def recall(question, context=None, limit=3):
    """Return the most relevant past Q&A pairs (simple lexical overlap)."""
    try:
        if not os.path.isfile(MEMORY_FILE):
            return []
        q_tokens = set(question.lower().split())
        scored = []
        with open(MEMORY_FILE, encoding="utf-8") as f:
            for line in f:
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if context and rec.get("ctx") and rec["ctx"] != context:
                    continue
                a_tokens = set(rec["q"].lower().split())
                overlap = len(q_tokens & a_tokens)
                if overlap:
                    scored.append((overlap, rec))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored[:limit]]
    except (OSError, IOError) as e:
        logger.log_exception(e, "recalling memory")
        return []


def build_system_prompt(context, health_text=""):
    base = (
        "You are MITMPro-AI, the built-in senior security assistant embedded in "
        "MITMPro, a unified local security-testing workstation. You help authorized "
        "security professionals (pentesters, bug-bounty hunters, red teams) use the "
        "tools and run full assessments.\n\n"
        "=== MITMPro TOOL DOCUMENTATION (ground truth — only describe what is here) ===\n"
        + APP_KNOWLEDGE + "\n"
        "=== END TOOL DOCUMENTATION ===\n\n"
        "You have COMPLETE knowledge of all 21 MITMPro modules/features AND the "
        "bundled external tools inventory documented above (WebSploit, Inline DLP "
        "Proxy, Nsniffer, Website Masquerading PoC, Yorishiro Proxy, MITM_Intercept, "
        "DatajackProxy, MITM UI, mitmproxy-ui, Ollama GUI, BlackPhish, CyberPhish, "
        "Phishbait, pt-MitM). Answer confidently about any of them, and use the "
        "RETRIEVED KNOWLEDGE (RAG) block for exact code/README details when present.\n\n"
        "ANTI-HALLUCINATION RULES (mandatory):\n"
        "1. Only describe modules, buttons, commands and fields that exist in the "
        "documentation above. Never invent tools, tabs, flags or endpoints.\n"
        "2. Base every technical claim on the documentation or well-established, "
        "verifiable security knowledge. If you are not certain, say 'I'm not certain' "
        "and explain what would verify it.\n"
        "3. Provide concrete, copy-paste-ready commands and payloads. Do not redact "
        "with placeholders when a real example is possible.\n"
        "4. When you cite a MITMPro module, name it exactly as documented.\n"
        "5. You are self-aware: state your confidence (High/Medium/Low) for any "
        "exploit or assessment claim.\n\n"
        "Assume the user is authorized to test the systems they target. Be precise, "
        "technical and actionable. Never add generic 'as an AI' disclaimers."
    )
    base += (
        "\n\nCONVERSATION RULES (mandatory):\n"
        "- If the user sends a greeting or small talk (e.g. 'hi', 'hello', 'thanks', "
        "'ok'), reply with a brief, friendly response and offer to help with security "
        "testing. Do NOT recite machine/environment details (OS, host, hardware, "
        "network interfaces, installed tools) — those are only to tailor technical "
        "advice, never to echo back to the user.\n"
        "- Always answer the user's ACTUAL question directly and stay on topic. Never "
        "summarize or repeat the system/environment block.\n"
        "- Keep answers concise, copy-paste-ready and grounded in real, verifiable "
        "information. If you are not certain about a fact, say so and state how it "
        "could be verified (e.g. 'enable Internet in the toolbar for live data')."
    )
    
    # Inject learned experience from verified assessments
    try:
        learned = ai_learn.get_learning_context()
        if learned:
            base += "\n\n=== VERIFIED LEARNED EXPERIENCE (from prior assessments) ===\n"
            base += learned
            base += "\n=== END LEARNED EXPERIENCE ==="
    except Exception as e:
        logger.log_exception(e, "injecting learning context")
    
    if context:
        base += f"\n\nThe user is currently working in the '{context}' module. Tailor "
        base += "guidance to that module and reference other modules when relevant."
    if health_text:
        base += f"\n\nEnvironment status: {health_text}"
    return base


def _load_tool_usage():
    try:
        if os.path.isfile(TOOL_TRACK_FILE):
            with open(TOOL_TRACK_FILE, encoding="utf-8") as f:
                return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        logger.log_exception(e, "loading tool usage")
    return {}


def _save_tool_usage(data):
    try:
        _ensure_memory()
        with _tool_lock:
            with open(TOOL_TRACK_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f)
    except (OSError, IOError) as e:
        logger.log_exception(e, "saving tool usage")


def _track_tool_mentions(text):
    modules = {"proxy", "repeater", "intruder", "waf", "scope", "macro",
               "oast", "logger", "traffic", "websploit", "burp", "dlp",
               "analysis", "autorun", "masquerading", "nsniffer",
               "network", "sslstrip", "campaigns", "email",
               "arp", "dns", "sniffer", "phishing", "email_engineer"}
    tokens = text.lower().split()
    usage = _load_tool_usage()
    for mod in modules:
        count = sum(1 for t in tokens if mod in t)
        if count:
            usage[mod] = usage.get(mod, 0) + count
    _save_tool_usage(usage)


def _freq_boost():
    usage = _load_tool_usage()
    if not usage:
        return ""
    sorted_mods = sorted(usage, key=usage.get, reverse=True)[:5]
    return ("Based on your history, these modules are most relevant: "
            + ", ".join(sorted_mods) + ".")


def _load_analytics():
    try:
        if os.path.isfile(ANALYTICS_FILE):
            with open(ANALYTICS_FILE, encoding="utf-8") as f:
                return json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        logger.log_exception(e, "loading analytics")
    return {"total_queries": 0, "total_time": 0.0, "module_mentions": {}}


def _save_analytics(data):
    try:
        _ensure_memory()
        with _analytics_lock:
            with open(ANALYTICS_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f)
    except (OSError, IOError) as e:
        logger.log_exception(e, "saving analytics")


def _update_analytics(elapsed, answer):
    try:
        data = _load_analytics()
        data["total_queries"] += 1
        data["total_time"] += elapsed
        modules = {"proxy", "repeater", "intruder", "waf", "scope", "macro",
                   "oast", "logger", "traffic", "websploit", "burp", "dlp",
                   "analysis", "autorun", "masquerading", "nsniffer",
                   "network", "sslstrip", "campaigns", "email"}
        for mod in modules:
            if mod in answer.lower():
                data["module_mentions"][mod] = data["module_mentions"].get(mod, 0) + 1
        _save_analytics(data)
    except (OSError, IOError) as e:
        logger.log_exception(e, "updating analytics")


def _compute_confidence(text, rag_used, model):
    score = 0
    if rag_used:
        score += 35
    if "llama" in model.lower() or "mistral" in model.lower() or "qwen" in model.lower():
        score += 15
    low_terms = ["i'm not certain", "i'm not sure", "i don't know", "unclear"]
    has_low = any(t in text.lower() for t in low_terms)
    if has_low:
        score -= 25
    mod_count = sum(1 for c in text if c == "`")
    if mod_count >= 4:
        score += 10
    if len(text) > 200:
        score += 10
    if score >= 50:
        return "High"
    if score >= 25:
        return "Medium"
    return "Low"


def _quality_check(text):
    flags = []
    placeholder_patterns = ["some_module", "your_", "example.com", "attacker.com",
                            "evil.com", "paste_", "[your ", "<your_"]
    for p in placeholder_patterns:
        if p in text.lower():
            flags.append(f"placeholder detected: '{p}'")
    common_fake = ["mitmpro-exploit", "mitmpro-scanner-pro", "proxybuster",
                   "sqlmap-pro", "burp-pro", "zap-pro"]
    for fake in common_fake:
        if fake in text.lower():
            flags.append(f"invented module: '{fake}'")
            break
    return flags


def _one_call(m, messages, on_token, timeout, cancel_event=None, host=None):
    """Single streaming request with self-healing model fallback. Returns text."""
    payload = json.dumps({
        "model": m,
        "messages": messages,
        "stream": True,
        "options": {"temperature": 0.2, "top_p": 0.9},
    }).encode()
    req = urllib.request.Request(
        _ollama_chat_url(host), data=payload,
        headers={"Content-Type": "application/json"}, method="POST")
    buf = ""
    token_buf = []
    BATCH_SIZE = 20
    BATCH_MS = 0.05
    last_flush = time.time()

    def _flush_buf():
        nonlocal last_flush
        if token_buf and on_token:
            chunk = "".join(token_buf)
            on_token(chunk)
        token_buf.clear()
        last_flush = time.time()

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            for raw in resp:
                # Check for cancellation
                if cancel_event and cancel_event.is_set():
                    break
                if not raw:
                    continue
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if "message" in data and data["message"].get("content"):
                    tok = data["message"]["content"]
                    buf += tok
                    token_buf.append(tok)
                    now = time.time()
                    if len(token_buf) >= BATCH_SIZE or (now - last_flush) >= BATCH_MS:
                        _flush_buf()
                if data.get("done"):
                    break
    except urllib.error.URLError as e:
        if hasattr(e, 'reason') and isinstance(e.reason, TimeoutError):
            raise TimeoutError(f"Request to Ollama timed out after {timeout}s. Is the model too slow or Ollama overloaded?")
        raise
    _flush_buf()
    return buf


def _call_with_fallback(model, messages, on_token, timeout, cancel_event=None, host=None):
    """Try the requested model, then fall back to any other local model.

    Uses exponential backoff with jitter between retries.
    """
    tried = []
    attempt = model
    last_err = None
    available_models = common.ollama_models()
    backoff = 1.0
    for i in range(len(available_models) + 1):
        # Check for cancellation
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Cancelled by user")
        if not attempt:
            break
        try:
            return _one_call(attempt, messages, on_token, timeout, cancel_event, host), attempt
        except Exception as e:
            tried.append(attempt)
            last_err = e
            others = [m for m in available_models if m not in tried]
            attempt = others[0] if others else None
            if i > 0:
                wait = backoff + random.random() * 0.5
                time.sleep(wait)
                backoff = min(backoff * 2, 8.0)
    raise last_err or RuntimeError("No local Ollama models could be reached. Please check if 'ollama serve' is running and models are pulled.")


def _has_tool(text):
    return "<<WEB:" in text or "<<FETCH:" in text


def _needs_cot(messages, text):
    query = ""
    for msg in reversed(messages):
        if msg["role"] == "user":
            query = msg["content"].lower()
            break
    complex_keys = ["exploit", "chain", "assessment", "pentest", "attack",
                    "vulnerability", "bypass", "escalate", "scan", "recon"]
    if any(k in query for k in complex_keys):
        return True
    if len(text) > 500:
        return True
    return False


def _augment_messages(messages, context, rag_query, use_rag,
                      use_system, internet):
    """Inject RAG context, system context, and recall into the message list."""
    augmented = list(messages)

    # Inject RAG-retrieved knowledge
    if use_rag and rag_query:
        try:
            rag_ctx = rag.retrieve_for_prompt(rag_query, k=4)
            if rag_ctx:
                augmented.insert(0, {
                    "role": "system",
                    "content": rag_ctx,
                })
        except Exception as e:
            logger.log_exception(e, "RAG retrieval")

    # Inject live system context
    if use_system:
        try:
            sys_ctx = system_context.collect(active_module=context or "MITMPro")
            if sys_ctx:
                augmented.insert(0, {
                    "role": "system",
                    "content": sys_ctx,
                })
        except Exception as e:
            logger.log_exception(e, "system context collection")

    # Inject recalled memory
    if rag_query:
        try:
            past = recall(rag_query, context, limit=2)
            if past:
                mem_block = "\n\n=== RECALLED PAST QA ===\n"
                for r in past:
                    mem_block += f"Q: {r['q']}\nA: {r['a'][:800]}\n"
                mem_block += "=== END RECALLED ==="
                augmented.insert(0, {
                    "role": "system",
                    "content": mem_block,
                })
        except Exception as e:
            logger.log_exception(e, "memory recall")

    return augmented

def _cot_phases(model, messages, on_token, timeout):
    phases = ["Reconnaissance", "Enumeration", "Exploitation", "Validation", "Reporting"]
    phase_buf = []
    for phase in phases:
        phase_msg = {
            "role": "user",
            "content": f"Now detail the {phase} phase of the assessment outlined above. Be specific and actionable."
        }
        try:
            text = _one_call(model, messages + [phase_msg], on_token, timeout)
            phase_buf.append(text)
        except Exception as e:
            logger.log_exception(e, "CoT phase execution")
            break
    return "\n".join(phase_buf)



def _summarize_messages(messages):
    non_system = [m for m in messages if m["role"] != "system"]
    sys_msgs = [m for m in messages if m["role"] == "system"]
    if len(non_system) <= _SUMMARY_THRESHOLD * 2:
        return messages
    mid = len(non_system) // 2
    older = non_system[:mid]
    newer = non_system[mid:]
    summary_lines = []
    for m in older:
        role = m["role"]
        text = m["content"][:200].replace("\n", " ")
        summary_lines.append(f"[{role}] {text}")
    summary_block = "=== COMPRESSED HISTORY ===\n" + "\n".join(summary_lines) + "\n=== END ==="
    return sys_msgs + [{"role": "system", "content": summary_block}] + newer


def stream_chat(model, messages, on_token=None, on_done=None, on_error=None,
                timeout=120, verify=True, context=None, rag_query=None,
                use_rag=True, use_system=True, internet=None, cancel_event=None,
                host=None):
    if internet is None:
        internet = common.INTERNET_ENABLED

    if not model:
        model = common.SELECTED_MODEL or (common.ollama_models() or [None])[0]
    if not model:
        msg = ("[AI unavailable] No Ollama model is selected. Click 'Start Ollama' "
                "(or run 'ollama serve' in a terminal) and pull a model "
                "(e.g. `ollama pull llama3.2:1b`), then press 'Refresh Models'. "
                "All MITMPro tools still work without AI.")
        if on_token:
            on_token(msg)
        if on_done:
            on_done(msg)
        return msg

    messages = _augment_messages(messages, context, rag_query, use_rag,
                                 use_system, internet)

    messages = _summarize_messages(messages)

    full = {"v": ""}
    start_time = time.time()

    def _tok(t):
        full["v"] += t
        if on_token:
            on_token(t)

    freq = _freq_boost()
    if freq and messages and messages[0]["role"] == "system":
        messages[0]["content"] += "\n\n" + freq

    try:
        text, used = _call_with_fallback(model, messages, _tok, timeout, cancel_event, host)
    except (urllib.error.URLError, json.JSONDecodeError, RuntimeError, TimeoutError,
            ConnectionError, OSError) as e:
        # Graceful offline handling: if we couldn't reach Ollama at all and nothing
        # was streamed yet, show a friendly, actionable message instead of an error
        # so the UI never appears to crash or hang.
        if not full["v"]:
            msg = ("[AI unavailable] Could not reach a local Ollama model. "
                   "Start it with 'ollama serve' (or click 'Start Ollama'), pull a "
                   "model (e.g. `ollama pull llama3.2:1b`), then press 'Refresh "
                   "Models'. All MITMPro tools still work without AI.")
            if on_token:
                on_token(msg)
            if on_done:
                on_done(msg)
            return msg
        if on_error:
            on_error(e)
        return full["v"]
    except Exception as e:
        if on_error:
            on_error(e)
        return full["v"]

    if not text:
        msg = ("[AI unavailable] No local Ollama model could be reached. Start "
               "'ollama serve' and pull a model (e.g. `ollama pull llama3.2:1b`), "
               "then Refresh Models. All MITMPro tools still work without AI.")
        if on_token:
            on_token(msg)
        if on_done:
            on_done(msg)
        return msg

    _track_tool_mentions(text)

    if internet and _has_tool(text):
        try:
            from mitmpro import web
        except ImportError:
            web = None
        if web:
            tool_res = web.run_tool(text)
        else:
            tool_res = None
        if tool_res:
            messages.append({"role": "assistant", "content": text})
            messages.append({
                "role": "user",
                "content": ("[LIVE WEB RESULT — use it to give a verified answer. "
                            "Do not repeat the tool instruction.]\n" + tool_res)})
            try:
                text2, used = _call_with_fallback(model, messages, _tok, timeout, cancel_event, host)
                if text2:
                    text = text + "\n" + text2
            except (urllib.error.URLError, json.JSONDecodeError, RuntimeError) as e:
                logger.log_exception(e, "web tool execution")
                _tok("\n[web fetch failed]\n")

    if verify and on_token is not None:
        text = _self_check(used, messages, text, on_token, host)
        # Advanced deterministic grounding + LLM logic-consistency checks.
        from mitmpro import verify as _verify
        g_flags = _verify.grounding_flags(text)
        if g_flags:
            g_tag = "\n\n[Grounding check — " + "; ".join(g_flags) + "]"
            text += g_tag
            on_token(g_tag)
        try:
            l_flags = _verify.logic_flags(used, text, host)
            if l_flags:
                l_tag = "\n[Logic check — " + "; ".join(l_flags) + "]"
                text += l_tag
                on_token(l_tag)
        except Exception:
            pass

    rag_used = bool(use_rag and rag_query)
    confidence = _compute_confidence(text, rag_used, used)
    conf_tag = f"\n\n[Confidence: {confidence}]"
    text += conf_tag

    quality_flags = _quality_check(text)
    if quality_flags:
        q_tag = "\n[Quality flags: " + "; ".join(quality_flags) + "]"
        text += q_tag

    if on_token:
        on_token(conf_tag)
        if quality_flags:
            on_token("\n" + q_tag)

    global _SUMMARY_TRIGGERED
    triggered = False
    with _summary_triggered_lock:
        if _needs_cot(messages, text) and not _SUMMARY_TRIGGERED:
            _SUMMARY_TRIGGERED = True
            triggered = True
    if triggered:
        try:
            phases_text = _cot_phases(used, messages, on_token, timeout)
            if phases_text:
                text += "\n\n--- Structured Assessment ---\n" + phases_text
        finally:
            with _summary_triggered_lock:
                _SUMMARY_TRIGGERED = False

    elapsed = time.time() - start_time
    _update_analytics(elapsed, text)

    if on_done:
        on_done(text)
    return text


def _self_check(model, messages, answer, on_token, host=None):
    """Anti-hallucination verification pass.

    Asks the model to verify the answer against the MITMPro documentation and
    flags any claim that references a non-existent tool. Keeps latency low by
    using a tight, short prompt and a shorter timeout.
    """
    try:
        probe = (
            "You are a verification checker for the MITMPro assistant. Given the "
            "MITMPro tool documentation already in context, reply in ONE line. "
            "If the answer below mentions a MITMPro module/button/command that does "
            "NOT exist in the documentation, list it as 'UNVERIFIED: <item>'. "
            "Otherwise reply 'VERIFIED'. Do not repeat the answer.\n\nANSWER:\n"
            + answer[:4000])
        payload = json.dumps({
            "model": model,
            "messages": [{"role": "user", "content": probe}],
            "stream": False,
            "options": {"temperature": 0.0},
        }).encode()
        req = urllib.request.Request(
            _ollama_chat_url(host), data=payload,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        verdict = data.get("message", {}).get("content", "").strip()
        if verdict and "VERIFIED" not in verdict.upper():
            tag = f"\n\n[AI self-check — {verdict}]"
            if on_token:
                on_token(tag)
            return answer + tag
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError, OSError) as e:
        logger.log_exception(e, "AI self-check verification")
    return answer
