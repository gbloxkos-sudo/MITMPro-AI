import re
import json
import threading
import urllib.parse
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog

import requests


from mitmpro import common
from mitmpro.ai_components import AIHelperTab

class MacroPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="Macro / Flow")
        self.add(AIHelperTab(self, "Macro / Flow"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Button(top, text="Add Step", command=self.add_step).grid(row=0, column=0)
        ttk.Button(top, text="Remove Step", command=self.remove_step).grid(row=0, column=1)
        ttk.Button(top, text="Run Sequence", command=self.run).grid(row=0, column=2, padx=4)
        ttk.Button(top, text="Save", command=self.save).grid(row=0, column=3)
        ttk.Button(top, text="Load", command=self.load).grid(row=0, column=4)

        ttk.Label(top, text="Ollama Model:").grid(row=0, column=5, padx=(10, 0))
        self.model_cb = ttk.Combobox(top, width=22, state="readonly")
        self.model_cb.grid(row=0, column=6)
        self.model_cb.bind("<<ComboboxSelected>>",
                           lambda e: common.set_model(self.model_cb.get()))
        common.register_model_listener(self._on_model_change)
        self._refresh_models()

        self.steps = ttk.Treeview(self.main_frame, columns=("Step", "Method", "URL"), show="headings", height=8)
        self.steps.heading("Step", text="Step")
        self.steps.heading("Method", text="Method")
        self.steps.heading("URL", text="URL")
        self.steps.column("Step", width=40)
        self.steps.column("Method", width=70)
        self.steps.column("URL", width=400)
        self.steps.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.steps.bind("<<TreeviewSelect>>", self.on_select)

        edit = ttk.Frame(self.main_frame)
        edit.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        edit.columnconfigure(1, weight=1)
        ttk.Label(edit, text="Method:").grid(row=0, column=0)
        self.method = ttk.Combobox(edit, values=["GET", "POST", "PUT", "DELETE", "PATCH"], width=10)
        self.method.set("GET")
        self.method.grid(row=0, column=1, sticky="w")
        ttk.Label(edit, text="URL:").grid(row=0, column=2)
        self.url = ttk.Entry(edit)
        self.url.grid(row=0, column=3, sticky="ew")
        edit.columnconfigure(3, weight=1)
        ttk.Label(edit, text="Extract regex (from resp -> var):").grid(row=1, column=0, columnspan=2, sticky="w")
        self.extract = ttk.Entry(edit)
        self.extract.grid(row=1, column=2, columnspan=2, sticky="ew")
        ttk.Label(edit, text="Body:").grid(row=2, column=0, sticky="w")
        self.body = scrolledtext.ScrolledText(edit, height=3)
        self.body.grid(row=3, column=0, columnspan=4, sticky="ew")

        self.out = scrolledtext.ScrolledText(self.main_frame, height=10)
        self.out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)
        self.out.config(state="disabled")
        self.main_frame.rowconfigure(3, weight=1)

        self._data = {}


    def _refresh_models(self):
        try:
            models = common.ollama_models()
            self.model_cb["values"] = models
            cur = common.SELECTED_MODEL
            if cur and cur in models:
                self.model_cb.set(cur)
            elif models:
                self.model_cb.set(models[0])
        except Exception:
            pass

    def _on_model_change(self, model):
        try:
            if not self.winfo_exists():
                return
            if model and self.model_cb["values"]:
                self.model_cb.set(model)
        except Exception:
            pass

    def add_step(self):
        iid = self.steps.insert("", "end", values=(len(self.steps.get_children()) + 1, self.method.get(), self.url.get() or "http://"))
        self._data[iid] = {"method": self.method.get(), "url": self.url.get(),
                           "extract": self.extract.get(), "body": self.body.get("1.0", "end").strip("\n")}

    def remove_step(self):
        sel = self.steps.selection()
        if sel:
            del self._data[sel[0]]
            self.steps.delete(sel[0])
            self._renumber()

    def _renumber(self):
        for i, iid in enumerate(self.steps.get_children(), 1):
            self.steps.set(iid, "Step", i)

    def on_select(self, event):
        sel = self.steps.selection()
        if not sel:
            return
        d = self._data.get(sel[0], {})
        self.method.set(d.get("method", "GET"))
        self.url.delete(0, "end"); self.url.insert(0, d.get("url", ""))
        self.extract.delete(0, "end"); self.extract.insert(0, d.get("extract", ""))
        self.body.delete("1.0", "end"); self.body.insert("1.0", d.get("body", ""))

    def _store_selected(self):
        sel = self.steps.selection()
        if sel:
            iid = sel[0]
            self._data[iid] = {"method": self.method.get(), "url": self.url.get(),
                               "extract": self.extract.get(), "body": self.body.get("1.0", "end").strip("\n")}
            self.steps.set(iid, "Method", self.method.get())
            self.steps.set(iid, "URL", self.url.get())

    def run(self):
        self._store_selected()
        iids = list(self.steps.get_children())
        threading.Thread(target=self._run_sequence, args=(iids,), daemon=True).start()

    def _run_sequence(self, iids):
        vars_ = {}

        def _append(text):
            self.after(0, lambda t=text: self._safe_append(t))

        def _update_out():
            self.out.config(state="normal")
            self.out.delete("1.0", "end")
            self.out.config(state="disabled")

        self.after(0, _update_out)
        for n, iid in enumerate(iids, 1):
            d = self._data.get(iid, {})
            url = self._subst(d.get("url", ""), vars_)
            body = self._subst(d.get("body", ""), vars_)
            step_text = f"\n--- Step {n} {d.get('method')} {url} ---\n"
            self.after(0, lambda t=step_text: self._safe_append(t))
            try:
                r = requests.request(d.get("method", "GET"), url, data=body, timeout=20, verify=False)
                resp_text = f"HTTP {r.status_code} ({len(r.content)} bytes)\n"
                if d.get("extract"):
                    m = re.search(d["extract"], r.text)
                    if m:
                        vars_["extract"] = m.group(1) if m.groups() else m.group(0)
                        resp_text += f"[+] extracted var 'extract' = {vars_['extract']}\n"
                if len(r.text) < 2000:
                    resp_text += r.text + "\n"
                self.after(0, lambda t=resp_text: self._safe_append(t))
            except Exception as e:
                err_text = f"[ERROR] {e}\n"
                self.after(0, lambda t=err_text: self._safe_append(t))
        def _finish():
            self.out.config(state="disabled")
        self.after(0, _finish)

    def _safe_append(self, text):
        self.out.config(state="normal")
        self.out.insert("end", text)
        self.out.see("end")
        self.out.config(state="disabled")

    def _subst(self, s, vars_):
        out = s
        for k, v in vars_.items():
            out = out.replace("{{" + k + "}}", str(v))
        return out

    def save(self):
        self._store_selected()
        p = filedialog.asksaveasfilename(defaultextension=".json")
        if p:
            data = [self._data[i] for i in self.steps.get_children()]
            with open(p, "w") as f:
                json.dump(data, f, indent=2)
            messagebox.showinfo("Saved", p)

    def load(self):
        p = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if p:
            try:
                with open(p) as f:
                    data = json.load(f)
            except (json.JSONDecodeError, OSError) as e:
                messagebox.showerror("Error", f"Failed to load plan: {e}")
                return
            if not isinstance(data, list):
                messagebox.showerror("Error", "Invalid plan format: expected a JSON list.")
                return
            for iid in self.steps.get_children():
                self.steps.delete(iid)
            self._data.clear()
            for d in data:
                iid = self.steps.insert("", "end", values=(len(self.steps.get_children()) + 1, d.get("method", "GET"), d.get("url", "")))
                self._data[iid] = d
            messagebox.showinfo("Loaded", p)
