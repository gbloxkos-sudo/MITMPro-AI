import sys
import tkinter as tk
from tkinter import ttk, messagebox
import threading

from mitmpro import common
from mitmpro.common import ensure_ollama_gui_importable, ollama_models, register_model_listener
from mitmpro.knowledge import APP_KNOWLEDGE
from mitmpro import ai_core

try:
    import urllib.request
    import urllib.parse
    import json
except Exception:
    pass


from mitmpro.ai_components import AIHelperTab

class AIPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="AI Assistant")
        self.add(AIHelperTab(self, "AI Assistant"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(1, weight=1)

        bar = ttk.Frame(self.main_frame)
        bar.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        bar.columnconfigure(1, weight=1)
        ttk.Label(bar, text="Ollama:").grid(row=0, column=0)
        self.status = ttk.Label(bar, text="checking...")
        self.status.grid(row=0, column=1, sticky="w")
        self.refresh = ttk.Button(bar, text="Refresh", command=lambda: threading.Thread(target=self.update_status, daemon=True).start())
        self.refresh.grid(row=0, column=2)
        self.open_gui = ttk.Button(bar, text="Open Standalone Ollama GUI", command=self.open_standalone)
        self.open_gui.grid(row=0, column=3)

        ttk.Label(bar, text="Model:").grid(row=0, column=6, padx=(10, 0))
        self.model = ttk.Combobox(bar, width=22, state="readonly")
        self.model.grid(row=0, column=7)
        self.model.bind("<<ComboboxSelected>>",
                        lambda e: common.set_model(self.model.get()))
        ttk.Button(bar, text="↻", width=3,
                   command=lambda: threading.Thread(target=self.load_models, daemon=True).start()).grid(row=0, column=8, padx=2)

        self.host_var = tk.StringVar(value="http://127.0.0.1:11434")
        ttk.Label(bar, text="Host:").grid(row=0, column=4)
        self.host = ttk.Entry(bar, textvariable=self.host_var, width=22)
        self.host.grid(row=0, column=5)
        self.host.bind("<FocusOut>",
                       lambda e: ai_core.set_ollama_host(self.host_var.get()))
        self.host.bind("<Return>",
                       lambda e: ai_core.set_ollama_host(self.host_var.get()))

        self.embed = ttk.Frame(self.main_frame)
        self.embed.grid(row=1, column=0, sticky="nsew", padx=4, pady=4)
        self.embed.columnconfigure(0, weight=1)
        self.embed.rowconfigure(0, weight=1)

        self.ollama_iface = None
        self.build_embed()
        self.load_models()
        register_model_listener(self._on_global_model)


    def load_models(self):
        import threading
        def _fetch():
            try:
                models = ollama_models()
            except Exception:
                models = []
            def apply():
                self.model["values"] = models
                if models:
                    self.model.set(common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0])
            try:
                self.after(0, apply)
            except Exception:
                apply()
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            try:
                if model and model not in (self.model["values"] or ()):
                    self.model["values"] = list(self.model["values"] or ()) + [model]
                if model:
                    self.model.set(model)
            except Exception as e:
                print(f"Error syncing model combobox: {e}")
            if self.ollama_iface and model:
                try:
                    if hasattr(self.ollama_iface, 'model_select'):
                        self.ollama_iface.model_select.set(model)
                except Exception as e:
                    print(f"Error setting global model on embed: {e}")
        try:
            self.after(0, apply)
        except Exception:
            pass

    def build_embed(self):
        try:
            ensure_ollama_gui_importable()
            import ollama_gui
            frame = ttk.Frame(self.embed)
            frame.grid(row=0, column=0, sticky="nsew")
            frame.columnconfigure(0, weight=1)
            frame.rowconfigure(1, weight=1)
            try:
                self.ollama_iface = ollama_gui.OllamaInterface(frame)
                self.ollama_iface.root = frame
            except Exception as e:
                self.ollama_iface = None
                message = f"Could not embed Ollama GUI: {e}"
                print(f"build_embed error: {e}")
                ttk.Label(self.embed, text=message, foreground="red").grid(row=0, column=0)
                return
        except Exception as e:
            message = f"Could not embed Ollama GUI: {e}"
            print(f"build_embed error: {e}")
            ttk.Label(self.embed, text=message, foreground="red").grid(row=0, column=0)

    def update_status(self):
        host = self.host_var.get().strip().rstrip("/")
        if not host:
            host = "http://127.0.0.1:11434"
        ai_core.set_ollama_host(host)
        try:
            with urllib.request.urlopen(urllib.parse.urljoin(host, "/api/tags"), timeout=3) as r:
                data = json.load(r)
            models = [m["name"] for m in data.get("models", [])]
            text = f"RUNNING | models: {', '.join(models) if models else 'none'}"
        except Exception as e:
            text = f"NOT REACHABLE ({e})"
        self.after(0, lambda t=text: self.status.config(text=t))

    def open_standalone(self):
        import subprocess
        try:
            subprocess.Popen([sys.executable, "ollama_gui.py"],
                             cwd=common.OLLAMA_GUI_DIR)
        except Exception as e:
            messagebox.showerror("Error", str(e))
