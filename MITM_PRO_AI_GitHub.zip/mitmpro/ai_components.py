import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
from mitmpro import common
from mitmpro.common import ollama_models, register_model_listener
from mitmpro import ai_core
from mitmpro import ai_auto_helper


class AIHelperTab(ttk.Frame):
    """A reusable AI helper interface that can be embedded as a tab in any tool.

    Every MITMPro module that subclasses ttk.Notebook should add one of these:
        self.add(AIHelperTab(self, "Module Name"), text="AI Helper")

    The tab provides:
      - Context-aware chat (the AI knows which module the user is in).
      - Streaming responses with a cancel-safe design.
      - An "Auto-Run" button that feeds the user's request to the
        AutoRunEngine so the AI can orchestrate multi-step assessments.
      - A per-tab Ollama model selector that stays synced with the global
        model (so every feature can pick its own model).
      - Persistent per-tab conversation memory (cleared on app restart).
    """

    def __init__(self, master, tool_name="MITMPro"):
        super().__init__(master)
        self.tool_name = tool_name
        self.history = []
        self._busy = False
        self._cancel_event = threading.Event()
        self._stream_thread = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        bar = ttk.Frame(self)
        bar.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        ttk.Label(bar, text=f"AI Auto Helper — {self.tool_name}").grid(
            row=0, column=0, sticky="w")
        ttk.Button(bar, text="How do I use this?",
                   command=self.explain_tool).grid(row=0, column=1, padx=5)
        ttk.Button(bar, text="Assess (checklist)", command=self.assess).grid(
            row=0, column=2, padx=5)
        ttk.Button(bar, text="\U0001f9e0 Smart Suggest", command=self.smart_suggest).grid(
            row=0, column=3, padx=5)
        ttk.Button(bar, text="\U0001f680 Auto-Run", command=self.auto_run).grid(
            row=0, column=4, padx=5)
        self.stop_btns = []
        self.stop_btns.append(ttk.Button(bar, text="Stop", command=self.stop_stream, state="disabled"))
        self.stop_btns[0].grid(row=0, column=5, padx=5)
        ttk.Button(bar, text="Clear", command=self.clear).grid(
            row=0, column=6, padx=5)

        # Per-tab Ollama model selector (synced with the global model).
        ttk.Label(bar, text="Model:").grid(row=0, column=7, padx=(8, 0))
        self.model = ttk.Combobox(bar, width=20, state="readonly")
        self.model.grid(row=0, column=8, padx=(2, 2))
        self.model.bind("<<ComboboxSelected>>",
                        lambda e: common.set_model(self.model.get()))
        ttk.Button(bar, text="\u21bb", width=3,
                   command=lambda: threading.Thread(
                       target=self.load_models, daemon=True).start()).grid(
                           row=0, column=9, padx=2)

        register_model_listener(self._on_global_model)
        self.load_models()

        # Context-aware quick-action chips
        chips = ttk.Frame(self)
        chips.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 4))
        self._build_chips(chips)

        # Chat area
        self.chat = scrolledtext.ScrolledText(
            self, state="disabled", font=("TkDefaultFont", 11))
        self.chat.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)

        # Friendly onboarding shown once per tab so beginners know what to do.
        self._show_welcome()

        # Input area
        bottom = ttk.Frame(self)
        bottom.grid(row=3, column=0, sticky="ew", padx=4, pady=4)
        bottom.columnconfigure(0, weight=1)

        self.entry = scrolledtext.ScrolledText(bottom, height=3)
        self.entry.grid(row=0, column=0, sticky="ew")
        self.entry.bind("<Control-Return>", self._on_send_event)
        self._install_placeholder()

        self.send_btn = ttk.Button(
            bottom, text="Ask AI  (Ctrl+Enter)",
            command=lambda: threading.Thread(
                target=self.send, daemon=True).start())
        self.send_btn.grid(row=0, column=1, padx=5)

        self.stop_btns.append(ttk.Button(
            bottom, text="Stop", command=self.stop_stream,
            state="disabled"))
        self.stop_btns[1].grid(row=0, column=2, padx=5)

    def _set_stop(self, state):
        for b in self.stop_btns:
            try:
                b.config(state=state)
            except Exception:
                pass

    # --------------------------------------------------- model selection
    def load_models(self):
        def _fetch():
            try:
                models = ollama_models()
            except Exception:
                models = []
            def apply():
                try:
                    self.model["values"] = models
                    if models:
                        self.model.set(
                            common.SELECTED_MODEL
                            if common.SELECTED_MODEL in models
                            else models[0])
                except Exception:
                    pass
            try:
                self.after(0, apply)
            except Exception:
                apply()
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            try:
                if model and model not in (self.model["values"] or ()):
                    self.model["values"] = list(self.model["values"] or ()) + [model]
                if model:
                    self.model.set(model)
            except Exception:
                pass
        try:
            self.after(0, apply)
        except Exception:
            pass

    # --------------------------------------------------- context-aware chips
    def _build_chips(self, parent):
        """Render module-specific quick-action chips that drive the AI."""
        actions = ai_auto_helper.get_quick_actions(self.tool_name)
        for a in actions:
            b = ttk.Button(
                parent, text=a["label"],
                command=lambda p=a["prompt"]: self._chip_send(p))
            b.pack(side="left", padx=3, pady=2)

    def _chip_send(self, prompt):
        """Send a quick-action prompt as if the user typed it."""
        if self._busy:
            return
        threading.Thread(
            target=lambda: self.send(message=prompt),
            daemon=True).start()

    # ----------------------------------------------------------- smart suggest
    def smart_suggest(self):
        """Proactively recommend the next assessment step for this module."""
        if self._busy:
            return
        rec = ai_auto_helper.smart_suggest(self.tool_name, self._live_state())
        self.append("AI Auto Helper", rec)
        # Also offer to expand it into a full plan.
        prompt = (f"Based on this recommendation: '{rec}' — give me the concrete "
                  f"next 3 steps to run inside the {self.tool_name} tool, with "
                  f"exact buttons/commands.")
        threading.Thread(
            target=lambda: self.send(message=prompt, display="[Smart Suggest]"),
            daemon=True).start()

    def _live_state(self):
        """Best-effort snapshot of live state for Smart Suggest."""
        try:
            app = self.winfo_toplevel()
            state = {}
            if hasattr(app, "scope") or hasattr(app, "autorun_engine"):
                from mitmpro import scope as _scope
                state["scope_count"] = len(getattr(_scope, "SCOPE", []))
            return state
        except Exception:
            return {}

    # -------------------------------------------------------- beginner UX
    def _show_welcome(self):
        """Plain-English intro so first-time users know exactly what to do."""
        msg = (
            f"Hi! I'm your built-in AI assistant for the '{self.tool_name}' tool.\n"
            "You don't need to be an expert — just ask in plain English.\n\n"
            "Try one of these:\n"
            f"  • \"What does the {self.tool_name} tool do?\"\n"
            "  • \"How do I use this, step by step?\"\n"
            "  • \"Give me a beginner example.\"\n\n"
            "Or click a button above:\n"
            "  • 'How do I use this?'  — a simple walkthrough of this tool\n"
            "  • 'Assess (checklist)'  — a full step-by-step testing plan\n"
            "  • '\U0001f680 Auto-Run'  — type a goal, and the AI runs the tools for you\n\n"
            "Type your question below and press 'Ask AI' (or Ctrl+Enter).")
        self.append("AI Assistant", msg)

    def _install_placeholder(self):
        self._placeholder = ("Ask anything, e.g. 'How do I use this tool?' "
                             "— then press Ask AI or Ctrl+Enter")
        self._placeholder_on = False

        def show_ph():
            if not self.entry.get("1.0", "end").strip():
                self.entry.insert("1.0", self._placeholder)
                try:
                    self.entry.config(foreground="#8b949e")
                except Exception:
                    pass
                self._placeholder_on = True

        def on_focus_in(_e):
            if self._placeholder_on:
                self.entry.delete("1.0", "end")
                try:
                    self.entry.config(foreground="#e6edf3")
                except Exception:
                    pass
                self._placeholder_on = False

        def on_focus_out(_e):
            show_ph()

        self.entry.bind("<FocusIn>", on_focus_in)
        self.entry.bind("<FocusOut>", on_focus_out)
        show_ph()

    def explain_tool(self):
        """One-click plain-English explanation of the current tool."""
        if self._busy:
            return
        prompt = (
            f"Explain the '{self.tool_name}' tool in MITMPro to a beginner in "
            f"simple language. Cover: (1) what it does in one sentence, (2) when "
            f"to use it, (3) a numbered step-by-step of how to use it in this app, "
            f"and (4) one concrete beginner example. Keep it friendly and clear.")
        threading.Thread(
            target=lambda: self.send(message=prompt,
                                     display="[How do I use this?]"),
            daemon=True).start()

    # ------------------------------------------------------------------ send
    def _on_send_event(self, event):
        threading.Thread(target=self.send, daemon=True).start()
        return "break"

    def send(self, message=None, display=None):
        if self._busy:
            return
        self._busy = True
        def _do():
            if message is None:
                if getattr(self, "_placeholder_on", False):
                    self._busy = False
                    return
                msg = self.entry.get("1.0", "end").strip()
                if not msg or msg == getattr(self, "_placeholder", None):
                    self._busy = False
                    return
                self.entry.delete("1.0", "end")
                self.append("You", msg)
                self.history.append({"role": "user", "content": msg})
            else:
                msg = message
                self.append("You", display or msg)
                self.history.append({"role": "user", "content": msg})

            model = common.SELECTED_MODEL
            if not model:
                # Fetch models in background to avoid blocking UI
                def _fetch_and_send():
                    try:
                        models = common.ollama_models()
                    except Exception:
                        models = []
                    def apply():
                        if models:
                            model = models[0]
                            common.set_model(model)
                            self._send_with_model(model, msg)
                        else:
                            self.append("AI", (
                                "No Ollama model available. Click 'Start Ollama' in the "
                                "toolbar (or run `ollama serve` in a terminal), pull a model "
                                "(e.g. `ollama pull llama3.2:1b`), then 'Refresh Models'."))
                            self._busy = False
                    self.after(0, apply)
                threading.Thread(target=_fetch_and_send, daemon=True).start()
                return

            self._send_with_model(model, msg)
        self.after(0, _do)

    def _send_with_model(self, model, msg):
        """Send message using the specified model (actual streaming logic)."""
        system_prompt = ai_core.build_system_prompt(
            self.tool_name, self._health_text())
        past = ai_core.recall(msg, self.tool_name, limit=2)
        if past:
            system_prompt += (
                "\n\n=== Prior verified answers (reuse when consistent) ===\n")
            for r in past:
                system_prompt += (
                    f"Q: {r['q']}\nA: {r['a'][:1500]}\n")
            system_prompt += "=== END PRIOR ANSWERS ===\n"

        messages = [{"role": "system", "content": system_prompt}] + self.history

        self._cancel_event = threading.Event()
        self._set_stop("normal")
        self.chat.config(state="normal")
        self.chat.insert("end", "\nAI: ")
        self.chat.see("end")
        self.chat.config(state="disabled")

        collected = {"text": ""}

        def on_token(t):
            def update():
                collected["text"] += t
                self.chat.config(state="normal")
                self.chat.insert("end", t)
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        def on_done(full):
            def update():
                self._busy = False
                self._set_stop("disabled")
                self.history.append({"role": "assistant", "content": full})
                ai_core.remember(msg, full, self.tool_name)
            self.after(0, update)

        def on_error(e):
            def update():
                self._busy = False
                self._set_stop("disabled")
                err_text = str(e)
                if "urlopen" in err_text or "Connection refused" in err_text:
                    err_text = (
                        "Cannot reach Ollama. Make sure 'ollama serve' is "
                        "running (or click 'Start Ollama' in the toolbar).")
                self.chat.config(state="normal")
                self.chat.insert("end", f"\n[error: {err_text}]")
                self.chat.see("end")
                self.chat.config(state="disabled")
            self.after(0, update)

        threading.Thread(
            target=ai_core.stream_chat,
            args=(model, messages),
            kwargs={
                "on_token": on_token,
                "on_done": on_done,
                "on_error": on_error,
                "context": self.tool_name,
                "rag_query": msg,
                "cancel_event": self._cancel_event,
            },
            daemon=True,
        ).start()

    # ---------------------------------------------------------------- assess
    def assess(self):
        if self._busy:
            return
        prompt = (
            f"Produce a complete, phased security assessment methodology / "
            f"checklist for the '{self.tool_name}' module in MITMPro. Cover "
            f"recon, enumeration, exploitation, validation, and reporting. "
            f"Include concrete commands, tool usage, and example payloads.")
        threading.Thread(
            target=lambda: self.send(message=prompt,
                                     display="[Assessment Checklist]"),
            daemon=True).start()

    # --------------------------------------------------------------- auto_run
    def auto_run(self):
        msg = self.entry.get("1.0", "end").strip()
        if not msg:
            self.append("System", (
                "Enter a goal in the text area first, then click Auto-Run.\n"
                "Example: 'Scan target.example.com for XSS and try WAF bypass'"))
            return

        app = self.winfo_toplevel()
        if not hasattr(app, "autorun_engine"):
            self.append("System", "AutoRun Engine not found.")
            return

        self.append("System", f"Submitting to AutoRun Engine: {msg}")
        def _run():
            result = app.autorun_engine.execute_goal(
                msg, context=self.tool_name)
            self.after(0, lambda r=result: self.append("System", r))
        threading.Thread(target=_run, daemon=True).start()

    # ----------------------------------------------------------------- clear
    def clear(self):
        self.history = []
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")

    def stop_stream(self):
        """Stop the currently streaming AI response."""
        if hasattr(self, '_cancel_event') and self._cancel_event:
            self._cancel_event.set()
        self._set_stop("disabled")

    # ----------------------------------------------------------------- append
    def append(self, who, text):
        self.chat.config(state="normal")
        self.chat.insert("end", f"\n=== {who} ===\n{text}\n")
        self.chat.see("end")
        self.chat.config(state="disabled")

    # ---------------------------------------------------------------- health
    def _health_text(self):
        try:
            app = self.winfo_toplevel()
            if hasattr(app, "_health_text"):
                return app._health_text()
        except Exception:
            pass
        net = "Internet ON" if common.INTERNET_ENABLED else "Internet OFF"
        if common.ollama_running():
            return (
                f"Ollama RUNNING | model "
                f"{common.SELECTED_MODEL or 'none'} | {net}")
        return f"Ollama OFFLINE | {net}"
