import time
import threading
import functools

MAX_ENTRIES = 1000
MAX_BODY = 20000


class TrafficLog:
    def __init__(self):
        self._entries = []
        self._lock = threading.Lock()
        self._listeners = []
        self._listeners_lock = threading.Lock()

    def add(self, rec):
        with self._lock:
            rec.setdefault("time", time.time())
            self._entries.append(rec)
            if len(self._entries) > MAX_ENTRIES:
                self._entries.pop(0)
        with self._listeners_lock:
            listeners = list(self._listeners)
        for fn in listeners:
            try:
                fn()
            except Exception as e:
                print(f"TrafficLog listener error: {e}")

    def register(self, fn):
        with self._listeners_lock:
            if fn not in self._listeners:
                self._listeners.append(fn)

    def unregister(self, fn):
        with self._listeners_lock:
            if fn in self._listeners:
                self._listeners.remove(fn)

    def snapshot(self):
        with self._lock:
            return list(self._entries)

    def clear(self):
        with self._lock:
            self._entries.clear()
        with self._listeners_lock:
            listeners = list(self._listeners)
        for fn in listeners:
            try:
                fn()
            except Exception as e:
                print(f"TrafficLog clear listener error: {e}")


log = TrafficLog()


def _truncate(b):
    if b is None:
        return ""
    if isinstance(b, bytes):
        try:
            b = b.decode("utf-8", "replace")
        except Exception:
            b = repr(b[:MAX_BODY])
    if len(b) > MAX_BODY:
        return b[:MAX_BODY] + "\n...[truncated]"
    return b


_INSTALLED = False


def install_hook():
    """Monkey-patch the global ``requests`` module so every HTTP request the
    suite sends (Repeater, Intruder, Scanner, Macro, Web research) is recorded
    in the live HTTP History log. Safe to call multiple times (idempotent)."""
    global _INSTALLED
    if _INSTALLED:
        return
    import requests

    orig_request = requests.request

    def wrapped(method, url, **kwargs):
        rec = {
            "method": str(method).upper(),
            "url": str(url),
            "req_headers": dict(kwargs.get("headers") or {}),
            "req_body": _truncate(kwargs.get("data") or kwargs.get("json")),
            "status": None,
            "resp_headers": {},
            "resp_body": "",
            "error": None,
        }
        try:
            r = orig_request(method, url, **kwargs)
            rec["status"] = r.status_code
            rec["resp_headers"] = dict(r.headers)
            rec["resp_body"] = _truncate(r.content)
            return r
        except Exception as e:
            rec["error"] = str(e)
            raise
        finally:
            log.add(rec)

    requests.request = wrapped
    for verb in ("get", "post", "put", "delete", "patch", "head", "options"):
        orig = getattr(requests, verb, None)
        if orig is not None:
            # functools.partial fixes the verb; the real URL is the first
            # positional/keyword argument passed by callers (the previous lambda
            # accidentally bound the URL to the verb slot, breaking every call).
            setattr(requests, verb, functools.partial(wrapped, verb))

    # Also capture traffic that goes through urllib.request.urlopen directly
    # (e.g. the passive/network scanner), so it shows up in HTTP History too.
    import urllib.request
    _orig_urlopen = urllib.request.urlopen

    def wrapped_urlopen(url, *args, **kwargs):
        target = url
        if not isinstance(target, str):
            target = getattr(target, "full_url", str(target))
        rec = {
            "method": "GET",
            "url": str(target),
            "req_headers": {},
            "req_body": "",
            "status": None,
            "resp_headers": {},
            "resp_body": "",
            "error": None,
        }
        try:
            return _orig_urlopen(url, *args, **kwargs)
        except Exception as e:
            rec["error"] = str(e)
            raise
        finally:
            log.add(rec)

    urllib.request.urlopen = wrapped_urlopen
    _INSTALLED = True
