import threading
import subprocess
import os
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
from mitmpro import common
from mitmpro.ai_components import AIHelperTab

class DLPPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        self.project_dir = os.path.join(common.PROJECT_ROOT, "mitm_tools", "inline-dlp-proxy-main")
        self.manage_script = os.path.join(self.project_dir, "scripts/manage-proxy.sh")
        self.rules_file = os.path.join(self.project_dir, "rules/dlp_patterns.json")
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="DLP Proxy Control")
        self.add(AIHelperTab(self, "Inline DLP Proxy"), text="AI Helper")
        
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(2, weight=1)

        # Control bar
        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        ttk.Button(top, text="Start Proxy", command=lambda: self.run_manage("start")).grid(row=0, column=0, padx=5)
        ttk.Button(top, text="Stop Proxy", command=lambda: self.run_manage("stop")).grid(row=0, column=1, padx=5)
        ttk.Button(top, text="Restart", command=lambda: self.run_manage("restart")).grid(row=0, column=2, padx=5)
        ttk.Button(top, text="Status", command=lambda: self.run_manage("status")).grid(row=0, column=3, padx=5)
        ttk.Button(top, text="Edit Rules", command=self.edit_rules).grid(row=0, column=4, padx=5)
        ttk.Button(top, text="View Alerts", command=self.view_alerts).grid(row=0, column=5, padx=5)

        # Info bar
        info = ttk.LabelFrame(self.main_frame, text="Engine Info")
        info.grid(row=1, column=0, sticky="ew", padx=4, pady=4)
        info.columnconfigure(0, weight=1)
        self.info_text = ttk.Label(info, text="Proxy Status: Unknown | Admin: http://localhost:9901 | Dashboard: http://localhost:3000")
        self.info_text.grid(row=0, column=0, sticky="w", padx=4, pady=4)

        # Console output
        self.out = scrolledtext.ScrolledText(self.main_frame, height=15, bg="black", fg="lightgreen", font=("Courier", 10))
        self.out.grid(row=2, column=0, sticky="nsew", padx=4, pady=4)
        self.out.config(state="disabled")
        self.main_frame.rowconfigure(2, weight=1)

    def run_manage(self, cmd=None, **kwargs):
        if cmd is None:
            return
        if not os.path.isfile(self.manage_script):
            self._append_output(f"\n[!] DLP management script not found at: {self.manage_script}\n")
            self._append_output("[*] Ensure the inline-dlp-proxy tool is installed in mitm_tools/.\n")
            return
        if not os.access(self.manage_script, os.X_OK):
            full_cmd = ["/bin/bash", self.manage_script, cmd]
        else:
            full_cmd = [self.manage_script, cmd]
        threading.Thread(target=self._execute, args=(full_cmd,), daemon=True).start()

    def _execute(self, cmd):
        try:
            self.after(0, lambda: self._append_output(f"\nExecuting: {' '.join(cmd)}\n" + "-"*40 + "\n"))
            
            process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
            )
            for line in process.stdout:
                self.after(0, self._append_output, line)
            process.wait()
            self.after(0, self._append_output, f"\n[Process exited with code {process.returncode}]\n")
        except Exception as e:
            self.after(0, self._append_output, f"\n[Error: {e}]\n")

    def _append_output(self, text):
        self.out.config(state="normal")
        self.out.insert("end", text)
        self.out.see("end")
        self.out.config(state="disabled")

    def edit_rules(self):
        if not os.path.isfile(self.rules_file):
            messagebox.showinfo("Info", f"DLP rules file not found at:\n{self.rules_file}\n\nEnsure the inline-dlp-proxy tool is installed.")
            return
        try:
            import platform
            if platform.system() == "Linux":
                subprocess.Popen(["xdg-open", self.rules_file])
            elif platform.system() == "Darwin":
                subprocess.Popen(["open", self.rules_file])
            elif platform.system() == "Windows":
                subprocess.Popen(["cmd", "/c", "start", "", self.rules_file])
        except Exception as e:
            messagebox.showerror("Error", f"Could not open rules file: {e}")

    def view_alerts(self):
        alerts_path = os.path.join(self.project_dir, "logs/dlp_alerts.log")
        if not os.path.isfile(alerts_path):
            messagebox.showinfo("Info", "No DLP alerts found yet.")
            return
        
        try:
            with open(alerts_path, "r") as f:
                content = f.read()
            
            alert_win = tk.Toplevel(self)
            alert_win.title("DLP Alerts")
            alert_win.geometry("800x600")
            txt = scrolledtext.ScrolledText(alert_win, font=("Courier", 10))
            txt.pack(expand=True, fill="both")
            txt.insert("1.0", content)
            txt.config(state="disabled")
        except Exception as e:
            messagebox.showerror("Error", f"Could not read alerts: {e}")
