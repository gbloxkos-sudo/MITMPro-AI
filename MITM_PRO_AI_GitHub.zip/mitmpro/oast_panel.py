import socket
import threading
import uuid
import json
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

from mitmpro import common

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")


class _Handler(BaseHTTPRequestHandler):
    server_version = "MITMPro-OAST/1.0"

    def _log(self):
        body = b""
        try:
            length = int(self.headers.get("Content-Length", 0) or 0)
        except (ValueError, TypeError):
            length = 0
        if length:
            body = self.rfile.read(length)
        try:
            body = body.decode("utf-8", "replace")
        except Exception:
            body = repr(body[:2000])
        rec = {
            "client": self.client_address[0],
            "method": self.command,
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        }
        self.server.owner._incoming_lock.acquire()
        try:
            self.server.owner._incoming.append(rec)
        finally:
            self.server.owner._incoming_lock.release()
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"ok")
        except Exception:
            pass

    def do_GET(self):
        self._log()

    def do_POST(self):
        self._log()

    def do_PUT(self):
        self._log()

    def log_message(self, *args):
        pass


from mitmpro.ai_components import AIHelperTab

class OASTPanel(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        
        self.main_frame = ttk.Frame(self)
        self.add(self.main_frame, text="OAST Listener")
        self.add(AIHelperTab(self, "OAST / DNS"), text="AI Helper")
        
        self._incoming = []
        self._incoming_lock = threading.Lock()
        self._shown = 0
        self._server = None
        self._thread = None
        self.main_frame.columnconfigure(0, weight=1)
        self.main_frame.rowconfigure(3, weight=1)

        top = ttk.Frame(self.main_frame)
        top.grid(row=0, column=0, sticky="ew", padx=4, pady=4)
        top.columnconfigure(2, weight=1)
        ttk.Label(top, text="Listen port:").grid(row=0, column=0)
        self.port = ttk.Entry(top, width=8)
        self.port.insert(0, "8888")
        self.port.grid(row=0, column=1)
        ttk.Label(top, text="Bind address:").grid(row=0, column=2, padx=(10, 0))
        self.bind_addr = ttk.Entry(top, width=15)
        self.bind_addr.insert(0, "127.0.0.1")
        self.bind_addr.grid(row=0, column=3)
        ttk.Label(top, text="(use 0.0.0.0 for external access)", foreground="#8b949e").grid(row=0, column=4, padx=4)
        self.start_btn = ttk.Button(top, text="Start Listener", command=self.start)
        self.start_btn.grid(row=0, column=5, sticky="w", padx=4)
        self.stop_btn = ttk.Button(top, text="Stop", command=self.stop)
        self.stop_btn.grid(row=0, column=6)
        ttk.Button(top, text="Clear", command=self.clear).grid(row=0, column=7)
        ttk.Button(top, text="Generate Payload", command=self.gen_payload).grid(row=0, column=8)

        info = ttk.Frame(self.main_frame)
        info.grid(row=1, column=0, sticky="ew", padx=4, pady=2)
        info.columnconfigure(0, weight=1)
        self.status = ttk.Label(info, text="Listener stopped")
        self.status.grid(row=0, column=0, sticky="w")
        self.callback = ttk.Entry(info)
        self.callback.grid(row=0, column=1, sticky="ew")
        self.callback.insert(0, "callback URL appears here")
        ttk.Button(info, text="Copy Headers", command=self.copy_headers).grid(row=0, column=2, padx=4)

        ttk.Label(info, text="Ollama Model:").grid(row=0, column=3, padx=(10, 0))
        self.model_cb = ttk.Combobox(info, width=22, state="readonly")
        self.model_cb.grid(row=0, column=4)
        self.model_cb.bind("<<ComboboxSelected>>",
                           lambda e: common.set_model(self.model_cb.get()))
        common.register_model_listener(self._on_model_change)
        self._refresh_models()

        self.out = scrolledtext.ScrolledText(self.main_frame, height=14)
        self.out.grid(row=3, column=0, sticky="nsew", padx=4, pady=4)
        self.out.config(state="disabled")


    def _host_ip(self):
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            return ip
        except Exception:
            return "127.0.0.1"
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass

    def start(self):
        if self._server:
            return
        try:
            port = int(self.port.get() or "8888")
        except (ValueError, TypeError):
            messagebox.showerror("Error", "Port must be a number.")
            return
        if not (1 <= port <= 65535):
            messagebox.showerror("Error", "Port must be between 1 and 65535.")
            return
        bind_addr = self.bind_addr.get().strip() or "127.0.0.1"
        try:
            srv = ThreadingHTTPServer((bind_addr, port), _Handler)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return
        srv.owner = self
        self._server = srv
        self._thread = threading.Thread(target=srv.serve_forever, daemon=True)
        self._thread.start()
        ip = self._host_ip()
        self.status.config(text=f"Listening on {bind_addr}:{port} (host {ip})")
        self._append(f"[*] OAST listener started on {bind_addr}:{port}\n")
        self.after(500, self._poll)

    def stop(self):
        if self._server:
            try:
                self._server.shutdown()
                self._server.server_close()
            except Exception:
                pass
            self._server = None
        self.status.config(text="Listener stopped")
        self._append("[*] Listener stopped\n")

    def clear(self):
        with self._incoming_lock:
            self._incoming.clear()
        self._shown = 0
        self.out.config(state="normal")
        self.out.delete("1.0", "end")
        self.out.config(state="disabled")

    def gen_payload(self):
        if not self._server:
            messagebox.showinfo("Start first", "Start the listener to generate a callback URL.")
            return
        try:
            port = int(self.port.get() or "8888")
        except (ValueError, TypeError):
            port = 8888
        cid = uuid.uuid4().hex[:12]
        host = self._host_ip()
        url = f"http://{host}:{port}/oob/{cid}"
        self.callback.delete(0, "end")
        self.callback.insert(0, url)
        self._append(f"[+] Generated OOB payload: {url}\n"
                     f"[+] Inject into blind SSRF / XSS / XXE exfil endpoints.\n")

    def copy_headers(self):
        url = self.callback.get().strip()
        if "callback URL appears" in url or not url.startswith("http"):
            messagebox.showinfo("Generate first", "Generate a payload to get a callback URL.")
            return
        headers = (f"X-Forwarded-For: {url}\n"
                   f"True-Client-IP: {url}\n"
                   f"X-Original-URL: {url}\n"
                   f"Referer: {url}\n")
        try:
            self.clipboard_clear()
            self.clipboard_append(headers)
        except tk.TclError:
            # No clipboard owner available (e.g. headless display); the headers
            # are still shown below so the user can copy them manually.
            pass
        self._append(f"[+] Collaborator-style headers copied to clipboard:\n{headers}\n")

    def _append(self, text):
        self.out.config(state="normal")
        self.out.insert("end", text)
        self.out.see("end")
        self.out.config(state="disabled")

    def _poll(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:
            return
        with self._incoming_lock:
            pending = list(self._incoming[self._shown:])
            self._shown = len(self._incoming)
        for rec in pending:
            self._append(f"\n>>> [{rec['client']}] {rec['method']} {rec['path']}\n")
            for k, v in rec["headers"].items():
                self._append(f"    {k}: {v}\n")
            if rec["body"]:
                self._append(f"    BODY: {rec['body'][:500]}\n")
            self._save_callback(rec)
        if self._server:
            try:
                if self.winfo_exists():
                    self.after(500, self._poll)
            except Exception:
                pass

    def _save_callback(self, rec):
        try:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            out_path = os.path.join(OUTPUT_DIR, "oast_callbacks.json")
            existing = []
            if os.path.isfile(out_path):
                raw = None
                try:
                    with open(out_path, "r", encoding="utf-8") as f:
                        raw = f.read()
                    existing = json.loads(raw)
                except (OSError, json.JSONDecodeError):
                    # Never wipe prior data: back up the raw file before we
                    # overwrite it so corrupted/old callbacks can be recovered.
                    if raw is not None:
                        try:
                            with open(out_path + ".bak", "w",
                                      encoding="utf-8") as fb:
                                fb.write(raw)
                        except Exception:
                            pass
                    existing = []
            rec_copy = {
                "timestamp": time.ctime(),
                "client": rec.get("client", ""),
                "method": rec.get("method", ""),
                "path": rec.get("path", ""),
                "headers": rec.get("headers", {}),
                "body": rec.get("body", "")[:2000],
            }
            existing.append(rec_copy)
            if len(existing) > 500:
                existing = existing[-500:]
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(existing, f, indent=2, ensure_ascii=False, default=str)
        except Exception:
            pass

    def _refresh_models(self):
        try:
            models = common.ollama_models()
            self.model_cb["values"] = models
            cur = common.SELECTED_MODEL
            if cur and cur in models:
                self.model_cb.set(cur)
            elif models:
                self.model_cb.set(models[0])
        except Exception:
            pass

    def _on_model_change(self, model):
        try:
            if not self.winfo_exists():
                return
            if model and self.model_cb["values"]:
                self.model_cb.set(model)
        except Exception:
            pass

    def destroy(self):
        self.stop()
        super().destroy()
