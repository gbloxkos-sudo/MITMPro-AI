# MITMPro — Full User Guide

**Version 1.1** · Unified AI-Assisted Security Assessment Platform

## 🚀 What's New in v1.1

- **Enterprise-Grade Reliability:** Implemented advanced thread-safety and concurrency management across all real-time monitoring and capture modules (e.g., Masquerading, OAST, Traffic Log), ensuring seamless, crash-free operation under high-load testing.
- **Smarter Phishing Engine:** Improved the Email Engineer with intelligent, port-aware TLS/SSL detection (e.g., port 465 vs. 587) for more reliable and realistic phishing simulations.
- **Enhanced Dependency Robustness:** Improved error handling and import guards for optional dependencies like `beautifulsoup4` in the Burp Tools scanner.


| Component      | Minimum                                  |
|----------------|------------------------------------------|
| OS             | Linux (primary), macOS, Windows 10+      |
| Python         | 3.10+ (developed on 3.11.9)              |
| RAM            | 4 GB (8 GB+ recommended for local models)|
| Disk           | 2 GB for app + models                    |
| Ollama         | Required for all AI features (local)     |
| Root/sudo      | Only for WebSploit network attacks       |
| Display        | Required (the app is a GUI)              |

### Python dependencies
`requests`, `scapy`, `netifaces`, `psutil`, `beautifulsoup4`, `lxml`,
`flask`, `urllib3` (all installed via `pip install -r requirements.txt`).
The AI GUI uses only the standard library + Tkinter.
The bundled `ollama-gui-1.2.2` provides the embedded chat client.

---

## 2. Installation & Launch

From the project root (`MITM_PRO_AI/`) run:

```bash
# Ensure Ollama is running with at least one model
ollama serve
ollama pull llama3.2:1b            # small/fast
ollama pull xploiter/pentester     # security-tuned (if available)

# Launch the unified application (either command works)
python3 run.py
# or:
python3 -m mitmpro.main
```

The window opens with a branded header, a global **Ollama Model** selector in the
toolbar, a left **module sidebar**, the active module in the centre, a persistent
**AI Help** dock on the right, and a live status bar at the bottom.

> If you already have a `venv`, activate it first. Dependencies can also be
> installed with `python3 -m pip install requests scapy netifaces psutil
> beautifulsoup4 lxml`.

---

## 3. Choosing the AI Model (full-system)

The toolbar **Ollama Model** dropdown is the single source of truth for the whole
app. Selecting a model there updates, in real time:

- the embedded **AI Assistant** chat,
- the **AI Helper** tab,
- the **AI Traffic Analyst** tab,
- the **WAF/Bypass → Explain with AI** action, and
- the persistent **AI Help** dock (visible on every module).

Click **Refresh Models** to re-read the list from the running Ollama service. The
status bar always shows the active model and Ollama health (green dot = running,
red = offline). You may also pick a model directly inside any AI panel; all stay
in sync via a shared model listener.

### The MITMPro-AI engine (self-healing, anti-hallucination, self-learning)
Every AI feature is powered by one local engine (`mitmpro/ai_core.py`):

- **One model selector drives the whole system.** The toolbar **Ollama Model**
  dropdown is the single source of truth. Pick any local model (e.g.
  `llama3.2:1b`, `xploiter/pentester`, `xploiter/bugbounty-ai`,
  `huihui_ai/qwen3-abliterated:4b`) and it instantly propagates to the embedded
  AI Assistant, AI Helper, AI Traffic Analyst, WAF/Bypass "Explain with AI", and
  the persistent AI Help dock — every panel stays in sync via a shared model
  listener. You can also pick a model directly inside any AI panel; all stay
  consistent.
- **Self-healing:** if the selected model is unavailable or Ollama hiccups, it
  retries and automatically falls back to any other local model. If Ollama is
  fully offline it returns a clear, grounded message instead of crashing.
- **Anti-hallucination / verified answers:** answers are grounded in the real
  MITMPro tool documentation supplied as context; the model is told to only
  describe tools that actually exist and to state confidence
  (High/Medium/Low). A verification pass flags any claim that references a
  non-existent tool. Real, verifiable answers are prioritised — when the
  operator enables **Internet** in the toolbar, the assistant can fetch live,
  externally-verified information and continue the answer with it.
- **Self-learning:** verified Q&A pairs are stored locally (`~/.mitmpro/memory.jsonl`)
  and reused, so repeated questions stay consistent.
- **Self-aware / full use of system:** the assistant is injected with a live
  **system context** describing your actual machine — OS, hardware, network
  interfaces, installed security tools (nmap, curl, mitmproxy, frida, sqlmap…),
  running Ollama models, current Scope, captured HTTP history, and the active
  module — so its advice matches what the system can really do.
- **RAG (Retrieval-Augmented Generation):** before answering, the engine
  retrieves the most relevant passages from the MITMPro documentation, the
  application source code, the user/sale guides, and the bundled tool READMEs,
  and grounds the answer in them (`mitmpro/rag.py`, offline BM25 index cached at
  `~/.mitmpro/rag_index.json`).
- **Internet research (opt-in):** the toolbar **Internet: OFF/ON** button enables
  live verification. When ON, the assistant may emit `<<WEB: <query>>` or
  `<<FETCH: <url>>`; the engine fetches the live result (web search or page
  fetch) and continues the answer with it. This is the only traffic that leaves
  the machine, and only on demand; AI inference always stays local.

---

## 4. Layout

```
+--------------------------------------------------------------+
| Header: MITMPro · v1.0 · Unified AI-Assisted ... Platform     |
+--------------------------------------------------------------+
| Toolbar: Ollama Model [v] Refresh Models  Ollama: RUNNING     |
+------------------+-----------------------------+--------------+
| MODULES (sidebar)|  Active module (centre)    | AI Help dock |
|  Dashboard        |                             | (always on)  |
|  AI Assistant     |                             |              |
|  AI Traffic ...   |                             |              |
|  Burp Tools       |                             |              |
|  WebSploit        |                             |              |
|  Proxy Tools      |                             |              |
|  WAF/Bypass       |                             |              |
|  AI Helper        |                             |              |
|  HTTP History     |                             |              |
|  OAST / DNS       |                             |              |
|  Macro / Flow     |                             |              |
|  Scope            |                             |              |
|  Analysis         |                             |              |
+------------------+-----------------------------+--------------+
| Status bar: ● Ollama status | module | model: <name>            |
+--------------------------------------------------------------+
```

### 4.1 Universal Copy / Paste & Right-Click Menu

Every editable and read-only text surface in MITMPro (chat panes, request/response
boxes, logs, console output, entries, comboboxes, listboxes, and result tables)
supports a right-click context menu with **Cut**, **Copy**, **Paste**, and
**Select All**. Read-only widgets show **Copy** / **Select All** only. Treeview
tables copy the selected row(s) as tab-separated values. Standard shortcuts also
work everywhere: `Ctrl+C` / `Ctrl+Insert` to copy (including from disabled log
panes), `Ctrl+X` to cut, and `Ctrl+V` to paste into editable fields.

---

## 5. Module Reference

### 5.1 Dashboard
Landing tab. Shows AI-engine health, quick-start buttons that jump to any module,
and beginner tips. Buttons: *Chat with AI*, *Scan a website*, *Analyze my traffic*,
*Bypass a WAF*, *Network tools*, *Ask the AI Helper*.

### 5.2 AI Assistant (Ollama)
Fully embedded Ollama chat client. Features:
- Auto-detects available Ollama models and shows them in the model box.
- Multi-turn chat with streaming responses and a Stop button.
- Right-click to copy a message; double-click a message to edit it.
- **Model Management** window (gear icon) to download/delete models from the
  running Ollama host.
- **Open Standalone Ollama GUI** launches the original single-file `ollama_gui.py`.

All responses come from your local model — no cloud, no telemetry.

### 5.3 AI Traffic Analyst
Paste a raw HTTP request (and optional response), pick an action
(*Explain request/response*, *Find vulnerabilities*, *Suggest exploit / bypass
payload*), and the local AI analyses it for OWASP Top 10 issues (SQLi, XSS, SSRF,
IDOR, access control, deserialization, XXE, SSTI, request smuggling) using the
exact lines/parameters. It proposes concrete, copy-paste-ready exploit or test
payloads and WAF/IDS evasion where relevant. Load a captured request directly from
**HTTP History → Send to AI Analyst**.

### 5.4 Burp Tools
- **Repeater:** build/send raw HTTP requests (method, URL, headers, body) and
  inspect the full response (status line, headers, byte count, body).
- **Intruder:** fuzzing/brute force. Mark injection points with `§name§`.
  *Sniper* (one payload across all markers) or *Cluster bomb* (cartesian product).
  Load wordlists. Results show `payload -> HTTP status (size)`.
- **Decoder:** Base64 / URL / HTML / Hex / ASCII-HEX encode & decode.
- **Comparer:** unified diff between two text blobs (Original / Modified).
- **Sequencer:** per-position + overall entropy analysis of session tokens.
- **Scanner:** light passive/active web checks for **Reflected XSS** and **SQL
  Injection** across discovered form/URL params. Issues live HTTP requests to the
  target you specify.

### 5.5 WebSploit
Live console into the WebSploit 4.0.4 toolkit.
- Pick a **Module** (`arp_spoof`, `http_sniffer`, `scan_network`, `scan_wifi`,
  `wifi_deauth`, `wifi_fap`, `wifi_fap_spam`).
- **Use & Launch** starts it in an interactive console (`help`, `options`,
  `set`, `run`). **Stop** terminates the process.
- Network modules require root and a real network interface.

### 5.6 Proxy Tools
Launches bundled MITM interception scripts in a console:
- **mitm_intercept.py** — SSL interception relay (TCP/UDP, mixed TLS). Example
  args: `-l 0.0.0.0:8080 -t 127.0.0.1:80 -lc cert.pem -lk key.pem`
- **DatajackProxy.py** — Frida-based MITM of a running process (Linux/Windows);
  requires `frida`/`frida-tools`.
- The **extra args** box is pre-filled with a template; click it to edit.

### 5.7 WAF/Bypass (Advanced WAF & Security Bypass Engine)
Generates a large set of **real** evasion variants for a payload:
- Choose a **Category**: SQLi, XSS, Path Traversal, Command Injection, SSRF.
- Enter a base **Payload** and press **Generate**.
- Produces encoding/obfuscation variants: URL (single/double/nested), HTML entity,
  Unicode, UTF-8 overlong, Base64, Hex, MySQL `CHAR()`, PostgreSQL `CHR()`,
  MSSQL `NCHAR()`, case randomization, inline comments (`/**/`, `/*!*/`, `--`, `#`,
  `;`), null-byte, plus category-specific tricks (e.g. `0x7f000001` for
  `127.0.0.1`, `....//` for `../`).
- **Test Bypass** sends each variant to the **Test URL** and flags responses whose
  status, size, or block-signature differ from the baseline as potential bypasses;
  it also sends spoofed headers (`X-Forwarded-For`, `X-Original-URL`, etc.).
- **Explain with AI** uses the active Ollama model to pick the best variant(s) for
  the observed WAF behaviour and explain why.
- **Save** writes the variant list for use in Intruder.

### 5.8 AI Helper
Context-aware assistant that knows the entire MITMPro feature set (full product
knowledge as a system prompt).
- **Context** selects the module (auto-filled by **Use Current Tab**).
- Ask how to use a tool, request payloads, or explain findings.
- **Assessment Checklist** generates a phased methodology (recon → enumeration →
  exploitation → validation → reporting) for the selected module.
- Uses the same global **Ollama Model** as the rest of the app.

### 5.9 HTTP History
Live log of every real HTTP request the suite sends (Repeater, Intruder, Scanner,
Macro). Columns: #, Method, Status, Host, Path, Size. Double-click to view the
full request/response. **Filter** by URL substring. **Send to Repeater** loads it
into Burp Repeater; **Send to AI Analyst** loads it into AI Traffic Analyst.
**Clear** empties the log.

### 5.10 OAST / DNS (Out-of-Band)
Starts a local HTTP listener (default port 8888) that captures out-of-band
callbacks — used to prove blind SSRF, Blind XSS, XXE exfiltration, etc.
- **Generate Payload** creates a callback URL using the machine's reachable LAN
  IP (so a target on the network can actually call back to you).
- **Copy Headers** copies collaborator-style headers (`X-Forwarded-For`,
  `True-Client-IP`, `X-Original-URL`, `Referer`) pre-filled with the callback URL
  for injection.

### 5.11 Macro / Flow
Builds multi-step request chains (e.g. login → fetch CSRF token → authenticated
action). Each step: Method, URL, optional **Extract regex** that captures a value
from the response into `{{extract}}` for later steps, and a Body. Save/Load
sequences as JSON. Runs real requests in order and substitutes `{{var}}`
placeholders.

### 5.12 Scope
Add hostnames you are authorized to test. When Scope is non-empty, tools should
stay inside it (empty scope = all targets allowed). Add/Remove from the list.

### 5.13 Analysis
On open, scans every project folder and reports:
- Presence, file count, Python file count, and size per folder.
- Dependency availability (`requests`, `scapy`, `netifaces`, `psutil`,
  `beautifulsoup4`, `lxml`, `tkinter`).
- Ollama service status and the list of running models.
Use this as a pre-engagement health check.

---

## 6. The AI Help Dock (on every feature)
The right-hand **AI Help** pane is always visible and knows which module is active.
Ask it how to use the current tool, or press **Assess** to generate a full
methodology for that module. It uses the same global model and the same
self-healing / anti-hallucination / self-learning engine as the other AI features.

---

## 7. Troubleshooting

| Symptom                          | Fix                                                      |
|----------------------------------|----------------------------------------------------------|
| AI says "Ollama: OFFLINE"        | Start `ollama serve` in a terminal; click Refresh Models |
| No models in dropdown            | `ollama pull llama3.2:1b` then Refresh Models           |
| AI tab shows red error           | Ensure `ollama-gui-1.2.2/ollama_gui.py` exists          |
| WebSploit won't start            | Run the app with `sudo` for network modules; needs iface|
| Proxy tool arg errors            | Click the args box and enter real arguments             |
| `ImportError: No module named X` | `pip install X` (see Requirements)                      |

---

## 8. Legal & Responsible Use
MITMPro is built for **authorized security testing** — penetration tests, bug
bounty programs, and red-team engagements on systems you own or have written
permission to test. Always obey applicable law and scope agreements.
